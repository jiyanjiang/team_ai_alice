#!/usr/bin/env python3
"""TAA upgrade: staging + protected data + atomic swap + rollback.

This script is intentionally self-contained (stdlib only). It is called by the
package install.sh only when an existing install is detected. A fresh install
continues to use the normal install path.

Phases:
  preflight -> backup -> stop -> migrate-events -> stage -> swap -> start
  -> verify -> commit
Any failure after stop restores the previous app and database backups.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _version_key(v: str):
    """把 `x.y.z[-pre]` 转成可比较元组；同号时正式版 > 预发布。

    返回 None 表示版本串非法（调用方应视为不可比较，不阻断）。
    """
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.\-]+))?$", (v or "").strip())
    if not m:
        return None
    major, minor, patch = int(m.group(1)), int(m.group(2)), int(m.group(3))
    pre = m.group(4)
    if pre is None:
        return (major, minor, patch, 1, ())
    parts = tuple((0, int(s)) if s.isdigit() else (1, s) for s in re.split(r"[.\-]", pre))
    return (major, minor, patch, 0, parts)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_file(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, symlinks=True)


_REQ_CHECK = r'''
import importlib.metadata as md
import re
import sys


def key(v):
    parts = re.split(r"[.\-+_]", str(v).strip())
    return tuple((0, int(p)) if p.isdigit() else (1, p) for p in parts if p != "")


def cmp(have, op, want):
    a, b = key(have), key(want)
    if op == "==":
        return a == b
    if op == "!=":
        return a != b
    if op == ">=":
        return a >= b
    if op == "<=":
        return a <= b
    if op == ">":
        return a > b
    if op == "<":
        return a < b
    if op == "~=":                     # 近似：只保证 >=（下界），足够做"要不要装"
        return a >= b
    return True


path = sys.argv[1]
bad = []
n = 0
for raw in open(path, encoding="utf-8"):
    line = raw.split("#", 1)[0].strip()
    if not line or line.startswith("-"):
        continue
    m = re.match(r"^([A-Za-z0-9_.\-]+)\s*(.*)$", line)
    if not m:
        continue
    name, spec = m.group(1), m.group(2).strip()
    if not spec:
        continue                   # 目录式/无版本约束的行不计入统计
    n += 1
    try:
        have = md.version(name)
    except md.PackageNotFoundError:
        bad.append(name + " (missing)")
        continue
    for part in spec.split(","):
        mm = re.match(r"^(==|>=|<=|!=|~=|>|<)\s*(.+)$", part.strip())
        if not mm:
            continue
        if not cmp(have, mm.group(1), mm.group(2).strip()):
            bad.append("%s %s%s (have %s)" % (name, mm.group(1), mm.group(2), have))

if bad:
    print("; ".join(bad))
    sys.exit(3)
print("%d ok" % n)
'''


def sqlite_backup(src: Path, dst: Path) -> None:
    """Consistent SQLite copy (includes WAL). Caller must stop writers."""
    if not src.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    with contextlib.closing(sqlite3.connect(str(src))) as s:
        with contextlib.closing(sqlite3.connect(str(dst))) as d:
            s.backup(d)


def sqlite_integrity(path: Path) -> str:
    if not path.exists():
        return "missing"
    with contextlib.closing(sqlite3.connect(str(path))) as c:
        row = c.execute("PRAGMA integrity_check").fetchone()
        return str(row[0] if row else "unknown")


def port_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def wait_port_free(port: int, timeout: float = 20.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if not port_open(port):
            return True
        time.sleep(0.25)
    return False


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """探针不跟随重定向，只认首跳状态码。

    2026-11-02 升级误回滚的根因：verify 探 /setup/，urllib 默认自动跟随
    302 -> /app/bridge -> /app/chats（108KB 主聊天页）。冷启动首次渲染约 3s，
    正好撞上 timeout=3 被读成"无响应"，把一次完全健康的升级判死。
    探针只该回答"这条路由还在不在"，不该顺带把整个首页渲染一遍。
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_PROBE_OPENER = urllib.request.build_opener(_NoRedirect())


def health(port: int, timeout: float = 5.0) -> bool:
    try:
        with _PROBE_OPENER.open(f"http://127.0.0.1:{port}/v1/health", timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def http_status(port: int, path: str, timeout: float = 10.0) -> int:
    """取一次 HTTP 状态码（不跟随重定向）；连不上/超时返回 0。"""
    try:
        with _PROBE_OPENER.open(f"http://127.0.0.1:{port}{path}", timeout=timeout) as r:
            return int(r.status)
    except urllib.error.HTTPError as exc:
        return int(exc.code)
    except Exception:
        return 0


def probe_status(port: int, path: str, attempts: int = 3,
                 timeout: float = 10.0, gap: float = 2.0) -> int:
    """关键路由探活：0（无响应）可能是冷启动慢，重试后再判，避免误杀。"""
    code = 0
    for i in range(max(1, attempts)):
        code = http_status(port, path, timeout=timeout)
        if code:
            return code
        if i + 1 < attempts:
            time.sleep(gap)
    return code


def run(cmd: list[str], *, env: dict[str, str], timeout: int = 60) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, env=env, text=True, capture_output=True, timeout=timeout)


class UpgradeError(RuntimeError):
    pass


class Upgrade:
    def __init__(self, source: Path, home: Path, port: int, python: str,
                 no_open: bool = True, dry_run: bool = False):
        self.source = source.resolve()
        self.home = home.expanduser().resolve()
        self.port = int(port)
        self.python = python
        self.no_open = no_open
        self.dry_run = dry_run
        self.app = self.home / "app"
        self.stamp = now_stamp()
        self.new_app = self.home / f"app.new.{self.stamp}"
        self.prev_app = self.home / f"app.prev.{self.stamp}"
        self.failed_app = self.home / f"app.failed.{self.stamp}"
        self.backup = self.home / "backups" / f"upgrade-{self.stamp}"
        self.journal = self.home / "upgrade.state.json"
        self.swapped = False
        self.stopped = False
        self.old_events = self.app / "events.db"
        self.home_events = self.home / "events.db"
        # 老装可能从未写过事件（装了 + claim 了但没实际用过），此时没有 events.db
        # 是正常状态；verify 不能因此判定升级失败，否则会无谓回滚。
        self.had_events = self.old_events.exists() or self.home_events.exists()
        # 失败留证：journal 每阶段互相覆盖，事后只剩 ROLLED_BACK，
        # 上次（2026-11-02）只能去 275MB 的 web.log 里拼时间线。
        self.phase = ""
        self.fail_log = self.home / f"upgrade.failed.{self.stamp}.log"

    # ---------- journal ----------
    def say(self, msg: str) -> None:
        print(f"[upgrade]{'[dry-run]' if self.dry_run else ''} {msg}")

    def describe_plan(self) -> None:
        """演练模式：只描述将要发生的动作，绝不 stop / 移动 / 覆盖任何文件。"""
        cur = ""
        if (self.app / "VERSION").exists():
            cur = (self.app / "VERSION").read_text(encoding="utf-8").strip()
        new = ""
        if (self.source / "VERSION").exists():
            new = (self.source / "VERSION").read_text(encoding="utf-8").strip()
        self.say(f"当前版本={cur or '未知'}  目标版本={new or '未知'}")
        self.say(f"home={self.home}")
        self.say(f"port={self.port}")
        self.say(f"app  {self.app}  ->  {self.prev_app.name}（旧版留档）")
        self.say(f"new  {self.new_app.name}  ->  {self.app}（原子替换）")
        self.say("计划动作：STOP -> BACKUP -> STAGE -> DEPS(依赖已满足则跳过) -> SWAP -> START -> VERIFY")
        self.say("保留数据：identity.json / agents/ / data.db* / events.db / "
                 "config.toml / static/uploads/ / backups/")
        self.say("演练结束：未停止服务、未改动任何文件")

    def set_phase(self, phase: str, **extra) -> None:
        self.phase = phase
        if self.dry_run:
            self.say(f"phase={phase}")
            return
        data = {
            "phase": phase,
            "source": str(self.source),
            "home": str(self.home),
            "app": str(self.app),
            "prev_app": str(self.prev_app),
            "backup": str(self.backup),
            "timestamp": now_stamp(),
            **extra,
        }
        tmp = self.journal.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.journal)
        print(f"[upgrade] phase={phase}")

    def record_failure(self, exc: BaseException) -> None:
        """把失败现场落成独立文件：阶段 + 异常 + 完整栈。

        journal 只保留最后一个 phase，rollback 后连"死在哪个断言"都查不到；
        这份日志是 upgrade 失败后第一手证据，比翻 web.log 靠谱。
        """
        lines = [
            f"phase={self.phase or 'UNKNOWN'}",
            f"time={now_stamp()}",
            f"source={self.source}",
            f"home={self.home}",
            f"app={self.app}",
            f"exception={type(exc).__name__}: {exc}",
            "",
            traceback.format_exc(),
        ]
        try:
            self.fail_log.write_text("\n".join(lines) + "\n", encoding="utf-8")
            print(f"[upgrade] 失败详情：{self.fail_log}", file=sys.stderr)
        except Exception as again:                                # noqa: BLE001
            print(f"[upgrade] 失败日志写入失败：{again}", file=sys.stderr)

    # ---------- service ----------
    def stop(self) -> None:
        self.stopped = True
        env = dict(os.environ, TAA_HOME=str(self.home), TAA_HTTP_PORT=str(self.port),
                   TAA_PYTHON=self.python)
        launcher = self.app / "taa"
        if launcher.exists():
            try:
                run([str(launcher), "stop"], env=env, timeout=20)
            except Exception as exc:
                print(f"[upgrade] stop command warning: {exc}")
        if not wait_port_free(self.port):
            raise UpgradeError(f"port {self.port} still in use after stop")
        print("[upgrade] old service stopped")

    def start(self, app: Path) -> bool:
        env = dict(os.environ, TAA_HOME=str(self.home), TAA_HTTP_PORT=str(self.port),
                   TAA_PYTHON=self.python)
        launcher = app / "taa"
        cmd = [str(launcher), "start", "--no-open"] if self.no_open else [str(launcher), "start"]
        try:
            # 启动器内部 wait_ready 最长等 30s；这里必须比它长，否则会被
            # subprocess 超时先杀掉（nohup 的子进程仍然活着，但输出全丢）。
            proc = subprocess.run(cmd, env=env, cwd=str(app), text=True,
                                  capture_output=True, timeout=45)
            if proc.returncode != 0:
                print(proc.stdout[-3000:])
                print(proc.stderr[-3000:], file=sys.stderr)
        except Exception as exc:
            print(f"[upgrade] start warning: {exc}", file=sys.stderr)
        end = time.time() + 60
        while time.time() < end:
            if health(self.port, timeout=2.0):
                print("[upgrade] health OK")
                return True
            time.sleep(0.35)
        return False

    def stop_new(self) -> None:
        env = dict(os.environ, TAA_HOME=str(self.home), TAA_HTTP_PORT=str(self.port),
                   TAA_PYTHON=self.python)
        launcher = self.app / "taa"
        if launcher.exists():
            try:
                run([str(launcher), "stop"], env=env, timeout=20)
            except Exception:
                pass
        wait_port_free(self.port, timeout=10)

    # ---------- backup ----------
    def make_backup(self) -> None:
        self.backup.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.backup, 0o700)
        except OSError:
            pass
        copy_file(self.home / "identity.json", self.backup / "identity.json")
        copy_tree(self.home / "agents", self.backup / "agents")
        copy_tree(self.home / "bootstrap", self.backup / "bootstrap")
        copy_file(self.home / "config.toml", self.backup / "config.toml")
        sqlite_backup(self.home / "data.db", self.backup / "data.db")
        sqlite_backup(self.old_events, self.backup / "events.db")
        if self.home_events.exists():
            sqlite_backup(self.home_events, self.backup / "events.home.db")
        copy_tree(self.app / "data", self.backup / "app-data")
        copy_file(self.app / ".share_secret", self.backup / ".share_secret")
        # uploads can be large; record them, but allow a full copy via env.
        uploads = self.home / "static" / "uploads"
        if os.environ.get("TAA_UPGRADE_SKIP_UPLOADS") != "1":
            copy_tree(uploads, self.backup / "uploads")
        entries = {}
        for p in self.backup.rglob("*"):
            if p.is_file():
                entries[p.relative_to(self.backup).as_posix()] = sha256_file(p)
        (self.backup / "checksums.json").write_text(
            json.dumps(entries, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"[upgrade] backup -> {self.backup}")

    # ---------- staging ----------
    def stage(self) -> None:
        if self.new_app.exists():
            shutil.rmtree(self.new_app)
        shutil.copytree(self.source, self.new_app, symlinks=True)
        # Preserve runtime state that lived under old app.
        if self.old_events.exists():
            sqlite_backup(self.old_events, self.new_app / "events.db")
        copy_tree(self.app / "data", self.new_app / "data")
        # Host share links must survive an upgrade; otherwise every Client
        # invite becomes invalid after the Host updates.
        copy_file(self.app / ".share_secret", self.new_app / ".share_secret")
        # Data symlinks are the only live links in the app tree.
        for rel, target in (("agents", self.home / "agents"),
                            ("bootstrap", self.home / "bootstrap"),
                            ("static/uploads", self.home / "static" / "uploads")):
            target.mkdir(parents=True, exist_ok=True)
            link = self.new_app / rel
            if link.is_symlink() or link.exists():
                if link.is_dir() and not link.is_symlink():
                    shutil.rmtree(link)
                else:
                    link.unlink()
            link.parent.mkdir(parents=True, exist_ok=True)
            link.symlink_to(target)
        # Move the event log to the stable home path for new launchers.
        if not self.home_events.exists():
            sqlite_backup(self.old_events, self.home_events)
        print("[upgrade] staged app.new")

    # ---------- 依赖 ----------
    def install_deps(self) -> None:
        """把新包声明的依赖装进**现有** venv：升级路径以前完全不跑 pip。

        为什么必须做（2026-10-31 复盘）：beta.35 → 1.0.0 之所以没炸，纯粹是两版
        依赖集合恰好相同。一旦新版本新增依赖，升级后新服务会因 ModuleNotFoundError
        起不来，只能靠回滚兜底——那不是升级，是赌博。

        顺序刻意放在 STAGE 之后、SWAP 之前：此时旧服务已 STOP（venv 无人使用），
        装失败就直接中止，旧 app 目录原封不动，rollback 只负责把服务重新拉起来。
        依赖已满足时不联网、不调用 pip（离线升级仍可用）。
        """
        if os.environ.get("TAA_UPGRADE_SKIP_DEPS") == "1":
            print("[upgrade] TAA_UPGRADE_SKIP_DEPS=1，跳过依赖安装")
            return
        req = self.new_app / "requirements-core.txt"
        if not req.exists():
            req = self.new_app / "requirements.txt"
        if not req.exists():
            print("[upgrade] 新包无 requirements 文件，跳过依赖安装")
            return
        env = dict(os.environ, PIP_DISABLE_PIP_VERSION_CHECK="1")
        try:
            chk = subprocess.run([self.python, "-c", _REQ_CHECK, str(req)],
                                 capture_output=True, text=True, timeout=120, env=env)
        except Exception as exc:                                  # noqa: BLE001
            raise UpgradeError(f"依赖自检无法执行（{type(exc).__name__}）：{exc}")
        if chk.returncode == 0:
            print(f"[upgrade] 依赖已满足（{chk.stdout.strip() or 'ok'}），跳过 pip")
            return
        if chk.returncode != 3:
            print(f"[upgrade] 依赖自检异常 rc={chk.returncode}："
                  f"{(chk.stderr or '').strip()[:200]}；转直接安装")
        else:
            print(f"[upgrade] 依赖需更新：{chk.stdout.strip()[:300]}")
        try:
            r = subprocess.run([self.python, "-m", "pip", "install", "-r", str(req),
                                "--no-input", "--disable-pip-version-check"],
                               capture_output=True, text=True, timeout=600, env=env)
        except Exception as exc:                                  # noqa: BLE001
            raise UpgradeError(f"依赖安装无法执行（{type(exc).__name__}）：{exc}")
        if r.returncode != 0:
            tail = (r.stderr or r.stdout or "").strip().splitlines()[-3:]
            raise UpgradeError("依赖安装失败：" + " | ".join(tail))
        print("[upgrade] 依赖安装完成")
        self._install_render_deps(env)

    def _install_render_deps(self, env: dict) -> None:
        """渲染栈（playwright + chromium）**best-effort**：失败只告警，不中止升级。

        论证图/穿搭图首选浏览器渲染；缺 chromium 时降级 pillow + 系统中文字体
        （core/fonts.py），中文仍正常。故这里绝不能 raise。
        """
        if os.environ.get("TAA_UPGRADE_SKIP_DEPS") == "1":
            return
        req = self.new_app / "requirements-render.txt"
        try:
            if req.exists():
                p = subprocess.run([self.python, "-m", "pip", "install", "-r", str(req),
                                    "--no-input", "--disable-pip-version-check"],
                                   capture_output=True, text=True, timeout=600, env=env)
                if p.returncode != 0:
                    print("[upgrade] playwright 未装成：论证图将走 pillow 兜底（中文正常）")
                    return
            code = ("import sys; sys.path.insert(0, %r);"
                    "from core import deps; print(deps.ensure_chromium(quiet=True))") % str(self.new_app)
            c = subprocess.run([self.python, "-c", code],
                               capture_output=True, text=True, timeout=900, env=env)
            ok = '"ok": True' in (c.stdout or "")
            print(f"[upgrade] chromium {'就绪' if ok else '未就绪（降级 pillow+中文字体）'}")
        except Exception as exc:                                  # noqa: BLE001
            print(f"[upgrade] 渲染依赖安装跳过（{type(exc).__name__}: {exc}）")

    # ---------- verify ----------
    def verify(self) -> None:
        if not health(self.port):
            raise UpgradeError("new service unhealthy")
        if not (self.home / "identity.json").exists():
            raise UpgradeError("identity.json missing after upgrade")
        if not (self.home / "data.db").exists():
            raise UpgradeError("data.db missing after upgrade")
        ver = (self.app / "VERSION").read_text(encoding="utf-8").strip() if (self.app / "VERSION").exists() else ""
        if not ver:
            raise UpgradeError("new app VERSION missing")
        dbi = sqlite_integrity(self.home / "data.db")
        if dbi != "ok":
            raise UpgradeError(f"data.db integrity={dbi}")
        ev = self.home_events if self.home_events.exists() else (self.app / "events.db")
        if ev.exists():
            evi = sqlite_integrity(ev)
            if evi != "ok":
                raise UpgradeError(f"events.db integrity={evi}")
        elif self.had_events:
            raise UpgradeError("events.db missing after upgrade")
        else:
            # 老装本来就没有事件库（从未写入事件）：跳过校验，绝不为了满足断言去造空文件。
            print("[upgrade] 老装无 events.db（从未写入事件），跳过事件库校验")
        # 身份模块必须在包里（2026-10-31 事故：包内 taa_node_v05 为空目录，
        # 装完 /setup 直接 404，用户无法登录/claim；health 却仍是 200）。
        missing_id = [n for n in ("taa_node_v05/web.py", "taa_node_v05/center.py",
                                  "taa_node_v05/identity.py", "taa_node_v05/claim_ui.py")
                      if not (self.app / n).is_file()]
        if missing_id:
            raise UpgradeError(f"身份模块缺失（登录/claim 会失效）：{', '.join(missing_id)}")
        # 探针只认首跳（302 是正常的"已连接→跳本地 app"），无响应要重试：
        # 冷启动首次渲染慢并不等于登录链路断裂。
        setup_code = probe_status(self.port, "/setup/")
        if setup_code not in (200, 302):
            raise UpgradeError(f"/setup/ 不可用（HTTP {setup_code or '无响应'}）：登录/claim 链路断裂")
        # agents 计数只为日志留痕，绝不参与判定：这是升级成功前的最后一步，
        # 任何读失败（busy/locked）都不该把一次健康升级推进回滚。
        agents: object = "unknown"
        try:
            with contextlib.closing(sqlite3.connect(str(self.home / "data.db"))) as c:
                agents = c.execute("SELECT COUNT(*) FROM agents").fetchone()[0]
        except Exception as exc:                                  # noqa: BLE001
            print(f"[upgrade] agents 计数读取失败（不影响判定）：{exc}", file=sys.stderr)
        print(f"[upgrade] verified version={ver} agents={agents} setup=HTTP{setup_code}")

    # ---------- rollback ----------
    def rollback(self, *, failed_phase: str = "", error: str = "") -> None:
        print("[upgrade] ROLLBACK")
        self.stop_new()
        if self.swapped and self.prev_app.exists():
            if self.app.exists():
                os.replace(self.app, self.failed_app)
            os.replace(self.prev_app, self.app)
        # Restore only DB/event data that may have been migrated.
        if (self.backup / "data.db").exists():
            sqlite_backup(self.backup / "data.db", self.home / "data.db")
        if (self.backup / "events.db").exists():
            sqlite_backup(self.backup / "events.db", self.app / "events.db")
        if (self.backup / "events.home.db").exists():
            sqlite_backup(self.backup / "events.home.db", self.home / "events.db")
        elif self.home_events.exists() and not (self.backup / "events.home.db").exists():
            # Old app may not understand home events; leave it, old app uses app/events.db.
            pass
        try:
            self.start(self.app)
        except Exception as exc:
            print(f"[upgrade] old restart failed: {exc}", file=sys.stderr)
        self.set_phase("ROLLED_BACK", failed_app=str(self.failed_app),
                       failed_phase=failed_phase, error=error)

    def check_version_gate(self) -> None:
        """校验当前安装版本不低于包声明的最低可升级版本。

        历史问题：`upgrade-manifest.json` 写了 `min_upgrade_from`，但升级脚本
        从未读取它 —— 等于所有版本无条件放行，是个装饰字段。此处补上真校验。
        """
        cur_file = self.app / "VERSION"
        cur_v = cur_file.read_text(encoding="utf-8").strip() if cur_file.exists() else ""
        um = self.source / "upgrade-manifest.json"
        if not um.exists():
            return
        try:
            raw = json.loads(um.read_text(encoding="utf-8")).get("min_upgrade_from") or ""
        except Exception:                                        # noqa: BLE001
            return
        if isinstance(raw, list):
            pairs = [(_version_key(x), x) for x in raw if _version_key(x)]
            raw = min(pairs)[1] if pairs else ""
        if not raw or not cur_v:
            return
        cur_key, min_key = _version_key(cur_v), _version_key(raw)
        if cur_key and min_key and cur_key < min_key:
            raise UpgradeError(
                f"当前版本 {cur_v} 低于可升级下限 {raw}；请用完整安装包重装，不要走升级")

    def _dry_run(self) -> int:
        """演练入口：走完 PREFLIGHT（含版本门槛），不建目录、不写锁、不动服务。"""
        self.set_phase("PREFLIGHT")
        if not (self.home / "identity.json").exists():
            print("no existing identity; use fresh installer", file=sys.stderr)
            return 2
        if not (self.source / "VERSION").exists():
            raise UpgradeError("package VERSION missing")
        if not self.app.exists():
            raise UpgradeError("existing app missing")
        try:
            self.check_version_gate()
        except UpgradeError as exc:
            print(f"[upgrade][dry-run] FAILED: {exc}", file=sys.stderr)
            return 1
        self.describe_plan()
        return 0

    def run(self) -> int:
        if self.dry_run:
            return self._dry_run()
        self.home.mkdir(parents=True, exist_ok=True)
        lock_path = self.home / ".upgrade.lock"
        with lock_path.open("w") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                print("upgrade already running", file=sys.stderr)
                return 3
            try:
                # 这三个前置条件不算"一次升级尝试"：不写 journal，保持零改动，
                # 由 install.sh 走全新安装路径。
                if not (self.home / "identity.json").exists():
                    print("no existing identity; use fresh installer", file=sys.stderr)
                    return 2
                if not (self.source / "VERSION").exists():
                    raise UpgradeError("package VERSION missing")
                if not self.app.exists():
                    raise UpgradeError("existing app missing")
                self.set_phase("PREFLIGHT")
                # G4：门槛必须真校验，否则等于没有
                self.check_version_gate()
                self.set_phase("STOP")
                self.stop()
                self.set_phase("BACKUP")
                self.make_backup()
                self.set_phase("STAGE")
                self.stage()
                self.set_phase("DEPS")
                self.install_deps()
                self.set_phase("SWAP")
                os.replace(self.app, self.prev_app)
                os.replace(self.new_app, self.app)
                self.swapped = True
                self.set_phase("START")
                if not self.start(self.app):
                    raise UpgradeError("new service did not become healthy")
                if os.environ.get("TAA_UPGRADE_FORCE_FAIL") == "verify":
                    raise UpgradeError("forced verify failure for rollback test")
                self.verify()
                self.set_phase("COMMITTED")
                print(f"[upgrade] committed; previous={self.prev_app}")
                return 0
            except Exception as exc:
                print(f"[upgrade] FAILED: {exc}", file=sys.stderr)
                self.record_failure(exc)
                if not self.stopped and not self.swapped:
                    # PREFLIGHT 阶段就被拒（版本门槛 / 包缺失）：服务没停、目录没换，
                    # 没有任何东西需要回滚。此前的实现会照走 rollback()，去 start 一个
                    # 还在原地的 app（甚至是不存在的 app），纯噪声。
                    print("[upgrade] 未进入 STOP 阶段，无需回滚")
                    return 1
                try:
                    self.rollback(failed_phase=self.phase,
                                  error=f"{type(exc).__name__}: {exc}")
                except Exception as rb:
                    print(f"[upgrade] rollback error: {rb}", file=sys.stderr)
                return 1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--port", type=int, default=6080)
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--dry-run", action="store_true",
                    help="只演练：校验门槛并打印计划，不停止服务、不改动任何文件")
    a = ap.parse_args()
    return Upgrade(Path(a.source), Path(a.home), a.port, a.python,
                   a.no_open, dry_run=a.dry_run).run()


if __name__ == "__main__":
    raise SystemExit(main())
