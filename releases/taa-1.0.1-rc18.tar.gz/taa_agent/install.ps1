# TAA 安装器薄壳（Windows / PowerShell）—— 2026-11-08 新增。
#
# 与 install.sh 完全对等：只负责找一个 >=3.11 的解释器，把参数转交 bootstrap.py。
# 安装逻辑只有一份（bootstrap.py），所以 Windows 与 macOS/Linux 不会各演化一套。
#
# 用法（PowerShell）：
#   irm https://<center>/install.ps1 | iex        # 中心提供后
#   .\install.ps1 --center https://<center> --ref <name>
#   或直接：py -3 bootstrap.py

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$boot = Join-Path $root "bootstrap.py"
if (-not (Test-Path $boot)) { $boot = Join-Path $root "scripts\taa_bootstrap.py" }
if (-not (Test-Path $boot)) {
  Write-Error "包里没有 bootstrap.py（包不完整）：$root"
  exit 2
}

function Test-Py([string]$exe) {
  try {
    & $exe -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
  } catch { return $false }
}

# 1) 显式指定
if ($env:TAA_PYTHON -and (Test-Py $env:TAA_PYTHON)) {
  & $env:TAA_PYTHON $boot @args
  exit $LASTEXITCODE
}

# 2) py launcher（PEP 397，Windows 官方安装器默认带）
foreach ($v in @("3.13", "3.12", "3.11")) {
  try {
    & py "-$v" -c "import sys" 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
      & py "-$v" $boot @args
      exit $LASTEXITCODE
    }
  } catch { }
}
try {
  & py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null | Out-Null
  if ($LASTEXITCODE -eq 0) {
    & py -3 $boot @args
    exit $LASTEXITCODE
  }
} catch { }

# 3) PATH 上的 python
if (Test-Py "python") {
  & python $boot @args
  exit $LASTEXITCODE
}

# 4) uv 兜底（自带 Python 下载）
if (Get-Command uv -ErrorAction SilentlyContinue) {
  & uv run --python 3.12 $boot @args
  exit $LASTEXITCODE
}

Write-Host @"
x 需要 Python 3.11+
  winget install Python.Python.3.12
  或安装 uv（单文件、无需管理员）：winget install astral-sh.uv
  装好后重开 PowerShell 再跑；也可以用 TAA_PYTHON 指定解释器路径。
"@ -ForegroundColor Yellow
exit 3
