"""TAA Node identity: center Owner + local Node/Agent only.

The Owner is created and authenticated by the center. A local machine stores
only its Node and Agent keys, plus the center binding. There is intentionally
no local Owner account and no local Owner password.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import pathlib
import platform
import secrets
import socket
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

from .crypto import generate_keypair
from .names import random_name, unique_name

SCHEMA_VERSION = 2
IDENTITY_FILE = "identity.json"
REF_FILE = "ref.txt"

OWNER_PREFIX = "own_"
NODE_PREFIX = "nod_"
AGENT_PREFIX = "agt_"
NODE_KEY_PREFIX = "nk_"
AGENT_KEY_PREFIX = "ak_"


def normalize_ref(value: str) -> str:
    """推荐码（中心 public_id）：只留小写字母/数字/_-，长度 ≤64。"""
    raw = str(value or "").strip().lower()
    return "".join(ch for ch in raw if ch.isalnum() or ch in "_-")[:64]


def install_ref(home: pathlib.Path) -> str:
    """安装器 `--ref` 落下的推荐码（注册时带上，中心据此直接建好友）。

    读取顺序：`$TAA_REF` → `<home>/ref.txt`。都没有就返回空串。
    """
    env = normalize_ref(os.environ.get("TAA_REF", ""))
    if env:
        return env
    try:
        return normalize_ref((pathlib.Path(home).expanduser() / REF_FILE).read_text(encoding="utf-8"))
    except OSError:
        return ""


def save_install_ref(home: pathlib.Path, value: str) -> str:
    """把推荐码写进 `<home>/ref.txt`；返回归一后的值（空值不写）。"""
    ref = normalize_ref(value)
    if not ref:
        return ""
    home = pathlib.Path(home).expanduser()
    home.mkdir(parents=True, exist_ok=True)
    (home / REF_FILE).write_text(ref + "\n", encoding="utf-8")
    return ref


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_id(prefix: str) -> str:
    return prefix + secrets.token_hex(8)


def new_key(prefix: str) -> str:
    return prefix + secrets.token_urlsafe(32)


def default_alias() -> str:
    host = socket.gethostname().split(".")[0].strip()
    if host:
        return host[:40]
    return f"{platform.system() or 'TAA'}-node"[:40]


def _machine_id() -> str:
    if platform.system() == "Darwin":
        return platform.mac_ver()[0] or ""
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            value = pathlib.Path(path).read_text(encoding="utf-8").strip()
            if value:
                return value
        except OSError:
            pass
    return ""


def machine_fingerprint() -> str:
    """Return a local fingerprint string; callers must not persist it raw."""
    parts = [
        platform.system(),
        platform.release(),
        platform.machine(),
        _machine_id(),
        socket.gethostname(),
        platform.processor(),
    ]
    return "|".join(parts)


def fingerprint_hash(salt_hex: str | None = None) -> tuple[str, str]:
    """Return (hmac_sha256_hex, salt_hex). Raw fingerprint is never returned."""
    salt = salt_hex or secrets.token_hex(16)
    digest = hmac.new(
        bytes.fromhex(salt),
        machine_fingerprint().encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return digest, salt


@dataclass
class Node:
    node_id: str
    alias: str
    node_key: str
    fingerprint_hash: str
    fingerprint_salt: str
    status: str = "pending_owner"
    enc_pubkey: str = ""
    enc_privkey: str = ""
    created_at: str = field(default_factory=now_iso)


@dataclass
class Agent:
    agent_id: str
    node_id: str
    display_name: str
    agent_key: str
    status: str = "active"
    created_at: str = field(default_factory=now_iso)


@dataclass
class CenterBinding:
    base: str = ""
    owner_id: str = ""
    username: str = ""
    email: str = ""
    claimed_at: str = ""


@dataclass
class IdentityState:
    node: Node
    agents: list[Agent] = field(default_factory=list)
    center: CenterBinding = field(default_factory=CenterBinding)
    schema_version: int = SCHEMA_VERSION

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "node": asdict(self.node),
            "agents": [asdict(agent) for agent in self.agents],
            "center": asdict(self.center),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IdentityState":
        version = int(data.get("schema_version") or 0)
        if version not in (1, SCHEMA_VERSION):
            raise ValueError("unsupported identity schema")
        try:
            node_raw = dict(data["node"])
            node_raw.pop("owner_id", None)
            node = Node(**node_raw)
            agents = [Agent(**item) for item in data.get("agents") or []]
            center_raw = dict(data.get("center") or {})
            if version == 1:
                old_owner = data.get("owner") or {}
                center_raw.setdefault("username", old_owner.get("username") or "")
                center_raw.setdefault("email", old_owner.get("email") or "")
            center = CenterBinding(**center_raw)
        except (KeyError, TypeError) as exc:
            raise ValueError(f"invalid identity data: {exc}") from exc
        _validate(node, agents, center)
        return cls(node=node, agents=agents, center=center)

    def agent_by_id(self, agent_id: str) -> Agent | None:
        return next((agent for agent in self.agents if agent.agent_id == agent_id), None)


@dataclass
class InitResult:
    state: IdentityState
    temporary_password: str = ""
    generated_password: bool = False


def _validate(node: Node, agents: list[Agent], center: CenterBinding | None = None) -> None:
    if not node.node_id.startswith(NODE_PREFIX):
        raise ValueError("invalid node id")
    if not node.node_key.startswith(NODE_KEY_PREFIX):
        raise ValueError("invalid node key")
    if center and center.owner_id and not center.owner_id.startswith(OWNER_PREFIX):
        raise ValueError("invalid center owner id")
    ids = set()
    for agent in agents:
        if not agent.agent_id.startswith(AGENT_PREFIX):
            raise ValueError("invalid agent id")
        if not agent.agent_key.startswith(AGENT_KEY_PREFIX):
            raise ValueError("invalid agent key")
        if agent.node_id != node.node_id:
            raise ValueError("agent node mismatch")
        if agent.agent_id in ids:
            raise ValueError("duplicate agent id")
        ids.add(agent.agent_id)


def identity_path(home: pathlib.Path) -> pathlib.Path:
    return pathlib.Path(home) / IDENTITY_FILE


def ensure_home(home: pathlib.Path) -> pathlib.Path:
    home = pathlib.Path(home).expanduser()
    home.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(home, 0o700)
    except OSError:
        pass
    return home


def save_state(home: pathlib.Path, state: IdentityState) -> pathlib.Path:
    home = ensure_home(home)
    path = identity_path(home)
    tmp = home / (IDENTITY_FILE + ".tmp")
    payload = json.dumps(state.as_dict(), ensure_ascii=False, indent=2) + "\n"
    tmp.write_text(payload, encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    os.chmod(path, 0o600)
    return path


def load_state(home: pathlib.Path) -> IdentityState:
    path = identity_path(pathlib.Path(home).expanduser())
    if not path.exists():
        raise FileNotFoundError(f"identity not found: {path}")
    return IdentityState.from_dict(json.loads(path.read_text(encoding="utf-8")))


def init_identity(
    home: pathlib.Path,
    *,
    alias: str | None = None,
    username: str | None = None,   # legacy arg, ignored
    password: str | None = None,   # legacy arg, ignored
    email: str = "",               # legacy arg, ignored
    create_agent: bool = True,
    agent_name: str = "",
) -> InitResult:
    """Create only local Node/Agent identity.

    The center Owner is created/authenticated separately by onboarding.connect().
    """
    home = pathlib.Path(home).expanduser()
    if identity_path(home).exists():
        raise FileExistsError(f"identity already exists: {home}")
    fp_hash, fp_salt = fingerprint_hash()
    enc_privkey, enc_pubkey = generate_keypair()
    node = Node(
        node_id=new_id(NODE_PREFIX),
        alias=(alias or default_alias())[:40],
        node_key=new_key(NODE_KEY_PREFIX),
        fingerprint_hash=fp_hash,
        fingerprint_salt=fp_salt,
        status="pending_owner",
        enc_pubkey=enc_pubkey,
        enc_privkey=enc_privkey,
    )
    agents: list[Agent] = []
    if create_agent:
        agents.append(
            Agent(
                agent_id=new_id(AGENT_PREFIX),
                node_id=node.node_id,
                display_name=unique_name(agent_name or random_name(), []),
                agent_key=new_key(AGENT_KEY_PREFIX),
            )
        )
    state = IdentityState(node=node, agents=agents)
    save_state(home, state)
    return InitResult(state=state)


def add_agent(
    home: pathlib.Path,
    display_name: str,
    *,
    state: IdentityState | None = None,
) -> tuple[IdentityState, Agent]:
    state = state or load_state(home)
    name = (display_name or "").strip()[:40]
    if not name:
        raise ValueError("agent display name is required")
    name = unique_name(name, [a.display_name for a in state.agents])
    agent = Agent(
        agent_id=new_id(AGENT_PREFIX),
        node_id=state.node.node_id,
        display_name=name,
        agent_key=new_key(AGENT_KEY_PREFIX),
    )
    state.agents.append(agent)
    save_state(home, state)
    return state, agent


def public_summary(state: IdentityState) -> dict[str, Any]:
    c = state.center
    return {
        "owner_id": c.owner_id,
        "owner_username": c.username,
        "node_id": state.node.node_id,
        "node_alias": state.node.alias,
        "node_status": state.node.status,
        "enc_pubkey": state.node.enc_pubkey,
        "center": {
            "base": c.base,
            "owner_id": c.owner_id,
            "username": c.username,
            "email": c.email,
            "claimed_at": c.claimed_at,
        },
        "agents": [
            {"agent_id": agent.agent_id, "name": agent.display_name, "status": agent.status}
            for agent in state.agents
        ],
    }
