"""Center-first local setup for TAA Node.

The center owns the Owner account. This page only:
  1. creates the local Node/Agent keys;
  2. logs in / registers the center Owner once;
  3. claims this Node to that Owner.

There is no local Owner password and no local-only mode.
"""
from __future__ import annotations

import html
import json
import os
import pathlib
import re
import urllib.request
from urllib.parse import quote
from typing import Any

from flask import Flask, Response, redirect, request

from . import __version__
from .center import CenterClient, CenterError
from .names import random_name
from .identity import (
    IdentityState,
    add_agent,
    init_identity,
    install_ref,
    load_state,
    public_summary,
)
from .onboarding import connect as connect_center, reset_owner_password
from .theme import THEME_CSS

# 对外文案（P2.2）：改这一处即可，首页与向导共用。
COPY = {
    "tagline": "TAA：让你和你的 agent 协作更方便。",
    "steps": ("服务", "账号", "agent", "KEY", "第一条指令"),
}


def _h(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _wizard_steps(current: int, *, done_through: int = 0) -> str:
    """5 步进度条；current/done_through 都从 1 起算。"""
    items = []
    for i, label in enumerate(COPY["steps"], 1):
        cls = "done" if i <= done_through else ("now" if i == current else "")
        items.append(f'<li class="{cls}"><b>{i}</b><span>{_h(label)}</span></li>')
    return '<ol class="steps">' + "".join(items) + "</ol>"


def _service_ready(port: int | None) -> tuple[bool, str]:
    """只读探测主程序（同端口）：/v1/version 200 即视为本地服务已起。"""
    if not port:
        return False, ""
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{int(port)}/v1/version", timeout=2) as resp:
            data = json.loads(resp.read(2048).decode("utf-8", "ignore"))
        return True, str(data.get("runtime_version") or data.get("version") or "")
    except Exception:                                          # noqa: BLE001
        return False, ""


def _center_error(exc: Exception) -> str:
    status = int(getattr(exc, "status", 0) or 0)
    body = getattr(exc, "body", {})
    code = body.get("error", "") if isinstance(body, dict) else ""
    if code == "bad_username" or status == 400 and "username" in str(body):
        return "用户名格式不对：3–32 位，只能使用字母、数字、_、-，不能填邮箱。"
    if code == "weak_password":
        return "密码太短：至少 8 位。"
    if code == "username_taken" or status == 409:
        return "这个用户名已经注册。请直接登录，或换一个用户名。"
    if status == 401:
        return "密码错误。请重新输入 TAA 账号的密码。"
    if status == 404:
        return "中心地址或接口不存在。检查高级设置里的中心地址。"
    if status == 0:
        return "中心暂时不可达。检查网络后再试。"
    return f"中心返回 HTTP {status}，请稍后重试。"


def _home_warning() -> str:
    """P2.2b：主程序发现向导目录与数据目录分家时，在页面顶部提示。"""
    try:
        from flask import current_app, has_app_context
        if has_app_context():
            return str(current_app.config.get("TAA_HOME_WARNING") or "")
    except Exception:                                          # noqa: BLE001
        pass
    return ""


def _shell(body: str, *, error: str = "", notice: str = "",
           steps: str = "", tagline: bool = False) -> str:
    err = f'<div class="error">{_h(error)}</div>' if error else ""
    ok = f'<div class="notice">{_h(notice)}</div>' if notice else ""
    tag = f'<p class="tagline">{_h(COPY["tagline"])}</p>' if tagline else ""
    env_warn = _home_warning()
    warn = f'<div class="error">{_h(env_warn)}</div>' if env_warn else ""
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="data:,">
<title>TAA</title>
<style>{THEME_CSS}
:root{{--bg:var(--porcelain);--card:var(--apron);--muted:var(--ink-soft);--line:var(--hair);--accent:var(--powder-deep);--soft:var(--powder-light)}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.75 var(--sans)}}
main{{max-width:560px;margin:0 auto;padding:46px 18px 70px}}
h1{{font-size:30px;letter-spacing:.02em;margin:0 0 4px}}h2{{font-size:19px;margin:0 0 8px}}p{{color:var(--muted);margin:6px 0}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px 22px;margin:18px 0;box-shadow:0 4px 18px rgba(30,60,80,.05)}}
label{{display:block;font-size:13px;color:var(--ink-soft);font-weight:600;margin:14px 0 5px}}
input{{width:100%;border:1px solid var(--line);border-radius:9px;padding:11px 12px;font:inherit;background:var(--apron);outline:none}}
input:focus{{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 16%,transparent)}}
button{{border:0;border-radius:9px;background:var(--accent);color:#fff;padding:12px 16px;font:600 14px/1 inherit;cursor:pointer;margin:0}}
.primary{{width:100%;margin-top:20px;font-size:15px;padding:13px 16px}}
.tabs{{display:flex;gap:4px;background:var(--soft);border:1px solid var(--line);border-radius:11px;padding:4px;margin:2px 0 18px}}
.tabs a{{flex:1;text-align:center;text-decoration:none;color:var(--muted);font-size:13px;font-weight:600;padding:8px 6px;border-radius:8px}}
.tabs a.on{{background:var(--card);color:var(--ink);box-shadow:0 1px 4px rgba(30,60,80,.10)}}
.hint{{font-size:12px;color:var(--muted);margin-top:5px;line-height:1.55}}
.field-error{{font-size:12px;color:#b3261e;margin-top:5px;min-height:0}}
.field-error:empty{{display:none}}
.availability{{display:none;font-size:12px;margin-top:5px;line-height:1.55}}
.availability.ok,.availability.bad,.availability.checking{{display:block}}
.availability.ok{{color:#2f7d59}}
.availability.bad{{color:#b3261e}}
.availability.checking{{color:var(--muted)}}
.availability a{{color:inherit;font-weight:600;margin-left:4px}}
.advanced{{margin-top:20px;border-top:1px solid var(--hair);padding-top:12px}}
.advanced summary{{cursor:pointer;font-size:13px;color:var(--muted);font-weight:600;list-style:none}}
.advanced summary::-webkit-details-marker{{display:none}}
.advanced summary:before{{content:"+";display:inline-block;width:12px;text-align:center;margin-right:4px;font-size:15px}}
.advanced[open] summary:before{{content:"−"}}
.advanced .inner{{padding-top:2px}}
.footnote{{font-size:12px;color:var(--muted);text-align:center;margin:16px 0 0;line-height:1.65}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}@media(max-width:680px){{.grid{{grid-template-columns:1fr}}}}
textarea{{width:100%;border:1px solid var(--line);border-radius:9px;padding:10px 11px;font:inherit;background:var(--apron);resize:vertical}}
.qrbox{{margin:12px 0}}.qrbox img{{width:180px;height:180px;border:1px solid var(--line);border-radius:10px;background:#fff}}
.kv{{display:grid;grid-template-columns:150px 1fr;gap:8px;padding:7px 0;border-bottom:1px solid var(--hair);font-size:14px}}.kv:last-child{{border-bottom:0}}
.mono{{font-family:"SF Mono",ui-monospace,Menlo,monospace;font-size:12px;word-break:break-all}}
.notice{{background:#edf8f3;border:1px solid #b7e2cf;color:#1d6b4f;border-radius:10px;padding:10px 12px;margin:12px 0;font-size:13px}}
.error{{background:#fff0f0;border:1px solid #efc2c2;color:#a22;border-radius:10px;padding:10px 12px;margin:12px 0;font-size:13px}}
a{{color:var(--powder-deep)}}
select{{width:100%;border:1px solid var(--line);border-radius:9px;padding:10px 11px;font:inherit;background:var(--apron)}}
.tag{{display:inline-block;background:var(--soft);color:var(--ink-soft);border-radius:999px;padding:3px 9px;font-size:12px;margin:3px 5px 3px 0}}
.members{{margin-top:8px}}
.msgline{{border-bottom:1px solid var(--hair);padding:11px 0}}.msgline:last-child{{border-bottom:0}}
.msgmeta{{font-size:11px;color:var(--muted);font-family:ui-monospace,Menlo,monospace;margin-bottom:4px}}
.msgbody{{font-size:14px;line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere}}
.tagline{{font-size:13px;color:var(--muted);margin:3px 0 0}}
.steps{{display:flex;gap:6px;list-style:none;padding:0;margin:18px 0 6px}}
.steps li{{flex:1;display:flex;flex-direction:column;gap:5px;align-items:center;font-size:11px;color:var(--muted);text-align:center}}
.steps li b{{width:22px;height:22px;border-radius:50%;background:var(--soft);color:var(--ink-soft);display:grid;place-items:center;font-size:11px;font-weight:700}}
.steps li.now b{{background:var(--accent);color:#fff}}
.steps li.now{{color:var(--ink);font-weight:600}}
.steps li.done b{{background:#2f7d59;color:#fff}}
.steps li.done{{color:#2f7d59}}
.btn{{display:block;text-align:center;text-decoration:none;border-radius:9px;background:var(--accent);color:#fff;padding:13px 16px;font:600 15px/1.2 var(--sans);margin-top:20px}}
.btn.ghost{{background:var(--soft);color:var(--ink-soft)}}
pre.cmd{{background:var(--soft);border:1px solid var(--line);border-radius:9px;padding:10px 12px;font-size:12px;overflow-x:auto;margin:10px 0}}
</style></head><body><main>
<h1>TAA</h1>
{tag}{warn}{steps}{err}{ok}{body}
</main></body></html>"""


def _mode(value: Any) -> str:
    return "login" if str(value or "") == "login" else "create"


def _field_error(field_errors: dict[str, str] | None, name: str) -> str:
    message = (field_errors or {}).get(name, "")
    return f'<div class="field-error" data-error-for="{_h(name)}">{_h(message)}</div>'


def _account_form(*, mode: str = "create", action: str = "create",
                  username: str = "", base: str = "https://alice.loomsci.com",
                  alias: str = "TAA-NODE", agent_name: str = "", ref: str = "",
                  error: str = "", field_errors: dict[str, str] | None = None,
                  state: IdentityState | None = None,
                  show_agent: bool = True) -> str:
    mode = _mode(mode)
    create = mode == "create"
    heading = "创建 TAA 账号" if create else "登录 TAA 账号"
    button = "创建账号" if create else "登录"
    username_rule = ("3–32 位，只能使用字母、数字、_、-；不区分大小写；不要填邮箱。"
                     if create else "请输入你的 TAA 用户名，不区分大小写；不要填邮箱。")
    password_rule = "至少 8 位。" if create else ""
    confirm = f"""
    <label for="password2">再次输入密码</label>
    <input id="password2" name="password2" type="password" autocomplete="new-password" required>
    {_field_error(field_errors, "password2")}
""" if create else ""
    ref_field = f"""
    <label for="ref">推荐码（可选）</label>
    <input id="ref" name="ref" value="{_h(ref)}" maxlength="64"
           autocomplete="off" autocapitalize="none" spellcheck="false">
    <div class="hint">填朋友的主页 ID；注册后你们自动互为好友。留空则不加任何人。</div>
    {_field_error(field_errors, "ref")}
""" if create else ""
    node_fields = "" if state is not None else f"""
      <label for="alias">本机名称（可选）</label>
      <input id="alias" name="alias" value="{_h(alias)}" maxlength="40">
"""
    # P2.2：向导 Step2 只建 Owner/Node，agent 放到 Step3 单独建。
    if state is None and show_agent:
        node_fields += f"""
      <label for="agent_name">默认 Agent（可选）</label>
      <input id="agent_name" name="agent_name" value="{_h(agent_name)}" maxlength="40">
"""
    local_note = "这台电脑还没有绑定 TAA 账号。" if state is not None else ""
    body = f"""
<section class="card">
  <div class="tabs" role="tablist">
    <a href="?mode=create" class="{'on' if create else ''}" role="tab" aria-selected="{'true' if create else 'false'}">第一次使用</a>
    <a href="?mode=login" class="{'on' if not create else ''}" role="tab" aria-selected="{'false' if create else 'true'}">已有账号</a>
  </div>
  <h2>{heading}</h2>
  <p>{local_note or "账号由 TAA 中心管理；本机不保存密码。"}</p>
  <form class="account" method="post" action="{_h(action)}" novalidate>
    <input type="hidden" name="mode" value="{mode}">
    <label for="username">用户名</label>
    <input id="username" name="username" value="{_h(username)}" maxlength="32"
           autocomplete="{'off' if create else 'username'}" autocapitalize="none" spellcheck="false" required>
    <div class="hint">{username_rule}</div>
    {_field_error(field_errors, "username")}
    {f'<div class="availability" data-availability aria-live="polite"><span data-availability-text></span><a data-availability-login href="?mode=login" hidden>去登录</a></div>' if create else ''}

    <label for="password">密码</label>
    <input id="password" name="password" type="password"
           autocomplete="{'new-password' if create else 'current-password'}" required>
    {f'<div class="hint">{password_rule}</div>' if password_rule else ''}
    {_field_error(field_errors, "password")}
    {confirm}
    {ref_field}

    <button class="primary" type="submit">{button}</button>
    <p class="footnote">{'创建后会自动绑定这台电脑。' if create else '登录后会自动绑定这台电脑。'}</p>

    <details class="advanced">
      <summary>高级设置</summary>
      <div class="inner">
        <label for="base">中心地址</label>
        <input id="base" name="base" value="{_h(base)}" maxlength="200">
        {node_fields}
      </div>
    </details>
  </form>
</section>
<script>
(() => {{
  const form = document.querySelector("form.account");
  if (!form) return;
  const mode = form.querySelector('input[name="mode"]').value;
  const username = form.querySelector('[name="username"]');
  const password = form.querySelector('[name="password"]');
  const password2 = form.querySelector('[name="password2"]');
  const base = form.querySelector('[name="base"]');
  const availability = form.querySelector("[data-availability]");
  const availabilityText = form.querySelector("[data-availability-text]");
  const availabilityLogin = form.querySelector("[data-availability-login]");
  let availabilityTimer = 0;
  let availabilitySeq = 0;
  let lastChecked = "";
  const setError = (name, message) => {{
    const el = form.querySelector('[data-error-for="' + name + '"]');
    if (el) el.textContent = message;
  }};
  const clearAvailability = () => {{
    lastChecked = "";
    if (!availability) return;
    availability.className = "availability";
    availabilityText.textContent = "";
    availabilityLogin.hidden = true;
  }};
  const showAvailability = (kind, message) => {{
    if (!availability) return;
    availability.className = "availability " + kind;
    availabilityText.textContent = message;
    if (kind !== "bad") availabilityLogin.hidden = true;
  }};
  const validCreateName = (value) => {{
    return value.length >= 3 && value.length <= 32 &&
      !value.includes("@") && !value.includes(".") && /^[A-Za-z0-9_-]+$/.test(value);
  }};
  const checkAvailability = async () => {{
    if (mode !== "create" || !availability) return;
    const value = username.value.trim();
    if (!value || !validCreateName(value)) {{
      clearAvailability();
      return;
    }}
    if (value === lastChecked) return;
    const seq = ++availabilitySeq;
    showAvailability("checking", "检查用户名…");
    try {{
      const checkURL = new URL("username-check", window.location.href);
      checkURL.searchParams.set("username", value);
      if (base && base.value.trim()) checkURL.searchParams.set("base", base.value.trim());
      const response = await fetch(checkURL.toString(), {{
        headers: {{ accept: "application/json" }}, cache: "no-store"
      }});
      const data = await response.json().catch(() => ({{}}));
      if (seq !== availabilitySeq) return;
      if (data.supported === false) {{
        showAvailability("checking", "暂时无法自动检查，提交时会再检查。");
      }} else if (data.available === true) {{
        lastChecked = value;
        showAvailability("ok", "可以使用");
      }} else if (data.available === false) {{
        lastChecked = value;
        showAvailability("bad", "已被使用");
        availabilityLogin.hidden = false;
        availabilityLogin.href = "?mode=login&username=" + encodeURIComponent(value);
      }} else {{
        showAvailability("checking", data.error || "暂时无法检查，提交时会再检查。");
      }}
    }} catch (error) {{
      if (seq !== availabilitySeq) return;
      showAvailability("checking", "暂时无法检查，提交时会再检查。");
    }}
  }};
  if (mode === "create" && availability) {{
    username.addEventListener("input", () => {{
      availabilitySeq++;
      clearAvailability();
      if (availabilityTimer) clearTimeout(availabilityTimer);
      availabilityTimer = setTimeout(checkAvailability, 450);
    }});
    username.addEventListener("blur", () => {{
      if (availabilityTimer) clearTimeout(availabilityTimer);
      checkAvailability();
    }});
    if (username.value.trim()) checkAvailability();
  }}
  form.addEventListener("submit", (event) => {{
    ["username", "password", "password2"].forEach((name) => setError(name, ""));
    let ok = true;
    const value = username.value.trim();
    if (!value) {{
      setError("username", "请输入用户名。");
      ok = false;
    }} else if (mode === "create" && (value.includes("@") || value.includes("."))) {{
      setError("username", "这里要填用户名，不是邮箱。");
      ok = false;
    }} else if (mode === "create" && (!/^[A-Za-z0-9_-]+$/.test(value) || value.length < 3 || value.length > 32)) {{
      setError("username", "用户名需 3–32 位，只能使用字母、数字、_、-。");
      ok = false;
    }}
    if (!password.value) {{
      setError("password", "请输入密码。");
      ok = false;
    }} else if (mode === "create" && password.value.length < 8) {{
      setError("password", "密码至少 8 位。");
      ok = false;
    }}
    if (mode === "create" && password.value !== password2.value) {{
      setError("password2", "两次输入的密码不一致。");
      ok = false;
    }}
    if (!ok) event.preventDefault();
  }});
}})();
</script>"""
    return body


def _setup_page(*, mode: str = "create", username: str = "",
                alias: str = "TAA-NODE", base: str = "https://alice.loomsci.com",
                agent_name: str = "", ref: str = "", error: str = "",
                field_errors: dict[str, str] | None = None,
                steps: str = "", show_agent: bool = True,
                action: str = "create") -> str:
    body = _account_form(mode=mode, action=action, username=username, base=base,
                         alias=alias, agent_name=agent_name or random_name(), ref=ref,
                         field_errors=field_errors, show_agent=show_agent)
    return _shell(body, error=error, steps=steps, tagline=bool(steps))


def _connect_form(state: IdentityState, *, mode: str = "create", username: str = "",
                  base: str = "", ref: str = "", error: str = "",
                  field_errors: dict[str, str] | None = None,
                  steps: str = "") -> str:
    body = _account_form(mode=mode, action="connect", username=username,
                         base=base or state.center.base or "https://alice.loomsci.com",
                         alias=state.node.alias, state=state, ref=ref,
                         field_errors=field_errors)
    return _shell(body, error=error, steps=steps, tagline=bool(steps))


def _validate_account(form: Any, mode: str) -> dict[str, str]:
    """账号表单校验（/create 与向导 /owner 共用口径）。"""
    username = (form.get("username") or "").strip()
    pw = form.get("password") or ""
    pw2 = form.get("password2") or ""
    errors: dict[str, str] = {}
    if not username:
        errors["username"] = "请输入用户名。"
    elif mode == "create" and ("@" in username or "." in username):
        errors["username"] = "这里要填用户名，不是邮箱。"
    elif mode == "create" and not re.fullmatch(r"[A-Za-z0-9_-]{3,32}", username):
        errors["username"] = "用户名需 3–32 位，只能使用字母、数字、_、-。"
    if not pw:
        errors["password"] = "请输入密码。"
    elif mode == "create" and len(pw) < 8:
        errors["password"] = "密码至少 8 位。"
    if mode == "create" and pw != pw2:
        errors["password2"] = "两次输入的密码不一致。"
    return errors


_DIAG_TEXT = {
    "core_no_agent": "本机还没有任何 agent。向导第 3 步会建一个，建完就能进工作区。",
    "v05_no_identity": "没找到旧版安装的身份（新装机器正常如此），已尝试走本机库。",
    "v05_no_agent": "旧版身份里没有 agent，已尝试走本机库。",
    "identity_unreadable": "本机身份文件读不出来（半写入或被改坏）。"
                           "可以删掉 ~/.taa/identity.json 重新走一遍向导——"
                           "本机的 agent 与聊天记录在 data.db，不会因此丢失。",
}


def _diag_note(diag: str) -> str:
    """把 /app/bridge 带回来的失败原因翻译成人话（rc16 W3）。"""
    codes = [c for c in (diag or "").split(",") if c]
    if not codes:
        return ""
    lines = []
    for code in codes:
        text = _DIAG_TEXT.get(code)
        if not text:
            text = f"内部错误：<code>{_h(code)}</code>"
        lines.append(f"<li>{text}</li>")
    return ('<div class="hint">进工作区时没成功，原因是：<ul style="margin:6px 0 0 18px">'
            + "".join(lines) + "</ul></div>")


def _step1_page(port: int | None, diag: str = "") -> str:
    """Step 1：只读探测主程序，不写盘。"""
    ok, ver = _service_ready(port)
    note = _diag_note(diag)
    if ok:
        body = f"""
<section class="card">
  <h2>本地服务已就绪</h2>
  <p>端口 {_h(port)} 上运行着 TAA 主程序{('（v' + _h(ver) + '）') if ver else ''}。
     下一步创建你的 TAA 账号，它是这台电脑的归属。</p>
  {note}
  <a class="btn" href="/setup/owner">开始</a>
</section>"""
    else:
        body = f"""
<section class="card">
  <h2>先启动本地服务</h2>
  <p>向导需要主程序在跑。在终端执行：</p>
  <pre class="cmd">$TAA_HOME/app/taa start</pre>
  <p class="hint">如果刚装完，安装器通常已经启动了；仍未就绪就点“重新检测”。</p>
  {note}
  <a class="btn" href="/setup/">重新检测</a>
  <a class="btn ghost" href="/setup/owner">先继续（稍后启动）</a>
</section>"""
    return _shell(body, steps=_wizard_steps(1), tagline=True)


_KEY_NAMES = {"deepseek": "deepseek_api_key", "alibaba": "alibaba_api_key",
              "volcano": "volcano_api_key", "ark": "ark_api_key"}


def _read_llm_keys(paths: list[pathlib.Path]) -> dict[str, str]:
    try:
        import tomllib
    except ImportError:                                        # py<3.11
        return {}
    for path in paths:
        try:
            data = tomllib.loads(path.read_text(encoding="utf-8"))
        except Exception:                                      # noqa: BLE001
            continue
        llm = data.get("llm") or {}
        if isinstance(llm, dict):
            return {k: str(v) for k, v in llm.items() if isinstance(v, str)}
    return {}


def _key_configured(home: pathlib.Path) -> tuple[bool, str]:
    """KEY 是否已配置：**只认本次安装的 home**。

    不读 ~/.taa 的旧 key——否则在已装过 TAA 的机器上，新用户还没填就显示
    “已配置”（实测截图复现）。home 与 ~/.taa 的口径统一见 P2.2b。
    """
    keys = _read_llm_keys([home / "config.toml"])
    raw = keys.get("deepseek_api_key") or keys.get("api_key") or ""
    if not raw:
        return False, ""
    return True, ("尾号 " + raw[-4:]) if len(raw) >= 4 else "已配置"


def _write_key_fallback(home: pathlib.Path, provider: str, key: str) -> bool:
    """无 core 包时（独立跑 node-v05）直接写 home/config.toml。"""
    name = _KEY_NAMES.get(provider)
    if not name or not key.strip():
        return False
    path = home / "config.toml"
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        lines = []
    start = next((i for i, line in enumerate(lines) if line.strip() == "[llm]"), -1)
    if start < 0:
        lines += ["", "[llm]"]
        start = len(lines) - 1
    end = next((i for i in range(start + 1, len(lines)) if lines[i].strip().startswith("[")),
               len(lines))
    for i in range(start + 1, end):
        if lines[i].strip().startswith(name) and "=" in lines[i]:
            lines[i] = f"{name} = {json.dumps(key.strip())}"
            break
    else:
        lines.insert(start + 1, f"{name} = {json.dumps(key.strip())}")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return True


def _db_candidates(home: pathlib.Path) -> list[pathlib.Path]:
    """第 5 步读哪个库：home/data.db 优先，其次 TEAMAI_DB（隔离实例/自定义库）。

    2026-11-08（rc16 W1）：原来只认 `home/data.db`，一旦主程序用了别的库路径
    （TEAMAI_DB / 自定义 --home），"完成态"永远不会亮——用户看到的是
    "发完刷新没反应"，而库里其实早有回复。
    """
    out = [home / "data.db"]
    env_db = (os.environ.get("TEAMAI_DB") or "").strip()
    if env_db:
        out.append(pathlib.Path(env_db).expanduser())
    return [p for p in out if p.is_file()]


def _first_reply(home: pathlib.Path, agent_ids: list[str]) -> bool:
    """Step5 判定：库里是否已有这些 agent 发出的消息（只读）。"""
    if not agent_ids:
        return False
    try:
        import sqlite3
        for db in _db_candidates(home):
            try:
                conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=3)
            except Exception:                                  # noqa: BLE001
                continue
            try:
                marks = ",".join("?" * len(agent_ids))
                row = conn.execute(
                    f"select 1 from room_messages where agent_id in ({marks}) limit 1",
                    tuple(agent_ids)).fetchone()
                if row:
                    return True
            finally:
                conn.close()
        return False
    except Exception:                                          # noqa: BLE001
        return False


def _executor_health() -> dict:
    """执行器/模型后端健康（不调模型、不花 token）；独立跑时返回空字典。"""
    try:
        from core import executor_bridge
        return dict(executor_bridge.health() or {})
    except Exception:                                          # noqa: BLE001
        return {}


def _step3_page(state: IdentityState) -> str:
    body = f"""
<section class="card">
  <h2>给你的电脑配一个 agent</h2>
  <p>这个名字就是你在群里 @ 它时用的名字；以后还能再加。</p>
  <form method="post" action="/setup/agent">
    <input type="hidden" name="next" value="key">
    <label for="name">agent 名字</label>
    <input id="name" name="name" value="{_h(random_name())}" maxlength="40" required>
    <button class="primary" type="submit">创建 agent</button>
  </form>
</section>"""
    return _shell(body, steps=_wizard_steps(3, done_through=2), tagline=True)


def _step4_page(configured: bool, tail: str = "", *, error: str = "") -> str:
    if configured:
        note = f'<div class="notice">已配置模型 KEY（{_h(tail)}）。</div>'
    else:
        # rc16 W2：没有 KEY 时"AI 能力不可用"必须写在脸上，并给申请入口。
        # 原来这一页只说"KEY 只写在本机"，用户跳过之后在第 5 步干等回复。
        note = ('<div class="error">没有 KEY，<b>AI 能力不可用</b>：agent 能收到消息，'
                '但不会回复。可以先跳过，之后再回来配。</div>'
                '<p class="hint">没有 KEY？到 '
                '<a href="https://platform.deepseek.com/api_keys" target="_blank" '
                'rel="noopener">platform.deepseek.com</a> 申请一个（DeepSeek 最省事）。</p>')
    body = f"""
{note}
<section class="card">
  <h2>填一个模型 KEY</h2>
  <p>KEY 只写在这台电脑的 config.toml（权限 600），不上传。</p>
  <form method="post" action="/setup/key">
    <label for="provider">模型服务</label>
    <select id="provider" name="provider">
      <option value="deepseek">DeepSeek</option>
      <option value="alibaba">阿里云百炼 / DashScope</option>
      <option value="volcano">火山方舟 / Ark</option>
    </select>
    <label for="api_key">API KEY</label>
    <input id="api_key" name="api_key" type="password" autocomplete="off" placeholder="sk-...">
    <div class="hint">已保存的 KEY 不回显；填新的会覆盖。</div>
    <button class="primary" type="submit">保存并继续</button>
  </form>
  <p class="footnote"><a href="/setup/first">稍后配置（AI 暂时无法回复）→</a></p>
</section>"""
    return _shell(body, error=error, steps=_wizard_steps(4, done_through=3), tagline=True)


def _step5_diag(home: pathlib.Path) -> tuple[str, bool]:
    """第 5 步的"为什么没回复"诊断。返回 (html, 是否具备回复条件)。

    2026-11-08（rc16 W1/W2）：workbuddy 实测发 `@Billy …` 8 秒无回复、无完成态、
    也没有任何提示。元凶不止一个（没 KEY / 没执行器 / 没有可用后端），但页面
    一条都不说。这里把三个必要条件逐条摊开，能省掉的判断就带按钮直接做掉。
    """
    key_ok, key_tail = _key_configured(home)
    h = _executor_health()
    probe_ok = bool(h)
    backends = h.get("backends") or {}
    usable = [str(n) for n, ok in backends.items() if ok] if isinstance(backends, dict) else []
    sup = bool(h.get("supervisor"))
    sup_n = len(h.get("supervisor_pids") or [])

    rows: list[str] = []
    if key_ok:
        rows.append(f'<li class="ok">模型 KEY 已配置（{_h(key_tail)}）。</li>')
    else:
        rows.append('<li class="bad"><b>没有模型 KEY</b>：agent 收得到消息，但没有模型可调，'
                    '不会回复。<a href="/setup/key">现在去配 →</a></li>')
    if not probe_ok:
        rows.append('<li>执行器状态无法探测（本页没有跑在主程序进程内）。</li>')
        ready = False
    else:
        if key_ok and not usable:
            rows.append('<li class="bad"><b>KEY 有了，但没有可用模型后端</b>：本机没找到 '
                        'opencode / codebuddy 等执行通道。</li>')
        elif usable:
            rows.append(f'<li class="ok">模型后端：{_h("、".join(usable[:3]))}。</li>')
        if sup:
            rows.append(f'<li class="ok">执行器在跑（{sup_n} 个进程）。</li>')
        else:
            rows.append('<li class="bad"><b>执行器没在跑</b>：没人接手你发的指令。'
                        '<form method="post" action="/setup/executor/start" '
                        'style="display:inline"><button type="submit" '
                        'style="padding:5px 10px;font-size:12px;margin-left:6px">启动执行器</button>'
                        '</form></li>')
        ready = key_ok and bool(usable) and sup
    body = ('<ul class="diag">' + "".join(rows) + "</ul>"
            + ('<p class="hint">三项都绿之后再去发，通常 2–8 秒就有回复。</p>' if ready
               else '<p class="hint">上面红的那条就是原因；修好再刷新本页。</p>'))
    return body, ready


def _step5_page(state: IdentityState, done: bool, *, home: pathlib.Path | None = None,
                diag: str = "") -> str:
    name = state.agents[0].display_name if state.agents else "你的 agent"
    if done:
        note = '<div class="notice">已经收到 agent 的回复：第一公里走通了。</div>'
        extra = ""
        tail = ('<a class="btn ghost" href="/app/chats">进去继续用 →</a>')
    else:
        note = ('<div class="hint">发完回来点“我发完了，刷新”，出现完成态才算走通。'
                '一直没回复就看下面三条。</div>')
        extra = (f'<div class="card" style="margin-top:0"><h2 style="font-size:15px">'
                 f'为什么可能没回复</h2>{diag}</div>')
        tail = '<a class="btn ghost" href="/setup/first">我发完了，刷新</a>'
    body = f"""
{note}
{extra}
<section class="card">
  <h2>发第一条指令</h2>
  <p>打开工作区，在群里发这句：</p>
  <pre class="cmd">@{_h(name)} 你好，用一句话介绍你自己</pre>
  <a class="btn" href="/app/bridge">去工作区</a>
  {tail}
</section>"""
    return _shell(body, steps=_wizard_steps(5, done_through=4), tagline=True)


def _profile_page(state: IdentityState, profile: dict[str, Any], *, notice: str = "",
                  error: str = "") -> str:
    public_id = str(profile.get("public_id") or profile.get("username") or "")
    base = (state.center.base or "https://alice.loomsci.com").rstrip("/")
    public_url = f"{base}/u/{quote(public_id)}" if public_id else base
    alias = str(profile.get("display_alias") or profile.get("username") or "")
    bio = str(profile.get("bio") or "")
    home = str(profile.get("home_location") or "")
    raw_visible = profile.get("location_visible", True)
    visible = str(raw_visible).lower() not in ("0", "false", "no", "")
    body = f"""
<section class="card">
  <h2>公开主页</h2>
  <p>编辑后会立即出现在你的公开主页；本机不保存 TAA 账号密码。</p>
  <p class="mono">{_h(public_url)}</p>
  <div class="qrbox"><img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data={_h(quote(public_url, safe=''))}" alt="公开主页二维码"></div>
  <p class="hint">二维码只编码公开主页 URL，不包含密码或 key。</p>
</section>
<section class="card">
  <form method="post" action="/setup/profile">
    <label>公开显示名 / 别名</label>
    <input name="display_alias" value="{_h(alias)}" maxlength="40">
    <div class="hint">可重复、可随时改；不是登录凭据。</div>

    <label>简介</label>
    <textarea name="bio" id="bio" maxlength="500" rows="7">{_h(bio)}</textarea>
    <div class="hint">最多 500 字符；支持基础 Markdown、$...$ 和 $$...$$ LaTeX；不支持原始 HTML。</div>
    <div class="hint"><span id="bio-count">{len(bio)}</span>/500</div>

    <label>常居地</label>
    <input name="home_location" value="{_h(home)}" maxlength="40" placeholder="例如：成都">
    <div class="hint">只公开城市/地区，不公开精确地址。</div>

    <label style="display:flex;gap:8px;align-items:center;margin-top:16px">
      <input type="checkbox" name="location_visible" value="1" {'checked' if visible else ''} style="width:auto">
      在公开主页显示常居地
    </label>

    <button class="primary" type="submit">保存公开主页</button>
    <p class="footnote"><a href="/setup/friends">好友申请</a> · <a href="/setup/account">返回账号页</a></p>
  </form>
</section>
<script>
(function(){{
  var b=document.getElementById("bio"), c=document.getElementById("bio-count");
  if(!b||!c) return;
  function n(){{ c.textContent=Array.from(b.value).length; }}
  b.addEventListener("input",n); n();
}})();
</script>"""
    return _shell(body, notice=notice, error=error)


def _short_id(value: Any, n: int = 14) -> str:
    text = str(value or "")
    return text if len(text) <= n else text[:n] + "…"


def _group_detail_page(state: IdentityState, group: dict[str, Any], members: list[dict[str, Any]],
                       messages: list[dict[str, Any]], *, notice: str = "", error: str = "") -> str:
    gid = str(group.get("group_id") or "")
    member_labels = []
    for m in members:
        oid = str(m.get("owner_id") or "")
        aid = str(m.get("agent_id") or "")
        member_labels.append(f'<span class="tag">{("agent " + _short_id(aid)) if aid else ("用户 " + _short_id(oid))}</span>')
    sender_options = ['<option value="">我（用户）</option>']
    for agent in state.agents:
        sender_options.append(f'<option value="{_h(agent.agent_id)}">{_h(agent.display_name)}（agent）</option>')
    msg_rows = []
    for m in messages:
        sender = str(m.get("agent_id") or m.get("owner_id") or "")
        kind = "agent" if m.get("agent_id") else "用户"
        msg_rows.append(
            f'<div class="msgline"><div class="msgmeta">{_h(kind)} {_h(_short_id(sender))} · {_h(m.get("created_at", ""))}</div>'
            f'<div class="msgbody">{_h(m.get("body", ""))}</div></div>')
    body = f"""
<section class="card">
  <div class="kicker">CROSS-LAN GROUP</div>
  <h2>{_h(group.get("name", gid))}</h2>
  <p class="mono">{_h(gid)}</p>
  <div class="members">{''.join(member_labels)}</div>
  <p><a href="/setup/groups">← 返回工作组</a></p>
</section>
<section class="card">
  <h2>消息</h2>
  {''.join(msg_rows) or '<p class="hint">还没有消息。</p>'}
</section>
<section class="card">
  <form method="post" action="/setup/groups/{_h(gid)}/send">
    <label>发送者</label>
    <select name="agent_id">{''.join(sender_options)}</select>
    <label>消息</label>
    <textarea name="body" maxlength="4000" rows="4" required></textarea>
    <button class="primary" type="submit">发送</button>
    <p class="footnote">消息经中心中继，两个局域网节点只需访问中心。</p>
  </form>
</section>"""
    return _shell(body, notice=notice, error=error)


def _groups_page(state: IdentityState, friends: list[dict[str, Any]], groups: list[dict[str, Any]],
                 *, notice: str = "", error: str = "") -> str:
    approved = [f for f in friends if str(f.get("status")) == "approved"]
    friend_rows = "".join(
        f'<label style="display:flex;gap:8px;align-items:center;margin:7px 0">'
        f'<input type="checkbox" name="member_owner_ids" value="{_h(f.get("friend_id", ""))}" style="width:auto">'
        f'{_h(f.get("friend_alias") or f.get("friend_username") or f.get("friend_id", ""))}</label>'
        for f in approved) or '<p class="hint">先通过公开主页加好友，再拉工作组。</p>'
    group_rows = []
    for g in groups:
        gid = str(g.get("group_id") or "")
        members = g.get("members") or []
        owners = sum(1 for m in members if m.get("owner_id") and not m.get("agent_id"))
        agents = sum(1 for m in members if m.get("agent_id"))
        group_rows.append(
            f'<div class="kv"><span><a href="/setup/groups/{_h(gid)}">{_h(g.get("name", ""))}</a></span><b>{owners} 人 / {agents} agent</b>'
            f'<code class="mono">{_h(gid)}</code></div>')
    body = f"""
<section class="card">
  <h2>跨机工作组</h2>
  <p>从已批准好友中选择至少一位，创建一个 2 真人 + 2 agent 的工作组。成员由中心目录同步。</p>
  <form method="post" action="/setup/groups/create">
    <label>工作组名字</label>
    <input name="name" maxlength="80" placeholder="例如：物理讨论组" required>
    <div class="hint">邀请好友（至少一位）</div>
    {friend_rows}
    <button class="primary" type="submit">创建工作组</button>
  </form>
</section>
<section class="card">
  <h2>我的工作组</h2>
  {''.join(group_rows) or '<p class="hint">还没有工作组。</p>'}
</section>
<p><a href="/setup/friends">返回好友</a> · <a href="/setup/account">返回账号页</a></p>"""
    return _shell(body, notice=notice, error=error)


def _friends_page(state: IdentityState, friends: list[dict[str, Any]], *, notice: str = "",
                  error: str = "", notices: list[dict[str, Any]] | None = None) -> str:
    pending = [f for f in friends if str(f.get("status")) == "pending"
               and str(f.get("requested_by")) != str(state.center.owner_id)]
    approved = [f for f in friends if str(f.get("status")) == "approved"]
    notices = notices or []
    unread = [n for n in notices if not str(n.get("read_at") or "")]

    def notice_row(n: dict[str, Any]) -> str:
        who = str(n.get("actor_username") or n.get("actor_public_id") or "")
        kind = str(n.get("kind") or "")
        text = (f"{who} 通过你的推荐码注册，你们已成为好友。"
                if kind == "friend_linked" else f"{who} 与你的关系有更新。")
        when = str(n.get("created_at") or "")[:10]
        return f'<div class="kv"><span>{_h(text)}</span><b>{_h(when)}</b></div>'

    unread_note = f"（{len(unread)} 条未读）" if unread else ""
    read_btn = ('<form method="post" action="/setup/friends/notices/read" style="margin-top:10px">'
                '<button type="submit">全部标为已读</button></form>') if unread else ""
    notices_block = f"""
<section class="card">
  <h2>通知{unread_note}</h2>
  {''.join(notice_row(n) for n in notices)}
  {read_btn}
</section>""" if notices else ""
    def row(f: dict[str, Any], *, approve: bool = False) -> str:
        alias = str(f.get("friend_alias") or f.get("friend_username") or f.get("friend_id") or "")
        pid = str(f.get("friend_public_id") or "")
        link = f'<a href="{_h((state.center.base or "https://alice.loomsci.com").rstrip("/"))}/u/{_h(pid)}" target="_blank" rel="noopener">{_h(alias)}</a>' if pid else _h(alias)
        action = ""
        if approve:
            action = f"""<form method="post" action="/setup/friends/approve" style="display:inline">
              <input type="hidden" name="from_owner_id" value="{_h(f.get("friend_id", ""))}">
              <button type="submit">批准</button></form>"""
        status = {"pending": "待批准", "approved": "已批准"}.get(str(f.get("status", "")), str(f.get("status", "")))
        return f'<div class="kv"><span>{link}</span><b>{_h(status)}</b>{action}</div>'
    pending_rows = "".join(row(f, approve=True) for f in pending) or '<p class="hint">没有待批准申请。</p>'
    approved_rows = "".join(row(f) for f in approved) or '<p class="hint">还没有好友。</p>'
    body = f"""
{notices_block}
<section class="card">
  <h2>好友</h2>
  <p>通过对方公开主页申请加好友；对方批准后出现在这里。</p>
  <p><a href="/app/settings/profile">编辑公开主页 / 二维码 →</a></p>
</section>
<section class="card">
  <h2>待批准</h2>
  {pending_rows}
</section>
<section class="card">
  <h2>已批准</h2>
  {approved_rows}
</section>
<p><a href="/setup/account">返回账号页</a></p>"""
    return _shell(body, notice=notice, error=error)


def _state_page(state: IdentityState, *, notice: str = "", error: str = "") -> str:
    c = state.center
    agents = "".join(
        f'<div class="kv"><span>{_h(a.display_name)}</span><b class="mono">{_h(a.agent_id)}</b></div>'
        for a in state.agents) or '<p class="muted">还没有 Agent</p>'
    body = f"""
<section class="card">
  <h2>TAA 账号</h2>
  <div class="kv"><span>中心</span><b>{_h(c.base)}</b></div>
  <div class="kv"><span>用户名</span><b>{_h(c.username or "—")}</b></div>
  <div class="kv"><span>账号 ID</span><b class="mono">{_h(c.owner_id or "—")}</b></div>
</section>
<section class="card">
  <h2>本机</h2>
  <div class="kv"><span>名称</span><b>{_h(state.node.alias)}</b></div>
  <div class="kv"><span>本机 ID</span><b class="mono">{_h(state.node.node_id)}</b></div>
  <div class="kv"><span>状态</span><b>{_h(state.node.status)}</b></div>
</section>
<section class="card">
  <h2>Agents</h2>
  {agents}
  <form method="post" action="agent">
    <label>新增 Agent 名字</label>
    <input name="name" placeholder="bob" maxlength="40" required>
    <button type="submit">添加</button>
  </form>
</section>
<section class="card">
  <h2>TAA 账号密码</h2>
  <p>密码只由中心管理；本机不保存密码。</p>
  <form method="post" action="password">
    <label>新密码（至少 8 位）</label>
    <input name="password1" type="password" required>
    <label>再次输入</label>
    <input name="password2" type="password" required>
    <button type="submit">修改密码</button>
  </form>
</section>
<p><a href="/app/settings/profile">编辑公开主页 / 二维码 →</a> · <a href="/setup/friends">好友申请 →</a> · <a href="/setup/groups">工作组 →</a></p>
<p><a href="/app/bridge">进入本地工作台 →</a></p>
"""
    return _shell(body, notice=notice, error=error)


def create_app(home: pathlib.Path, port: int | None = None,
               home_warning: str = "") -> Flask:
    home = pathlib.Path(home).expanduser()
    app = Flask(__name__)
    app.config["TAA_HOME"] = str(home)
    # P2.2b：目录分家告警（主程序传入；空串=一致）
    app.config["TAA_HOME_WARNING"] = home_warning

    def state_or_none() -> IdentityState | None:
        try:
            state = load_state(home)
        except FileNotFoundError:
            app.config["TAA_IDENTITY_ERROR"] = ""
            return None
        except Exception as exc:  # noqa: BLE001
            # rc16 W3：identity.json 半写入或被改坏时，原来每条向导路由都 500，
            # 用户看到的就是"打不开、也没原因"。这里退回"未初始化"，并把原因
            # 带到首屏；重建比 500 有用。
            app.config["TAA_IDENTITY_ERROR"] = f"{type(exc).__name__}: {exc}"
            print(f"[setup] identity unreadable: {type(exc).__name__}: {exc}")
            return None
        app.config["TAA_IDENTITY_ERROR"] = ""
        return state

    @app.get("/")
    def index() -> Response:
        state = state_or_none()
        mode = _mode(request.args.get("mode"))
        username = (request.args.get("username") or "").strip()[:32]
        if state is None:
            # P2.2 Step 1：先确认本地服务在跑，再建账号。
            diag = request.args.get("diag", "")
            if not diag and app.config.get("TAA_IDENTITY_ERROR"):
                diag = "identity_unreadable"
            return Response(_step1_page(port, diag), mimetype="text/html")
        if not state.center.owner_id:
            return Response(_connect_form(state, mode=mode, username=username,
                                          steps=_wizard_steps(2, done_through=1)),
                            mimetype="text/html")
        # A connected node has nothing to do on /setup/. Send the user straight
        # to the local app; account details remain available at /setup/account.
        return redirect("/app/bridge")

    @app.get("/owner")
    def owner_page() -> Response:
        """Step 2：建 Owner（中心账号）+ 本机 Node；**不建 agent**（Step 3 单独建）。"""
        state = state_or_none()
        if state is not None and state.center.owner_id:
            return redirect("/setup/agent")
        steps = _wizard_steps(2, done_through=1)
        # 安装器 `--ref` 落盘的推荐码预填：用户不用再手填，注册即成为好友。
        ref = install_ref(home)
        if state is not None:
            return Response(_connect_form(state, steps=steps, ref=ref), mimetype="text/html")
        return Response(_setup_page(action="owner", steps=steps, show_agent=False, ref=ref),
                        mimetype="text/html")

    @app.post("/owner")
    def owner_create() -> Response:
        state = state_or_none()
        if state is not None and state.center.owner_id:
            return redirect("/setup/agent")
        mode = _mode(request.form.get("mode") or request.form.get("action"))
        base = (request.form.get("base") or "https://alice.loomsci.com").strip().rstrip("/")
        username = (request.form.get("username") or "").strip()
        pw = request.form.get("password") or ""
        alias = (request.form.get("alias") or "TAA-NODE").strip()
        ref = (request.form.get("ref") or install_ref(home)).strip()
        steps = _wizard_steps(2, done_through=1)
        field_errors = _validate_account(request.form, mode)
        if field_errors:
            if state is None:
                return Response(_setup_page(mode=mode, username=username, alias=alias,
                                            base=base, field_errors=field_errors,
                                            steps=steps, show_agent=False, action="owner"),
                                status=400, mimetype="text/html")
            return Response(_connect_form(state, mode=mode, username=username, base=base,
                                          field_errors=field_errors, steps=steps),
                            status=400, mimetype="text/html")
        # 只建本机 Node/密钥，不顺手建 agent（向导 Step3 负责）。
        if state is None:
            try:
                init_identity(home, alias=alias, create_agent=False)
            except FileExistsError:
                pass
        try:
            connect_center(home, base=base, username=username, password=pw,
                           create_owner=(mode == "create"), register_agents=False,
                           ref=ref)
        except CenterError as exc:
            next_mode = "login" if getattr(exc, "status", 0) in (401, 409) else mode
            state = load_state(home)
            return Response(_connect_form(state, mode=next_mode, username=username, base=base,
                                          error=_center_error(exc), steps=steps),
                            mimetype="text/html")
        except (RuntimeError, ValueError) as exc:
            state = load_state(home)
            return Response(_connect_form(state, mode=mode, username=username, base=base,
                                          error=str(exc), steps=steps),
                            mimetype="text/html")
        return redirect("/setup/agent")

    @app.get("/agent")
    def wizard_agent() -> Response:
        """Step 3：建 agent（名字即群里 @ 的名字）。"""
        state = state_or_none()
        if state is None:
            return redirect("/setup/")
        if not state.center.owner_id:
            return redirect("/setup/owner")
        if state.agents:
            return redirect("/setup/key")
        return Response(_step3_page(state), mimetype="text/html")

    @app.get("/key")
    def wizard_key() -> Response:
        """Step 4：填模型 KEY（可跳过）。"""
        state = state_or_none()
        if state is None:
            return redirect("/setup/")
        if not state.center.owner_id:
            return redirect("/setup/owner")
        if not state.agents:
            return redirect("/setup/agent")
        configured, tail = _key_configured(home)
        return Response(_step4_page(configured, tail), mimetype="text/html")

    @app.post("/key")
    def wizard_key_save() -> Response:
        state = state_or_none()
        if state is None:
            return redirect("/setup/")
        if not state.center.owner_id:
            return redirect("/setup/owner")
        if not state.agents:
            return redirect("/setup/agent")
        provider = (request.form.get("provider") or "deepseek").strip()
        key = (request.form.get("api_key") or "").strip()
        if not key:
            return Response(_step4_page(*_key_configured(home), error="请填写 API KEY。"),
                            status=400, mimetype="text/html")
        try:
            # 同进程挂载时走主程序唯一口径（core.config）
            from core.config import save_taa_key as _save
            ok = bool(_save(provider, key))
        except Exception:                                      # noqa: BLE001
            ok = _write_key_fallback(home, provider, key)
        if not ok:
            return Response(_step4_page(False, "", error="KEY 没写进去：检查目录权限。"),
                            status=400, mimetype="text/html")
        return redirect("/setup/first")

    @app.get("/first")
    def wizard_first() -> Response:
        """Step 5：发第一条指令。**有回复才算完成**，没回复给诊断。"""
        state = state_or_none()
        if state is None:
            return redirect("/setup/")
        if not state.center.owner_id:
            return redirect("/setup/owner")
        if not state.agents:
            return redirect("/setup/agent")
        done = _first_reply(home, [a.agent_id for a in state.agents])
        diag = "" if done else _step5_diag(home)[0]
        return Response(_step5_page(state, done, home=home, diag=diag),
                        mimetype="text/html")

    @app.post("/executor/start")
    def wizard_executor_start() -> Response:
        """第 5 步的"启动执行器"按钮：把本机 agent 的 runner 拉起来（幂等）。"""
        state = state_or_none()
        if state is None:
            return redirect("/setup/")
        ids = [a.agent_id for a in state.agents]
        if os.environ.get("TAA_DISABLE_AGENT_AUTOSTART") == "1":
            # 与 /app/bridge 的自动拉起保持同一口径：测试环境不该被按钮带起进程。
            return redirect("/setup/first")
        try:
            from core import agent_launcher
            agent_launcher.ensure_agents(ids)
            return redirect("/setup/first")
        except Exception as exc:                              # noqa: BLE001
            return Response(
                _step5_page(state, False, home=home,
                            diag=f'<div class="error">启动执行器失败：'
                                 f'{_h(type(exc).__name__)}: {_h(exc)}</div>'),
                status=500, mimetype="text/html")

    @app.get("/account")
    def account() -> Response:
        state = state_or_none()
        if state is None:
            return redirect("/")
        if not state.center.owner_id:
            return Response(_connect_form(state, mode=_mode(request.args.get("mode"))),
                            mimetype="text/html")
        return Response(_state_page(state), mimetype="text/html")

    @app.get("/username-check")
    def username_check() -> Response:
        username = (request.args.get("username") or "").strip()
        base = (request.args.get("base") or "https://alice.loomsci.com").strip().rstrip("/")
        if not re.fullmatch(r"[A-Za-z0-9_-]{3,32}", username):
            payload = {"ok": False, "supported": True, "available": None,
                       "error": "用户名需 3–32 位，只能使用字母、数字、_、-。"}
            return Response(json.dumps(payload, ensure_ascii=False), status=400,
                            mimetype="application/json")
        if not base.startswith(("http://", "https://")):
            payload = {"ok": False, "supported": True, "available": None,
                       "error": "中心地址格式不对。"}
            return Response(json.dumps(payload, ensure_ascii=False), status=400,
                            mimetype="application/json")
        try:
            result = CenterClient(base).username_available(username=username)
        except CenterError as exc:
            if int(getattr(exc, "status", 0) or 0) == 404:
                payload = {"ok": True, "supported": False, "available": None}
            else:
                payload = {"ok": False, "supported": True, "available": None,
                           "error": _center_error(exc)}
            return Response(json.dumps(payload, ensure_ascii=False),
                            mimetype="application/json")
        payload = {"ok": True, "supported": True,
                   "username": username,
                   "available": bool(result.get("available"))}
        return Response(json.dumps(payload, ensure_ascii=False), mimetype="application/json")

    @app.post("/create")
    def create() -> Response:
        if state_or_none() is not None:
            return Response("already initialized", status=409)
        mode = _mode(request.form.get("mode") or request.form.get("action"))
        base = (request.form.get("base") or "https://alice.loomsci.com").strip().rstrip("/")
        username = (request.form.get("username") or "").strip()
        pw = request.form.get("password") or ""
        pw2 = request.form.get("password2") or ""
        alias = (request.form.get("alias") or "TAA-NODE").strip()
        agent_name = (request.form.get("agent_name") or random_name()).strip()
        ref = (request.form.get("ref") or "").strip() if mode == "create" else ""
        field_errors: dict[str, str] = {}
        if not username:
            field_errors["username"] = "请输入用户名。"
        elif mode == "create" and ("@" in username or "." in username):
            field_errors["username"] = "这里要填用户名，不是邮箱。"
        elif mode == "create" and not re.fullmatch(r"[A-Za-z0-9_-]{3,32}", username):
            field_errors["username"] = "用户名需 3–32 位，只能使用字母、数字、_、-。"
        if ref and not re.fullmatch(r"[A-Za-z0-9_-]{3,32}", ref):
            field_errors["ref"] = "推荐码是对方的主页 ID：3–32 位字母、数字、_、-。"
        if not pw:
            field_errors["password"] = "请输入密码。"
        elif mode == "create" and len(pw) < 8:
            field_errors["password"] = "密码至少 8 位。"
        if mode == "create" and pw != pw2:
            field_errors["password2"] = "两次输入的密码不一致。"
        if field_errors:
            return Response(_setup_page(mode=mode, username=username, alias=alias, base=base,
                                        agent_name=agent_name, ref=ref, field_errors=field_errors),
                            status=400, mimetype="text/html")
        # Node/Agent keys are local; the account is created/authenticated by center.
        try:
            init_identity(home, alias=alias, create_agent=True, agent_name=agent_name)
        except FileExistsError:
            pass
        try:
            result = connect_center(home, base=base, username=username, password=pw,
                                    create_owner=(mode == "create"), register_agents=True,
                                    ref=ref)
        except CenterError as exc:
            state = load_state(home)
            next_mode = "login" if getattr(exc, "status", 0) in (401, 409) else mode
            return Response(_connect_form(state, mode=next_mode, username=username, base=base,
                                          ref=ref, error=_center_error(exc)), mimetype="text/html")
        except (RuntimeError, ValueError) as exc:
            state = load_state(home)
            return Response(_connect_form(state, mode=mode, username=username, base=base,
                                          ref=ref, error=str(exc)), mimetype="text/html")
        ref_info = (result or {}).get("ref") or {}
        if ref_info.get("applied"):
            friend = str(ref_info.get("username") or ref)
            return redirect("/setup/friends?notice=" + quote(f"已与 {friend} 成为好友"))
        return redirect("/app/bridge")

    @app.post("/connect")
    def connect() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        mode = _mode(request.form.get("mode") or request.form.get("action"))
        base = (request.form.get("base") or state.center.base or "https://alice.loomsci.com").strip().rstrip("/")
        username = (request.form.get("username") or "").strip()
        pw = request.form.get("password") or ""
        pw2 = request.form.get("password2") or ""
        ref = (request.form.get("ref") or "").strip() if mode == "create" else ""
        field_errors: dict[str, str] = {}
        if not username:
            field_errors["username"] = "请输入用户名。"
        elif mode == "create" and ("@" in username or "." in username):
            field_errors["username"] = "这里要填用户名，不是邮箱。"
        elif mode == "create" and not re.fullmatch(r"[A-Za-z0-9_-]{3,32}", username):
            field_errors["username"] = "用户名需 3–32 位，只能使用字母、数字、_、-。"
        if ref and not re.fullmatch(r"[A-Za-z0-9_-]{3,32}", ref):
            field_errors["ref"] = "推荐码是对方的主页 ID：3–32 位字母、数字、_、-。"
        if not pw:
            field_errors["password"] = "请输入密码。"
        elif mode == "create" and len(pw) < 8:
            field_errors["password"] = "密码至少 8 位。"
        if mode == "create" and pw != pw2:
            field_errors["password2"] = "两次输入的密码不一致。"
        if field_errors:
            return Response(_connect_form(state, mode=mode, username=username, base=base,
                                          ref=ref, field_errors=field_errors),
                            status=400, mimetype="text/html")
        try:
            result = connect_center(home, base=base, username=username, password=pw,
                                    create_owner=(mode == "create"), register_agents=True,
                                    ref=ref)
        except CenterError as exc:
            next_mode = "login" if getattr(exc, "status", 0) in (401, 409) else mode
            return Response(_connect_form(load_state(home), mode=next_mode, username=username,
                                          base=base, ref=ref, error=_center_error(exc)),
                            mimetype="text/html")
        except (RuntimeError, ValueError) as exc:
            return Response(_connect_form(load_state(home), mode=mode, username=username,
                                          base=base, ref=ref, error=str(exc)), mimetype="text/html")
        ref_info = (result or {}).get("ref") or {}
        if ref_info.get("applied"):
            friend = str(ref_info.get("username") or ref)
            return redirect("/setup/friends?notice=" + quote(f"已与 {friend} 成为好友"))
        return redirect("/app/bridge")

    def _group_bundle(base: str, node_key: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        client = CenterClient(base)
        friends = client.friends_for_node(node_key=node_key).get("friends") or []
        raw_groups = client.groups_for_node(node_key=node_key).get("groups") or []
        groups = []
        for g in raw_groups:
            try:
                detail = client.group_for_node(node_key=node_key, group_id=str(g.get("group_id")))
                groups.append({**g, "members": detail.get("members") or []})
            except CenterError:
                groups.append({**g, "members": []})
        return friends, groups

    @app.get("/groups")
    def groups_page() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="先登录 TAA 账号"), mimetype="text/html")
        try:
            friends, groups = _group_bundle(state.center.base, state.node.node_key)
        except CenterError as exc:
            return Response(_groups_page(state, [], [], error=_center_error(exc)), mimetype="text/html")
        return Response(_groups_page(state, friends, groups), mimetype="text/html")

    @app.post("/groups/create")
    def groups_create() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        name = (request.form.get("name") or "").strip()
        members = [x for x in request.form.getlist("member_owner_ids") if x]
        if not name or not members:
            return Response(_groups_page(state, [], [], error="工作组名字和至少一位好友必填"), status=400,
                            mimetype="text/html")
        client = CenterClient(state.center.base)
        try:
            created = client.create_group_for_node(node_key=state.node.node_key, name=name,
                                                   member_owner_ids=members)
            gid = str(created.get("group_id") or "")
            # every owner contributes at least one agent when available
            for agent in state.agents:
                client.add_group_member_for_node(node_key=state.node.node_key, group_id=gid,
                                                 owner_id=state.center.owner_id, agent_id=agent.agent_id)
            for owner_id in members:
                try:
                    detail = client.friend_nodes_for_node(node_key=state.node.node_key, owner_id=owner_id)
                except CenterError:
                    continue
                for agent in detail.get("agents") or []:
                    try:
                        client.add_group_member_for_node(node_key=state.node.node_key, group_id=gid,
                                                         owner_id=owner_id,
                                                         agent_id=str(agent.get("agent_id") or ""))
                    except CenterError:
                        pass
            friends, groups = _group_bundle(state.center.base, state.node.node_key)
        except CenterError as exc:
            return Response(_groups_page(state, [], [], error=_center_error(exc)), mimetype="text/html")
        return Response(_groups_page(state, friends, groups, notice="工作组已创建"), mimetype="text/html")

    @app.get("/groups/<group_id>")
    def group_detail(group_id: str) -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="先登录 TAA 账号"), mimetype="text/html")
        client = CenterClient(state.center.base)
        try:
            detail = client.group_for_node(node_key=state.node.node_key, group_id=group_id)
            msgs = client.group_messages_for_node(node_key=state.node.node_key, group_id=group_id)
        except CenterError as exc:
            return Response(_groups_page(state, [], [], error=_center_error(exc)), mimetype="text/html")
        return Response(_group_detail_page(state, detail.get("group") or {},
                                          detail.get("members") or [],
                                          msgs.get("messages") or []), mimetype="text/html")

    @app.post("/groups/<group_id>/send")
    def group_send(group_id: str) -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        body = (request.form.get("body") or "").strip()
        agent_id = (request.form.get("agent_id") or "").strip()
        if not body:
            return Response(_group_detail_page(state, {"group_id": group_id}, [], [],
                                              error="消息不能为空"), status=400, mimetype="text/html")
        client = CenterClient(state.center.base)
        try:
            client.send_group_message_for_node(node_key=state.node.node_key, group_id=group_id,
                                               body=body, agent_id=agent_id)
            detail = client.group_for_node(node_key=state.node.node_key, group_id=group_id)
            msgs = client.group_messages_for_node(node_key=state.node.node_key, group_id=group_id)
        except CenterError as exc:
            return Response(_group_detail_page(state, {"group_id": group_id}, [], [],
                                              error=_center_error(exc)), mimetype="text/html")
        return Response(_group_detail_page(state, detail.get("group") or {},
                                          detail.get("members") or [],
                                          msgs.get("messages") or [],
                                          notice="消息已发送"), mimetype="text/html")

    @app.get("/friends")
    def friends_page() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="先登录 TAA 账号"), mimetype="text/html")
        client = CenterClient(state.center.base)
        try:
            data = client.friends_for_node(node_key=state.node.node_key)
        except CenterError as exc:
            return Response(_friends_page(state, [], error=_center_error(exc)), mimetype="text/html")
        try:
            notices = client.notices_for_node(node_key=state.node.node_key).get("notices") or []
        except CenterError:
            notices = []  # 中心还是旧版本（无 /notices）时，好友页照常可用
        return Response(_friends_page(state, data.get("friends") or [], notices=notices,
                                      notice=(request.args.get("notice") or "").strip()),
                        mimetype="text/html")

    @app.post("/friends/approve")
    def friends_approve() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        from_id = (request.form.get("from_owner_id") or "").strip()
        try:
            CenterClient(state.center.base).friend_approve_for_node(
                node_key=state.node.node_key, from_owner_id=from_id)
            data = CenterClient(state.center.base).friends_for_node(node_key=state.node.node_key)
        except CenterError as exc:
            return Response(_friends_page(state, [], error=_center_error(exc)), mimetype="text/html")
        return Response(_friends_page(state, data.get("friends") or [], notice="已批准好友"), mimetype="text/html")

    @app.post("/friends/notices/read")
    def friends_notices_read() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="先登录 TAA 账号"), mimetype="text/html")
        try:
            CenterClient(state.center.base).mark_notices_read_for_node(
                node_key=state.node.node_key)
        except CenterError as exc:
            return Response(_friends_page(state, [], error=_center_error(exc)), mimetype="text/html")
        return redirect("/setup/friends")

    @app.get("/profile")
    def profile_page() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="先登录 TAA 账号"), mimetype="text/html")
        return redirect("/app/settings/profile")

    @app.post("/profile")
    def profile_save() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="先登录 TAA 账号"), mimetype="text/html")
        fields = {
            "display_alias": (request.form.get("display_alias") or "").strip(),
            "bio": (request.form.get("bio") or "").strip(),
            "home_location": (request.form.get("home_location") or "").strip(),
            "location_visible": "1" if request.form.get("location_visible") == "1" else "0",
        }
        if len(fields["bio"]) > 500:
            profile = dict(fields, public_id=state.center.username)
            return Response(_profile_page(state, profile, error="简介最多 500 字符"), status=400,
                            mimetype="text/html")
        try:
            data = CenterClient(state.center.base).update_owner_profile(
                node_key=state.node.node_key, **fields)
        except CenterError as exc:
            profile = dict(fields, public_id=state.center.username)
            return Response(_profile_page(state, profile, error=_center_error(exc)), mimetype="text/html")
        return Response(_profile_page(state, data.get("profile") or {}, notice="公开主页已更新"), mimetype="text/html")

    @app.post("/password")
    def password() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        p1 = request.form.get("password1") or ""
        p2 = request.form.get("password2") or ""
        if p1 != p2:
            return Response(_state_page(state, error="两次密码不一致"), mimetype="text/html")
        if len(p1) < 8:
            return Response(_state_page(state, error="密码至少 8 位"), mimetype="text/html")
        if not state.center.base or not state.center.owner_id:
            return Response(_connect_form(state, error="请先登录 TAA 账号"), mimetype="text/html")
        try:
            reset_owner_password(home, base=state.center.base, password=p1)
        except CenterError as exc:
            return Response(_state_page(load_state(home), error=_center_error(exc)), mimetype="text/html")
        except (ValueError, RuntimeError) as exc:
            return Response(_state_page(load_state(home), error=str(exc)), mimetype="text/html")
        return Response(_state_page(load_state(home), notice="密码已修改；本机不保存密码"), mimetype="text/html")

    @app.post("/agent")
    def agent() -> Response:
        state = state_or_none()
        if state is None:
            return Response(_setup_page(error="还没有本机 Node"), mimetype="text/html")
        name = (request.form.get("name") or "").strip()
        if not name:
            return Response(_state_page(state, error="Agent 名字必填"), mimetype="text/html")
        next_step = (request.form.get("next") or "").strip()
        try:
            state, ag = add_agent(home, name)
        except ValueError as exc:
            return Response(_state_page(state, error=str(exc)), mimetype="text/html")
        if state.center.base and state.center.owner_id:
            try:
                CenterClient(state.center.base).register_agent(
                    node_key=state.node.node_key, agent_id=ag.agent_id,
                    agent_key=ag.agent_key, display_name=ag.display_name)
            except Exception as exc:                           # noqa: BLE001
                # 向导态：本机已建，中心注册失败不阻断第一公里（联网后可重试）。
                if next_step != "key":
                    return Response(_state_page(load_state(home), error=str(exc)),
                                    mimetype="text/html")
        if next_step == "key":
            return redirect("/setup/key")
        return Response(_state_page(load_state(home), notice="Agent 已添加"), mimetype="text/html")

    @app.get("/api/state")
    def api_state() -> Response:
        state = state_or_none()
        if state is None:
            return Response('{"ok":false,"error":"not_ready"}', status=404, mimetype="application/json")
        import json
        return Response(json.dumps({"ok": True, **public_summary(state)}, ensure_ascii=False),
                        mimetype="application/json")

    @app.get("/health")
    def health() -> Response:
        return Response('{"ok":true,"service":"taa-setup","version":"%s"}' % _h(__version__),
                        mimetype="application/json")

    return app
