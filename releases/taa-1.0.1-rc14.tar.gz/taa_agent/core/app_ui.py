"""TAA 本地界面（/app）：与中心**同一套外壳/样式**（static/teamai 由中心同步）。

唯一真源：alice/src/shell.ts + 各页面 <style>
同步：../venv/bin/python scripts/sync_ui_from_center.py
"""
from __future__ import annotations

import base64
import csv
import datetime
import hashlib
import hmac
import html
import ipaddress
import json
import time
import markdown as mdlib
import os
import pathlib
import re
import socket
import sqlite3
import subprocess
import tempfile
import threading
import urllib.parse
import uuid
import urllib.request

from urllib.parse import quote

from core import db as core_db
from core import i18n, message_route, moment_reward, thumbnails, timeutil
from flask import Response, g, redirect, request, send_file, session, stream_with_context
try:  # Step 2: optional so a pre-WebSocket package can still start.
    from flask_sock import Sock
except Exception:  # noqa: BLE001
    Sock = None  # type: ignore[assignment]

ROOT = pathlib.Path(__file__).resolve().parent.parent
# P1A/A1：不再各自 fallback 到 cwd/data.db；统一走 core.db.DB_PATH（正式部署 = <home>/data.db）
DB = pathlib.Path(os.environ.get("TEAMAI_UI_DB") or core_db.DB_PATH)
UI = ROOT / "static" / "teamai"

# Step 2 minimal room hub.  One Host process owns this map; a browser or a
# same-LAN client connects to the Host and receives the same ordered events.
_WS_CLIENTS: dict[str, dict[int, object]] = {}
_WS_LOCK = threading.RLock()


def _asset(name: str, default: str = "") -> str:
    p = UI / name
    return p.read_text(encoding="utf-8") if p.exists() else default


SHELL_CSS = _asset("shell.css")
COPY_CSS = _asset("copy.css")
ICONS = json.loads(_asset("icons.json", "{}") or "{}")
_brand = json.loads(_asset("brand.json", "{}") or "{}")
_taa_brand = json.loads(_asset("taa-brand.json", "{}") or "{}")
BRAND = (_taa_brand.get("mark") or _brand.get("data_uri")
         or "/static/teamai/brand/taa-mark-square-32.png")
PAGE_CSS = {k: _asset(f"{k}.css") for k in ("home", "chat", "feed", "inbox", "board", "team", "settings", "version")}

# R1：手机端把“会话列表”作为首屏；选中会话后才展开聊天。
CHAT_MOBILE_CSS = """
.mobile-back{display:none;border:1px solid var(--hair);background:var(--apron);color:var(--ink);width:36px;height:36px;min-height:36px;border-radius:10px;align-items:center;justify-content:center;font-size:26px;line-height:1;padding:0;text-decoration:none}
.onboard{margin:0 0 12px;padding:14px 12px;border:1px solid var(--powder);background:linear-gradient(135deg,var(--apron),var(--powder-light));border-radius:14px}
.onboard>b{display:block;margin:4px 0 8px;font-family:var(--serif);font-size:16px}
.onboard ol{margin:0;padding-left:18px;font-size:13px;line-height:1.7}
.onboard li{margin:5px 0}
.onboard a{margin-left:4px;color:var(--powder-deep);text-decoration:underline;text-underline-offset:2px}
.onboardacts{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}
.onboardacts .btn{min-height:32px;padding:0 10px;font-size:12px}
.sysitem{width:100%;background:transparent;border:0;text-align:left;font:inherit;color:inherit}
.sysitem.on{background:var(--powder-light)}
.syspane .sysbody{flex:1;min-height:0;overflow:auto;padding:18px}
.sysmsg{max-width:720px;margin:0 auto;border:1px solid var(--hair);border-radius:16px;background:var(--porcelain);padding:18px}
.sysmsg h3{margin:6px 0 8px;font-family:var(--serif);font-size:20px}
.sysmsg p,.sysmsg li{font-size:14px;line-height:1.8;color:var(--ink-soft)}
.sysmsg ol{padding-left:20px;margin:10px 0 14px}
.sysmsg a{margin-left:6px;color:var(--powder-deep);text-decoration:underline;text-underline-offset:2px}
.mnavtoggle{display:none;order:-1;margin-left:0;margin-right:6px;width:34px;height:34px;min-height:34px;border:1px solid var(--hair);border-radius:9px;background:var(--apron);color:var(--ink);font-size:18px;align-items:center;justify-content:center;padding:0}
@media (max-width:900px){
  .app.chats-page .side{display:flex;position:static;width:auto;height:auto;min-height:100vh;transform:none;z-index:auto;box-shadow:none;border-right:0;padding:14px 16px calc(16px + env(safe-area-inset-bottom));overflow:auto}
  .app.chats-page .mnav{display:none}
  .app.chats-page .sidefoot{display:none}
  .app.chats-page .mnavtoggle{display:inline-flex}
  .app.chats-page .side .brand{order:-2;padding:0 0 8px;min-height:0}
  .app.chats-page .side .brand .blogo,
  .app.chats-page .side .brand b{display:none}
  .app.chats-page.nav-open .mnav{display:flex!important}
  .app.chats-page .onboard{order:-1}
  .app.chats-page .sysbox{order:0}
  .app.chats-page .convbox{order:1}
  .app.chats-page .agentsbox{order:2}
  .app.chats-page .friendsbox{order:3}
  .app.chats-page .side .brand{padding-bottom:10px}
  .app.chats-page .pane{display:none}
  .app.chats-page.chat-open .side{display:none}
  .app.chats-page.chat-open .pane{display:flex;min-height:100vh}
  .app.chats-page .sidetoggle{display:none}
  .app.chats-page.chat-open .mobile-back{display:inline-flex}
  .app.chats-page .aitem,.app.chats-page .citem{padding:12px 10px;font-size:15px}
  .app.chats-page.chat-open .room{height:calc(100dvh - 112px);min-height:0;border-radius:14px}
  .app.chats-page.chat-open main{padding:10px 12px max(10px,env(safe-area-inset-bottom))}
  .app.chats-page.chat-open .top{padding:12px 14px 10px 14px}
  .app.chats-page.chat-open .roomhead{padding:10px 12px}
  .app.chats-page.chat-open .log{padding:12px}
  .app.chats-page.chat-open .say{padding:9px 12px calc(9px + env(safe-area-inset-bottom))}
  .app.chats-page.chat-open .say textarea{min-height:48px;max-height:120px}
  .app.chats-page.chat-open .say .btn{min-width:64px;height:40px}
}
"""

LOCAL_CSS = """
.mnavtoggle{display:none;order:-1;margin-left:0;margin-right:6px;width:34px;height:34px;min-height:34px;border:1px solid var(--hair);border-radius:9px;background:var(--apron);color:var(--ink);font-size:18px;align-items:center;justify-content:center;padding:0}
.brand .blogo{width:18px;height:18px;border-radius:4px;display:block;image-rendering:auto}
.roomacts{display:flex;gap:6px;margin-left:auto;align-items:center}
.roomacts form{display:inline}
.say textarea:disabled{opacity:.55;cursor:not-allowed}
.say .btn:disabled{opacity:.45;cursor:not-allowed}
.replyquote{font-size:12px;line-height:1.45;border-left:3px solid var(--powder);background:rgba(60,107,150,.08);color:var(--ink-soft);padding:5px 8px;margin:0 0 6px;border-radius:0 7px 7px 0;overflow-wrap:anywhere}
.msg.me .replyquote{background:rgba(255,255,255,.16);border-left-color:rgba(255,255,255,.7);color:#eef2ff}
.replyquote b{color:inherit}
.msg .text a{color:var(--powder-deep)}
.msg .mava img{width:28px;height:28px;border-radius:50%;display:block}
.msg.me .bubble{background:#3C6B96;border-color:#3C6B96}
.msg.me .who{color:#fff;text-align:right}
.msg.me .text{color:#fff}
.msg.me .text a{color:#fff;text-decoration:underline}
.msg{outline:none}
.msg .bubble{cursor:pointer}
.msg:focus-visible .bubble{box-shadow:0 0 0 2px var(--powder-deep)}
.msg.selected .bubble{box-shadow:0 0 0 2px var(--powder-deep)}
.msg .acts{display:flex;gap:4px;align-items:center;opacity:0;transition:opacity .12s;align-self:center}
.msg:hover .acts,.msg:focus-within .acts,.msg.selected .acts{opacity:1}
.actbtn{border:1px solid var(--pearl);background:var(--apron);color:var(--ink-soft);border-radius:999px;padding:3px 9px;font-size:12px;cursor:pointer;white-space:nowrap;flex:0 0 auto}
.actbtn:hover{border-color:var(--powder-deep);color:var(--ink)}
/* 消息详情：右栏不再是静态统计卡，点消息即可查看全文 / 附件 / 操作 */
.msg-detail-hint{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--ink-soft);
  border:1px dashed var(--pearl);border-radius:999px;padding:3px 10px;margin-left:auto}
@media (max-width:1440px){.msg-detail-hint{display:none}}
.roomacts .tag{white-space:nowrap}
.msgdetail-body{font-size:14px;line-height:1.85;overflow-wrap:anywhere}
.msgdetail-body p{margin:0 0 10px}
.msgdetail-body p:last-child{margin-bottom:0}
.msgdetail-body img{max-width:100%;height:auto;border-radius:10px;display:block;margin:8px 0;cursor:zoom-in}
.msgdetail-body pre{white-space:pre-wrap;overflow-wrap:anywhere;max-width:100%}
.msgdetail-body table{display:block;max-width:100%;overflow-x:auto}
.msgdetail-body code{overflow-wrap:anywhere}
.detail .chatatt-img{max-width:100%;height:auto;max-height:none;border-radius:10px}
.detail .msgmeta{display:flex;flex-wrap:wrap;gap:6px 12px;font-size:12px;color:var(--ink-soft);margin-top:8px}
.detail .msgmeta code{font-size:12px}
.detail .dflash{animation:dfade 1.1s ease}
@keyframes dfade{0%{background:#FFF3C4}100%{background:transparent}}
@media (hover:none){.msg .acts{opacity:1}}
.graphchip{margin-left:6px;border:1px solid #D6E7F5;background:#EAF3FB;color:#3c5f7a;border-radius:999px;padding:0 6px;font-size:12px;cursor:pointer}
.daysep{text-align:center;font-size:12px;color:var(--ink-soft);margin:4px 0 2px;letter-spacing:.08em}
.msg.me .acts{order:-1}
.post{position:relative;transition:border-color .15s,box-shadow .15s,transform .15s}
.post:hover{border-color:var(--powder);box-shadow:0 2px 4px rgba(22,24,28,.04),0 16px 34px rgba(22,24,28,.07);transform:translateY(-1px)}
.post .stretch{position:absolute;inset:0;z-index:0;border-radius:18px}
.post .head,.post .body,.post h2{position:relative;z-index:1;pointer-events:none}
.post .link,.post .tags,.post a:not(.stretch){position:relative;z-index:2;pointer-events:auto}
.post .body a,.post .body img,.post .body code{pointer-events:auto}
.postdetail .body{pointer-events:auto}
.postdetail .body{padding-bottom:4px}
.post{cursor:pointer}
.img-missing{display:inline-block;font-size:12px;color:var(--ink-soft);background:var(--lace);border:1px dashed var(--pearl);border-radius:8px;padding:4px 8px;margin:6px 0}
/* t-9457018c：附件图片加载失败兜底（/app 页面不加载 static/board.js，故在公共外壳内自带一份） */
.img-fallback{display:inline-flex;align-items:center;gap:10px;max-width:min(420px,100%);padding:8px 10px;
  border:1px dashed var(--pearl);border-radius:10px;background:var(--lace);color:var(--ink);
  font-size:12px;line-height:1.5;vertical-align:middle;margin:4px 0}
.img-fallback-icon{flex:none;font-size:18px;line-height:1;opacity:.75}
.img-fallback-main{display:flex;flex-direction:column;gap:2px;min-width:0}
.img-fallback-name{font-weight:600;overflow-wrap:anywhere}
.img-fallback-hint{color:var(--ink-soft)}
.img-fallback-acts{display:flex;gap:6px;flex:none;align-items:center}
.img-fallback-retry,.img-fallback-open{border:0;background:rgba(15,23,32,.06);color:#334155;
  border-radius:7px;min-height:32px;padding:3px 8px;font-size:12px;cursor:pointer;text-decoration:none;white-space:nowrap}
.img-fallback-retry:hover,.img-fallback-open:hover{background:rgba(15,23,32,.12)}
.img-fallback-retry:disabled{opacity:.6;cursor:default}
.img-fallback.retry-failed{border-color:#f3c7c7;background:#fff7f7}
.msg.me .img-fallback{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.35);color:#eef2ff}
.msg.me .img-fallback-name{color:#fff}
.msg.me .img-fallback-hint{color:#dbe3ff}
.msg.me .img-fallback-retry,.msg.me .img-fallback-open{background:rgba(255,255,255,.25);color:#fff}
.msg.me .img-fallback-retry:hover,.msg.me .img-fallback-open:hover{background:rgba(255,255,255,.35)}
.postdetail-pane{position:sticky;top:14px;padding:16px 18px;max-height:calc(100vh - 120px);overflow:auto}
.post.selected{border-color:var(--powder-deep);box-shadow:0 0 0 1px rgba(111,156,196,.25)}
.post img{max-width:100%;height:auto;border-radius:10px}
.body pre{max-width:100%;overflow:auto;background:var(--lace);padding:10px 12px;border-radius:10px;font-size:12px;line-height:1.6}
.body pre code{white-space:pre;font-size:12px}
.body code{background:var(--lace);padding:1px 5px;border-radius:5px;font-size:12px}
.body table{display:block;max-width:100%;overflow:auto}
.body blockquote{margin:8px 0;padding:6px 12px;border-left:3px solid var(--powder);color:var(--ink-soft)}
.post .inline-img{max-height:260px;width:auto;max-width:100%;object-fit:contain;background:var(--lace)}
.postdetail .inline-img{max-height:70vh;width:auto;max-width:100%}
.msg .inline-img{max-width:260px;max-height:200px;width:auto}
.scopenote{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:12px 14px;margin-bottom:10px;font-size:13px;color:var(--ink-soft)}
.more{display:inline-block;margin:8px 0 2px;font-size:13px;color:#3c6f8f;position:relative;z-index:2}
.feedmore{margin:14px 0;text-align:center;color:var(--ink-soft);font-size:13px;cursor:pointer;padding:10px;border:1px dashed var(--pearl);border-radius:12px}
.inline-img{max-width:100%;border-radius:10px;margin:10px 0;display:block;cursor:zoom-in;border:1px solid var(--hair)}
.atts{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;position:relative;z-index:2}
.post .atts{pointer-events:none}
.postdetail .atts{pointer-events:auto}
.post .atts img,.post .atts a{pointer-events:auto}
.post .atts .img-fallback,.post .atts .img-fallback-retry{pointer-events:auto}
.atts-img{width:96px;height:96px;object-fit:cover;border-radius:10px;border:1px solid var(--hair);cursor:zoom-in;background:var(--lace)}
.chatatt{margin-top:6px;display:flex;flex-wrap:wrap;gap:6px}
.chatatt-img{max-width:100%;max-height:200px;height:auto;border-radius:10px;border:1px solid var(--hair);cursor:zoom-in;display:block}
.attfile{font-size:12px;color:var(--ink-soft);text-decoration:underline}
.attchip{display:inline-flex;align-items:center;gap:4px;padding:5px 8px;border:1px solid var(--hair);border-radius:8px;background:var(--lace);font-size:12px;color:var(--ink-soft);pointer-events:none}
.postrefs{display:grid;gap:6px;margin:8px 0;position:relative;z-index:2}
.postfoot{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:10px 0 0;position:relative;z-index:2;pointer-events:auto}
.ract{display:flex;gap:4px;align-items:center}
.rform{display:inline-flex;margin:0}
.rbtn{border:1px solid var(--hair);background:var(--apron);color:var(--ink-soft);border-radius:999px;padding:0 8px;height:40px;font-size:12px;line-height:1.4;cursor:pointer}
.rbtn:hover{border-color:var(--powder-deep);color:var(--ink)}.rbtn.on{background:var(--powder-light);border-color:var(--powder-deep);color:var(--ink)}
.rlink{font-size:12px;color:var(--ink-soft)}.rlink:hover{color:var(--ink)}
.replies{padding:16px 18px;margin-top:12px}
.replylist{margin-top:8px}
.reply{padding:9px 0;border-bottom:1px solid var(--hair)}.reply:last-child{border-bottom:0}
.rhead{display:flex;justify-content:space-between;gap:8px;font-size:12px;color:var(--ink-soft)}.rhead b{color:var(--ink)}
.rbody{font-size:14px;line-height:1.7;margin-top:3px;overflow-wrap:anywhere}
.replyform{display:flex;gap:8px;align-items:flex-end;margin-top:12px}
.replyform textarea{flex:1;min-width:0;box-sizing:border-box;border:1px solid var(--hair);border-radius:10px;padding:8px 10px;font:inherit;background:var(--apron);color:var(--ink)}
.replyform .btn{flex:0 0 auto}
@media(max-width:520px){.replyform{flex-wrap:wrap}.replyform .btn{width:100%}}
.postref-card{display:grid;grid-template-columns:auto minmax(0,1fr);gap:2px 8px;padding:8px 10px;border:1px solid var(--hair);border-radius:10px;background:var(--lace);font-size:13px;line-height:1.45}
.postref-card:hover{border-color:var(--powder-deep)}
.postref-id{font-size:12px;color:var(--ink-soft);font-family:ui-monospace,Menlo,monospace;white-space:nowrap}
.postref-title{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}
.postref-meta{grid-column:2;font-size:12px;color:var(--ink-soft);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.att-doc{flex:1 0 100%;min-width:0;margin:8px 0;border:1px solid var(--hair);border-radius:12px;background:var(--apron);overflow:hidden}
.att-doc>summary{display:flex;align-items:center;gap:10px;justify-content:space-between;padding:9px 12px;background:var(--lace);cursor:pointer;font-size:13px;list-style:none}
.att-doc>summary::-webkit-details-marker{display:none}
.att-doc>summary span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.att-md-body{padding:8px 14px 14px;font-size:14px;line-height:1.8;max-height:70vh;overflow:auto;overflow-wrap:anywhere}
.att-md-body h1,.att-md-body h2,.att-md-body h3{margin:10px 0 6px;line-height:1.35}
.att-md-body h1{font-size:20px}.att-md-body h2{font-size:17px}.att-md-body h3{font-size:15px}
.att-md-body p{margin:6px 0}
.att-md-body table{display:block;max-width:100%;overflow:auto;border-collapse:collapse}
.att-md-body th,.att-md-body td{border:1px solid var(--hair);padding:5px 8px;font-size:12.5px}
.att-md-body img{max-width:100%;height:auto}
.att-table{padding:8px 10px;max-height:60vh;overflow:auto}
.att-table table{border-collapse:collapse;width:100%;font-size:12.5px}
.att-table th,.att-table td{border:1px solid var(--hair);padding:5px 8px;text-align:left;vertical-align:top}
.att-table th{background:var(--lace);position:sticky;top:0}
.att-video{flex:1 0 100%;min-width:0;margin:8px 0}
.post-video{display:block;width:100%;max-height:min(520px,60vh);border-radius:12px;background:#000}
.att-video-name{margin-top:5px;font-size:12px;color:var(--ink-soft)}
.att-txt pre{max-height:60vh;overflow:auto;white-space:pre-wrap;font-size:12.5px;margin:0;padding:10px 12px}
/* 聊天输入框图片预览（t-a42f7aac）：粘贴/拖拽后先本地缩略图，再替换为上传 URL */
.imgpreview{display:grid;grid-template-columns:repeat(3,92px);gap:10px;margin:10px 0}
.imgpreview:empty{display:none}
.imgthumb{position:relative;width:92px;height:92px}
.imgthumb img{width:92px;height:92px;object-fit:cover;border-radius:10px;border:1px solid var(--hair)}
.imgthumb button{position:absolute;top:-7px;right:-7px;width:22px;height:22px;border-radius:50%;border:1px solid var(--hair);background:#fff;color:var(--ink);font-size:14px;line-height:1;cursor:pointer}
.imgthumb.uploading img{opacity:.55;filter:blur(1px)}
.imgthumb.uploading:after{content:"上传中";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:12px;color:#fff;background:rgba(20,30,40,.38);border-radius:10px;pointer-events:none}
.say-main{flex:1;min-width:0}
.say-main textarea{width:100%}
.say-main .imgpreview{margin:0 0 8px}
.say-main #chatmsg{min-height:16px;font-size:12px;padding:4px 2px 0}
@media(max-width:900px){#lbprev,#lbnext{width:48px;height:48px;font-size:30px}#lbprev{left:8px}#lbnext{right:8px}}
@media(max-width:640px){.imgpreview{grid-template-columns:repeat(3,78px)}.imgthumb,.imgthumb img{width:78px;height:78px}
  .say{flex-wrap:wrap}.say-main{flex-basis:100%}.say .btn{flex:1}}
.pcard{display:block;border-radius:10px;transition:background .15s}
.pcard:hover{background:var(--lace);padding-left:8px;padding-right:8px}
.lb{position:fixed;inset:0;z-index:999;background:rgba(10,12,16,.84);display:flex;align-items:center;justify-content:center;cursor:zoom-out}
.lb[hidden]{display:none}
.lb img{max-width:92vw;max-height:88vh;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.4)}
.lb>button{position:absolute;width:42px;height:42px;border-radius:50%;border:1px solid rgba(255,255,255,.35);background:rgba(255,255,255,.16);color:#fff;font-size:24px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center}
#lbprev,#lbnext{top:50%;transform:translateY(-50%);z-index:3;background:rgba(0,0,0,.58)}#lbprev{left:18px}#lbnext{right:18px}#lbx{top:18px;right:18px;font-size:26px;z-index:3}
#lbcounter{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);color:#fff;font-size:12px;background:rgba(0,0,0,.35);border-radius:999px;padding:4px 10px}
.lb button{position:absolute;top:14px;right:18px;width:40px;height:40px;border-radius:50%;border:0;background:rgba(255,255,255,.14);color:#fff;font-size:24px;cursor:pointer}
.topact{display:flex;align-items:center;gap:8px}
/* 详情栏宽度/断点统一由 shell.css 管理（420–520 吸顶栏 + 窄屏 460 抽屉） */
@media (max-width:900px){.app.with-detail{grid-template-columns:1fr}}
.detail .postdetail-pane{position:static;max-height:none;overflow:visible}
.mobnav{display:none}
.mnav{display:none}
@media (max-width:900px){
  .mobnav{display:none}
  .mnav{display:flex;flex-direction:column;gap:2px;margin-bottom:8px}
  .mobitem{display:flex;flex-direction:column;align-items:center;gap:2px;font-size:10px;color:var(--ink-soft);padding:3px 0}
  .mobitem svg{width:18px;height:18px}
  .mobitem.on{color:var(--ink)}
  .mobitem.on svg{color:var(--powder-deep)}
  #qrbtn{display:none}
}
.qrmodal{position:fixed;inset:0;z-index:1000;background:rgba(10,12,16,.55);display:flex;align-items:center;justify-content:center}
.qrmodal[hidden]{display:none}
.qrcard{background:var(--apron);border:1px solid var(--hair);border-radius:18px;padding:20px;width:min(300px,90vw);text-align:center;box-shadow:0 24px 60px rgba(0,0,0,.25)}
#qrbox{display:flex;justify-content:center;margin:14px 0}
#qrbox img,#qrbox canvas{width:220px;height:220px}
#qrurl{font-size:10px;word-break:break-all;color:var(--ink-soft);max-height:44px;overflow:auto;margin-bottom:10px}
.qracts{display:flex;gap:8px;justify-content:center}
.qrca{margin-bottom:8px}
.qrhint{font-size:11px;line-height:1.6;color:var(--ink-soft);margin:8px 0 10px;text-align:left}
.qrhint b{color:var(--ink)}
.share .compose,.share .board-add,.share .settings-key,.share .inbox-read,.share form[action="/app/post"]{display:none}
.share .say{display:flex;opacity:.62;pointer-events:none}
.sharebar{padding:7px 14px;border-bottom:1px solid var(--hair);background:#FFF6E6;color:#7a5b1d;font-size:12px;line-height:1.5}
.sharebar a{color:#5b4310;text-decoration:underline}
.unread{font-weight:600}
.aitem.on{background:var(--powder-light)}
.sidebox{padding:4px 2px}
.shead{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-soft);padding:6px 6px 8px}
.aitem,.citem{display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:10px;cursor:pointer;font-size:14px}
.aitem:hover,.citem:hover{background:var(--lace)}
.citem.on{background:var(--powder-light)}
.aitem .dot{width:7px;height:7px;border-radius:50%;background:var(--powder-deep);flex:0 0 auto}
.aitem .dot.off{background:var(--pearl)}
.aitem .when{margin-left:auto;font-size:12px}
.citem .cname{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sidebox .tag{margin:2px 4px 2px 0}
.citem .dim{white-space:nowrap}
.empty-log{display:flex;align-items:center;justify-content:center;height:100%;color:var(--ink-soft);font-size:13px}
.sec{margin-bottom:12px;padding:18px 20px}
.kv{display:grid;grid-template-columns:170px minmax(0,1fr);gap:12px;align-items:center;padding:9px 0;border-bottom:1px solid var(--hair);font-size:14px}
.kv:last-child{border-bottom:0}
.kv>span:first-child{color:var(--ink-soft);font-size:13px}
.settings-key>span:last-child{display:flex;align-items:center;gap:8px;min-width:0}
.settings-key>span:last-child input{flex:1 1 auto;min-width:0;width:auto}
.settings-key>span:last-child .btn{flex:0 0 auto;white-space:nowrap;min-width:64px;justify-content:center}
.theme{border-color:var(--pearl);background:var(--apron);color:var(--ink)}
.theme.on{border-color:var(--powder-deep);background:var(--powder-light)}
.rows .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:9px 0;border-bottom:1px solid var(--hair);font-size:14px}
.rows .row:last-child{border-bottom:0}
.grid,.card,.pane,main{min-width:0}
.grid>*{min-width:0}
#update{min-width:0}
#update .kv{display:grid;grid-template-columns:minmax(120px,170px) minmax(0,1fr)}
#update .kv b{overflow-wrap:anywhere;word-break:break-word}
@media (max-width:1200px){#update .kv{display:grid;grid-template-columns:minmax(0,1fr)}#update .kv>b{text-align:left}#update .kv>span,#update .kv>b{min-width:0;max-width:100%;overflow-wrap:anywhere;word-break:break-word}}
.update-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
.update-actions .btn:disabled{opacity:.45;cursor:not-allowed}
#updates .kv>span:last-child{display:flex;gap:8px;align-items:center;min-width:0}
#updates .kv select{flex:1 1 auto;min-width:0;width:auto}
#updates .kv .btn{flex:0 0 auto;white-space:nowrap;min-width:64px;justify-content:center}
.tool-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;margin-top:14px}
.tool-form{display:flex;gap:8px;align-items:center;flex-wrap:wrap;min-width:0;margin:0}
.tool-actions .tool-form{flex:1 1 300px}
.tool-form input[type="password"],.tool-form input[type="text"]{flex:1 1 160px;min-width:0;width:auto;max-width:280px}
.tool-form .keep-input{flex:0 0 64px;width:64px;max-width:64px;text-align:center}
.tool-form .btn{flex:0 0 auto;white-space:nowrap}
.tool-import{margin-top:10px}
.tool-import input[type="file"]{flex:1 1 260px;min-width:0;max-width:520px;width:auto}
.tool-import .btn{flex:0 0 auto}
.table-wrap{width:100%;overflow-x:auto;margin-top:8px}
.tool-table{width:100%;border-collapse:collapse;font-size:13px;line-height:1.6}
.tool-table th,.tool-table td{padding:9px 8px;border-bottom:1px solid var(--hair);vertical-align:top;text-align:left}
.tool-table th{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-soft);font-weight:500;white-space:nowrap}
.tool-table td.mono{font-family:ui-monospace,Menlo,monospace;font-size:11.5px;overflow-wrap:anywhere}
.inline-form{display:inline;margin:0}
.card pre{max-width:100%;overflow-x:auto;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word}
.ritem,.pcard p,.body,.addr,.kv{overflow-wrap:anywhere}
.bar{flex-wrap:wrap}
@media (max-width:520px){
  .kv{grid-template-columns:1fr;gap:4px}
  .crow{flex-direction:column}
  .crow input,.crow button{width:100%}
  .post .tags{justify-content:flex-start}
  .roomhead{flex-wrap:wrap}
}
.avatar{border-radius:50%;background:var(--powder-light);display:inline-flex;align-items:center;justify-content:center;font-family:var(--serif);font-weight:600}
/* 参与人（t-ec42f5cd）：群页面主区常驻名单，不再依赖右侧详情 */
.room{position:relative}
.peoplebar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px 10px;align-items:center;padding:9px 18px;border-bottom:1px solid var(--hair);background:var(--porcelain)}
.phead{grid-column:1;grid-row:1;display:flex;align-items:baseline;gap:6px;white-space:nowrap;min-width:0}
.phead .kicker{letter-spacing:.12em}
.phead b{font-size:15px}
.phead .dim{font-size:12px}
.plist{grid-column:1/-1;grid-row:2;display:flex;flex-wrap:wrap;align-items:center;gap:6px;min-width:0;overflow:hidden}
.pchip{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--hair);background:var(--apron);border-radius:999px;padding:2px 9px 2px 3px;font-size:12px;line-height:1.5;max-width:100%;min-width:0;flex-wrap:wrap;overflow:hidden}
.pchip .pill{width:22px;height:22px;border-radius:50%;display:block;flex:0 0 auto}
.pchip .pname{font-size:13px;font-weight:600;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}
.pchip .pid{font-size:12px;color:var(--ink-soft);white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}
.pchip .pnode{font-size:12px;color:#4f6072;background:var(--lace);border:1px solid var(--hair);border-radius:6px;padding:0 5px;white-space:nowrap}
.mwho .mnode{font-size:12px;color:#4f6072;background:var(--lace);border:1px solid var(--hair);border-radius:6px;padding:0 5px;white-space:nowrap}
.pchip .prole{font-size:12px;color:#3c5f7a;background:#EAF3FB;border:1px solid #D6E7F5;border-radius:999px;padding:0 6px;white-space:nowrap}
.pstate{display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--ink-soft);white-space:nowrap}
.pdot{width:7px;height:7px;border-radius:50%;background:#c3c9d1;display:inline-block;flex:0 0 auto}
.pchip.online .pdot,.memberrow.online .pdot{background:var(--ok);box-shadow:0 0 0 2px rgba(63,143,107,.14)}
.pchip.offline{background:var(--porcelain)}
.pchip.offline .pname{color:var(--ink-soft)}
.plink{grid-column:2;grid-row:1;justify-self:end;border:1px solid var(--pearl);background:var(--apron);color:var(--ink-soft);font-size:12px;cursor:pointer;padding:3px 10px;border-radius:999px;white-space:nowrap}
.plink:hover{border-color:var(--powder-deep);color:var(--ink)}
.ptable{padding:8px 18px 12px;border-bottom:1px solid var(--hair);background:var(--porcelain);display:grid;grid-template-columns:repeat(auto-fill,minmax(310px,1fr));gap:4px 14px}
.ptable[hidden]{display:none}
.ptable .memberrow{padding:4px 0;border-radius:8px}
/* 实时回合条：把“收到了 / 谁在说 / 第几轮 / 还剩几秒”从盲盒变成可见 */
.liveturn{display:flex;align-items:center;gap:7px;padding:8px 18px;border-bottom:1px solid var(--hair);
  background:linear-gradient(90deg,var(--powder-light),var(--apron));font-size:13px;color:var(--ink-soft);min-height:36px}
.liveturn[hidden]{display:none}
.liveturn .livedot{width:8px;height:8px;border-radius:50%;background:var(--powder-deep);flex:0 0 auto}
.liveturn.busy .livedot{background:var(--ok);box-shadow:0 0 0 3px rgba(63,143,107,.14)}
.liveturn b{color:var(--ink);font-weight:600}
.liveturn .livesep{color:var(--pearl)}
.liveturn .liveclock{margin-left:auto;font-variant-numeric:tabular-nums;color:#3c5f7a;font-weight:600}
.liveturn.sent{background:#FFF6E6;border-bottom-color:#F2DCAE;color:#7a5b1d}
@media (max-width:640px){.liveturn{padding:7px 12px;font-size:12px}.liveturn .liveclock{margin-left:auto}}
.memberrow{display:flex;align-items:center;gap:8px;font-size:13px;min-width:0}
.memberrow .pill{width:24px;height:24px;border-radius:50%;flex:0 0 auto}
.mwho{display:flex;align-items:baseline;gap:4px;flex-wrap:wrap;min-width:0}
.mwho .mrole{font-size:12px}
.mstate{margin-left:auto;display:inline-flex;align-items:center;gap:5px;font-size:12px;color:var(--ink-soft);white-space:nowrap}
.mstate .dim{font-size:12px}
.tag.off{color:#8a5a00;background:#FFF4E0;border-color:#F2DCAE}
.newpill{position:absolute;left:50%;transform:translateX(-50%);bottom:170px;z-index:3;border:1px solid var(--powder-deep);background:var(--apron);color:#3c5f7a;border-radius:999px;padding:5px 12px;font-size:12px;box-shadow:0 6px 18px rgba(22,24,28,.14);cursor:pointer}
.newpill[hidden]{display:none}
.citem .rdot{width:7px;height:7px;border-radius:50%;flex:0 0 auto;background:var(--pearl)}
.citem .rdot.running{background:var(--ok)}
.citem .rdot.ended{background:#c3c9d1}
.citem .rdot.open{background:var(--powder-deep)}
.citem .cname{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.log{overflow-anchor:none}
@media (max-width:640px){.peoplebar{padding:8px 12px;min-width:0}.plist{gap:5px;overflow:hidden}.pchip{max-width:100%;min-width:0}.pchip .pid{max-width:100%}.newpill{bottom:196px}}
"""
# 本地详情栏/抽屉样式独立保存：sync_ui_from_center.py 会覆盖 shell.css，
# 不能把这些本地专用规则放回 shell.css。
LOCAL_CSS += "\n" + _asset("local-detail.css")
# 手机端 IA：底部只留「分发 / 通讯簿 / 留言 / 设置」；桌面端不显示。
LOCAL_CSS += """
@media (max-width:640px){
  .mobnav{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:60;justify-content:space-around;
    background:var(--apron);border-top:1px solid var(--hair);padding:4px 6px calc(4px + env(safe-area-inset-bottom))}
  .mobitem{flex:1;min-height:44px;justify-content:center;text-decoration:none}
  .pane main{padding-bottom:76px}
  .app.chats-page.chat-open .mobnav{display:none}
  .mact{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
  .mact .btn{padding:5px 10px;font-size:12px;min-height:0}
  .mhero{display:grid;gap:8px}
  .mhero h2{margin:0;font-size:20px}
  .mhero p{margin:0;color:var(--ink-soft);font-size:13px;line-height:1.6}
  .mrow{padding:10px 0;border-bottom:1px solid var(--hair)}
  .mrow:last-child{border-bottom:0}
  .mrow b{display:block;font-size:14px;line-height:1.45}
  .mrow .mmeta{color:var(--ink-soft);font-size:12px;margin-top:2px}
  .cpeople{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px}
  .cperson{display:flex;align-items:center;gap:8px;border:1px solid var(--hair);border-radius:10px;padding:8px;text-decoration:none;color:inherit;background:var(--apron)}
  .cperson .pill{width:30px;height:30px;border-radius:50%;flex:0 0 auto}
  .cperson .cwho{min-width:0}
  .cperson .cwho b{display:block;font-size:13px}
  .cperson .cwho span{display:block;color:var(--ink-soft);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .cacts{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
  .cacts .btn{padding:4px 9px;font-size:12px;min-height:0}
}
"""

NAV = [
    ("chats", "/app/chats", "会话", "chats"),
    ("feed", "/app/feed", "频道", "feed"),
    ("inbox", "/app/inbox", "收件箱", "inbox"),
    ("board", "/app/board", "看板", "board"),
    ("team", "/app/team", "团队", "team"),
    ("tools", "/app/tools", "工具", "tools"),
    ("moments", "/app/moments", "朋友圈", "moments"),
    ("version", "/app/version", "版本", "version"),
]
# 手机端 IA：只留“分发 / 通讯簿 / 留言”。手机不是协作台，聊天降级为异步留言。
MOBILE_NAV = [
    ("dist", "/app", "分发", "feed"),
    ("contacts", "/app/team", "通讯簿", "team"),
    ("messages", "/app/chats", "留言", "chats"),
]
MOBILE_PAGE_KEY = {"home": "dist", "team": "contacts", "chats": "messages"}
TITLES = {
    "home": ("首页", "团队动态与最近工作"),
    "chats": ("会话", "和团队、和你的 agent 说话"),
    "feed": ("频道", "本地的工作与交付记录"),
    "inbox": ("收件箱", "需要你处理的事"),
    "board": ("看板", "任务进度"),
    "team": ("团队", "成员与 agent"),
    "version": ("版本", "版本迭代"),
    "settings": ("设置", "账号、模型与界面"),
}


def esc(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _locale() -> str:
    """?lang= 优先（便于自检/分享），其次 Cookie，最后中文。"""
    try:
        q = (request.args.get("lang") or "").strip()
        return i18n.locale_of(q or request.cookies.get("taa_lang"))
    except Exception:
        return i18n.DEFAULT


def tr(key: str, default: str) -> str:
    """页面模板用：从当前请求语言取 locale，没请求时回退中文。"""
    return i18n.t(key, default, _locale())


def _is_mobile() -> bool:
    """手机 UA 判定：手机 = 分发页 + 通讯簿，桌面 = 协作台（见 docs/329）。"""
    ua = (request.headers.get("User-Agent") or "").lower()
    return any(k in ua for k in ("iphone", "ipad", "android", "mobile", "harmonyos", "micromessenger"))


def clean(text) -> str:
    """数据里遗留的 "human," / "jiyan," 前缀只在展示层去掉。"""
    return re.sub(r"^(human|jiyan|user)\s*[,，:：]\s*", "", str(text or ""), flags=re.I)


def _same_host(url: str) -> str:
    """本机 :6080 的 /static 图片改成相对路径，换机/手机也能打开。"""
    return re.sub(r"^https?://[^/]+(/static/.*)$", r"\1", url)


def _img_tag(alt, url: str) -> str:
    rel = _same_host(url)
    if rel.startswith("/static/"):
        if not (ROOT / rel.lstrip("/")).exists():
            return f'<span class="img-missing">{tr("feed.img_missing", "[图片缺失]")} {alt}</span>'
    return (f'<img class="inline-img" alt="{alt}" src="{esc(thumbnails.thumb_url(rel))}" '
            f'loading="lazy" decoding="async" data-full="{esc(rel)}" '
            f'onerror="this.style.display=\'none\'">')


def md_html(text) -> str:
    """完整 Markdown（extra：表格/围栏代码/列表；nl2br）；先转义原始 HTML 再渲染。"""
    raw = clean(text)
    # 允许内容里的 <img src="..."> 转成 Markdown 图片
    raw = re.sub(r'<img[^>]+src=["\']([^"\']+)["\'][^>]*>', lambda m: f"![]({m.group(1)})", raw, flags=re.I)
    safe = raw.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    out = mdlib.markdown(safe, extensions=["extra", "sane_lists", "nl2br"], output_format="html5")

    def img(m):
        tag = m.group(0)
        sm = re.search(r'src="([^"]+)"', tag)
        if not sm:
            return tag
        rel = _same_host(sm.group(1))
        if rel.startswith("/static/") and not (ROOT / rel.lstrip("/")).exists():
            am = re.search(r'alt="([^"]*)"', tag)
            return f'<span class="img-missing">{tr("feed.img_missing", "[图片缺失]")} {am.group(1) if am else ""}</span>'
        tag = re.sub(r'src="[^"]*"', f'src="{rel}"', tag, count=1)
        if "class=" not in tag:
            tag = tag.replace("<img ", '<img class="inline-img" ', 1)
        if "data-full=" not in tag:
            tag = tag.replace("<img ", f'<img data-full="{rel}" onerror="this.style.display=\'none\'" ', 1)
        return tag

    out = re.sub(r"<img[^>]*>", img, out)
    out = re.sub(r"<(/?)h([1-5])>", lambda m: f"<{m.group(1)}h{min(6, int(m.group(2)) + 1)}>", out)
    out = re.sub(r'(href|src)="javascript:[^"]*"', r'\1="#"', out)
    return out


def md_plain(text) -> str:
    """首页摘要：去掉图片/链接/标记，只留可读文字。"""
    t = clean(text)
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", t)
    t = re.sub(r"[`*_>#]+", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t[:180]


def _share_secret() -> bytes:
    p = ROOT / ".share_secret"
    if not p.exists():
        p.write_text(base64.urlsafe_b64encode(os.urandom(32)).decode(), encoding="utf-8")
        p.chmod(0o600)
    return p.read_text(encoding="utf-8").strip().encode()


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def share_token(path: str, hours: int = 24, write: bool = False,
                viewer_id: str = "", viewer_name: str = "", owner_id: str = "") -> str:
    payload = {"p": path, "e": int(time.time()) + hours * 3600,
               "w": 1 if write else 0}
    if viewer_id:
        payload.update({"viewer_id": viewer_id[:80],
                        "viewer_name": viewer_name[:80],
                        "owner_id": owner_id[:80]})
    body = _b64(json.dumps(payload, ensure_ascii=False).encode())
    sig = _b64(hmac.new(_share_secret(), body.encode(), hashlib.sha256).digest())
    return body + "." + sig


def share_viewer():
    """Viewer identity carried by a signed share link (None for legacy links)."""
    try:
        data = share_verify(request.cookies.get("taa_share", ""))
        if data and data.get("viewer_id"):
            return {"id": str(data["viewer_id"]), "name": str(data.get("viewer_name") or data["viewer_id"]),
                    "owner_id": str(data.get("owner_id") or "")}
    except Exception:  # noqa: BLE001
        pass
    return None


def share_claims():
    """Signed share claims, including legacy write links without viewer_id."""
    try:
        return share_verify(request.cookies.get("taa_share", ""))
    except Exception:  # noqa: BLE001
        return None


def chat_viewer(c, *, ensure: bool = True) -> dict:
    v = share_viewer()
    if v:
        if ensure:
            try:
                ensure_remote_stub(c, agent_id=v["id"], name=v["name"], kind="human",
                                   full_name=f"{v['name']}@center",
                                   owner_id=v["owner_id"], owner_name=v["name"])
                c.commit()
            except Exception:  # noqa: BLE001
                pass
        return v
    claims = share_claims()
    # TAA has exactly two identities: Owner and Agent.  A share token without
    # a viewer claim is not a login and must not mint a synthetic "guest".
    if claims:
        return None
    return {"id": human_id(c), "name": owner_display_name(c), "owner_id": _center_owner_id()}


def share_verify(tok: str):
    try:
        body, sig = tok.split(".", 1)
        want = _b64(hmac.new(_share_secret(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, want):
            return None
        data = json.loads(_unb64(body))
        if int(data.get("e", 0)) < time.time():
            return None
        return data
    except Exception:  # noqa: BLE001
        return None


def is_share() -> bool:
    try:
        data = share_verify(request.cookies.get("taa_share", ""))
        return bool(data and not data.get("w"))
    except Exception:  # noqa: BLE001
        return False


def _tls_ready() -> bool:
    return (os.environ.get("TEAM_TLS", "1") != "0"
            and (ROOT / "certs/server.crt").exists()
            and (ROOT / "certs/server.key").exists())


def share_base() -> str:
    """二维码/分享链接：手机必须用 LAN IP；绝不把 .local/机器名塞进微信。"""
    env = os.environ.get("TAA_SHARE_BASE", "").rstrip("/")
    if env:
        return env
    host = request.host
    name = host.split(":")[0]

    def lan_ip() -> str:
        cands = []
        try:
            for info in socket.getaddrinfo(socket.gethostname(), None):
                ip = info[4][0]
                if re.match(r"^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))\.", ip):
                    cands.append(ip)
        except Exception:  # noqa: BLE001
            pass

        def rank(ip: str) -> int:
            return 0 if ip.startswith("192.168.") else 1 if ip.startswith("10.") else 2

        if cands:
            return sorted(set(cands), key=rank)[0]
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sk.connect(("8.8.8.8", 80))
            return sk.getsockname()[0]
        finally:
            sk.close()

    # loopback / mDNS / 单标签机器名：一律换成 LAN IPv4。
    # 明确传入的公网域名（含点且非 .local）保留域名。
    is_ipv4 = bool(re.match(r"^\d{1,3}(?:\.\d{1,3}){3}$", name))
    is_mdns_or_hostname = name.endswith(".local") or ("." not in name)
    # 二维码/分享链接走只读 HTTP 6080；不要求 CA。
    # 完整应用仍走 6443 TLS，二者不是同一入口。
    if is_ipv4 or name in ("127.0.0.1", "localhost", "::1") or is_mdns_or_hostname:
        ip = name if (is_ipv4 and name not in ("127.0.0.1",)) else lan_ip()
        port = os.environ.get("TAA_SHARE_HTTP_PORT") or os.environ.get("TEAM_HTTP_PORT") or "6080"
        return f"http://{ip}:{port}"
    return request.host_url.rstrip("/")


def full_app_base() -> str:
    """只读 HTTP 分享页里的“完整聊天”入口：走 6443 TLS。"""
    try:
        from core import nodeinfo
        ip = nodeinfo.lan_ip() or "127.0.0.1"
    except Exception:  # noqa: BLE001
        ip = request.host.split(":")[0]
    port = int(os.environ.get("TEAM_TLS_PORT") or 6443)
    return f"https://{ip}:{port}"


def fmt_dt(x) -> str:
    """统一时间显示：YYYY-MM-DD HH:MM（用于非消息的本地时间字段）。"""
    return str(x or "")[:16].replace("T", " ")


def fmt_msg_dt(row) -> str:
    """Chat message time: created_at_utc -> local timezone."""
    return timeutil.message_time(row)


def clean_client_message_id(value) -> str:
    text = str(value or "").strip()[:120]
    if not text:
        return ""
    return text if re.fullmatch(r"[A-Za-z0-9._:-]{1,120}", text) else ""


def new_client_message_id() -> str:
    return "cm-" + uuid.uuid4().hex


IMG_EXT = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")


def _transport_image_url(url: str) -> str:
    """Create a bounded WebP transport derivative; the original stays local."""
    raw = str(url or "")
    if not raw.startswith("/static/uploads/") or ".." in raw:
        return raw
    src = ROOT / raw.lstrip("/")
    if not src.is_file() or src.suffix.lower() not in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
        return raw
    if src.stem.endswith("-t"):
        return raw
    dst = src.with_name(src.stem + "-t.webp")
    if dst.is_file() and dst.stat().st_size <= 1024 * 1024:
        return "/static/uploads/" + dst.name
    try:
        from io import BytesIO
        from PIL import Image, ImageOps
        im = Image.open(src)
        im = ImageOps.exif_transpose(im)
        if getattr(im, "is_animated", False):
            im.seek(0)
        im.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGB")
        # Target <=500KB; hard ceiling 1MB.
        for quality, edge in ((80, 1600), (72, 1400), (64, 1200), (55, 1000)):
            work = im.copy()
            work.thumbnail((edge, edge), Image.Resampling.LANCZOS)
            buf = BytesIO()
            work.save(buf, format="WEBP", quality=quality, method=6)
            data = buf.getvalue()
            if len(data) <= 1024 * 1024:
                dst.write_bytes(data)
                return "/static/uploads/" + dst.name
    except Exception:  # noqa: BLE001
        return raw
    return raw


def _sniff_image_type(raw: bytes) -> str:
    """按文件头识别常见图片，避免只依赖远端 Content-Type。"""
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if raw.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "image/webp"
    if raw[:2] == b"BM":
        return "image/bmp"
    return ""


# 单图上传上限：25MB（2026-10-31 Step4，由 10MB 上调）。
# 依据：全站请求体上限 32MB（core/hub.py），留 7MB 给 multipart 开销；
# 前端已做长边 ≤2560 的预压缩，正常截图/网页图进不到这个量级，此值只作兜底。
# 上传与远端抓取（/app/fetch-image）共用本常量，避免两处漂移。
IMG_MAX_BYTES = 25 * 1024 * 1024


def _upload_reject(reason: str, *, name: str = "", ext: str = "", mime: str = "",
                   size: int = 0) -> str:
    """上传被拒：返回**带数字**的文案，并落一行 JSON 留痕（best-effort）。

    2026-10-31 事故：连续 10 次 `POST /app/upload` 400，却查不出是体积还是格式
    —— 三个 400 出口都把原因吞了，只能靠事后推理。这里补两件事：
      1) 文案带具体数字（多少 MB / 什么后缀），用户一眼能懂；
      2) 留痕到 `<TAA_HOME>/run/upload_reject.log`，下次复现直接有铁证。
    写日志失败绝不影响响应（本地个人实例，宁可少记不可阻断）。
    """
    size = int(size or 0)
    if reason == "too_large":
        msg = (f"图片 {size / 1024 / 1024:.1f}MB，超过 "
               f"{IMG_MAX_BYTES / 1024 / 1024:.0f}MB 上限")
    elif reason == "bad_ext":
        msg = f"不支持的图片格式：{ext or '(无后缀)'}，请用 png/jpg/gif/webp/bmp"
    else:
        msg = "没有收到文件"
    try:
        # 安装实例：TAA_HOME=~/.taa → ~/.taa/run/upload_reject.log（正确位置）。
        # 开发树未设 TAA_HOME 时会落到仓库父目录的 run/；跑测试请显式设 TAA_HOME。
        home = pathlib.Path(os.environ.get("TAA_HOME") or ROOT.parent).expanduser()
        d = home / "run"
        d.mkdir(parents=True, exist_ok=True)
        rec = {"ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
               "reason": reason, "name": str(name or "")[:80], "ext": ext,
               "mime": mime, "bytes": size, "limit": IMG_MAX_BYTES, "msg": msg}
        with (d / "upload_reject.log").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:  # noqa: BLE001
        pass
    return msg


def _remote_image_error(url: str) -> str:
    """校验远端图片 URL（只允许 http/https + 公网地址），返回错误文案，空串表示通过。

    t-df77daf8：网页图片跨源时浏览器取不到，改由服务端代理抓取；
    这里做 SSRF 护栏，避免把内网/本机地址当图片源。
    """
    try:
        p = urllib.parse.urlsplit(url)
    except Exception:  # noqa: BLE001
        return "图片地址无效"
    if p.scheme not in ("http", "https") or not p.hostname:
        return "只支持 http/https 图片地址"
    if os.environ.get("TEAMAI_ALLOW_LOCAL_IMAGE_FETCH") == "1":
        return ""
    try:
        infos = socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme == "https" else 80),
                                   type=socket.SOCK_STREAM)
    except Exception:  # noqa: BLE001
        return "图片域名解析失败"
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            return "图片域名解析失败"
        if not ip.is_global:
            return "不允许访问内网地址"
    return ""


def _atts(raw) -> list[dict]:
    try:
        v = json.loads(raw) if raw else []
    except Exception:  # noqa: BLE001
        v = [raw] if isinstance(raw, str) and raw.strip() else []
    if isinstance(v, dict):
        v = [v]
    out = []
    for x in v if isinstance(v, list) else []:
        if isinstance(x, str):
            u, name = x, x.rsplit("/", 1)[-1]
        elif isinstance(x, dict):
            u = str(x.get("url") or x.get("path") or "")
            name = str(x.get("name") or u.rsplit("/", 1)[-1])
        else:
            continue
        if u:
            out.append({"url": u, "name": name})
    return out


_MD_EXT = (".md", ".markdown")
_CSV_EXT = (".csv", ".tsv")
_TXT_EXT = (".txt", ".log", ".json", ".yaml", ".yml")
_VIDEO_EXT = (".mp4", ".webm", ".mov", ".m4v")


def _att_roots() -> tuple[Path, ...]:
    """附件可读文件的合法根（越界护栏的白名单）。

    ★ 不能只认 ROOT：安装版把 `static/uploads`、`agents`、`bootstrap` 软链到
      `$TAA_HOME/…`（升级不丢数据），软链 `resolve()` 后会落到 ROOT 之外。
      只按 ROOT 判越界 → 附件解析全部失败 → md/csv/txt 退化成下载链接。
      2026-10-31 实测：`/app/p/<id>` 详情页的 md 附件内嵌失效，根因即此。
    """
    cands = (ROOT, ROOT / "static", ROOT / "static" / "uploads",
             ROOT / "agents", ROOT / "bootstrap", ROOT / "deliverables", ROOT / "work")
    roots: list[Path] = []
    for p in cands:
        try:
            rp = p.resolve()
        except OSError:
            continue
        if rp.is_dir() and rp not in roots:
            roots.append(rp)
    return tuple(roots)


def _att_path(url: str):
    """把本机附件 URL 解析成可读文件；外部链接/越界路径返回 None。"""
    raw = str(url or "")
    pu = urllib.parse.urlparse(raw)
    path = urllib.parse.unquote(pu.path)
    if pu.scheme and pu.scheme not in ("http", "https"):
        return None
    if path.startswith("/static/"):
        f = ROOT / path.lstrip("/")
    elif path.startswith("/deliverables/"):
        f = ROOT / "deliverables" / path[len("/deliverables/"):]
    elif path.startswith("/work/"):
        f = ROOT / path.lstrip("/")
    elif not path.startswith("/") and path:
        f = ROOT / path
    else:
        return None
    try:
        f = f.resolve()
    except OSError:
        return None
    # 越界判定用白名单根：ROOT 本身 + 数据软链的解析目标（见 _att_roots）
    if not any(f == r or f.is_relative_to(r) for r in _att_roots()):
        return None
    return f if f.is_file() else None


def _md_att_html(name: str, url: str, path) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")[:200_000]
    except OSError:
        return f'<a class="attfile" href="{esc(url)}" target="_blank" rel="noopener">📄 {esc(name)}</a>'
    # 相对图片按附件所在目录解析，避免右侧栏里图片 404。
    base = urllib.parse.urljoin(str(url), "./")
    text = re.sub(r"!\[([^\]]*)\]\((?!https?://|/|data:)([^)]+)\)",
                  lambda m: f"![{m.group(1)}]({urllib.parse.urljoin(base, m.group(2))})", text)
    return (f'<details class="att-doc att-md" open><summary><span>📄 {esc(name)}</span>'
            f'<a class="attfile" href="{esc(url)}" download>下载原文</a></summary>'
            f'<div class="att-md-body">{md_html(text)}</div></details>')


def _csv_att_html(name: str, url: str, path) -> str:
    try:
        with path.open(newline="", encoding="utf-8", errors="replace") as fh:
            rows = list(csv.reader(fh, delimiter="\t" if path.suffix.lower() == ".tsv" else ","))[:60]
    except OSError:
        return f'<a class="attfile" href="{esc(url)}" target="_blank" rel="noopener">📊 {esc(name)}</a>'
    if not rows:
        return f'<a class="attfile" href="{esc(url)}" target="_blank" rel="noopener">📊 {esc(name)}</a>'
    head = "".join(f"<th>{esc(x)}</th>" for x in rows[0])
    body = "".join("<tr>" + "".join(f"<td>{esc(x)}</td>" for x in row) + "</tr>" for row in rows[1:])
    return (f'<details class="att-doc att-csv" open><summary><span>📊 {esc(name)}</span>'
            f'<a class="attfile" href="{esc(url)}" download>下载原文</a></summary>'
            f'<div class="att-table"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div></details>')


def _video_att_html(name: str, url: str) -> str:
    return (f'<div class="att-video"><video class="post-video" src="{esc(url)}" controls '
            f'playsinline webkit-playsinline preload="none"></video>'
            f'<div class="att-video-name">🎬 {esc(name)} · '
            f'<a class="attfile" href="{esc(url)}" target="_blank" rel="noopener">打开 / 下载</a></div></div>')


def _att_html(raw, cls: str = "atts", grid: bool = False, detail: bool = False) -> str:
    items = _atts(raw)
    if not items:
        return ""
    bits = []
    for a in items[:8]:
        u, n = a["url"], a["name"]
        low = u.lower().split("?")[0]
        if low.endswith(IMG_EXT):
            rel = _same_host(u)
            if rel.startswith("/static/") and not (ROOT / rel.lstrip("/")).exists():
                bits.append(f'<span class="img-missing">{tr("feed.img_missing", "[图片缺失]")} {esc(n)}</span>')
            else:
                local_missing = (not rel.startswith(("http://", "https://", "/"))
                                 and not (ROOT / rel).exists())
                if local_missing:
                    bits.append(f'<span class="img-missing">{tr("feed.img_missing", "[图片缺失]")} {esc(n)}</span>')
                else:
                    # 聊天/朋友圈历史里常有 1–2MB 原图；一次渲染 200 条消息时
                    # eager 加载会把全部图片拉下来。懒加载只取viewport附近。
                    bits.append(f'<img class="{cls}-img" src="{esc(thumbnails.thumb_url(rel))}" '
                                f'alt="{esc(n)}" loading="lazy" decoding="async" '
                                f'data-full="{esc(rel)}" onerror="this.style.display=\'none\'">')
        elif detail and low.endswith(_VIDEO_EXT):
            bits.append(_video_att_html(n, u))
        elif detail and low.endswith(_MD_EXT):
            path = _att_path(u)
            bits.append(_md_att_html(n, u, path) if path else f'<a class="attfile" href="{esc(u)}" target="_blank" rel="noopener">📄 {esc(n)}</a>')
        elif detail and low.endswith(_CSV_EXT):
            path = _att_path(u)
            bits.append(_csv_att_html(n, u, path) if path else f'<a class="attfile" href="{esc(u)}" target="_blank" rel="noopener">📊 {esc(n)}</a>')
        elif detail and low.endswith(_TXT_EXT) and _att_path(u):
            try:
                txt = _att_path(u).read_text(encoding="utf-8", errors="replace")[:50_000]
                bits.append(f'<details class="att-doc att-txt" open><summary>📄 {esc(n)}</summary><pre>{esc(txt)}</pre></details>')
            except OSError:
                bits.append(f'<a class="attfile" href="{esc(u)}" target="_blank" rel="noopener">📄 {esc(n)}</a>')
        elif low.endswith(_MD_EXT + _CSV_EXT + _TXT_EXT + _VIDEO_EXT):
            bits.append(f'<span class="attchip" title="{tr("att.read_hint", "点开帖子后在右栏内嵌阅读/播放")}">'
                        f'{"🎬" if low.endswith(_VIDEO_EXT) else "📄"} {esc(n)}</span>')
        else:
            bits.append(f'<a class="attfile" href="{esc(u)}" target="_blank" rel="noopener">{esc(n)}</a>')
    n_img = sum(1 for a in items if a["url"].lower().split("?")[0].endswith(IMG_EXT))
    suffix = (f" grid{n_img}" if 1 <= n_img <= 4 else " grid9") if (grid and n_img) else ""
    klass = cls + suffix
    return f'<div class="{klass}">{"".join(bits)}</div>'


def icon(k: str, size: int = 20) -> str:
    body = ICONS.get(k, "")
    return (f'<svg viewBox="0 0 24 24" width="{size}" height="{size}" fill="none" stroke="currentColor" '
            f'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{body}</svg>')


IMG_FALLBACK_JS = r"""<script>
(function(){
  var SEL = ".chatatt-img, .atts-img, .inline-img, .msg-img, .dm-img, .post-img, .post-thumb, .mgrid-img, .attach-thumb";
  function fbFor(img){
    if(!img || img.dataset.fbApplied === "1") return;
    img.dataset.fbApplied = "1";
    var src = img.currentSrc || img.getAttribute("src") || "";
    var name = (img.getAttribute("alt") || "").trim();
    if(!name || /^(图片|image)$/i.test(name)){
      try { name = decodeURIComponent(src.split("?")[0].split("#")[0].split("/").pop() || ""); }
      catch(e) { name = ""; }
    }
    name = name || "图片";
    var fb = document.createElement("span");
    fb.className = "img-fallback";
    fb.dataset.src = src;
    fb.dataset.cls = img.className || "";
    fb.setAttribute("role", "img");
    fb.setAttribute("aria-label", "图片加载失败：" + name);
    fb.innerHTML = '<span class="img-fallback-icon" aria-hidden="true">🖼</span>'
      + '<span class="img-fallback-main"><span class="img-fallback-name"></span>'
      + '<span class="img-fallback-hint">图片加载失败，附件可能已不在本机</span></span>'
      + '<span class="img-fallback-acts"><button type="button" class="img-fallback-retry">重试</button></span>';
    fb.querySelector(".img-fallback-name").textContent = name;
    var acts = fb.querySelector(".img-fallback-acts");
    var btn = fb.querySelector(".img-fallback-retry");
    btn.onclick = function(){
      btn.disabled = true; btn.textContent = "重试中…";
      var probe = new Image();
      probe.className = img.className || "";
      probe.alt = img.getAttribute("alt") || "";
      probe.dataset.full = src;
      probe.onload = function(){ fb.replaceWith(probe); };
      probe.onerror = function(){
        btn.disabled = false; btn.textContent = "重试";
        fb.classList.add("retry-failed");
        fb.querySelector(".img-fallback-hint").textContent = "重试仍未成功，请确认附件是否已上传到本机";
      };
      probe.src = src + (src.indexOf("?") >= 0 ? "&" : "?") + "_retry=" + Date.now();
    };
    if(/^(https?:\/\/|\/)/i.test(src)){
      var open = document.createElement("a");
      open.className = "img-fallback-open";
      open.href = src; open.target = "_blank"; open.rel = "noopener";
      open.textContent = "打开原图";
      acts.appendChild(open);
    }
    img.replaceWith(fb);
  }
  document.addEventListener("error", function(e){
    var t = e.target;
    if(t && t.tagName === "IMG" && t.matches(SEL)) fbFor(t);
  }, true);
  window.addEventListener("load", function(){
    document.querySelectorAll(SEL).forEach(function(im){
      if(im.complete && im.naturalWidth === 0 && im.getAttribute("src")) fbFor(im);
    });
  });
})();
</script>"""


JS_I18N = {
    "detail": "详情", "copy": "复制", "copied": "已复制", "copy_failed": "复制失败",
    "gallery": "画廊", "detail_title": "消息详情", "copy_body": "复制正文",
    "mention": "@ 提及", "prev": "上一条", "next": "下一条", "locate": "定位到消息",
    "back": "返回会话", "body": "正文", "context": "上下文", "attachments": "附件",
    "meta": "元数据", "note": "说明", "author": "作者", "time": "时间",
    "msgid": "消息号", "position": "位置", "page_first_last": "已是本页第一条/最后一条。",
    "detail_hint": "点主区其他消息或「上一条 / 下一条」可切换；窄屏下抽屉自动打开。",
    "copy_hint": "「复制正文」只复制文字，图片请点附件另存。",
    "loaded": "（本页已载入）", "upload_failed": "上传失败", "upload_retry": "请重试",
    "upload_reading": "正在读取剪贴板图片…", "upload_wait": "图片上传中，请稍候…",
    "copy_ok": "已复制", "copy_fail": "复制失败", "no_image": "没有取到图片；请用「图片」按钮选择文件",
    "max9": "最多 9 张图", "uploading": "正在上传图片…",
    "clipboard_ref": "剪贴板里只有图片地址，浏览器取不到图片本身；请用「图片」按钮选择文件",
    "expand": "展开详情", "collapse": "收起详情",
    "online_status": "{online} 在线 · {human} 真人 · {ai} agent", "recent_active": "最近活跃",
    "mention": "在输入框插入 @{id}", "dm": "私信", "chat_with": "和 {name} 私聊",
    "rename": "改名",
}


def shell(title: str, body: str, active: str = "home", subtitle: str = "", side: str = "",
          page_css: str = "", scripts: str = "", detail: str = "", app_class: str = "") -> str:
    try:
        loc = _locale()
    except Exception:
        loc = i18n.DEFAULT
    mobile = _is_mobile()
    page_key = MOBILE_PAGE_KEY.get(active, active) if mobile else active
    title = i18n.t(f"page.{page_key}.title", title, loc)
    subtitle = i18n.t(f"page.{page_key}.sub", subtitle, loc) if subtitle else subtitle
    def nl(key: str, label: str) -> str:
        return i18n.t(f"nav.{key}", label, loc)
    js_i18n = {k: i18n.t(f"js.{k}", v, loc) for k, v in JS_I18N.items()}
    rail = "".join(
        f'<a class="ricon{" on" if key == active else ""}" href="{href}" title="{nl(key, label)}" aria-label="{nl(key, label)}">{icon(icon_key)}</a>'
        for key, href, label, icon_key in NAV)
    mob_active = MOBILE_PAGE_KEY.get(active, active) if mobile else active
    mobnav = "".join(
        f'<a class="mobitem{" on" if key == mob_active else ""}" href="{href}" aria-label="{nl(key, label)}">{icon(icon_key, 18)}<span>{nl(key, label)}</span></a>'
        for key, href, label, icon_key in MOBILE_NAV)
    return rf"""<!doctype html><html lang="{esc(loc)}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)} · Team AI</title>
<link rel="icon" href="/static/teamai/brand/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="/static/teamai/brand/apple-touch-icon.png">
<script>(function(){{try{{var t=new URLSearchParams(location.search).get("theme")||localStorage.getItem("taa_theme")||"classic";document.documentElement.dataset.theme=t;}}catch(e){{}}}})();</script>
<script>window.TAA_I18N={json.dumps(js_i18n, ensure_ascii=False)};</script>
<style>{SHELL_CSS}{COPY_CSS}{page_css}{LOCAL_CSS}</style></head><body class="{'share' if is_share() else ''}">
<div class="app{'' if side else ' no-side'}{" with-detail" if detail else ""}{(' ' + app_class) if app_class else ''}">
<nav class="rail" aria-label="primary">{rail}
  <div class="railfoot">
    <a class="ricon qr" id="qrbtn" href="javascript:void(0)" title="{i18n.t("nav.mobile", "手机看", loc)}" aria-label="{i18n.t("nav.mobile", "手机看", loc)}">{icon("qr")}</a>
    <a class="ricon gear{" on" if active == "settings" else ""}" href="/app/settings" title="{nl("settings", "设置")}" aria-label="{nl("settings", "设置")}">{icon("settings")}</a>
  </div>
</nav>
<aside class="side">
  <div class="brand"><img class="blogo" src="{BRAND}" alt=""><b>Team AI</b><button class="mnavtoggle" id="mnavtoggle" type="button" aria-label="菜单">☰</button></div>
  <nav class="mnav">
    {''.join(f'<a class="sitem{" on" if key == active else ""}" href="{href}">{nl(key, label)}</a>' for key, href, label, _ in NAV)}
    <a class="sitem{" on" if active == "settings" else ""}" href="/app/settings">{nl("settings", "设置")}</a>
  </nav>
  {side}
  <div class="sidefoot"></div>
</aside>
<div class="pane">
  <div class="top"><button id="sidetoggle" class="sidetoggle" type="button" aria-label="menu">☰</button><div><h1>{esc(title)}</h1>{f'<div class="sub">{esc(subtitle)}</div>' if subtitle else ""}</div>
    <div class="topact">{f'<button class="btn dtoggle" id="detail-toggle" type="button" aria-controls="detail" aria-expanded="true">{tr("shell.detail", "详情")}</button>' if detail else ''}{f'<span class="tag">{tr("shell.readonly", "只读分享")}</span>' if is_share() else ''}</div></div>
  <main>{body}</main>
</div>
{f'<aside class="detail" id="detail" aria-label="{tr("shell.detail_panel", "详情面板")}"><div class="dhead"><span class="dtitle">{tr("shell.detail", "详情")}</span><button class="dclose" id="detail-close" type="button" aria-label="{tr("shell.close", "收起详情")}">✕</button></div><div class="dscroll" id="detail-scroll">{detail}</div></aside><div class="detail-backdrop" id="detail-backdrop" hidden></div>' if detail else ''}
</div>
<nav class="mobnav" aria-label="mobile">
  {mobnav}
  <a class="mobitem{" on" if active == "settings" else ""}" href="/app/settings" aria-label="{nl("settings", "设置")}">{icon("settings", 18)}<span>{nl("settings", "设置")}</span></a>
</nav>
<div id="qrmodal" class="qrmodal" hidden>
  <div class="qrcard">
    <div class="kicker">{tr("chat.qr_scan", "手机扫一扫 · 分发 / 通讯簿")}</div>
    <div id="qrbox"></div>
    <div id="qrurl" class="mono"></div>
    <p class="qrhint">{tr("chat.qr_hint", "手机端用于分发交付物和查通讯簿；聊天已降级为异步留言，不保证即时回复。链接含临时访问权限，请勿外发。")}</p>
    <div class="qracts qrca"><a id="qhelp" class="btn" href="/app/help/https">证书 / 完整应用帮助</a></div>
    <div class="qracts"><button id="qrcopy" class="btn" type="button">{tr("chat.qr_copy", "复制链接")}</button><button id="qrclose" class="btn" type="button">{tr("chat.qr_close", "关闭")}</button></div>
  </div>
</div>
<div id="lb" class="lb" hidden>
  <button id="lbprev" type="button" aria-label="{tr("shell.prev_img", "上一张")}">‹</button>
  <img id="lbimg" alt="" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7">
  <button id="lbnext" type="button" aria-label="{tr("shell.next_img", "下一张")}">›</button>
  <div id="lbcounter"></div>
  <button id="lbx" type="button" aria-label="{tr("shell.close_img", "关闭")}">×</button>
</div>
<script>
(function(){{
  var t=document.getElementById("sidetoggle"), b=document.getElementById("sidebackdrop");
  if(!t) return;
  function close(){{ document.documentElement.classList.remove("side-open"); }}
  t.addEventListener("click",function(e){{ e.preventDefault(); document.documentElement.classList.toggle("side-open"); }});
  if(b) b.addEventListener("click",close);
  document.querySelectorAll(".side a").forEach(function(a){{ a.addEventListener("click",close); }});
  var mt=document.getElementById("mnavtoggle");
  if(mt) mt.addEventListener("click",function(e){{ e.preventDefault(); var app=document.querySelector(".app"); if(app) app.classList.toggle("nav-open"); }});
  document.querySelectorAll(".mnav a").forEach(function(a){{ a.addEventListener("click",function(){{ var app=document.querySelector(".app"); if(app) app.classList.remove("nav-open"); }}); }});
}})();
</script>
<script>window.TAA_COPY={{copy:"{tr("common.copy", "复制")}",copied:"{tr("common.copied", "已复制")}",failed:"{tr("common.copy_failed", "复制失败")}"}};</script>
<script src="/static/teamai/copy.js"></script>
<script src="/static/teamai/qr.js"></script>
<script>
(function(){{
  var btn=document.getElementById("qrbtn"), modal=document.getElementById("qrmodal"), box=document.getElementById("qrbox"), out=document.getElementById("qrurl");
  if(btn) btn.addEventListener("click", async function(){{
    var r=await fetch("/app/share/new",{{method:"POST",headers:{{"content-type":"application/json"}},body:JSON.stringify({{path:location.pathname+location.search}})}});
    var j=await r.json().catch(function(){{return {{}}}});
    if(!j.url) return;
    box.innerHTML=""; new QRCode(box,{{text:j.url,width:220,height:220,correctLevel:QRCode.CorrectLevel.M}});
    out.textContent=j.url;
    modal.hidden=false;
  }});
  if(modal) modal.addEventListener("click",function(e){{ if(e.target===modal || e.target.id==="qrclose") modal.hidden=true; }});
  var cp=document.getElementById("qrcopy");
  if(cp) cp.addEventListener("click",function(){{ navigator.clipboard&&navigator.clipboard.writeText(out.textContent||""); cp.textContent="已复制"; setTimeout(function(){{cp.textContent="复制链接";}},1200); }});
}})();
</script>
<script>
document.addEventListener("click",function(e){{
  var b=e.target.closest(".copybtn"); if(!b) return;
  var m=b.closest(".msg"), t=m&&m.querySelector(".text");
  if(t&&navigator.clipboard){{ navigator.clipboard.writeText(t.innerText); var ti=window.TAA_I18N||{{}}; b.textContent=ti.copied||"已复制"; setTimeout(function(){{b.textContent=ti.copy||"复制";}},1200); }}
}});
  (function(){{
    var lb=document.getElementById("lb"), im=document.getElementById("lbimg");
    if(!lb) return;
    var prev=document.getElementById("lbprev"), next=document.getElementById("lbnext"),
        count=document.getElementById("lbcounter"), items=[], idx=0;
    var swipeX=0, swipeY=0, swiped=false;
    function show(i){{
      if(!items.length) return false;
      idx=(i%items.length+items.length)%items.length;
      var el=items[idx];
      im.src=(typeof el==="string")?el:(el.getAttribute("data-full")||el.getAttribute("src")||"");
      count.textContent=(idx+1)+" / "+items.length;
      lb.hidden=false; return true;
    }}
    window.taaOpenGallery=function(root,start){{
      items=Array.from((root||document).querySelectorAll("img[data-full]"));
      return show(start||0);
    }};
    window.taaOpenGalleryUrls=function(urls,start){{
      items=Array.from(urls||[]);
      return show(start||0);
    }};
    function close(){{ lb.hidden=true; im.src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"; }}
    document.addEventListener("click", function(e){{
      var img=e.target.closest("img[data-full]");
      if(img){{
        var log=img.closest("#log");
        if(log && log.dataset.room){{
          var src=img.getAttribute("data-full")||img.getAttribute("src")||"";
          fetch("/app/api/room/"+encodeURIComponent(log.dataset.room)+"/gallery")
            .then(function(r){{return r.json();}})
            .then(function(j){{ if(window.taaOpenGalleryUrls) window.taaOpenGalleryUrls(j.urls||[], Math.max(0,(j.urls||[]).indexOf(src))); }})
            .catch(function(){{ var box=log; items=Array.from(box.querySelectorAll("img[data-full]")); show(items.indexOf(img)); }});
          e.preventDefault(); return;
        }}
        var box=img.closest(".post, .postdetail, .msg, .card, main")||document;
        items=Array.from(box.querySelectorAll("img[data-full]"));
        show(items.indexOf(img)); e.preventDefault(); return;
      }}
      var t=e.target.closest("[data-full]");
      if(t){{ items=[t]; show(0); e.preventDefault(); return; }}
      if(e.target===lb || e.target.id==="lbx"){{ if(swiped){{swiped=false;return;}} close(); }}
    }});
    lb.addEventListener("touchstart",function(e){{
      if(!e.touches || !e.touches[0]) return;
      swipeX=e.touches[0].clientX; swipeY=e.touches[0].clientY; swiped=false;
    }},{{passive:true}});
    lb.addEventListener("touchend",function(e){{
      var t=e.changedTouches && e.changedTouches[0]; if(!t) return;
      var dx=t.clientX-swipeX, dy=t.clientY-swipeY;
      if(Math.abs(dx)>40 && Math.abs(dx)>Math.abs(dy)){{ swiped=true; show(idx+(dx<0?1:-1)); }}
    }},{{passive:true}});
    if(prev) prev.addEventListener("click",function(e){{ e.stopPropagation(); show(idx-1); }});
    if(next) next.addEventListener("click",function(e){{ e.stopPropagation(); show(idx+1); }});
    document.addEventListener("keydown", function(e){{
      if(lb.hidden) return;
      if(e.key==="Escape") close();
      else if(e.key==="ArrowLeft") show(idx-1);
      else if(e.key==="ArrowRight") show(idx+1);
    }});
  }})();
</script>
<script>
function imageComposerList(ta){{
  var hidden=document.getElementById(ta.dataset.imageComposer||"");
  if(!hidden) return [];
  var raw=[]; try{{ raw=JSON.parse(hidden.value||"[]"); }}catch(_e){{ raw=[]; }}
  return (Array.isArray(raw)?raw:[]).map(function(x){{
    return typeof x==="string" ? x : ((x&&x.url)||"");
  }}).filter(function(x){{return !!x;}});
}}
function imageComposerSave(ta,list){{
  var hidden=document.getElementById(ta.dataset.imageComposer||"");
  if(hidden) hidden.value=JSON.stringify((list||[]).slice(0,9));
}}
function paintImages(ta){{
  var preview=document.getElementById(ta.dataset.preview||"");
  if(!preview) return;
  var list=imageComposerList(ta);
  preview.innerHTML="";
  list.forEach(function(u){{
    var box=document.createElement("div"); box.className="imgthumb";
    if(/^blob:/i.test(u)) box.className+=" uploading";
    var im=document.createElement("img"); im.src=u; im.alt="";
    var rm=document.createElement("button"); rm.type="button"; rm.textContent="×"; rm.title="移除";
    rm.addEventListener("click",function(){{
      imageComposerSave(ta,imageComposerList(ta).filter(function(x){{return x!==u;}}));
      paintImages(ta);
    }});
    box.appendChild(im); box.appendChild(rm); preview.appendChild(box);
  }});
}}
function composerHint(ta,text){{
  var el=document.getElementById(ta.dataset.hint||"");
  if(el) el.textContent=text||"";
}}
function setComposerBusy(ta,on){{
  var n=parseInt(ta.dataset.uploading||"0",10)+(on?1:-1);
  if(n<0) n=0;
  ta.dataset.uploading=String(n);
  var form=ta.closest("form"); if(!form) return;
  Array.prototype.forEach.call(form.querySelectorAll('button[type="submit"]'),function(b){{ b.disabled=n>0; }});
}}
function _imageMimeOf(f){{
  var t=((f&&f.type)||"").toLowerCase();
  if(/^image\//.test(t)) return t;
  // t-df77daf8：部分客户端（Finder / 旧剪贴板）只给文件名不给 MIME，按扩展名兜底。
  var n=((f&&f.name)||"").toLowerCase();
  var m=/\.([a-z0-9]+)$/.exec(n); var ext=m?m[1]:"";
  var map={{jpg:"jpeg",jpeg:"jpeg",png:"png",gif:"gif",webp:"webp",bmp:"bmp",avif:"avif",svg:"svg+xml"}};
  return map[ext] ? "image/"+map[ext] : "";
}}
function _asImageFile(f){{
  if(!f) return null;
  var mime=_imageMimeOf(f);
  if(!mime) return null;
  if(((f.type||"").toLowerCase())===mime) return f;
  var ext=(mime.split("/")[1]||"png").replace("+xml","");
  var name=f.name||("paste."+ext);
  try{{ return new File([f],name,{{type:mime}}); }}catch(_e){{ return f; }}
}}
function _pasteBitmapFiles(dt){{
  var out=[], seen={{}};
  function add(f){{
    f=_asImageFile(f);
    if(!f) return;
    var k=(f.type||"")+":"+(f.size||0);
    if(seen[k]) return; seen[k]=1; out.push(f);
  }}
  Array.prototype.forEach.call(dt.items||[],function(it){{
    if(it.kind==="file" || /^image\//i.test(it.type||"")){{
      try{{ add(it.getAsFile()); }}catch(_e){{}}
    }}
  }});
  Array.prototype.forEach.call(dt.files||[],add);
  return out;
}}
function _pasteImageRefs(dt){{
  var refs=[];
  var html=""; try{{ html=dt.getData("text/html")||""; }}catch(_e){{}}
  if(html){{
    try{{
      var doc=new DOMParser().parseFromString(html,"text/html");
      if(!(doc.body.textContent||"").trim()){{
        Array.prototype.forEach.call(doc.querySelectorAll("img[src]"),function(im){{
          var u=im.getAttribute("src")||""; if(u) refs.push(u);
        }});
      }}
    }}catch(_e){{}}
  }}
  var txt=""; try{{ txt=(dt.getData("text/plain")||"").trim(); }}catch(_e){{}}
  if(/^data:image\//i.test(txt)){{
    refs.push(txt);
  }} else if(txt && txt.length<8192){{
    var m=txt.match(/^\s*!\[[^\]]*\]\(\s*([^)\s]+)\s*\)\s*$/i);
    if(!m) m=txt.match(/^\s*<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>\s*$/i);
    if(!m && /^https?:\/\/\S+$/i.test(txt)) m=[txt,txt];
    if(m && (/^data:image\//i.test(m[1]) || /\.(png|jpe?g|gif|webp|bmp|svg)([?#]|$)/i.test(m[1]))) refs.push(m[1]);
  }}
  // 同一次粘贴常同时给 text/html 和 text/plain 两个表示，按 URL 去重，避免重复缩略图。
  return refs.filter(function(u,i){{return refs.indexOf(u)===i;}});
}}
async function _blobToImageFile(b,i){{
  if(!b || !/^image\//i.test(b.type||"")) return null;
  var e2=(b.type.split("/")[1]||"png").replace("jpeg","jpg").replace("svg+xml","svg");
  return new File([b],"clipboard-"+Date.now()+"-"+(i||0)+"."+e2,{{type:b.type}});
}}
function _sameOrigin(u){{
  try{{ return new URL(u,location.href).origin===location.origin; }}catch(_e){{ return false; }}
}}
async function _refToImageFile(u,i){{
  if(/^data:image\//i.test(u)){{
    var d=/^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(u);
    if(!d) return null;
    try{{
      var bin=atob(d[2].replace(/\s/g,""));
      var buf=new Uint8Array(bin.length);
      for(var j=0;j<bin.length;j++) buf[j]=bin.charCodeAt(j);
      var ext=(d[1].split("/")[1]||"png").replace("jpeg","jpg").replace("svg+xml","svg");
      return new File([buf],"clipboard-"+Date.now()+"-"+(i||0)+"."+ext,{{type:d[1]}});
    }}catch(_e){{ return null; }}
  }}
  if(!/^https?:\/\//i.test(u) && !/^\/static\//i.test(u)) return null;
  // 跨源网页图片浏览器直取会被 CORS 挡掉：交给服务端代理抓取（服务端做内网/大小/类型校验）。
  if(/^https?:\/\//i.test(u) && !_sameOrigin(u)){{
    try{{
      var fd=new FormData(); fd.append("url",u);
      var pr=await fetch("/app/fetch-image",{{method:"POST",body:fd}});
      if(!pr.ok) return null;
      return await _blobToImageFile(await pr.blob(),i);
    }}catch(_e){{ return null; }}
  }}
  try{{
    var r=await fetch(u,{{credentials:"same-origin"}});
    if(!r.ok) return null;
    return await _blobToImageFile(await r.blob(),i);
  }}catch(_e){{ return null; }}
}}
/* ---- 上传前预处理（Step2 预压缩 / Step3 格式转码）----
 * 2026-10-31：网页大图经剪贴板常被重编码成 PNG（体积膨胀 3–5 倍），TIFF/HEIC 则直接被
 * 服务端白名单拒掉。这里在浏览器侧先解码 → 缩到长边 ≤2560 → 编码 WebP(q0.85)：
 * 既把撞 10MB 上限的概率降到很低，也顺手把 macOS 的 TIFF 转成可上传格式。
 * 边界：SVG（矢量）与 GIF（动图）不处理，避免失真/丢帧；解码失败则原样上传，
 * 由服务端返回带数字的明确文案（不吞错）。
 */
var IMG_MAX_EDGE=2560, IMG_QUALITY=0.85, IMG_PREP_OVER=1572864;   /* >1.5MB 才压 */
function _imgExtOf(mime){{
  var m=String(mime||"").toLowerCase();
  if(m==="image/webp") return "webp";
  if(m==="image/jpeg") return "jpg";
  return "png";
}}
function _imgNeedsPrep(file){{
  var t=String((file&&file.type)||"").toLowerCase();
  if(t==="image/svg+xml"||t==="image/gif") return false;      /* 矢量/动图：不转码 */
  if(t && t!=="image/png" && t!=="image/jpeg" && t!=="image/webp") return true;  /* tiff/heic/avif/bmp */
  return ((file&&file.size)||0) > IMG_PREP_OVER;              /* 大图：压缩 */
}}
async function _decodeImageFile(file){{
  try{{ if(window.createImageBitmap) return await createImageBitmap(file); }}catch(_e){{}}
  return await new Promise(function(res,rej){{
    var im=new Image(), u=URL.createObjectURL(file);
    im.onload=function(){{ try{{ URL.revokeObjectURL(u); }}catch(_e){{}} res(im); }};
    im.onerror=function(){{ try{{ URL.revokeObjectURL(u); }}catch(_e){{}} rej(new Error("decode")); }};
    im.src=u;
  }});
}}
async function _prepImage(file){{
  if(!_imgNeedsPrep(file)) return null;
  var src=null;
  try{{ src=await _decodeImageFile(file); }}catch(_e){{ return null; }}
  var w=src.width||src.naturalWidth||0, h=src.height||src.naturalHeight||0;
  if(!w||!h) return null;
  var sc=Math.min(1, IMG_MAX_EDGE/Math.max(w,h));
  var tw=Math.max(1,Math.round(w*sc)), th=Math.max(1,Math.round(h*sc));
  var cv=document.createElement("canvas"); cv.width=tw; cv.height=th;
  try{{ cv.getContext("2d").drawImage(src,0,0,tw,th); }}catch(_e){{ return null; }}
  if(src.close){{ try{{ src.close(); }}catch(_e){{}} }}
  var mime="image/webp", blob=null;
  try{{ blob=await new Promise(function(res){{ cv.toBlob(res,mime,IMG_QUALITY); }}); }}catch(_e){{ blob=null; }}
  if(!blob || !blob.size){{                       /* 老浏览器不支持 WebP 编码 → PNG 兜底 */
    mime="image/png";
    try{{ blob=await new Promise(function(res){{ cv.toBlob(res,mime); }}); }}catch(_e){{ blob=null; }}
  }}
  if(!blob || !blob.size) return null;           /* 编码失败：原图照传，服务端给明确文案 */
  return {{blob:blob, mime:mime, ext:_imgExtOf(mime), w:tw, h:th}};
}}
async function composerUploadFile(ta,file,temp){{
  try{{
    var orig=file, prep=null;
    try{{ prep=await _prepImage(file); }}catch(_e){{ prep=null; }}      /* 压/转失败不当失败处理 */
    if(prep) file=new File([prep.blob],"paste."+prep.ext,{{type:prep.mime}});
    if(prep){{
      ta.dataset.imgPrep=String(parseInt(ta.dataset.imgPrep||"0",10)+1);
      ta.dataset.imgSaved=String(parseInt(ta.dataset.imgSaved||"0",10)+
        Math.max(0,((orig&&orig.size)||0)-((file&&file.size)||0)));
    }}
    var ext=((file.type||"").split("/")[1]||"png").replace("+xml","");
    var fd=new FormData(); fd.append("file",file,"paste."+ext);
    var r=await fetch("/app/upload",{{method:"POST",body:fd}});
    var j=await r.json().catch(function(){{return {{}};}});
    if(!r.ok || !j.ok) throw new Error(j.error||((window.TAA_I18N||{{}}).upload_failed||"上传失败"));
    var list=imageComposerList(ta);
    var idx=list.indexOf(temp);
    if(idx>=0){{ list[idx]=j.url; imageComposerSave(ta,list); }}
    paintImages(ta);
    return true;
  }}catch(err){{
    imageComposerSave(ta,imageComposerList(ta).filter(function(x){{return x!==temp;}}));
    paintImages(ta);
    var ti=window.TAA_I18N||{{}}; composerHint(ta,(ti.upload_failed||"上传失败")+"："+(err.message||ti.upload_retry||"请重试"));
    return false;
  }}finally{{
    try{{ URL.revokeObjectURL(temp); }}catch(_e){{}}
    setComposerBusy(ta,false);
  }}
}}
async function composerAddFiles(ta,files){{
  files=Array.prototype.slice.call(files||[]).map(_asImageFile).filter(function(f){{return !!f;}});
  if(!files.length){{ composerHint(ta,(window.TAA_I18N||{{}}).no_image||"没有取到图片；请用「图片」按钮选择文件"); return; }}
  var room=9-imageComposerList(ta).length;
  if(room<=0){{ composerHint(ta,(window.TAA_I18N||{{}}).max9||"最多 9 张图"); return; }}
  var take=files.slice(0,room), failed=0;
  composerHint(ta,(window.TAA_I18N||{{}}).uploading||"正在上传图片…");
  for(var i=0;i<take.length;i++){{
    var temp=URL.createObjectURL(take[i]);
    var list=imageComposerList(ta); list.push(temp); imageComposerSave(ta,list); paintImages(ta);
    setComposerBusy(ta,true);
    if(!(await composerUploadFile(ta,take[i],temp))) failed++;
  }}
  // 失败提示由 composerUploadFile 写入；这里只在全部成功时清空，避免把错误提示覆盖掉。
  if(!failed){{
    var n=parseInt(ta.dataset.imgPrep||"0",10), saved=parseInt(ta.dataset.imgSaved||"0",10);
    composerHint(ta, n>0 ? ("已预处理 "+n+" 张，省 "+(saved/1048576).toFixed(1)+"MB") : "");
  }}
  try{{ delete ta.dataset.imgPrep; delete ta.dataset.imgSaved; }}catch(_e){{}}
}}
document.addEventListener("paste", async function(e){{
  var ta=e.target && e.target.closest ? e.target.closest("textarea") : null;
  if(!ta || !e.clipboardData || !ta.dataset.imageComposer) return;  // 纯文本/非图片输入框：完全走浏览器默认粘贴
  var files=_pasteBitmapFiles(e.clipboardData);
  if(!files.length){{
    var refs=_pasteImageRefs(e.clipboardData);
    if(!refs.length) return;                    // 真正的纯文本：不拦截
    e.preventDefault();                         // 已是「一张图」的 markdown/HTML：先拦住，绝不落进输入框
    composerHint(ta,(window.TAA_I18N||{{}}).upload_reading||"正在读取剪贴板图片…");
    for(var i=0;i<refs.length;i++){{
      var f=await _refToImageFile(refs[i],i);
      if(f) files.push(f);
    }}
    if(!files.length){{
      composerHint(ta,(window.TAA_I18N||{{}}).clipboard_ref||"剪贴板里只有图片地址，浏览器取不到图片本身；请用「图片」按钮选择文件");
      return;
    }}
  }} else {{
    e.preventDefault();                         // 剪贴板位图：拦住默认行为，改走上传+缩略图
  }}
  await composerAddFiles(ta,files);
}});
</script>
<script>
(function(){{
  if(!window.matchMedia("(max-width:900px)").matches) return;
  var order={json.dumps([href for _, href, _, _ in NAV])};
  var cur=order.indexOf(location.pathname);
  if(cur<0) return;
  var x0=0,y0=0,track=false;
  function blocked(el){{ return !!(el && el.closest("input,textarea,select,pre,code,table,.lb,.side,.qrmodal,.dep")); }}
  document.addEventListener("touchstart",function(e){{
    if(e.touches.length!==1 || document.documentElement.classList.contains("side-open")) return;
    if(blocked(e.target)) return;
    x0=e.touches[0].clientX; y0=e.touches[0].clientY; track=true;
  }},{{passive:true}});
  document.addEventListener("touchend",function(e){{
    if(!track) return; track=false;
    var t=e.changedTouches[0]; if(!t) return;
    var dx=t.clientX-x0, dy=t.clientY-y0;
    if(Math.abs(dx)<70 || Math.abs(dx)<Math.abs(dy)*1.5) return;
    var next=cur+(dx<0?1:-1);
    if(next<0||next>=order.length) return;
    location.href=order[next];
  }},{{passive:true}});
}})();
</script>
<script>
(function(){{
  var app=document.querySelector(".app.with-detail");
  if(!app) return;
  var btn=document.getElementById("detail-toggle"),
      closeBtn=document.getElementById("detail-close"),
      back=document.getElementById("detail-backdrop"),
      mq=window.matchMedia("(max-width:1359px)"),
      KEY="taa_detail_open",
      pref=true;
  try{{ pref=localStorage.getItem(KEY)!=="0"; }}catch(_e){{}}
  var open=mq.matches?false:pref;
  function render(){{
    if(mq.matches){{
      app.classList.toggle("detail-open",open);
      app.classList.remove("detail-collapsed");
      if(back) back.hidden=!open;
    }}else{{
      app.classList.toggle("detail-collapsed",!open);
      app.classList.remove("detail-open");
      if(back) back.hidden=true;
    }}
    if(btn){{
      btn.setAttribute("aria-expanded",open?"true":"false");
      btn.setAttribute("aria-label",open?((window.TAA_I18N||{{}}).collapse||"收起详情"):((window.TAA_I18N||{{}}).expand||"展开详情"));
      btn.classList.toggle("on",open);
    }}
  }}
  function setOpen(v,save){{
    open=!!v;
    if(save){{ pref=open; try{{ localStorage.setItem(KEY,open?"1":"0"); }}catch(_e){{}} }}
    render();
  }}
  window.taaDetailSetOpen=function(v){{ setOpen(!!v,true); }};
  render();
  if(btn) btn.addEventListener("click",function(){{ setOpen(!open,true); }});
  if(closeBtn) closeBtn.addEventListener("click",function(){{ setOpen(false,true); }});
  if(back) back.addEventListener("click",function(){{ setOpen(false,true); }});
  document.addEventListener("keydown",function(e){{
    if(e.key==="Escape" && mq.matches && open) setOpen(false,true);
  }});
  var onMQ=function(){{ open=mq.matches?false:pref; render(); }};
  if(mq.addEventListener) mq.addEventListener("change",onMQ); else if(mq.addListener) mq.addListener(onMQ);

  function flash(el,text){{
    if(!el) return;
    var old=el.getAttribute("data-old")||el.textContent;
    el.setAttribute("data-old",old); el.textContent=text;
    setTimeout(function(){{ el.textContent=old; }},1300);
  }}
  document.addEventListener("click",function(e){{
    var copy=e.target.closest("[data-detail-copy],[data-detail-copy-link]");
    if(copy){{
      var v=copy.getAttribute("data-detail-copy");
      if(copy.hasAttribute("data-detail-copy-link")) v=location.origin+copy.getAttribute("data-detail-copy-link");
      if(v && navigator.clipboard) navigator.clipboard.writeText(v).then(function(){{ flash(copy,"已复制"); }},function(){{}});
      e.preventDefault(); return;
    }}
    var focus=e.target.closest("[data-detail-focus]");
    if(focus){{
      var t=document.querySelector(focus.getAttribute("data-detail-focus"));
      if(t){{ t.scrollIntoView({{block:"center",behavior:"smooth"}}); setTimeout(function(){{ try{{ t.focus({{preventScroll:true}}); }}catch(_e){{}} }},160); }}
      e.preventDefault(); return;
    }}
    var mention=e.target.closest("[data-detail-mention]");
    if(mention){{
      var ta=document.getElementById("text");
      if(ta){{
        var name=mention.getAttribute("data-detail-mention");
        ta.value=(ta.value?ta.value.replace(/\\s*$/,"")+" ":"")+"@"+name+" ";
        ta.focus();
        try{{ ta.setSelectionRange(ta.value.length,ta.value.length); }}catch(_e){{}}
        ta.dispatchEvent(new Event("input",{{bubbles:true}}));
      }}
      e.preventDefault(); return;
    }}
    var people=e.target.closest("[data-detail-people]");
    if(people){{
      var bar=document.getElementById("peoplebar"), table=document.getElementById("ptable"), tg=document.getElementById("ptoggle");
      if(tg && table && table.hidden) tg.click();
      if(bar) bar.scrollIntoView({{block:"start",behavior:"smooth"}});
      e.preventDefault(); return;
    }}
    var backList=e.target.closest("[data-detail-back]");
    if(backList){{
      var list=document.getElementById("feedlist");
      if(list) list.scrollIntoView({{block:"start",behavior:"smooth"}});
      document.querySelectorAll(".post.selected").forEach(function(x){{x.classList.remove("selected");}});
      e.preventDefault();
    }}
  }});
}})();
</script>
<script>
(function(){{
  var pane=document.getElementById("detail-scroll");
  if(!pane) return;
  var stack=[];
  function openPost(href){{
    if(!href) return;
    var prev={{html:pane.innerHTML, top:pane.scrollTop}};
    pane.innerHTML='<p class="dnote">载入中…</p>';
    fetch(href,{{headers:{{"x-taa-detail":"1"}}}}).then(function(r){{
      if(!r.ok) throw new Error("http "+r.status);
      return r.text();
    }}).then(function(html){{
      var doc=new DOMParser().parseFromString(html,"text/html");
      var art=doc.querySelector(".postdetail");
      if(!art) throw new Error("post missing");
      stack.push(prev);
      var bar=document.createElement("div"); bar.className="dtoolbar";
      var kick=document.createElement("span"); kick.className="kicker"; kick.textContent="帖子详情";
      var acts=document.createElement("div"); acts.className="dacts";
      var back=document.createElement("button"); back.type="button"; back.className="dact"; back.setAttribute("data-post-back",""); back.textContent="← 返回";
      var open=document.createElement("a"); open.className="dact"; open.href=href; open.target="_blank"; open.rel="noopener"; open.textContent="新页打开";
      var copy=document.createElement("button"); copy.type="button"; copy.className="dact"; copy.setAttribute("data-detail-copy-link",href); copy.textContent="复制链接";
      acts.appendChild(back); acts.appendChild(open); acts.appendChild(copy);
      bar.appendChild(kick); bar.appendChild(acts);
      pane.innerHTML=""; pane.appendChild(bar); pane.appendChild(art); pane.scrollTop=0;
      if(window.taaDetailSetOpen) window.taaDetailSetOpen(true);
    }}).catch(function(){{
      pane.innerHTML=prev.html; pane.scrollTop=prev.top;
      var err=document.createElement("p"); err.className="dnote"; err.textContent="帖子载入失败，请用「新页打开」。";
      pane.insertBefore(err,pane.firstChild);
    }});
  }}
  window.taaOpenPostDetail=openPost;
  pane.addEventListener("click",function(e){{
    var a=e.target.closest(".postref-card");
    if(a){{
      e.preventDefault(); e.stopPropagation();
      openPost(a.getAttribute("href")||a.href||"");
      return;
    }}
    var back=e.target.closest("[data-post-back]");
    if(back){{
      var prev=stack.pop();
      if(prev){{ pane.innerHTML=prev.html; pane.scrollTop=prev.top; }}
      e.preventDefault();
    }}
  }});
}})();
</script>
{IMG_FALLBACK_JS}
<script>
(function(){{
  document.addEventListener("submit", function(e){{
    var f=e.target.closest ? e.target.closest("form.rform") : null;
    if(!f) return;
    // 分享/移除不是"表情切换"：返回的 JSON 里没有 mine/count，交给浏览器原生提交整页刷新。
    if(f.getAttribute("data-noasync")) return;
    e.preventDefault();
    var btn=f.querySelector("button"); if(!btn) return;
    btn.disabled=true;
    fetch(f.action,{{method:"POST",body:new FormData(f),headers:{{"x-taa-async":"1","accept":"application/json"}}}})
      .then(function(r){{return r.json();}})
      .then(function(j){{
        if(!j || !j.ok) throw new Error("react failed");
        btn.classList.toggle("on", !!j.mine);
        btn.textContent=j.emoji+" "+j.count;
      }})
      .catch(function(){{}})
      .finally(function(){{ btn.disabled=false; }});
  }});
}})();
</script>
{scripts}</body></html>"""


def db():
    c = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return c


def rw():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout = 30000")
    c.execute("PRAGMA foreign_keys = ON")
    return c


def _spawn_route(room: str, text: str, message_id: int, client_message_id: str,
                 prefixed: bool) -> None:
    """把"这条消息该怎么走"放到后台线程裁决，HTTP 请求立即返回。

    裁决本身（LLM 树状分叉）可能耗时数秒；放在请求线程里会让人感觉"发消息卡住"。
    同一 message_id 只会有一次 claim 成功，重试/并发都安全。
    """
    def _job() -> None:
        try:
            from core import executor_bridge
            action = executor_bridge.route_saved_message(
                room, text, message_id=int(message_id),
                client_message_id=client_message_id, prefixed=prefixed)
            print(f"[route] room={room} msg={message_id} -> {action}")
        except Exception as e:  # noqa: BLE001
            print(f"[route] err room={room} msg={message_id}: {e}")

    threading.Thread(target=_job, daemon=True, name=f"route-{message_id}").start()


COLORS = ["#8fb3e0", "#7fc8a9", "#e0a97f", "#d98f9a", "#b39ddb", "#76b5c2", "#c9b458", "#8fbf87"]


def color_for(name: str) -> str:
    h = 0
    for ch in name:
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    return COLORS[h % len(COLORS)]


def avatar(name: str, size: int = 36) -> str:
    return (f'<img class="pill" alt="" src="/avatar/m/{quote(str(name))}" '
            f'width="{size}" height="{size}" loading="lazy" decoding="async">')


def agent_names(c) -> dict:
    """id → 显示名（agents.name）。页面一律显示 `Alice`，不显示 `agt_9e63…`。

    内部 id 仍用于存储与路由；这里只解决"人看不懂"的显示问题。
    查不到时回落原值，保证老数据/未知 id 不会渲染成空白。
    """
    try:
        return {str(x["id"]): (str(x["name"] or x["id"])) for x in
                c.execute("select id,name from agents")}
    except Exception:  # noqa: BLE001
        return {}


def display_name(author_id: str, names: dict | None = None) -> str:
    """把 `agt_xxx` 渲染成可读名字；`human` 之类保持原样。"""
    aid = str(author_id or "")
    if not aid:
        return ""
    if names:
        return str(names.get(aid) or aid)
    return aid


_NAMES_CACHE: dict = {"at": 0.0, "map": {}}


def agent_names_cached(ttl: float = 30.0) -> dict:
    """给"手里没有 conn"的渲染函数用的短缓存（30 秒）。

    `_post_card` 这类纯展示函数一次渲染 80 条，逐条查 agents 表太浪费；
    改名最多延迟 30 秒生效，对显示层没有影响。
    """
    now = time.time()
    if now - float(_NAMES_CACHE.get("at") or 0) < ttl:
        return dict(_NAMES_CACHE.get("map") or {})
    try:
        c = db()
        try:
            mp = agent_names(c)
        finally:
            c.close()
    except Exception:  # noqa: BLE001
        mp = {}
    _NAMES_CACHE["at"] = now
    _NAMES_CACHE["map"] = mp
    return dict(mp)


def persona_text(raw) -> str:
    try:
        data = json.loads(raw or "{}")
    except Exception:  # noqa: BLE001
        return ""
    found = []

    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k in ("bio", "motto") and isinstance(v, str) and v.strip():
                    found.append(v.strip())
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)

    walk(data)
    return " · ".join(dict.fromkeys(found))[:180]


def owner_display_name(c=None) -> str:
    """Use the bound center Owner name, not a hardcoded personal username."""
    try:
        from pathlib import Path
        from taa_node_v05.identity import load_state
        home = Path(os.environ.get("TAA_HOME") or ROOT.parent).expanduser()
        st = load_state(home)
        name = str(getattr(getattr(st, "center", None), "username", "") or "").strip()
        if name:
            return name
    except Exception:  # noqa: BLE001
        pass
    if c is not None:
        try:
            r = c.execute("select name from agents where kind='human' order by id limit 1").fetchone()
            if r and r["name"]:
                return str(r["name"])
        except Exception:  # noqa: BLE001
            pass
    return "Owner"


def human_id(c) -> str:
    r = c.execute("select id from agents where kind='human' and id<>'human' "
                  "and id not like 'remote-human-%' order by id limit 1").fetchone()
    if not r:
        r = c.execute("select id from agents where kind='human' order by id limit 1").fetchone()
    return r["id"] if r else "Leader"


EXCLUDED = ("agent", "human", "codebuddy", "system")


def team_name() -> str:
    try:
        import yaml
        cfg = ROOT / "config.yaml"
        conf = yaml.safe_load(cfg.read_text(encoding="utf-8")) if cfg.exists() else {}
        return (conf.get("smtp") or {}).get("name") or "本地团队"
    except Exception:  # noqa: BLE001
        return "本地团队"


def agents(c):
    return c.execute("select id,name,full_name,role,status,last_seen,kind,is_primary from agents "
                     "where kind='ai' and id not in (?,?,?,?) and node_id is not null "
                     "and coalesce(full_name,'') not like '%@center' order by id", EXCLUDED).fetchall()


_FRIEND_CACHE: dict = {"at": 0.0, "items": []}
_FRIEND_CACHE_LOCK = threading.Lock()


def owner_friends(*, allow_fetch: bool = True) -> list[dict]:
    """Approved Owner friends + their primary agent, via the local node key.

    A short in-process cache keeps the chat page off the center request path.
    Background group sync refreshes it; explicit group creation may refresh.
    """
    import time as _time
    global _FRIEND_CACHE
    now = _time.monotonic()
    cached = list(_FRIEND_CACHE.get("items") or [])
    if cached and now - float(_FRIEND_CACHE.get("at") or 0) < 60:
        return cached
    if not allow_fetch:
        return cached
    if not _FRIEND_CACHE_LOCK.acquire(blocking=False):
        return cached
    try:
        return _refresh_owner_friends_locked()
    finally:
        _FRIEND_CACHE_LOCK.release()


def _refresh_owner_friends_locked() -> list[dict]:
    global _FRIEND_CACHE
    try:
        from pathlib import Path as _Path
        from taa_node_v05.identity import load_state
        from taa_node_v05.center import CenterClient
        home = _Path(os.environ.get("TAA_HOME") or ROOT.parent).expanduser()
        state = load_state(home)
        if not state.center.base or not state.node.node_key:
            return []
        client = CenterClient(state.center.base)
        payload = client.friends_for_node(node_key=state.node.node_key)
        out = []
        for f in payload.get("friends") or []:
            if f.get("status") != "approved":
                continue
            oid = str(f.get("friend_id") or "")
            if not oid:
                continue
            try:
                detail = client.friend_nodes_for_node(node_key=state.node.node_key, owner_id=oid)
            except Exception:  # noqa: BLE001
                detail = {}
            raw_agents = list(detail.get("agents") or [])
            agents = [a for a in raw_agents if str(a.get("status") or "") == "active"]
            # 首席只在 `paused` 上排除，**不要求 active** —— 必须与本地裁决口径
            # (`primary.candidates`: status<>'paused') 一致，否则对方处于 idle/busy 时
            # 我这边会误判成"没有首席"并退化成列表首元素。
            primary = next((a for a in raw_agents
                            if int(a.get("is_primary") or 0) == 1
                            and str(a.get("status") or "") != "paused"), None)
            out.append({
                "owner_id": oid,
                "username": str(f.get("friend_username") or f.get("friend_alias") or oid),
                "public_id": str(f.get("friend_public_id") or ""),
                # 兜底 = 中心按 created_at 排序的第一条，与本地第三条判据"最早创建"同义。
                "primary_agent": primary or (agents[0] if agents else None),
            })
        import time as _time
        _FRIEND_CACHE = {"at": _time.monotonic(), "items": out}
        return out
    except Exception:  # noqa: BLE001
        return list(_FRIEND_CACHE.get("items") or [])


def ensure_agent_owner_columns(c) -> None:
    cols = {str(r["name"]) for r in c.execute("pragma table_info(agents)").fetchall()}
    if "owner_id" not in cols:
        c.execute("alter table agents add column owner_id TEXT")
    if "owner_name" not in cols:
        c.execute("alter table agents add column owner_name TEXT")
    c.commit()


def ensure_remote_stub(c, *, agent_id: str, name: str, kind: str, full_name: str,
                       owner_id: str = "", owner_name: str = "") -> bool:
    """Project a remote human/agent into the local room_members FK table."""
    if not agent_id:
        return False
    try:
        ensure_agent_owner_columns(c)
        c.execute(
            "insert or ignore into agents(id,name,kind,node_id,full_name,role,persona_json,status,owner_id,owner_name) "
            "values(?,?,?,NULL,?, 'executor','{}','active',?,?)",
            (agent_id, name, kind, full_name, owner_id or None, owner_name or None),
        )
        c.execute("update agents set name=?, full_name=coalesce(nullif(?,''), full_name), "
                  "owner_id=coalesce(nullif(?,''), owner_id), "
                  "owner_name=coalesce(nullif(?,''), owner_name), status='active' where id=?",
                  (name, full_name, owner_id, owner_name, agent_id))
        c.commit()
        # `insert or ignore` can be a no-op when a UNIQUE column (for example
        # agents.full_name) collides.  Do not report success unless the row
        # really exists; otherwise rooms.say() later rejects the sender.
        return bool(c.execute("select 1 from agents where id=?", (agent_id,)).fetchone())
    except Exception:  # noqa: BLE001
        return False


def side_agents(c, active_agent: str = "") -> str:
    rows_a = agents(c)
    # 首席标记只在**有竞争**（>1 个 agent）时显示：单 agent 时"首席"没有任何信息量。
    multi = len(rows_a) > 1
    since: dict[str, str] = {}
    if multi:
        try:
            for r in c.execute("select agent_id, from_at from primary_terms where to_at is null"):
                since[str(r[0])] = str(r[1] or "")
        except Exception:  # noqa: BLE001
            since = {}

    def _row(a) -> str:
        prim = bool(int(a["is_primary"] or 0)) if multi else False
        at = since.get(str(a["id"]), "")
        tip = f' title="首席 · {esc(at)} 起"' if prim and at else (' title="首席"' if prim else "")
        return (f'<a class="aitem{" on" if a["id"] == active_agent else ""}" '
                f'href="/app/chats?agent={esc(a["id"])}"{tip}>'
                f'<span class="dot {"off" if a["status"] == "paused" else "on"}"></span>'
                f'<span class="who">{esc(a["name"])}</span>'
                f'<span class="when dim">{esc(fmt_dt(a["last_seen"]) or "never")}'
                f'{" · 首席" if prim else ""}</span></a>')

    rows = "".join(_row(a) for a in rows_a)
    return f'<div class="sidebox agentsbox"><div class="shead">AGENTS</div>{rows or "<div class=dim>没有 agent</div>"}</div>'


def _local_owner_id() -> str:
    """本机绑定的中心 owner id（取不到返回空串）。"""
    try:
        import os as _os
        import pathlib as _pathlib
        from taa_node_v05.identity import load_state
        home = _pathlib.Path(_os.environ.get("TAA_HOME") or "~/.taa").expanduser()
        st = load_state(home)
        return str(getattr(getattr(st, "center", None), "owner_id", "") or "")
    except Exception:  # noqa: BLE001
        return ""


def _my_agent_id(conn, owner_id: str) -> str:
    """我这边的首席 agent —— 只经 `core.primary` 裁决，不在页面层另立口径。

    2026-11-03 起 `agents.is_primary` 由 `core.primary` 写入（积分→资料完整度→最早
    创建），页面层直接读状态；未跑过裁决的老库由 `primary.my_agent` 现算并落库。
    """
    from core import primary as _primary
    aid = _primary.my_agent(conn, owner_id)
    if aid:
        return aid
    # 极端兜底：连候选都没有（空库/全 paused）时保持原行为，绝不抛异常到页面。
    row = conn.execute(
        "select id from agents where kind='ai' and coalesce(owner_id,'')='' "
        "and status<>'paused' and name<>'系统' order by created_at limit 1").fetchone()
    return str(row["id"]) if row else ""


def _friend_room_id(owner_id: str) -> str:
    """owner_id -> 好友房。缺什么补什么：双方真人、双方 agent、房间成员。"""
    oid = str(owner_id or "").strip()
    if not oid:
        return ""
    name = oid
    try:
        for f in owner_friends(allow_fetch=True):
            if str(f.get("owner_id")) == oid:
                name = str(f.get("username") or oid)
                break
    except Exception:  # noqa: BLE001
        pass
    from core import rooms as _rooms
    conn = rw()
    try:
        me = _rooms.human_id(conn)
        if not me:
            return ""
        human_key = "remote-human-" + oid
        # 好友刚加、对方还没发过消息时，本机没有这个人的行；这里补投影。
        ensure_remote_stub(conn, agent_id=human_key, name=name, kind="human",
                           full_name=name, owner_id=oid, owner_name=name)
        row = conn.execute(
            "select id from agents where owner_id=? and kind='ai' and status<>'paused' "
            "order by created_at limit 1", (oid,)).fetchone()
        other_agent = str(row["id"]) if row else ""
        my_agent = _my_agent_id(conn, _local_owner_id())
        return _rooms.ensure_friend_room(conn, me, human_key, my_agent, other_agent, name)
    finally:
        conn.close()


def side_friends(c, active_agent: str = "") -> str:
    """中心好友 —— 远端 owner，不属于本地团队。

    中心是好友真相源；本机只拿 owner_friends() 的 60 秒缓存渲染，
    缓存过期才回中心拉一次（内部有非阻塞锁，失败回旧缓存）。
    好友名下的 agent 可能还没同步到本机，此时只显示人，不显示入口。
    """
    try:
        friends = owner_friends(allow_fetch=True)
    except Exception:  # noqa: BLE001
        friends = []
    if not friends:
        return ""
    items = []
    for f in friends:
        oid = str(f.get("owner_id") or "")
        name = str(f.get("username") or oid)
        pa = f.get("primary_agent") or {}
        aid = str(pa.get("agent_id") or pa.get("id") or "") if isinstance(pa, dict) else ""
        st = str(pa.get("status") or "") if isinstance(pa, dict) else ""
        aname = str(pa.get("display_name") or pa.get("name") or "") if isinstance(pa, dict) else ""
        # 统一进「好友房」（我 + TA 本人 + TA 的 agent），不再跳到与 agent 的私信。
        label = esc(aname) if aid else esc(tr("chat.friend_nosync", "未同步"))
        items.append(
            f'<a class="aitem{" on" if aid and aid == active_agent else ""}" href="/app/chats?friend={esc(oid)}" '
            f'title="{esc(name)} · 远端好友 · {esc(aname or "未同步")}">'
            f'<span class="dot {"on" if st == "active" else "off"}"></span>'
            f'<span class="who">{esc(name)}</span>'
            f'<span class="when dim">{label}</span></a>')
    head = (f'<div class="shead"><span>{esc(tr("chat.side_friends", "好友"))}</span>'
            f'<span class="dim" style="font-weight:400">{len(items)}</span></div>')
    return f'<div class="sidebox friendsbox">{head}{"".join(items)}</div>'


def _dhero(kicker: str, title: str, sub: str = "", actions: str = "") -> str:
    """右侧详情统一抬头：kicker + 标题 + 一句话说明 + 首屏操作。"""
    return (f'<div class="dhero"><div class="kicker">{esc(kicker)}</div>'
            f'<h2>{esc(title)}</h2>{f"<p class=dsub>{esc(sub)}</p>" if sub else ""}'
            f'{f"<div class=dacts>{actions}</div>" if actions else ""}</div>')


def _dcard(title: str, body: str) -> str:
    return f'<section class="dcard"><h3>{esc(title)}</h3>{body}</section>'


def _dstat(value, label: str) -> str:
    return f'<div class="dstat"><b>{esc(str(value))}</b><span>{esc(label)}</span></div>'


def _drow(label: str, value: str) -> str:
    return f'<div class="drow"><span>{esc(label)}</span><b>{value}</b></div>'


def rooms_for(c, agent: str = ""):
    # 只统计页面真正展示的消息（skip/system 不显示，避免“733 条”与正文 188 条打架）
    if agent:
        return c.execute("""select r.id, r.topic, r.kind, r.title, r.status,
            sum(case when m.kind not in ('skip','system') then 1 else 0 end) n,
            max(case when m.kind not in ('skip','system') then m.created_at end) last
            from rooms r join room_messages m on m.room_id=r.id
            where r.id in (select room_id from room_members where agent_id=?)
              and r.kind != 'archived'
            group by r.id order by coalesce(last, r.created_at) desc limit 30""", (agent,)).fetchall()
    return c.execute("""select r.id, r.topic, r.kind, r.title, r.status,
        sum(case when m.kind not in ('skip','system') then 1 else 0 end) n,
        max(case when m.kind not in ('skip','system') then m.created_at end) last
        from rooms r left join room_messages m on m.room_id=r.id
        where r.kind != 'archived'
        group by r.id order by coalesce(last, r.created_at) desc limit 30""").fetchall()


def side_chats(c, cur: str = "", agent: str = "", system: bool = False) -> str:
    all_rooms = list(rooms_for(c, agent))
    visible = [r for r in all_rooms if int(r["n"] or 0) > 0 or r["id"] == cur]
    ai = list(agents(c))
    show_start = (not ai) or (not any(a["last_seen"] for a in ai))
    try:
        from core import center_sync
        center = center_sync.center_base().rstrip("/")
    except Exception:  # noqa: BLE001
        center = ""
    guide = (center + "/guide") if center else "/app/help/keys"
    install_link = f"{guide}#g3" if center else "/app/help/keys#agentkey"
    keys_link = f"{guide}#keys" if center else "/app/help/keys#keys"
    run_link = f"{guide}#g4" if center else "/app/help/keys#agentkey"
    start = ""
    if show_start:
        start = f'''
        <section class="onboard" id="onboard">
          <div class="kicker">开始使用</div>
          <b>先让你的 Agent 上线</b>
          <ol>
            <li>{'已创建 Agent' if ai else '创建 Agent，复制一次性 key'}
              <a href="{esc(center)}/agents/new" target="_blank" rel="noopener">{'管理' if ai else '去创建'}</a></li>
            <li>安装 TAA（公开包下载不需要 key；安装需要 agent key） <a href="{esc(install_link)}" target="_blank" rel="noopener">安装命令</a></li>
            <li>配置 DeepSeek / 阿里云百炼 <a href="{esc(keys_link)}" target="_blank" rel="noopener">申请与填写</a></li>
            <li>taa doctor 验证 <a href="{esc(run_link)}" target="_blank" rel="noopener">步骤</a></li>
          </ol>
          <div class="onboardacts">
            <a class="btn primary" href="{esc(guide)}" target="_blank" rel="noopener">打开完整指引</a>
            {'' if ai else f'<a class="btn" href="{esc(center)}/agents/new" target="_blank" rel="noopener">创建第一个 Agent</a>'}
          </div>
        </section>'''
    system_item = f'''
      <button class="citem sysitem{' on' if system else ''}" id="sysitem" type="button" onclick="location.href='/app/chats?system=1'">
        <span class="rdot {'running' if show_start else 'open'}"></span>
        <span class="cname">系统通知</span>
        <span class="dim" style="margin-left:auto;font-size:12px">{'待完成' if show_start else '正常'}</span>
      </button>'''
    def room_label(r):
        return r["title"] or r["topic"] or r["id"]
    rows = "".join(
        f'<a class="citem{" on" if r["id"] == cur else ""}" data-room="{esc(r["id"])}" href="/app/chats?room={esc(r["id"])}" '
        f'title="{esc(room_label(r))} · {esc(ROOM_STATUS_LABEL.get(r["status"], r["status"] or ""))} · {r["n"]} 条">'
        f'<span class="rdot {esc(r["status"] or "open")}"></span>'
        f'<span class="cname">{esc(room_label(r))}</span>'
        f'<span class="dim" style="margin-left:auto;font-size:12px">{tr("chat.room_count", "{n} 条").format(n=r["n"])}</span></a>'
        for r in (visible or all_rooms))
    members = "".join(
        f'<label class="pickrow"><input type="checkbox" name="members" value="{esc(a["id"])}">'
        f'<span>{avatar(a["name"], 22)} {esc(a["name"])}</span></label>'
        for a in ai if a["status"] != "paused")
    friends = owner_friends(allow_fetch=False)
    friend_picks = "".join(
        f'<label class="pickrow"><input type="checkbox" name="friend_owner_ids" value="{esc(f["owner_id"])}">'
        f'<span>{esc(f["username"])}'
        f' <span class="dim">· {esc((f.get("primary_agent") or {}).get("display_name") or "无首席 agent")}</span>'
        f'</span></label>'
        for f in friends)
    return (start +
            f'<div class="sidebox sysbox"><div class="shead">系统</div>{system_item}'
            f'<a class="citem" href="{esc(guide)}" target="_blank" rel="noopener"><span class="cname">使用指引</span><span class="dim" style="margin-left:auto;font-size:12px">↗</span></a></div>' +
            side_agents(c, agent) +
            side_friends(c, agent) +
            f'<div class="sidebox convbox" style="margin-top:12px"><div class="shead" style="display:flex;justify-content:space-between;align-items:center">'
            f'<span>{tr("chat.side_sessions", "会话")}</span><button class="minibtn" id="groupnew" type="button">{tr("chat.new_group", "＋ 群聊")}</button></div>'
            f'<input id="convfilter" class="convfilter" placeholder="{tr("chat.filter", "筛选会话…")}">'
            f'{rows or ("<div class=dim>" + tr("no_rooms", "没有会话") + "</div>")}</div>'
            f'<dialog id="groupdialog" class="groupdialog"><form method="post" action="/app/chats/group">'
            f'<div class="kicker">{tr("chat.group_title", "发起群聊")}</div><input name="name" placeholder="{tr("chat.group_name", "群名（留空自动，如 MBP32G群聊）")}">'
            f'<div class="groupsec"><div class="kicker">{tr("chat.my_agents", "我的 Agent")}</div><div class="picklist">{members}</div></div>'
            + (f'<div class="groupsec"><div class="kicker">{tr("chat.friend_agents", "好友 · 自动带首席 Agent")}</div><div class="picklist">{friend_picks}</div></div>' if friend_picks else '')
            + f'<p class="dim">{tr("chat.group_hint", "先勾选自己的 Agent，再勾选好友；好友的首席 Agent 会自动加入群。")}</p>'
            f'<div style="display:flex;gap:8px;justify-content:flex-end"><button class="btn" type="button" id="groupcancel">取消</button>'
            f'<button class="btn primary" type="submit">建群</button></div></form></dialog>'
            f'<script>'
            f'(function(){{var b=document.getElementById("groupnew"),d=document.getElementById("groupdialog");'
            f'if(b&&d){{b.onclick=function(){{d.showModal();}};document.getElementById("groupcancel").onclick=function(){{d.close();}};}}}})();'
            f'(function(){{var f=document.getElementById("convfilter");if(!f)return;f.oninput=function(){{var q=f.value.toLowerCase();'
            f'document.querySelectorAll(".sidebox .citem[data-room]").forEach(function(a){{a.style.display=(a.innerText||"").toLowerCase().indexOf(q)>=0?"":"none";}});}};}})();'
            f'</script>')


def system_body(c) -> str:
    ai = list(agents(c))
    try:
        from core import center_sync
        center = center_sync.center_base().rstrip("/")
    except Exception:  # noqa: BLE001
        center = ""
    guide = (center + "/guide") if center else "/app/help/keys"
    install_link = f"{guide}#g3" if center else "/app/help/keys#agentkey"
    keys_link = f"{guide}#keys" if center else "/app/help/keys#keys"
    run_link = f"{guide}#g4" if center else "/app/help/keys#agentkey"
    show_start = (not ai) or (not any(a["last_seen"] for a in ai))
    title = "还没有 Agent" if not ai else ("Agent 已创建，等待上线" if show_start else "Agent 已上线")
    return f'''
    <section class="card room syspane">
      <header class="roomhead">
        <a class="mobile-back" href="/app/chats" aria-label="返回会话">‹</a>
        <div><b>系统通知</b><div class="dim">开始使用与状态提醒</div></div>
      </header>
      <div class="sysbody">
        <div class="sysmsg">
          <div class="kicker">当前状态</div>
          <h3>{title}</h3>
          <p>按下面顺序完成即可。系统只推状态和入口，不保存模型 Key。</p>
          <ol>
            <li>{'Agent 已创建' if ai else '创建 Agent，复制一次性 key'}
              <a href="{esc(center)}/agents/new" target="_blank" rel="noopener">打开</a></li>
            <li>安装 TAA（公开包下载不需要 key；安装需要 agent key） <a href="{esc(install_link)}" target="_blank" rel="noopener">安装命令</a></li>
            <li>配置 DeepSeek / 阿里云百炼 <a href="{esc(keys_link)}" target="_blank" rel="noopener">申请与填写</a></li>
            <li>taa doctor 验证 <a href="{esc(run_link)}" target="_blank" rel="noopener">步骤</a></li>
          </ol>
          <a class="btn primary" href="{esc(guide)}" target="_blank" rel="noopener">打开完整指引</a>
        </div>
      </div>
    </section>'''


def _detail_js(list_sel: str, pane_id: str) -> str:
    return """<script>
(function(){
  document.addEventListener("click", function(e){
    if(window.innerWidth < 900) return;
    if(e.target.closest(".detail")) return;
    var a=e.target.closest("__LIST__") || e.target.closest(".postref-card"); if(!a) return;
    var href=a.getAttribute("href")||"";
    if(href.indexOf("/app/p/")<0) return;
    e.preventDefault();
    var pane=document.getElementById("__PANE__"); if(!pane) return;
    fetch(href).then(function(r){return r.text();}).then(function(html){
      var doc=new DOMParser().parseFromString(html,"text/html");
      var art=doc.querySelector(".postdetail"); if(!art) return;
      pane.innerHTML="";
      var bar=document.createElement("div");
      bar.style.cssText="display:flex;justify-content:space-between;gap:8px;margin-bottom:10px";
      var open=document.createElement("a"); open.className="btn"; open.href=href; open.textContent="打开全文 →";
      var close=document.createElement("button"); close.className="btn"; close.type="button"; close.textContent="关闭";
      close.onclick=function(){pane.innerHTML='<div class="kicker">帖子详情</div><p class="dim">点一篇帖子，在右栏阅读。</p>';};
      bar.appendChild(open); bar.appendChild(close); pane.appendChild(bar); pane.appendChild(art); pane.scrollTop=0;
    }).catch(function(){});
  }, true);
})();
</script>""".replace("__LIST__", list_sel).replace("__PANE__", pane_id)


def page_home():
    c = db()
    ags = agents(c)
    posts = _curated_posts(c, 5)
    moments = c.execute("""select id,author_id,title,body,tags,links,attachments,created_at from posts
        where coalesce(status,'') NOT IN ('duplicate','archived')
        and (lower(tags) like '%lobby%' or tags like '%朋友圈%' or lower(tags) like '%moment%')
        and coalesce(title,'') not like '%回执%'
        order by created_at desc limit 12""").fetchall()
    moments = [m for m in moments if not _is_process_post(m)]
    moments = _dedupe_rows(moments)[:3]
    recent = c.execute("""select agent_id, substr(body,1,70) b, created_at from (
          select agent_id, body, created_at, row_number() over (partition by agent_id order by id desc) rn
          from room_messages where kind not in ('skip','system') and trim(body)<>'（跳过）')
        where rn <= 3""").fetchall()
    by_agent = {}
    for r in recent:
        by_agent.setdefault(r["agent_id"].lower(), []).append(r)
    humans = c.execute("select count(*) n from agents where kind='human' and id not in (?,?,?,?)", EXCLUDED).fetchone()["n"]
    doing = c.execute("select count(*) n from tasks where status='in_progress'").fetchone()["n"]
    rooms = c.execute("select count(*) n from rooms").fetchone()["n"]
    agent_rows = "".join(
        f'<div class="arow"><div class="aline"><span class="dot {"off" if a["status"] == "paused" else "on"}"></span>'
        f'<b>{esc(a["name"])}</b><span class="dim">{esc(fmt_dt(a["last_seen"]) or "never")}</span></div>'
        + ("".join(f'<div class="ritem"><span class="dim">{esc(fmt_dt(x["created_at"]))}</span>{esc(clean(x["b"]))}</div>'
                   for x in by_agent.get(a["name"].lower(), [])) if by_agent.get(a["name"].lower()) else "")
        + "</div>" for a in ags)
    nm = agent_names(c)
    def _curated_card(p):
        raw_title = md_plain(p["title"] or p["body"]).replace(chr(10), " ").strip()
        raw_title = re.sub(r"^【[^】]{1,24}】\s*", "", raw_title)
        raw_body = re.sub(r"^\s*#+\s+[^\n]*\n?", "", str(p["body"] or ""))
        text = md_plain(raw_body).replace(chr(10), " ")
        text = re.sub(r"\s+", " ", text)
        excerpt = text[:100].rstrip("，。；、 ") + ("…" if len(text) > 100 else "")
        n = 0
        while n < min(len(raw_title), len(excerpt)) and raw_title[n] == excerpt[n]:
            n += 1
        if n >= 10:
            excerpt = excerpt[n:].lstrip(" ·:：-—")
        return (f'<a class="pcard" href="/app/p/{esc(p["id"])}"><div class="meta"><b>{esc(display_name(p["author_id"], nm))}</b>'
                f'<span class="dim">{esc(fmt_dt(p["created_at"]))}</span><span class="tag">精选</span></div>'
                f'<p><b>{esc(raw_title)}</b><br><span class="dim">{esc(excerpt)}</span></p></a>')
    post_rows = "".join(_curated_card(p) for p in posts)
    def _mini_moment(m):
        imgs = [a for a in _atts(m["attachments"]) if a["url"].lower().split("?")[0].endswith(IMG_EXT)][:3]
        thumbs = "".join(f'<img src="{esc(thumbnails.thumb_url(_same_host(a["url"]), 240))}" '
                         f'alt="" loading="lazy" decoding="async">' for a in imgs)
        text = md_plain(m["title"] or m["body"]).replace(chr(10), " ")[:90]
        return (f'<a class="mm" href="/app/p/{esc(m["id"])}"><div class="mmhead"><b>{esc(display_name(m["author_id"], nm))}</b>'
                f'<span class="dim">{esc(fmt_dt(m["created_at"]))}</span></div>'
                f'<p>{esc(text)}</p>{f"<div class=mmgrid>{thumbs}</div>" if thumbs else ""}</a>')
    moment_rows = "".join(_mini_moment(m) for m in moments)
    body = f"""
  <section class="card" style="padding:18px 20px;margin-bottom:12px">
    <div class="kicker" style="display:flex;justify-content:space-between;align-items:center">{tr("moments.lead", "朋友圈 · #lobby")} <a class="btn" href="/app/moments">→</a></div>
    <div class="mmrow">{moment_rows or f'<p class="dim">{tr("moments.empty", "今天还没有朋友圈。")}</p>'}</div>
  </section>
  <section class="grid">
    <div class="card" style="padding:18px 20px">
      <div class="kicker">{tr("home.team", "团队")}</div>
      <div class="stats"><span><b>{humans}</b> {tr("home.stats_people", "人")}</span><span><b>{len(ags)}</b> {tr("home.stats_agent", "agent")}</span><span><b>{doing}</b> {tr("home.stats_doing", "进行中")}</span></div>
      <div class="agents">{agent_rows or f'<p class="dim">{tr("home.no_agents", "没有 agent")}</p>'}</div>
    </div>
    <div class="card" style="padding:18px 20px">
      <div class="kicker">{tr("home.featured", "精选 · 值得读 5 篇")}</div>
      {post_rows or f'<p class="dim">{tr("home.empty","还没有适合人读的帖子")}</p>'}
    </div>
  </section>"""
    dpeople = []
    online_n = 0
    for a in ags:
        paused = str(a["status"] or "") == "paused"
        mins = _minutes_since(a["last_seen"])
        online = (not paused) and mins <= 30
        online_n += 1 if online else 0
        state = "online" if online else ""
        label = tr("home.online", "在线") if online else (tr("home.paused", "暂停") if paused else tr("home.offline", "离线"))
        dpeople.append(
            f'<a class="dperson" href="/app/chats?agent={esc(a["id"])}" title="{tr("home.chat_with", "和 {name} 私聊").format(name=esc(a["name"]))}">'
            f'<img class="pill" src="/avatar/m/{quote(a["id"])}" alt="">'
            f'<span class="dwho"><b>{esc(a["name"])}</b><span>@{esc(a["id"])} · {esc(a["role"] or "agent")}</span></span>'
            f'<span class="dpresence {state}"><i></i>{label}</span></a>')
    detail = ('<div id="homedetail" class="postdetail-pane">' + (
        _dhero(tr("home.today", "今日团队"), tr("home.today_sub", "一眼看清谁在、在忙什么"),
               tr("home.today_meta", "{h} 位真人 · {a} 个 agent · {o} 个 agent 近 30 分钟活跃").format(h=humans, a=len(ags), o=online_n),
               f'<a class="dact primary" href="/app/feed">{tr("home.go_feed", "去发帖")}</a>'
               f'<a class="dact" href="/app/chats">{tr("home.dispatch", "派活 / 私聊")}</a>'
               f'<a class="dact" href="/app/board">{tr("home.open_board", "打开看板")}</a>')
        + _dcard(tr("home.overview", "概览"), '<div class="dstats">'
                 + _dstat(humans, tr("home.members", "真人成员")) + _dstat(len(ags), "agent")
                 + _dstat(doing, tr("home.doing", "进行中任务")) + _dstat(rooms, tr("home.rooms", "会话房间")) + "</div>")
        + _dcard(tr("home.agent_status", "Agent 状态"), f'<div class="dpeople">{"".join(dpeople) or f"<p class=dnote>{tr("home.no_agents", "还没有 agent。")}</p>"}</div>')
        + _dcard(tr("home.how", "怎么用"), f'<p class="dnote">{tr("home.today_note", "在频道发帖留痕；在群聊里 @agent 直接发送 派活。手机可扫左下角二维码只读查看。")}</p>')
    ) + "</div>")
    return shell("首页", body, "home", "团队正在发生什么", side=side_agents(c), page_css=PAGE_CSS["home"], detail=detail,
                   scripts=_detail_js(".mm, .pcard", "homedetail"))


def page_mobile_home():
    """手机首屏 = 分发页：看最近交付、复制链接转发、按通讯簿找人。

    手机不承载协作（见 docs/329）：没有实时群聊控制台，只有异步「留言」。
    """
    c = db()
    try:
        rows = c.execute("""select id,author_id,title,body,tags,attachments,created_at from posts
            where coalesce(status,'') NOT IN ('duplicate','archived')
            order by created_at desc limit 80""").fetchall()
        people = c.execute("""select id,name,kind,role,status,last_seen,node_id from agents
            where id not in (?,?,?,?) order by kind desc, id""", EXCLUDED).fetchall()
    finally:
        c.close()
    host = (request.host_url or "").rstrip("/")
    nm = {str(x["id"]): (str(x["name"] or x["id"])) for x in people}
    cards = []
    for p in _dedupe_rows([r for r in rows if not _is_process_post(r)]):
        atts = _atts(p["attachments"])
        if not atts:
            continue
        title = md_plain(p["title"] or p["body"]).replace("\n", " ").strip()[:80] or p["id"]
        link = f'{host}/app/p/{p["id"]}'
        cards.append(
            f'<div class="mrow"><b>{esc(title)}</b>'
            f'<div class="mmeta">{esc(display_name(p["author_id"], nm))} · {esc(fmt_dt(p["created_at"]))} · {len(atts)} 个附件</div>'
            f'<div class="mact"><a class="btn" href="/app/p/{esc(p["id"])}">{tr("mobile.open", "打开")}</a>'
            f'<button class="btn" type="button" data-copy="{esc(link)}">{tr("mobile.copy_link", "复制链接")}</button>'
            f'<a class="btn" href="{esc(_same_host(atts[0]["url"]))}" target="_blank" rel="noopener">{tr("mobile.attachment", "附件")}</a></div></div>')
        if len(cards) >= 8:
            break
    people_html = []
    for m in people[:8]:
        online = str(m["status"] or "") != "paused" and (_minutes_since(m["last_seen"]) <= 30 if m["last_seen"] else False)
        state = tr("home.online", "在线") if online else (tr("home.paused", "暂停") if str(m["status"] or "") == "paused" else tr("home.offline", "离线"))
        kind = tr("team.human", "真人") if m["kind"] == "human" else "agent"
        inner = (f'<img class="pill" src="/avatar/m/{quote(m["id"])}" alt="">'
                 f'<span class="cwho"><b>{esc(m["name"])}</b><span>@{esc(m["id"])} · {kind} · {state}</span></span>')
        if m["kind"] == "ai":
            people_html.append(f'<a class="cperson" href="/app/chats?agent={esc(m["id"])}" title="{tr("mobile.leave_note", "留言")}">{inner}</a>')
        else:
            people_html.append(f'<div class="cperson">{inner}</div>')
    body = f"""
  <section class="card mhero" style="padding:16px 18px;margin-bottom:12px">
    <h2>{tr("mobile.hero_title", "分发 · 通讯簿")}</h2>
    <p>{tr("mobile.hero_body", "手机不是协作台。这里只做两件事：把交付物分发出去，按通讯簿找到人留个言。")}</p>
    <div class="mact">
      <a class="btn primary" href="/app/chats">{tr("mobile.to_messages", "去留言板")}</a>
      <a class="btn" href="/app/team">{tr("mobile.to_contacts", "打开通讯簿")}</a>
      <a class="btn" href="/deliverables/">{tr("mobile.to_deliverables", "本机交付目录")}</a>
    </div>
  </section>
  <section class="card" style="padding:16px 18px;margin-bottom:12px">
    <div class="kicker">{tr("mobile.latest_deliverables", "最近交付 · 可直接转发")}</div>
    {''.join(cards) or f'<p class="dim">{tr("mobile.empty_deliverables", "还没有带附件的交付帖。")}</p>'}
    <div class="mact"><a class="btn" href="/app/feed">{tr("mobile.all_feed", "全部频道 →")}</a></div>
  </section>
  <section class="card" style="padding:16px 18px;margin-bottom:12px">
    <div class="kicker">{tr("mobile.people", "发给谁 · 通讯簿")}</div>
    <div class="cpeople">{''.join(people_html) or f'<p class="dim">{tr("home.no_agents", "还没有 agent")}</p>'}</div>
    <div class="mact"><a class="btn" href="/app/team">{tr("mobile.to_contacts", "打开通讯簿")} →</a></div>
  </section>
  <section class="card" style="padding:16px 18px">
    <div class="kicker">{tr("mobile.role", "手机端定位")}</div>
    <p class="dim" style="margin:0;line-height:1.7">{tr("mobile.role_note", "分发：把交付物链接转给需要的人；通讯簿：记下谁是谁、怎么找到；留言：异步说一句，不保证即时回复。实时协作请用桌面端或工作群。")}</p>
  </section>"""
    return shell("分发", body, "dist", "手机 = 分发页 + 通讯簿", page_css=PAGE_CSS["feed"])


PRESENCE_MINUTES = 15
ROOM_STATUS_LABEL = {"running": "进行中", "ended": "已结束", "open": "未开始"}
ROLE_LABEL = {"host": "主持", "member": "成员"}
AGENT_ROLE_LABEL = {"coordinator": "协调者", "executor": "执行者", "observer": "观察者"}


def _minutes_since(ts) -> float:
    try:
        t = datetime.datetime.strptime(fmt_dt(ts), "%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        return 10 ** 6
    return (datetime.datetime.now() - t).total_seconds() / 60.0


def _ago(ts) -> str:
    if not ts:
        return tr("time.none", "无记录")
    mins = _minutes_since(ts)
    if mins < 1:
        return tr("time.just_now", "刚刚")
    if mins < 60:
        return tr("time.minutes", "{n} 分钟前").format(n=int(mins))
    if mins < 60 * 24:
        return tr("time.hours", "{n} 小时前").format(n=int(mins // 60))
    return tr("time.days", "{n} 天前").format(n=int(mins // (60 * 24)))


def _show_system_receipt(m) -> bool:
    """真实 agent 的立项/任务回执要显示；A 机规则提示不显示。

    `[chatwork] 收到，已立项 t-xxx` 是 Carol 侧真实执行链的回执，带任务号，有价值。
    后台调研作业的"全文：p-xxxxxxx"同理带帖子号，点开就是报告正文，也必须显示。
    `agent_id='system'` 的“目标不在本机执行器”是本地规则提示，不是 agent 回复。
    """
    try:
        agent = str(m["agent_id"] or "")
        body = str(m["body"] or "")
    except Exception:  # noqa: BLE001
        return False
    if agent == "system":
        return False
    return ("[chatwork]" in body or bool(re.search(r"\bt-[0-9a-f]{8}\b", body))
            or bool(re.search(r"(?<![\w/])p-[0-9a-f]{8}(?![\w])", body)))


def room_members(c, rid: str, viewer: str | None = None) -> list[dict]:
    """会话参与人（真实成员接口的唯一数据源）。

    来源：room_members（成员/角色）+ agents（姓名/身份/状态/最近心跳）
          + room_messages（该成员在本房间的最近发言）。
    在线判定：状态非 paused，且最近活动（心跳或本房发言）≤ PRESENCE_MINUTES；
              真人所有者本人打开页面时按“当前页面”计在线。
    """
    rows = c.execute("""
        select m.agent_id, m.kind, m.role, m.joined_at,
               a.name, a.full_name, a.node_id, a.role as agent_role, a.status, a.last_seen,
               (select max(created_at) from room_messages rm
                 where rm.room_id=m.room_id and rm.agent_id=m.agent_id
                   and rm.kind not in ('skip','system')) last_active
        from room_members m left join agents a on a.id=m.agent_id
        where m.room_id=?
        order by (m.role='host') desc, (m.kind='human') desc, m.rowid
    """, (rid,)).fetchall()
    out = []
    for r in rows:
        aid = r["agent_id"]
        kind = (r["kind"] or "ai").lower()
        last_active = max([x for x in (r["last_active"], r["last_seen"]) if x] or [""])
        status = str(r["status"] or "").lower()
        is_self = bool(viewer and aid == viewer)
        if status == "paused":
            state, state_label = "offline", tr("room.paused", "暂停")
        elif is_self:
            state, state_label = "online", tr("room.online", "在线")
        elif last_active and _minutes_since(last_active) <= PRESENCE_MINUTES:
            state, state_label = "online", tr("room.online", "在线")
        else:
            state, state_label = "offline", tr("room.offline", "离线")
        display_id = "" if aid == "human" or aid.startswith("remote-human-") else aid
        # A local human is the bound Owner, not the legacy placeholder "Owner".
        display_name = owner_display_name(c) if aid == "human" else (r["name"] or aid)
        out.append({
            "id": aid,
            "display_id": display_id,
            "name": display_name,
            "full_name": display_name if aid == "human" else (r["full_name"] or r["name"] or aid),
            "kind": kind,
            "kind_label": tr("room.human", "真人") if kind == "human" else tr("room.agent", "agent"),
            "node_id": r["node_id"] or "",
            "node_label": r["node_id"] or (tr("room.local", "本机") if kind == "human" and aid == viewer else ""),
            "role": r["role"] or "member",
            "role_label": tr("room.host", "主持") if (r["role"] or "") == "host" else tr("room.member", "成员"),
            "agent_role": r["agent_role"] or "",
            "agent_role_label": tr("room." + (r["agent_role"] or ""), r["agent_role"] or "") if r["agent_role"] in ("coordinator", "executor", "observer") else "",
            "status": status,
            "state": state,
            "state_label": state_label,
            "last_active": fmt_dt(last_active),
            "last_active_label": tr("room.current", "当前页面") if is_self else _ago(last_active),
            "joined_at": fmt_dt(r["joined_at"]),
            "is_self": is_self,
        })
    return out


def _member_chip(m: dict) -> str:
    role = f'<span class="prole">{esc(m["role_label"])}</span>' if m["role"] == "host" else ""
    did = str(m.get("display_id") or "")
    pid = f'<span class="pid mono">@{esc(did)}</span>' if did and m["name"] != did else ""
    node = f'<span class="pnode mono">{esc(m["node_label"])}</span>' if m.get("node_label") else ""
    return (f'<span class="pchip {m["state"]}" data-id="{esc(m["id"])}" '
            f'title="{esc(m["full_name"] or m["name"])}（{esc(m["kind_label"])} · {esc(m["role_label"])}）· '
            f'{esc(m["state_label"])} · {tr("room.recent_active", "最近活跃")} {esc(m["last_active_label"])}">'
            f'{avatar(m["id"], 22)}'
            f'<b class="pname">{esc(m["name"])}</b>{pid}{node}{role}'
            f'<span class="pstate"><i class="pdot"></i>{esc(m["state_label"])}</span></span>')


def _member_row(m: dict) -> str:
    role = f'{m["kind_label"]} · {m["agent_role_label"] or m["role_label"]}'
    if m["role"] == "host":
        role += " " + tr("chat.role_host", "· 主持")
    node = f'<span class="mnode mono dim">{esc(m["node_label"])}</span>' if m.get("node_label") else ""
    did = str(m.get("display_id") or "")
    pid = f'<span class="mono dim">@{esc(did)}</span>' if did and m["name"] != did else ""
    return (f'<div class="memberrow {m["state"]}" data-id="{esc(m["id"])}">'
            f'{avatar(m["id"], 24)}'
            f'<span class="mwho"><b>{esc(m["name"])}</b> {pid}{node}'
            f'<span class="mrole dim">{esc(role)}</span></span>'
            f'<span class="mstate"><i class="pdot"></i>{esc(m["state_label"])}'
            f'<span class="dim">{esc(m["last_active_label"])}</span></span></div>')


def center_state():
    try:
        from pathlib import Path as _Path
        from taa_node_v05.identity import load_state
        return load_state(_Path(os.environ.get("TAA_HOME") or ROOT.parent).expanduser())
    except Exception:  # noqa: BLE001
        return None


def ensure_center_group_column(c) -> None:
    cols = {str(r["name"]) for r in c.execute("pragma table_info(rooms)").fetchall()}
    for name, ddl in (
        ("center_group_id", "text"),
        ("center_transport_secret", "text"),
        ("center_peer_endpoints", "text"),
        ("canonical_id", "text"),
        ("participant_key", "text"),
        ("authority_node", "text"),
        ("read_only", "integer default 0"),
    ):
        if name not in cols:
            c.execute(f"alter table rooms add column {name} {ddl}")
    c.commit()


def resolve_room(c, ref: str):
    """Resolve a local room id or the canonical center group id."""
    ref = (ref or "").strip()
    if not ref:
        return None
    row = c.execute("select * from rooms where id=?", (ref,)).fetchone()
    if row:
        return row
    try:
        return c.execute(
            "select * from rooms where center_group_id=? or canonical_id=? "
            "order by created_at limit 1", (ref, ref)).fetchone()
    except Exception:  # noqa: BLE001
        return None


def public_room_id(room) -> str:
    if not room:
        return ""
    return str(room["center_group_id"] or room["canonical_id"] or room["id"])


def _center_owner_id() -> str:
    st = center_state()
    if st and st.center.owner_id:
        return str(st.center.owner_id)
    # Source-tree tests may not have taa_node_v05 importable; the identity
    # file is the same durable source of truth.
    try:
        home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa")).expanduser()
        data = json.loads((home / "identity.json").read_text(encoding="utf-8"))
        return str((data.get("center") or {}).get("owner_id") or "")
    except Exception:  # noqa: BLE001
        return ""


def room_participant_key(c, rid: str) -> str:
    """Local key in the same vocabulary as the center: o:<owner>, a:<agent>."""
    local_owner = _center_owner_id() or "human"
    owners: set[str] = set()
    agents: set[str] = set()
    for r in c.execute(
            "select m.agent_id,a.kind from room_members m left join agents a on a.id=m.agent_id "
            "where m.room_id=?", (rid,)):
        aid = str(r["agent_id"] or "")
        if not aid:
            continue
        if aid == "human":
            owners.add(local_owner)
        elif aid.startswith("remote-human-"):
            owners.add(aid[len("remote-human-"):])
        elif (r["kind"] or "ai") == "ai":
            agents.add(aid)
    return "|".join(sorted([f"o:{x}" for x in owners] + [f"a:{x}" for x in agents]))


_ROOM_META_LOCK = threading.Lock()
_ROOM_META_READY = False


def ensure_room_meta_once() -> None:
    """Run canonical/alias migration once per web process, not per page load.

    `reconcile_room_canonicals` writes every center room; doing it inside
    every /app/chats request can wait on SQLite writer locks and makes the
    composer feel dead for many seconds.
    """
    global _ROOM_META_READY
    if _ROOM_META_READY:
        return
    with _ROOM_META_LOCK:
        if _ROOM_META_READY:
            return
        c = rw()
        try:
            ensure_center_group_column(c)
            reconcile_room_canonicals(c)
        finally:
            c.close()
        _ROOM_META_READY = True


def reconcile_room_canonicals(c) -> None:
    """Give every center group one canonical local room and freeze aliases.

    This is intentionally additive: duplicate local rooms are kept as aliases,
    never deleted; their messages remain available for audit.
    """
    try:
        rows = c.execute(
            "select id,center_group_id from rooms where center_group_id is not null "
            "and center_group_id!='' order by created_at,id").fetchall()
    except Exception:  # noqa: BLE001
        return
    by_group: dict[str, list] = {}
    for r in rows:
        by_group.setdefault(str(r["center_group_id"]), []).append(r)
    from core import host_mode
    client = host_mode.is_client()
    for gid, items in by_group.items():
        canonical = items[0]
        for i, r in enumerate(items):
            readonly = 1 if client or i > 0 else 0
            c.execute(
                "update rooms set canonical_id=?, participant_key=?, authority_node=?, read_only=? where id=?",
                (gid, room_participant_key(c, str(r["id"])),
                 "" if client else "local", readonly, r["id"]))
            if i > 0:
                c.execute("update rooms set status='ended' where id=?", (r["id"],))
    c.commit()


def _store_group_transport(c, rid: str, detail: dict, own_node_id: str = "") -> None:
    """Persist the center-issued group capability and remote endpoint candidates."""
    group = detail.get("group") if isinstance(detail, dict) else {}
    secret = str((group or {}).get("transport_secret") or "")
    endpoints: list[dict] = []
    seen: set[str] = set()
    for m in (detail.get("members") or []) if isinstance(detail, dict) else []:
        if own_node_id and str(m.get("transport_node_id") or "") == own_node_id:
            continue
        raw = m.get("transport_endpoint")
        if not raw:
            continue
        try:
            parsed = json.loads(raw) if isinstance(raw, str) else raw
        except Exception:
            continue
        for e in (parsed.get("endpoints") or []) if isinstance(parsed, dict) else []:
            e = e if isinstance(e, dict) else {}
            kind = str(e.get("kind") or "")
            url = str(e.get("url") or "").rstrip("/")
            if kind == "peer-loopback" or not url or url in seen:
                continue
            seen.add(url)
            # 记录归属对端节点：同一对端的多个地址是冗余候选，投递判定按
            # 「每个节点至少一个地址成功」计（见 core/peer_server._post_per_peer）。
            item = {"kind": kind or "peer", "url": url,
                    "node": str(m.get("transport_node_id") or "")}
            for key in ("iface", "ip", "netmask", "scope", "priority"):
                if e.get(key) not in (None, ""):
                    item[key] = e[key]
            endpoints.append(item)
    c.execute("update rooms set center_transport_secret=?, center_peer_endpoints=? where id=?",
              (secret or None, json.dumps(endpoints, ensure_ascii=False) if endpoints else None, rid))
    c.commit()


def sync_group_to_center(c, rid: str, name: str, friend_ids: list[str], own_agents: list[str]) -> str:
    st = center_state()
    if not st or not st.center.base or not st.center.owner_id or not st.node.node_key:
        return ""
    try:
        from taa_node_v05.center import CenterClient
        client = CenterClient(st.center.base)
        # Include agents in the group identity.  The same owner set with a
        # different agent set is a different conversation; topic/name is not.
        fmap = {str(f.get("owner_id")): f for f in owner_friends()}
        friend_agent_ids = []
        for fid in dict.fromkeys(friend_ids):
            agent = (fmap.get(fid) or {}).get("primary_agent") or {}
            aid = str(agent.get("agent_id") or "")
            if aid:
                friend_agent_ids.append(aid)
        member_agent_ids = list(dict.fromkeys(list(own_agents) + friend_agent_ids))
        created = client.create_group_for_node(
            node_key=st.node.node_key, name=name,
            member_owner_ids=list(dict.fromkeys(friend_ids)),
            member_agent_ids=member_agent_ids)
        gid = str(created.get("group_id") or "")
        if not gid:
            return ""
        for aid in dict.fromkeys(own_agents):
            try:
                client.add_group_member_for_node(node_key=st.node.node_key, group_id=gid,
                                                 owner_id=st.center.owner_id, agent_id=aid)
            except Exception:  # noqa: BLE001
                pass
        fmap = {str(f.get("owner_id")): f for f in owner_friends()}
        for fid in dict.fromkeys(friend_ids):
            agent = (fmap.get(fid) or {}).get("primary_agent") or {}
            aid = str(agent.get("agent_id") or "")
            if aid:
                try:
                    client.add_group_member_for_node(node_key=st.node.node_key, group_id=gid,
                                                     owner_id=fid, agent_id=aid)
                except Exception:  # noqa: BLE001
                    pass
        ensure_center_group_column(c)
        c.execute("update rooms set center_group_id=? where id=?", (gid, rid))
        c.commit()
        try:
            _store_group_transport(c, rid, client.group_for_node(node_key=st.node.node_key, group_id=gid), st.node.node_id)
        except Exception:  # noqa: BLE001
            pass
        try:
            reconcile_room_canonicals(c)
        except Exception:  # noqa: BLE001
            pass
        return gid
    except Exception:  # noqa: BLE001
        return ""


def sync_center_groups() -> None:
    st = center_state()
    if not st or not st.center.base or not st.center.owner_id or not st.node.node_key:
        return
    try:
        from taa_node_v05.center import CenterClient
        from core import rooms as rooms_mod, presence as presence_mod, group_command
        client = CenterClient(st.center.base)
        payload = client.groups_for_node(node_key=st.node.node_key)
        if not (payload.get("groups") or []):
            return
        c = rw()
        try:
            ensure_center_group_column(c)
            presence_mod.ensure(c)
            group_command.ensure(c)
            host = human_id(c)
            local_ids = {str(a.agent_id) for a in getattr(st, "agents", []) or []}
            for g in payload.get("groups") or []:
                gid = str(g.get("group_id") or "")
                if not gid:
                    continue
                detail = client.group_for_node(node_key=st.node.node_key, group_id=gid)
                existing = c.execute("select id from rooms where center_group_id=?", (gid,)).fetchone()
                name = str(g.get("name") or "协作群")
                if existing:
                    rid = str(existing["id"])
                    c.execute("update rooms set title=?, topic=? where id=?", (name, name, rid))
                else:
                    rid = rooms_mod.create_room(c, host, name, expected_minutes=10080)
                    c.execute("update rooms set center_group_id=? where id=?", (gid, rid))
                for m in detail.get("members") or []:
                    presence_mod.upsert_member(c, m)
                    owner_id = str(m.get("owner_id") or "")
                    aid = str(m.get("agent_id") or "")
                    if owner_id == st.center.owner_id:
                        if not aid:
                            rooms_mod.add_member(c, rid, host, role="host")
                        else:
                            # The center is the global name authority. Refresh
                            # even an existing local row after a collision rename.
                            agent_name = str(m.get("agent_name") or "")
                            row = c.execute("select full_name from agents where id=?", (aid,)).fetchone()
                            if agent_name:
                                full = (str(row["full_name"] or "") if row and aid in local_ids
                                        else f"{agent_name}@center")
                                ensure_remote_stub(c, agent_id=aid, name=agent_name,
                                                   kind="ai", full_name=full,
                                                   owner_id=st.center.owner_id,
                                                   owner_name=str(m.get("owner_username") or st.center.username or ""))
                            elif not c.execute("select 1 from agents where id=?", (aid,)).fetchone():
                                ensure_remote_stub(c, agent_id=aid, name="agent",
                                                   kind="ai", full_name=f"{aid}@center",
                                                   owner_id=st.center.owner_id,
                                                   owner_name=str(m.get("owner_username") or st.center.username or ""))
                            rooms_mod.add_member(c, rid, aid)
                    else:
                        hstub = "remote-human-" + owner_id
                        ensure_remote_stub(c, agent_id=hstub, name=str(m.get("owner_username") or owner_id),
                                           kind="human", full_name=f"{m.get('owner_username') or owner_id}@center",
                                           owner_id=owner_id, owner_name=str(m.get("owner_username") or owner_id))
                        rooms_mod.add_member(c, rid, hstub)
                        if aid:
                            ensure_remote_stub(c, agent_id=aid, name=str(m.get("agent_name") or "agent"),
                                               kind="ai", full_name=f"{m.get('agent_name') or aid}@center",
                                               owner_id=owner_id, owner_name=str(m.get("owner_username") or owner_id))
                            rooms_mod.add_member(c, rid, aid)
                _store_group_transport(c, rid, detail, st.node.node_id)
                c.commit()
            group_command.expire_due(c)
            reconcile_room_canonicals(c)
        finally:
            c.close()
    except Exception:  # noqa: BLE001
        return


def ensure_center_message_column(c) -> None:
    """Ensure idempotency + UTC columns on legacy DBs (single implementation)."""
    from core.db import ensure_message_columns
    ensure_message_columns(c)


def _direct_attachment_files(att_json: str | None) -> list[dict]:
    """Read compressed transport files for raw direct upload (no base64)."""
    if not att_json:
        return []
    try:
        items = json.loads(att_json)
    except Exception:
        return []
    import mimetypes
    from pathlib import Path as _Path
    out = []
    for item in items[:9] if isinstance(items, list) else []:
        if isinstance(item, str):
            item = {"url": item}
        if not isinstance(item, dict):
            continue
        url = _transport_image_url(str(item.get("transport_url") or item.get("url") or ""))
        if not url.startswith("/static/uploads/") or ".." in url:
            continue
        p = _Path(ROOT) / url.lstrip("/")
        if not p.is_file():
            continue
        data = p.read_bytes()
        if not data or len(data) > 2 * 1024 * 1024:
            continue
        out.append({"name": str(item.get("name") or p.name)[:120],
                    "mime": mimetypes.guess_type(p.name)[0] or "application/octet-stream",
                    "sha256": __import__("hashlib").sha256(data).hexdigest(),
                    "size": len(data), "data": data})
    return out


# ---------------------------------------------------------------------------
# 直投队列：有界批次 + 终态 + 退避（2026-10-31 事故）
#
# 旧实现每轮把「所有未直投消息」全量取出重试，且失败只留在原状态：
#   · 结构上不可出站的行（agent_id='system'、无 owner 的镜像人）走 continue，
#     永远不落终态 → 每次同步都被重扫，队列只增不减；
#   · 没有 attempts / 退避，失败项和下一条新消息抢同一份预算。
# 现在：每轮最多 DIRECT_BATCH 条、只取到期的；成功/不可出站/重试耗尽各有终态，
# 终态不再进候选查询。语义区分清楚——`delivered` 才是真送到，
# `skipped` 是结构上不该走直投，`gave_up` 是直投放弃（中心/拉取兜底）。
# ---------------------------------------------------------------------------
DIRECT_BATCH = int(os.environ.get("TAA_DIRECT_BATCH", "20") or 20)
DIRECT_MAX_ATTEMPTS = int(os.environ.get("TAA_DIRECT_MAX_ATTEMPTS", "8") or 8)
DIRECT_RETRY_BASE_S = float(os.environ.get("TAA_DIRECT_RETRY_BASE", "30") or 30)
DIRECT_RETRY_CAP_S = float(os.environ.get("TAA_DIRECT_RETRY_CAP", "300") or 300)


def ensure_direct_state_columns(c) -> None:
    cols = {str(r["name"]) for r in c.execute("pragma table_info(room_messages)").fetchall()}
    for name, ddl in (("direct_state", "text"),
                      ("direct_attempts", "integer default 0"),
                      ("direct_next_at", "real"),
                      ("direct_last_error", "text")):
        if name not in cols:
            c.execute(f"alter table room_messages add column {name} {ddl}")


def direct_candidates(c, rid: str, limit: int | None = None):
    """待直投候选：只取 pending 且到期的，按 id 升序，最多 limit 条。"""
    ensure_direct_state_columns(c)
    return c.execute(
        "select id,agent_id,body,attachment,client_message_id,created_at,created_at_utc,"
        "reply_to_id,direct_attempts from room_messages where room_id=? "
        "and center_message_id is null and coalesce(direct_delivered,0)=0 "
        "and coalesce(direct_state,'pending')='pending' "
        "and kind not in ('skip') and coalesce(source,'') not in ('center','peer','p2p') "
        "and (direct_next_at is null or direct_next_at<=?) order by id limit ?",
        (rid, time.time(), int(limit or DIRECT_BATCH))).fetchall()


def direct_mark_delivered(c, mid: int, client_id: str = "") -> None:
    ensure_direct_state_columns(c)
    c.execute("update room_messages set direct_delivered=1,direct_state='delivered',"
              "direct_next_at=null,direct_last_error=null,"
              "client_message_id=coalesce(nullif(?,''),client_message_id) where id=?",
              (client_id, mid))


def direct_mark_skipped(c, mid: int, why: str) -> None:
    """结构上不可出站：落终态，永不再进候选（不是删除，可审计）。"""
    ensure_direct_state_columns(c)
    c.execute("update room_messages set direct_state='skipped',direct_next_at=null,"
              "direct_last_error=? where id=?", (str(why)[:200], mid))


def direct_mark_retry(c, row, why: str) -> None:
    """失败：attempts+1，指数退避；耗尽转 gave_up（交中心/拉取兜底）。"""
    ensure_direct_state_columns(c)
    n = int(row["direct_attempts"] or 0) + 1
    if n >= DIRECT_MAX_ATTEMPTS:
        c.execute("update room_messages set direct_attempts=?,direct_state='gave_up',"
                  "direct_next_at=null,direct_last_error=? where id=?",
                  (n, str(why)[:200], row["id"]))
        return
    wait = min(DIRECT_RETRY_BASE_S * (2 ** (n - 1)), DIRECT_RETRY_CAP_S)
    c.execute("update room_messages set direct_attempts=?,direct_next_at=?,direct_last_error=? "
              "where id=?", (n, time.time() + wait, str(why)[:200], row["id"]))


def _att_mark(c, mid: int, status: str, remote_url: str = "") -> None:
    """推进一条消息的附件投递状态（docs/16 §3.5 / §3.6）。

    直投前 pending、送达 synced、重试耗尽 failed。老库没有 `message_attachment`
    表时静默跳过——附件状态是展示层增量，不能反过来阻断消息投递。
    """
    try:
        c.execute("update message_attachment set status=?, "
                  "remote_url=coalesce(nullif(?,''),remote_url) where message_id=?",
                  (status, str(remote_url or ""), int(mid)))
    except Exception:                                            # noqa: BLE001
        pass


def direct_backlog(c, rid: str = "") -> dict:
    """水位（自检/门禁用）：各状态条数、真实待投数、被排除项的分桶解释。

    口径统一在 core.direct_queue（单一真相源）。本地私信房（无 center_group_id）、
    中心同步副本、入站消息都**不算**积压——它们本来就没有对端可投。
    """
    ensure_direct_state_columns(c)
    # 只算"有中心群的房间"：本地残房（无 center_group_id）没有对端可投，
    # 把它们算进"积压"会让水位永远降不下来，也不代表任何消息真的没送到。
    from core import direct_queue as dq
    where = " where " + dq.scope_sql(c)
    args: list = []
    if rid:
        where += " and room_id=?"
        args.append(rid)
    rows = c.execute(
        "select coalesce(direct_state,case when coalesce(direct_delivered,0)=1 then 'delivered' "
        "else 'pending' end) st,count(*) n,min(id) lo,max(id) hi from room_messages m" +
        where + " group by st", args).fetchall()
    out = {str(r["st"]): int(r["n"]) for r in rows}
    detail = {str(r["st"]): {"n": int(r["n"]), "lo": r["lo"], "hi": r["hi"]} for r in rows}
    return {"counts": out, "detail": detail, "total_pending": out.get("pending", 0),
            # queued = 真正待投（唯一权威水位）；excluded = 其余"看起来没投、其实不该投"的分桶，
            # 让读数的人不必再猜 334 条 NULL 是不是积压。
            "queued": dq.queued(c, rid), "excluded": dq.explain(c, rid)}


def flush_direct_group_messages(c, *, rid: str, gid: str, st, host: str) -> int:
    """Send pending local messages directly, before touching the center."""
    transport = c.execute(
        "select center_transport_secret,center_peer_endpoints from rooms where id=?", (rid,)
    ).fetchone()
    secret = str((transport["center_transport_secret"] if transport else "") or "")
    try:
        endpoints = json.loads(str((transport["center_peer_endpoints"] if transport else "") or "[]"))
    except Exception:
        endpoints = []
    if not secret or not isinstance(endpoints, list) or not endpoints:
        return 0
    local_agents = {str(r["id"]) for r in c.execute(
        "select id from agents where node_id is not null and kind='ai'"
    ).fetchall()}
    agent_meta = {str(r["id"]): r for r in c.execute(
        "select id,name,kind,owner_id from agents"
    ).fetchall()}

    def outbound_sender(aid: str):
        """Return (wire_agent_id, wire_owner_id, wire_agent_name).

        Laptop-local humans and agents use the local owner.  A writable share
        viewer is a local row named remote-human-<owner>; its message must
        keep the viewer's owner across the peer boundary instead of being
        silently skipped.
        """
        aid = str(aid or "")
        if aid == host:
            return "", str(st.center.owner_id or ""), ""
        if aid in local_agents:
            return aid, str(st.center.owner_id or ""), ""
        row = agent_meta.get(aid)
        if row and str(row["kind"] or "") == "human":
            owner = str(row["owner_id"] or "")
            if not owner:
                return None
            return ("", owner, str(row["name"] or ""))
        return None

    rows = direct_candidates(c, rid)
    for m in rows:
        if not str(m["client_message_id"] or ""):
            cid = "cm-" + uuid.uuid4().hex
            c.execute("update room_messages set client_message_id=? where id=?", (cid, m["id"]))
    c.commit()
    from core.peer_server import post_direct_group_message
    sent = 0
    for m in rows:
        sender = outbound_sender(str(m["agent_id"] or ""))
        if not sender:
            direct_mark_skipped(c, m["id"], "no_outbound_identity")
            continue
        out_aid, out_owner, out_name = sender
        client_id = str(m["client_message_id"] or "") or ("cm-" + uuid.uuid4().hex)
        files = _direct_attachment_files(m["attachment"])
        if files:
            _att_mark(c, m["id"], "pending")     # 在传：UI 显示"同步中"而不是死链
        direct_ok = True
        direct_meta = []
        direct_err = ""
        if files:
            from core.peer_server import post_direct_file
            for f in files:
                up = post_direct_file(group_id=gid, secret=secret, endpoints=endpoints,
                                      name=f["name"], data=f["data"], content_type=f["mime"])
                if not up.get("ok_all"):
                    direct_ok = False
                    direct_err = "attachment: " + "; ".join((up.get("errors") or [])[:2])
                    break
                direct_meta.append({"sha256": f["sha256"], "name": f["name"],
                                    "mime": f["mime"], "size": f["size"]})
        direct = {"ok_all": False, "errors": []}
        if direct_ok:
            # 局域网直连同样加密（T12）：正文用同一套 CEK + 每成员信封，
            # 差别只在传输通道是 HTTP 而非中心。拿不到公钥就不发明文，留给下次重试。
            plain = str(m["body"] or "")[:4000]
            body_enc, keys = "", {}
            if plain:
                try:
                    from core.group_crypto import seal_group
                    from taa_node_v05.center import CenterClient
                    body_enc, keys, _missing = seal_group(
                        st, CenterClient(st.center.base), gid, plain)
                except Exception as exc:  # noqa: BLE001
                    direct_mark_retry(c, m, f"e2ee_keys_unavailable: {exc}")
                    continue
            direct = post_direct_group_message(
                group_id=gid, secret=secret, endpoints=endpoints,
                payload={
                    "client_message_id": client_id,
                    "reply_to": _reply_center_id(c, rid, m["reply_to_id"]),
                    "owner_id": out_owner,
                    "node_id": st.node.node_id,
                    "agent_id": out_aid,
                    "agent_name": out_name,
                    "body": "" if body_enc else plain,
                    "body_enc": body_enc,
                    "keys": keys,
                    "enc_v": 1 if body_enc else 0,
                    "created_at": str(m["created_at_utc"] or
                                       timeutil.to_utc_iso(m["created_at"], assume="local")),
                    "attachments": direct_meta,
                },
            )
            direct_err = "; ".join((direct.get("errors") or [])[:3])
        if direct.get("ok_all"):
            direct_mark_delivered(c, m["id"], client_id)
            if files:
                _att_mark(c, m["id"], "synced")
            sent += 1
        else:
            direct_mark_retry(c, m, direct_err or "undelivered")
            # 重试耗尽 = 直投放弃：附件落 failed（可重试），不谎报已同步。
            if files and int(m["direct_attempts"] or 0) + 1 >= DIRECT_MAX_ATTEMPTS:
                _att_mark(c, m["id"], "failed")
    c.commit()
    return sent


def _center_attachment_urls(st, client, gid: str, att_json: str | None
                             ) -> tuple[list[str], list[str]]:
    """Upload local files to center R2 only when direct delivery failed.

    返回 `(已上传 URL 列表, 因超过 2MB 未能跨网的 sha256 列表)`。

    超限附件在「直连已失败 → 只能走中心兜底」这条路径上永远发不出去。
    调用方据此把**该附件**状态标成 failed，让发件人看到"未同步"，
    而不是以为对方收到了。这是事后一次性提示，不做发送前拦截——
    发送前拦截在 P2P 正常的绝大多数场景下都是误报。
    """
    if not att_json:
        return [], []
    try:
        items = json.loads(att_json)
    except Exception:
        return [], []
    out: list[str] = []
    oversize: list[str] = []
    import mimetypes
    from pathlib import Path as _Path
    for item in items[:9] if isinstance(items, list) else []:
        if isinstance(item, str):
            url = item
            p = _Path(ROOT) / url.lstrip("/") if url.startswith("/static/uploads/") else None
            name = p.name if p else "attachment"
        elif isinstance(item, dict):
            url = _transport_image_url(str(item.get("transport_url") or item.get("url") or ""))
            p = _Path(ROOT) / url.lstrip("/") if url.startswith("/static/uploads/") else None
            name = str(item.get("name") or (p.name if p else "attachment"))
        else:
            continue
        if not p or not p.is_file():
            continue
        try:
            data = p.read_bytes()
        except OSError:
            continue
        # 兜底附件上限 2MB：与 P2P 直连（core/peer_server.py）和中心
        # （alice src/nodeidentity.ts）保持一致，避免"传得上去、下不来"。
        if not data or len(data) > 2 * 1024 * 1024:
            if data:
                oversize.append(hashlib.sha256(data).hexdigest())
            continue
        try:
            res = client.upload_group_file_for_node(
                node_key=st.node.node_key, group_id=gid, name=name, data=data,
                content_type=mimetypes.guess_type(name)[0] or "application/octet-stream",
            )
            if res.get("url"):
                out.append(str(res["url"]))
        except Exception:  # noqa: BLE001
            continue
    return out, oversize


def _download_center_attachment(st, url: str) -> str:
    """Download a center fallback image into local uploads before 7-day expiry."""
    u = str(url or "").strip()
    if not u:
        return ""
    base = str(getattr(getattr(st, "center", None), "base", "") or "").rstrip("/")
    if u.startswith("/"):
        u = base + u
    if base and not u.startswith(base + "/"):
        return ""
    if not u.startswith(("https://", "http://")):
        return ""
    last = ""
    for attempt in range(3):
        try:
            req = urllib.request.Request(u, headers={"user-agent": "TAA-LocalDownload/1"})
            with urllib.request.urlopen(req, timeout=12) as resp:
                ctype = str(resp.headers.get("content-type") or "")
                data = resp.read(2 * 1024 * 1024 + 1)
            if not data or len(data) > 2 * 1024 * 1024:
                last = "size"
                continue
            if not ctype.startswith("image/"):
                last = "type"
                continue
            digest = hashlib.sha256(data).hexdigest()
            ext = mimetypes.guess_extension(ctype.split(";", 1)[0]) or ".webp"
            if ext == ".jpe":
                ext = ".jpg"
            name = "center-" + digest[:24] + ext
            out = ROOT / "static" / "uploads" / name
            out.parent.mkdir(parents=True, exist_ok=True)
            if not out.exists():
                out.write_bytes(data)
            return "/static/uploads/" + name
        except Exception as exc:  # noqa: BLE001
            last = type(exc).__name__
            time.sleep(0.4 * (attempt + 1))
    return ""


def repair_center_attachments(c, st, rid: str) -> int:
    """Retry local download for center URLs that were not saved yet."""
    changed = 0
    rows = c.execute("select id,attachment from room_messages where room_id=? "
                     "and attachment like '%/v05/collab/files/%'", (rid,)).fetchall()
    for row in rows:
        try:
            items = json.loads(row["attachment"] or "[]")
        except Exception:
            continue
        out = []
        dirty = False
        for item in items if isinstance(items, list) else []:
            if not isinstance(item, dict):
                continue
            item = dict(item)
            u = str(item.get("center_url") or item.get("url") or "")
            if "/v05/collab/files/" in u:
                local = _download_center_attachment(st, u)
                if local:
                    item["url"] = local
                    item["center_url"] = u
                    dirty = True
            out.append(item)
        if dirty:
            c.execute("update room_messages set attachment=? where id=?",
                      (json.dumps(out, ensure_ascii=False), row["id"]))
            changed += 1
    if changed:
        c.commit()
    return changed


def _maybe_dispatch_remote(c, *, rid: str, mid: int, body: str, source: str,
                            owner_id: str = "", local_owner_id: str = "") -> None:
    """Route newly pulled center/peer messages into the local executor once."""
    # 2026-11-02 docs/532 · P-C：p2p（拉取入库的那批）此前被白名单挡在外面 →
    # 跨机消息永不派活。来源归一化只在这一处判。
    if source not in ("center", "peer", "p2p") or not mid:
        return
    row = c.execute("select executor_dispatched,created_at_utc,kind from room_messages where id=?",
                    (mid,)).fetchone()
    if not row or int(row["executor_dispatched"] or 0):
        return
    if str(row["kind"] or "") in ("skip", "system"):
        c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
        c.commit()
        return
    # Do not re-run history on the first sync after an upgrade.
    dt = timeutil.parse(row["created_at_utc"], assume="utc") if row["created_at_utc"] else None
    if dt is not None:
        age = (datetime.datetime.now(datetime.timezone.utc) - dt).total_seconds()
        if age > 600:
            c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
            c.commit()
            return
    # Center pull can echo a local-owner message that was already handled by
    # the local UI; skip that.  A peer message is remote-originated even when
    # it carries our owner id (for example an Owner share page on another
    # node), and must still be routed/executed locally.
    if source != "peer" and owner_id and local_owner_id and owner_id == local_owner_id:
        c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
        c.commit()
        return
    room = c.execute("select read_only,status from rooms where id=?", (rid,)).fetchone()
    if room and int(room["read_only"] or 0):
        return
    from core import executor_bridge
    # 本机 owner 由调用方给出（跨机拉取已知归属），显式传下去；
    # 不依赖 ~/.taa 全局 identity，否则隔离测试/多身份实例会被过滤成空目标。
    targets = executor_bridge.resolve(rid, body, owner_id=local_owner_id or None)
    if not targets:
        c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
        c.commit()
        return
    if not executor_bridge.should_execute(body):
        c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
        c.commit()
        return
    try:
        mrow = c.execute("select client_message_id from room_messages where id=?", (mid,)).fetchone()
        mcid = str(mrow["client_message_id"] or "") if mrow else ""
        claimed_route = message_route.claim(c, room_id=rid, message_id=mid,
                                            client_message_id=mcid, owner="dispatcher")
        if not claimed_route:
            c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
            c.commit()
            return
    except Exception:  # noqa: BLE001
        claimed_route = False
    accepted = False
    from core import group_command as _gc, group_ingress as _ingress
    room_row = c.execute("select center_group_id from rooms where id=?", (rid,)).fetchone()
    group_id = str(room_row["center_group_id"] or "") if room_row else ""
    msg_row = c.execute("select center_message_id,peer_message_id from room_messages where id=?",
                        (mid,)).fetchone()
    for t in targets:
        try:
            cmd = _gc.create(
                c, room_id=rid, local_message_id=mid, group_id=group_id,
                center_message_id=str((msg_row["center_message_id"] if msg_row else "") or ""),
                peer_message_id=str((msg_row["peer_message_id"] if msg_row else "") or ""),
                source_owner_id=owner_id, target_agent_id=t.agent)
            accepted = True
            state = str(cmd.get("state") or "")
            if state in ("immediate", "idle"):
                try:
                    _ingress.materialize(c, cmd)
                except Exception as exc:  # noqa: BLE001
                    executor_bridge.notice(rid, "system", f"⚠ 指令物化失败（{t.name}）：{exc}")
            if state == "pending_consent":
                executor_bridge.notice(
                    rid, "system",
                    f"⚠ 跨 owner 指令待 {t.name} 的 owner 在 10 秒内选择：立即执行 / 拒绝；默认等空闲")
            elif state.startswith("offline_"):
                executor_bridge.notice(
                    rid, "system", f"⚠ {t.name} 当前离线或未知，未执行入站指令（{state}）")
        except Exception as exc:  # noqa: BLE001
            executor_bridge.notice(rid, "system", f"⚠ 指令登记失败（{t.name}）：{exc}")
    if accepted:
        c.execute("update room_messages set executor_dispatched=1 where id=?", (mid,))
        c.commit()
    # P1.3：claim 必须有配对终态。旧实现抢到所有权就不管了，整表永远停在 claimed，
    # 只能等租约过期兜底——账面看不出"派发成功"还是"派发失败"。
    if claimed_route:
        try:
            message_route.finish(c, room_id=rid, message_id=mid, owner="dispatcher",
                                 state="done" if accepted else "failed",
                                 note="dispatched" if accepted else "no target accepted")
        except Exception:  # noqa: BLE001
            pass


def _short_rw():
    """Short write connection for the direct path; never wait 30s for a slow center pull."""
    c = rw()
    try:
        c.execute("PRAGMA busy_timeout = 2000")
    except Exception:  # noqa: BLE001
        pass
    return c


def _room_direct_lock(rid: str):
    with _ROOM_DIRECT_LOCKS_GUARD:
        lock = _ROOM_DIRECT_LOCKS.get(rid)
        if lock is None:
            lock = threading.Lock()
            _ROOM_DIRECT_LOCKS[rid] = lock
        return lock


# 单次直投的时间预算（秒）。对端离线时每次 POST 都要等满 2s 超时，
# 「消息数 × 端点数 × 附件数」会线性叠加；不封顶就会长占 `_room_direct_lock`，
# 让后续每条消息都排队变慢（2026-10-31 事故）。超预算的部分留给后台 worker 与中心重试。
DIRECT_FLUSH_BUDGET_S = 3.0


def _direct_flush_room(rid: str) -> int:
    """Direct peer flush with short DB transactions and no global sync lock."""
    with _room_direct_lock(rid):
        return _direct_flush_room_locked(rid)


def _direct_flush_room_locked(rid: str) -> int:
    st = center_state()
    if not st or not st.center.base or not st.center.owner_id or not st.node.node_key:
        return 0
    c = _short_rw()
    try:
        ensure_center_group_column(c)
        ensure_center_message_column(c)
        row = c.execute("select center_group_id,center_transport_secret,center_peer_endpoints "
                        "from rooms where id=?", (rid,)).fetchone()
        gid = str(row["center_group_id"] or "") if row else ""
        secret = str(row["center_transport_secret"] or "") if row else ""
        try:
            endpoints = json.loads(str((row["center_peer_endpoints"] if row else "") or "[]"))
        except Exception:
            endpoints = []
        if not gid or not secret or not isinstance(endpoints, list) or not endpoints:
            return 0
        local_agents = {str(r["id"]) for r in c.execute(
            "select id from agents where node_id is not null and kind='ai'").fetchall()}
        agent_meta = {str(r["id"]): r for r in c.execute(
            "select id,name,kind,owner_id from agents").fetchall()}
        host = human_id(c)
        rows = direct_candidates(c, rid)
        prepared = []
        for m in rows:
            aid = str(m["agent_id"] or "")
            if aid == host:
                out_aid, out_owner, out_name = "", str(st.center.owner_id or ""), ""
            elif aid in local_agents:
                out_aid, out_owner, out_name = aid, str(st.center.owner_id or ""), ""
            else:
                meta = agent_meta.get(aid)
                if not (meta and str(meta["kind"] or "") == "human"):
                    # 结构上不可出站（如 agent_id='system'）：一次落终态，
                    # 否则每次同步都要重扫一遍，队列只增不减。
                    direct_mark_skipped(c, m["id"], f"agent_not_outbound:{aid or '-'}")
                    continue
                out_owner = str(meta["owner_id"] or "")
                if not out_owner:
                    direct_mark_skipped(c, m["id"], f"agent_without_owner:{aid or '-'}")
                    continue
                out_aid, out_name = "", str(meta["name"] or "")
            client_id = str(m["client_message_id"] or "") or ("cm-" + uuid.uuid4().hex)
            prepared.append({
                "id": int(m["id"]),
                "agent_id": out_aid,
                "owner_id": out_owner,
                "agent_name": out_name,
                "body": str(m["body"] or "")[:4000],
                "attachment": m["attachment"],
                "client_id": client_id,
                "attempts": int(m["direct_attempts"] or 0),
                "created_at": str(m["created_at_utc"] or
                                   timeutil.to_utc_iso(m["created_at"], assume="local")),
                "reply_to": _reply_center_id(c, rid, m["reply_to_id"]),
            })
        c.commit()
    finally:
        c.close()
    if not prepared:
        return 0
    from core.peer_server import post_direct_file, post_direct_group_message
    sent = 0
    deadline = time.monotonic() + DIRECT_FLUSH_BUDGET_S
    for m in prepared:
        if time.monotonic() > deadline:
            break                      # 预算用尽：本轮不算失败，留给下一轮
        direct_meta = []
        direct_ok = True
        direct_err = ""
        files = _direct_attachment_files(m["attachment"])
        if files:
            for f in files:
                if time.monotonic() > deadline:
                    direct_ok = False
                    direct_err = "budget"
                    break
                up = post_direct_file(group_id=gid, secret=secret, endpoints=endpoints,
                                      name=f["name"], data=f["data"], content_type=f["mime"])
                if not up.get("ok_all"):
                    direct_ok = False
                    direct_err = "attachment: " + "; ".join((up.get("errors") or [])[:2])
                    break
                direct_meta.append({"sha256": f["sha256"], "name": f["name"],
                                    "mime": f["mime"], "size": f["size"]})
        direct = {"ok_all": False, "errors": []}
        if direct_ok:
            direct = post_direct_group_message(
                group_id=gid, secret=secret, endpoints=endpoints,
                payload={
                    "client_message_id": m["client_id"],
                    "reply_to": m["reply_to"],
                    "owner_id": m["owner_id"],
                    "node_id": st.node.node_id,
                    "agent_id": m["agent_id"],
                    "agent_name": m["agent_name"],
                    "body": m["body"],
                    "created_at": m["created_at"],
                    "attachments": direct_meta,
                })
            direct_err = "; ".join((direct.get("errors") or [])[:3])
        c2 = _short_rw()
        try:
            if direct.get("ok_all"):
                direct_mark_delivered(c2, m["id"], m["client_id"])
                if files:
                    _att_mark(c2, m["id"], "synced")
                sent += 1
            elif direct_err != "budget":
                direct_mark_retry(c2, m, direct_err or "undelivered")
                if files and int(m["attempts"] or 0) + 1 >= DIRECT_MAX_ATTEMPTS:
                    _att_mark(c2, m["id"], "failed")
            elif files:
                _att_mark(c2, m["id"], "pending")   # 预算用尽：本轮没发，留在待同步
            c2.commit()
        finally:
            c2.close()
    return sent


def _flush_direct_for_room(rid: str) -> None:
    """Fast direct-only path; never waits for a slow center pull."""
    _direct_flush_room(rid)


def _room_sync_lock(rid: str):
    global _ROOM_SYNC_LOCKS
    with _ROOM_SYNC_LOCKS_GUARD:
        lock = _ROOM_SYNC_LOCKS.get(rid)
        if lock is None:
            lock = threading.Lock()
            _ROOM_SYNC_LOCKS[rid] = lock
        return lock


def sync_group_messages_for_room(rid: str) -> None:
    # Direct is independent of center pull: short transaction, no global lock.
    try:
        _flush_direct_for_room(rid)
    except Exception:  # noqa: BLE001
        pass
    with _room_sync_lock(rid):
        return _sync_group_messages_for_room_unlocked(rid)


def _sync_group_messages_for_room_unlocked(rid: str) -> None:
    st = center_state()
    if not st or not st.center.base or not st.center.owner_id or not st.node.node_key:
        return
    c = rw()
    try:
        ensure_center_group_column(c)
        ensure_center_message_column(c)
        row = c.execute("select center_group_id from rooms where id=?", (rid,)).fetchone()
        gid = str(row["center_group_id"] or "") if row else ""
        if not gid:
            return
        # Direct delivery must not depend on center availability.
        try:
            flush_direct_group_messages(c, rid=rid, gid=gid, st=st, host=human_id(c))
        except Exception:  # noqa: BLE001
            pass
        from taa_node_v05.center import CenterClient
        client = CenterClient(st.center.base)
        # Pull center messages into local room_messages.
        payload = client.group_messages_for_node(node_key=st.node.node_key, group_id=gid)
        current_round = c.execute("select coalesce(current_round,1) from rooms where id=?", (rid,)).fetchone()
        rnd = int(current_round[0] if current_round else 1)
        host = human_id(c)
        local_ids = {str(a.agent_id) for a in getattr(st, "agents", []) or []}
        to_dispatch: list[tuple[int, str, str]] = []
        for m in payload.get("messages") or []:
            mid = str(m.get("message_id") or "")
            if not mid or c.execute("select 1 from room_messages where center_message_id=?", (mid,)).fetchone():
                continue
            owner_id = str(m.get("owner_id") or "")
            aid = str(m.get("agent_id") or "")
            if owner_id == st.center.owner_id:
                local_aid = aid if aid else host
                if aid and m.get("agent_name"):
                    row = c.execute("select full_name from agents where id=?", (aid,)).fetchone()
                    full = (str(row["full_name"] or "") if row and aid in local_ids
                            else f"{m.get('agent_name')}@center")
                    ensure_remote_stub(c, agent_id=aid, name=str(m.get("agent_name")),
                                       kind="ai", full_name=full,
                                       owner_id=st.center.owner_id,
                                       owner_name=str(m.get("owner_username") or st.center.username or ""))
            else:
                local_aid = aid if aid else ("remote-human-" + owner_id)
                if aid:
                    if not c.execute("select 1 from agents where id=?", (aid,)).fetchone():
                        ensure_remote_stub(c, agent_id=aid, name=str(m.get("agent_name") or aid),
                                           kind="ai", full_name=f"{aid}@center",
                                           owner_id=owner_id, owner_name=str(m.get("owner_username") or owner_id))
                else:
                    if not c.execute("select 1 from agents where id=?", (local_aid,)).fetchone():
                        ensure_remote_stub(c, agent_id=local_aid, name=str(m.get("owner_username") or owner_id),
                                           kind="human", full_name=f"{owner_id}@center",
                                           owner_id=owner_id, owner_name=str(m.get("owner_username") or owner_id))
            created_utc = timeutil.to_utc_iso(m.get("created_at"), assume="utc") or timeutil.now_utc_iso()
            created = timeutil.to_local_text(created_utc, assume="utc")
            reply_center = str(m.get("reply_to") or "")
            reply_local = None
            if reply_center:
                rr = c.execute("select id from room_messages where center_message_id=?", (reply_center,)).fetchone()
                reply_local = int(rr["id"]) if rr else None
            raw_atts = m.get("attachments")
            atts = []
            try:
                if isinstance(raw_atts, str):
                    raw_atts = json.loads(raw_atts)
                if isinstance(raw_atts, list):
                    for u in raw_atts:
                        if not u:
                            continue
                        local_u = _download_center_attachment(st, str(u))
                        is_center = "/v05/collab/files/" in str(u)
                        atts.append({"url": local_u or str(u),
                                     "name": str(u).rsplit("/", 1)[-1],
                                     "center_url": str(u) if is_center else ""})
            except Exception:
                atts = []
            # 群聊 E2EE：中心给的是密文，本机用自己 node 私钥解；解不开就明说，不猜。
            body_text = str(m.get("body") or "")
            if m.get("body_enc"):
                try:
                    from core.group_crypto import open_group
                    body_text = open_group(m, st)
                except Exception:  # noqa: BLE001
                    body_text = "[无法解密：本机没有这条消息的密钥]"
            cur = c.execute(
                "insert or ignore into room_messages(room_id,round,agent_id,body,kind,source,created_at,"
                "created_at_utc,center_message_id,client_message_id,attachment,reply_to_id,reply_to_center_id) "
                "values(?,?,?,?, 'assertion','center',?,?,?,?,?,?,?)",
                (rid, rnd, local_aid, body_text[:4000], created, created_utc, mid,
                 str(m.get("client_message_id") or "") or None,
                 json.dumps(atts, ensure_ascii=False) if atts else None,
                 reply_local, reply_center or None),
            )
            local_mid = int(cur.lastrowid or 0)
            if not local_mid:
                rr = c.execute("select id from room_messages where center_message_id=?", (mid,)).fetchone()
                local_mid = int(rr["id"]) if rr else 0
            if local_mid:
                to_dispatch.append((local_mid, body_text, owner_id))
                try:
                    payload = _ws_payload(c, rid, local_mid)
                    if payload:
                        _ws_broadcast(rid, {"type": "message", "message": payload})
                except Exception:  # noqa: BLE001
                    pass
        c.execute(
            "update room_messages set reply_to_id=("
            "  select t.id from room_messages t where t.center_message_id=room_messages.reply_to_center_id"
            ") where room_id=? and reply_to_id is null and reply_to_center_id is not null",
            (rid,))
        c.commit()
        # Route only newly pulled remote messages; local owner messages already
        # passed through /app/chats/send.
        for local_mid, body_txt, owner_txt in to_dispatch:
            try:
                _maybe_dispatch_remote(c, rid=rid, mid=local_mid, body=body_txt,
                                       source="center", owner_id=owner_txt,
                                       local_owner_id=str(st.center.owner_id or ""))
            except Exception as e:  # noqa: BLE001
                print(f"[app_ui] inbound executor err: {e}")
        try:
            repair_center_attachments(c, st, rid)
        except Exception:  # noqa: BLE001
            pass
        # Push local messages: direct peer first, center relay only on failure.
        local_agents = {str(r["id"]) for r in c.execute(
            "select id from agents where node_id is not null and kind='ai'"
        ).fetchall()}
        agent_meta = {str(r["id"]): r for r in c.execute(
            "select id,name,kind,owner_id from agents"
        ).fetchall()}

        def outbound_sender(aid: str):
            aid = str(aid or "")
            if aid == host:
                return "", str(st.center.owner_id or ""), ""
            if aid in local_agents:
                return aid, str(st.center.owner_id or ""), ""
            row = agent_meta.get(aid)
            if row and str(row["kind"] or "") == "human":
                owner = str(row["owner_id"] or "")
                if not owner:
                    return None
                return ("", owner, str(row["name"] or ""))
            return None

        transport = c.execute(
            "select center_transport_secret,center_peer_endpoints from rooms where id=?", (rid,)
        ).fetchone()
        secret = str((transport["center_transport_secret"] if transport else "") or "")
        endpoints: list[dict] = []
        try:
            endpoints = json.loads(str((transport["center_peer_endpoints"] if transport else "") or "[]"))
        except Exception:
            endpoints = []
        if not isinstance(endpoints, list):
            endpoints = []
        rows = c.execute(
            "select id,agent_id,body,attachment,client_message_id,reply_to_id "
            "from room_messages where room_id=? "
            "and center_message_id is null and coalesce(direct_delivered,0)=0 and kind not in ('skip') "
            "and coalesce(direct_state,'pending')!='skipped' "
            "and coalesce(source,'') not in ('center','peer','p2p') order by id limit ?",
            (rid, DIRECT_BATCH)
        ).fetchall()
        from core.peer_server import post_direct_group_message
        for m in rows:
            sender = outbound_sender(str(m["agent_id"] or ""))
            if not sender:
                continue
            out_aid, out_owner, _out_name = sender
            # Center authenticates by node key and can only attribute the
            # local owner; a share viewer must not be rewritten as the host.
            if out_owner != str(st.center.owner_id or ""):
                continue
            client_id = str(m["client_message_id"] or "") or ("cm-" + uuid.uuid4().hex)
            # Direct was already attempted before center pull. Do not resend
            # base64 here; this path is the center fallback only.
            try:
                center_atts, oversize = _center_attachment_urls(st, client, gid, m["attachment"])
                # 群聊 E2EE：有正文就加密；纯附件消息没有正文可加。
                plain = str(m["body"] or "")[:4000]
                body_enc, keys, missing = "", {}, []
                if plain:
                    try:
                        from core.group_crypto import seal_group
                        body_enc, keys, missing = seal_group(st, client, gid, plain)
                    except Exception as exc:  # noqa: BLE001
                        # 一个成员公钥都拿不到：这条不发明文，保持本地待同步，下次再试。
                        print(f"[app_ui] e2ee seal err: {exc}（本条暂不发送）")
                        continue
                if missing:
                    print(f"[app_ui] e2ee: {len(missing)} 名成员未上报公钥，本条收不到")
                out = client.send_group_message_for_node(
                    node_key=st.node.node_key, group_id=gid,
                    body="" if body_enc else plain,
                    agent_id=out_aid, client_message_id=client_id, attachments=center_atts,
                    reply_to=_reply_center_id(c, rid, m["reply_to_id"]),
                    body_enc=body_enc, keys=keys, enc_v=1 if body_enc else 0,
                    sender_node_id=str(st.node.node_id or ""))
                cmid = str((out.get("message") or {}).get("message_id") or "")
                if cmid:
                    c.execute("update room_messages set center_message_id=?,client_message_id=? where id=?",
                              (cmid, client_id, m["id"]))
                    # 超 2MB 的附件在这条"直连已失败 → 中心兜底"路径上发不出去。
                    # 只标该附件 failed，不牵连同一条消息里成功的小附件；
                    # 前端徽标会显示"未同步"，这就是事后一次性提示。
                    if oversize:
                        from core import attachments as _att
                        for sha in oversize:
                            _att.set_status(c, int(m["id"]), sha, "failed")
                    c.commit()
            except Exception:  # noqa: BLE001
                break
        c.commit()
    except Exception:  # noqa: BLE001
        return
    finally:
        c.close()


_GROUP_SEND_LOCK = threading.Lock()
_GROUP_SEND_JOBS: set[str] = set()
_GROUP_SEND_DIRTY: set[str] = set()
_GROUP_MESSAGE_SYNC_LOCK = threading.Lock()
_ROOM_SYNC_LOCKS: dict[str, threading.Lock] = {}
_ROOM_SYNC_LOCKS_GUARD = threading.Lock()
_ROOM_DIRECT_LOCKS: dict[str, threading.Lock] = {}
_ROOM_DIRECT_LOCKS_GUARD = threading.Lock()


def queue_group_message_sync(rid: str) -> None:
    """Send the newly inserted message in the background; do not hold the page.

    If a room is already syncing, mark it dirty instead of dropping the new
    message.  The worker re-runs until no dirty flag remains, so two messages
    sent in quick succession both cross the peer/center boundary.
    """
    if not rid:
        return
    # 2026-10-31 事故（发的帖子不回清空）：这里原来**同步**跑一次
    # `_flush_direct_for_room`，而直投是「每条待投消息 × 每个 peer 端点 × 每张附件」
    # 逐个 HTTP，每次 2s 超时。带 5 张附件的消息＝5×2s(文件)+2s(消息)=12s，
    # 正好撞死前端 12s 的 AbortController → 消息其实已入库，界面却报"发送超时"
    # 且不清空草稿。`_run()` 里已有同样的直投（线程一启动就执行），此处那一次纯属
    # 重复：删掉后投递语义不变，HTTP 请求立刻返回。
    with _GROUP_SEND_LOCK:
        if rid in _GROUP_SEND_JOBS:
            _GROUP_SEND_DIRTY.add(rid)
            return
        _GROUP_SEND_JOBS.add(rid)

    def _run() -> None:
        try:
            # Deliver directly first.  A center pull for another room can hold
            # the shared sync lock for tens of seconds; the user must still see
            # this message on the peer immediately.
            try:
                _flush_direct_for_room(rid)
            except Exception:  # noqa: BLE001
                pass
            while True:
                sync_group_messages_for_room(rid)
                with _GROUP_SEND_LOCK:
                    if rid in _GROUP_SEND_DIRTY:
                        _GROUP_SEND_DIRTY.discard(rid)
                        continue
                    _GROUP_SEND_JOBS.discard(rid)
                    break
        except Exception:  # noqa: BLE001
            with _GROUP_SEND_LOCK:
                _GROUP_SEND_JOBS.discard(rid)
                _GROUP_SEND_DIRTY.discard(rid)

    threading.Thread(target=_run, name="taa-group-send", daemon=True).start()


def page_chats():
    system = request.args.get("system") == "1"
    if system:
        c = db()
        try:
            body = system_body(c)
            return shell("系统通知", body, "chats", "开始使用与状态提醒",
                         side=side_chats(c, "", "", True),
                         page_css=PAGE_CSS["chat"] + CHAT_MOBILE_CSS,
                         app_class="chats-page chat-open")
        finally:
            c.close()
    # Lazy migration is process-once; never write all rooms on every page.
    try:
        ensure_room_meta_once()
    except Exception as _e:  # noqa: BLE001
        print(f"[app_ui] room canonical migration skipped: {_e}")
    rid = request.args.get("room") or ""
    if rid:
        _rc = db()
        try:
            _resolved = resolve_room(_rc, rid)
            if _resolved:
                rid = str(_resolved["id"])
        finally:
            _rc.close()
    # 好友入口：进「我 + TA 本人 + TA 的 agent」的房间，而不是与 agent 的私信。
    fr = (request.args.get("friend") or "").strip()
    if fr and not rid and not is_share():
        try:
            _frid = _friend_room_id(fr)
        except Exception:  # noqa: BLE001
            _frid = ""
        if _frid:
            return redirect(f"/app/chats?room={_frid}")
    ag = request.args.get("agent") or ""
    if ag and not rid and not is_share():
        c0 = rw()
        try:
            from core import rooms as rooms_mod0
            a0 = c0.execute("select id,name,kind from agents where id=?", (ag,)).fetchone()
            if a0 and a0["kind"] == "ai":
                hid0 = rooms_mod0.human_id(c0)
                rid = rooms_mod0.ensure_dm(c0, hid0, a0["id"], a0["name"] or a0["id"])
        finally:
            c0.close()
        if rid:
            return redirect(f"/app/chats?room={rid}")
    # Group directory/message sync runs in a background loop. Never block a
    # chat page on center DNS/API latency (was 8-15s per page open).
    c = db()
    room = c.execute("select * from rooms where id=?", (rid,)).fetchone() if rid else None
    public_rid = public_room_id(room) if room else rid
    _sv = share_viewer()
    hid = (_sv or {}).get("id") or human_id(c)
    # 旧群房可能只有 AI：真人打开时补齐 human member（share 只读不写）。
    if room and not is_share():
        try:
            has_human = c.execute(
                "select 1 from room_members where room_id=? and agent_id=? and kind='human'",
                (rid, hid)).fetchone()
            if not has_human:
                from core import rooms as rooms_mod_ensure
                _rw = rw()
                try:
                    rooms_mod_ensure.ensure_human_member(_rw, rid, hid)
                finally:
                    _rw.close()
                room = c.execute("select * from rooms where id=?", (rid,)).fetchone()
        except Exception as e:  # noqa: BLE001
            print(f"[app_ui] ensure human member err: {e}")
    msgs = []
    members = []
    if room:
        msgs = c.execute("""select id,round,agent_id,body,attachment,created_at,created_at_utc,
            source,kind,reply_to_id from room_messages
            where room_id=? and kind != 'skip' order by id desc limit 300""", (rid,)).fetchall()
        msgs = list(reversed([m for m in msgs
                              if m["kind"] != "system" or _show_system_receipt(m)]))
        members = [r["agent_id"] for r in c.execute("select agent_id from room_members where room_id=?", (rid,))]
    ai_members = [r["agent_id"] for r in c.execute(
        "select m.agent_id from room_members m join agents a on a.id=m.agent_id "
        "where m.room_id=? and a.kind='ai'", (rid,))] if room else []
    # 参与人：room_members + agents + 本房最近发言（见 room_members()）
    member_info = room_members(c, rid, viewer=None if is_share() else hid) if room else []
    member_names = [str(x.get("name") or x.get("id") or "") for x in member_info]
    online_count = sum(1 for x in member_info if x["state"] == "online")
    human_count = sum(1 for x in member_info if x["kind"] == "human")
    ai_count = sum(1 for x in member_info if x["kind"] == "ai")
    is_dm = bool(room and (room["kind"] == "dm" or (not room["kind"] and len(members) == 2 and len(ai_members) == 1)))
    archived = bool(room and room["kind"] == "archived")
    running = bool(room and room["status"] == "running" and not archived)
    name_map = {r["id"]: (r["name"] or r["id"])
                for r in c.execute("select id,name from agents")}
    name_map["human"] = owner_display_name(c)
    node_map = {r["id"]: (r["node_id"] or "")
                for r in c.execute("select id,node_id from agents")}
    graph_ids = {r[0] for r in c.execute(
        "select g.message_id from argument_graphs g join room_messages m on m.id=g.message_id where m.room_id=?",
        (rid,))} if rid else set()
    parts = []
    last_day = ""
    for m in msgs:
        mdt = fmt_msg_dt(m)
        day = mdt[:10]
        if day and day != last_day:
            parts.append(f'<div class="daysep">{esc(day)}</div>')
            last_day = day
        who_name = name_map.get(m["agent_id"], m["agent_id"])
        ri = _reply_info(c, rid, m["reply_to_id"])
        reply_html = (f'<div class="replyquote"><b>{esc(ri.get("name") or "")}</b>：'
                      f'{esc(ri.get("text") or "")}</div>') if ri else ""
        if (m["source"] or "chat") == "opencode":
            node = node_map.get(m["agent_id"]) or ""
            full = f"{who_name}@{node}" if node else who_name
            hhmm = esc(mdt[11:16])
            parts.append(
                f'<div class="devlog" data-id="{m["id"]}">'
                f'<div class="devlog-head">🔧 opencode 工作汇报 · {esc(full)} · {hhmm}</div>'
                f'<div class="devlog-body">{md_html(m["body"])}{_post_refs(m["body"], c=c)}</div></div>')
            last_day = day
            continue
        me = m["agent_id"] == hid
        gpng = ROOT / "rooms" / rid / f"msg-{m['id']}.png"
        graph = m["id"] in graph_ids and gpng.exists()
        acts = (f'<div class="acts"><button class="actbtn detailbtn" type="button" title="{tr("chat.detail_hint", "在右侧查看这条消息的全文与附件")}">{tr("js.detail", "详情")}</button>'
                f'<button class="actbtn replybtn" type="button" data-reply="{m["id"]}" data-reply-name="{esc(who_name)}">回复</button>'
                f'<button class="actbtn copybtn" type="button">{tr("js.copy", "复制")}</button></div>')
        chip = (f'<button class="graphchip" type="button" data-full="/app/graph/{quote(rid)}/{m["id"]}.png">论证</button>' if graph else "")
        parts.append(
            f'<div class="msg{" me" if me else ""}" data-id="{m["id"]}" data-author="{esc(m["agent_id"])}" '
            f'data-name="{esc(who_name)}" data-time="{esc(mdt)}" '
            f'data-round="{esc(m["round"] or "")}" tabindex="0" '
            f'aria-label="查看 {esc(who_name)} 的消息详情">'
            f'<span class="mava">{avatar(m["agent_id"], 28)}</span>'
            f'<div class="bubble"><div class="who" title="@{esc(m["agent_id"])}">'
            f'{esc(who_name)}'
            f' · 第 {esc(m["round"] or "—")} 轮'
            f' · {esc(mdt)}{chip}</div>'
            f'{reply_html}'
            f'<div class="text">{md_html(m["body"])}</div>{_post_refs(m["body"], c=c)}'
            f'{_att_html(m["attachment"], "chatatt")}</div>'
            f'{acts}</div>')
    log = "".join(parts)
    if not room:
        log = f'<div class="empty-log dim">{tr("chat.empty", "从左侧选一个会话，或先选一个 agent。")}</div>'
    rname = esc((room["title"] if room else "") or room["topic"] or room["id"]) if room else tr("chat.choose", "选择一个会话")
    rsub = ""
    total = 0
    if room:
        total = c.execute("""select count(*) n from room_messages
            where room_id=? and kind not in ('skip','system')""", (rid,)).fetchone()["n"]
        all_total = c.execute("select count(*) n from room_messages where room_id=?", (rid,)).fetchone()["n"]
        status_label = (tr("chat.archived", "归档") if archived
                        else tr("chat.running", "进行中") if running
                        else tr("chat.can_type", "可输入"))
        shown = len(msgs)
        host_name = next((m["name"] for m in member_info if m["role"] == "host"),
                         room["created_by"] or "")
        rsub = (f"{status_label} · {tr('chat.status_round', '第 {n} 轮').format(n=room['current_round'] or 1)} · {tr('chat.status_msgs', '{n} 条消息').format(n=total)} · {tr('chat.status_people', '{n} 人').format(n=len(member_info))}"
                + (tr("room.loaded", "（已载入最近 {n} 条）").format(n=shown) if total > shown else ""))
    act = ""
    if room and running:
        act = (f'<form method="post" action="/app/chats/end"><input type="hidden" name="room" value="{esc(rid)}">'
               f'<button class="btn" type="submit">{tr("chat.end", "结束")}</button></form>')
    disabled = " disabled" if (not room or archived or is_share()) else ""
    hint = (tr("chat.hint_start", "发送即开始 · 10 分钟主动 · 30 分钟软结束")
            + (tr("chat.hint_exec", " · /exec 干活") if is_dm else tr("chat.hint_mention", " · @agent 即派活"))) if room else tr("chat.choose", "选一个会话后开始。")
    if archived:
        hint = tr("chat.archived_hint", "历史归档，只读；新对话请从左侧私信进入。")
    elif room and room["status"] == "ended":
        hint = (tr("chat.hint_reopen", "发送即重开 · 10 分钟主动 · 30 分钟软结束")
                + (tr("chat.hint_exec", " · /exec 干活") if is_dm else tr("chat.hint_mention", " · @agent 即派活")))
    if _is_mobile():
        hint = tr("chat.note_hint", "留言板 · 异步，不保证即时回复") + (f" · {hint}" if hint else "")
    note_placeholder = (tr("chat.note_placeholder", "留个言（异步，不保证即时回复）…")
                        if _is_mobile()
                        else (tr("chat.direct", "直接说…") if is_dm else tr("chat.group", "说点什么；@agent 发送即派活…")))
    people_bar = ""
    people_table = ""
    if room:
        people_bar = (
            '<div class="peoplebar" id="peoplebar">'
            f'<div class="phead"><span class="kicker">{tr("chat.participants", "参与人")}</span>'
            f'<b id="pcount">{len(member_info)}</b><span class="dim">{tr("chat.participants_unit", "位 ·")}</span>'
            f'<span class="dim" id="pstat">{online_count} {tr("home.online", "在线")} · {human_count} {tr("room.human", "真人")} · {ai_count} agent</span></div>'
            f'<div class="plist" id="plist">{"".join(_member_chip(m) for m in member_info)}</div>'
            f'<button class="plink" id="ptoggle" type="button" aria-expanded="false">{tr("chat.people", "名单")}</button></div>'
            '<div class="ptable" id="ptable" hidden>'
            f'{"".join(_member_row(m) for m in member_info)}</div>')
    pending_bar = ""
    if room:
        try:
            _owner_row = c.execute("select owner_id from agents where id=?", (human_id(c),)).fetchone()
            _owner_id = str(_owner_row["owner_id"] or "") if _owner_row else ""
            _pending = c.execute(
                "select id,target_agent_id,state,consent_deadline from group_command "
                "where target_owner_id=? and state='pending_consent' "
                "order by consent_deadline limit 5", (_owner_id,)).fetchall() if _owner_id else []
            if _pending:
                _rows = "".join(
                    f'<div class="cmdrow"><b>@{r["target_agent_id"]}</b>'
                    f'<span>待选择 · 截止 {esc(r["consent_deadline"] or "")}</span>'
                    f'<form method="post" action="/app/group/commands/{esc(r["id"])}/decide" style="display:inline">'
                    f'<input type="hidden" name="room" value="{esc(rid)}"><button class="btn" name="decision" value="immediate">立即执行</button>'
                    f'<button class="btn" name="decision" value="reject">拒绝</button></form></div>'
                    for r in _pending)
                pending_bar = ('<div class="card" style="margin:0 0 10px;padding:10px 12px;border:1px solid var(--hair)">'
                               f'<div class="kicker">跨 owner 指令 · 10 秒内选择</div>{_rows}</div>')
        except Exception:  # noqa: BLE001
            pending_bar = ""
    body = f"""
  <section class="card room">
    <header class="roomhead">
      {f'<a class="mobile-back" href="/app/chats" aria-label="{tr("chat.back", "返回会话")}">‹</a>' if room else ''}
      <div><b id="rname">{rname}</b><div class="dim" id="rsub">{rsub}</div></div>
      <div class="roomacts"><span class="msg-detail-hint">{tr("chat.detail_hint", "点消息或「详情」查看全文")}</span>
        {f'<button class="btn" id="roomgallery" type="button" title="{tr("chat.gallery", "画廊")}">{tr("chat.gallery", "画廊")}</button>' if room else ''}
        {act}{f'<span class="tag{" off" if room and (room["status"] != "running" or archived) else ""}">{status_label}</span>' if room else ''}</div>
    </header>
    {f'<div class="sharebar">只读分享 · <a href="{esc(full_app_base())}/app/share/exit?next={esc(quote("/app/chats?room=" + rid, safe=""))}" target="_blank" rel="noopener">打开完整聊天</a>（需要 HTTPS/证书）</div>' if is_share() and room else ''}
    {pending_bar}
    {people_bar}
    <div class="liveturn" id="liveturn" hidden aria-live="polite">
      <span class="livedot"></span>
      <b id="livewho">等待</b>
      <span id="livestate">等待发言</span>
      <span class="livesep">·</span>
      <span id="liveround">第 — 轮</span>
      <span class="liveclock" id="liveclock"></span>
    </div>
    <div id="log" class="log" data-room="{esc(rid)}">{log}</div>
    <button class="newpill" id="newpill" type="button" role="status" aria-live="polite" hidden>{tr("chat.newpill", "↓ 新消息 · 回到最新")}</button>
    <form id="sayform" class="say" method="post" action="/app/chats/send">
      <input type="hidden" name="room" value="{esc(rid)}">
      <input type="hidden" name="client_message_id" id="client_message_id" value="">
      <input type="hidden" name="reply_to" id="reply_to" value="">
      <input type="hidden" name="images" id="chatimages" value="[]">
      <div class="say-main">
        <div id="chatpreview" class="imgpreview"></div>
        <textarea id="text" name="text" rows="2" placeholder="{note_placeholder}" maxlength="4000"{disabled} data-image-composer="chatimages" data-preview="chatpreview" data-hint="chatmsg"></textarea>
        <div id="chatmsg" class="dim"></div>
      </div>
        <input type="file" id="chat-file" accept="image/*" multiple style="display:none">
        <div class="say-actions">
          <button class="btn" type="button" id="chat-pick" title="{tr("chat.image", "图片")}">{tr("chat.image", "图片")}</button>
          <span class="sayhint" id="hint">{hint}</span>
          <button class="btn primary" type="submit"{disabled}>{tr("chat.send", "发送")}</button>
        </div>
        <div class="dim" style="font-size:12px;line-height:1.6;margin:6px 0 0">{tr("chat.relay_limit", "跨网兜底：单文件 ≤ 2MB，经中心中转的文件仅保留 24 小时；更大的文件请在局域网内直连发送。")}</div>
      </form>
  </section>"""
    scripts = ""
    if room:
        chat_js = """<script>
(function(){
  var log=document.getElementById("log");
  var I=window.TAA_I18N||{};
  function tx(k,d){ return I[k]||d; }
  function thumbURL(u){
    u=String(u||"");
    return /^[/]static[/]uploads[/]/.test(u)
      ? "/thumb?u="+encodeURIComponent(u)+"&w=480" : u;
  }
  var last=__LAST__, room=__ROOM__;
  var box=document.getElementById("sayform"), ta=document.getElementById("text");
  var ws=null, wsReady=false, wsViewer="";
  var cidEl=document.getElementById("client_message_id");
  function nextCid(){ return "cm-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8); }
  function ensureCid(){ if(cidEl && !cidEl.value) cidEl.value=nextCid(); return (cidEl&&cidEl.value)||nextCid(); }
  var replyEl=document.getElementById("reply_to");
  function clearReply(){ if(replyEl) replyEl.value=""; var hm=document.getElementById("chatmsg"); if(hm){ hm.textContent=""; hm.onclick=null; } }
  function setReply(id,name){ if(!replyEl) return; replyEl.value=String(id||""); var hm=document.getElementById("chatmsg");
    if(hm){ hm.textContent="回复 "+name+" · 点这里取消"; hm.onclick=clearReply; }
    if(ta) ta.focus(); }

  /* Step 2: small WS append path.  The ordered Host event is enough for a
     text message; existing HTTP/SSE remains the fallback for attachments and
     executor commands. */
  function clearSendHint(){
    var hm=document.getElementById("chatmsg");
    if(hm && /^(发送中|未确认)/.test(hm.textContent||"")) hm.textContent="";
  }
  function wsAppend(m){
    if(!m || !m.id) return;
    if(document.querySelector('[data-id="'+m.id+'"]')) return;
    var mine=!!(m.me || (wsViewer && m.from===wsViewer));
    var d=document.createElement("div");
    d.className="msg"+(mine?" me":""); d.dataset.id=m.id;
    d.dataset.author=m.from||""; d.dataset.name=m.from_name||m.from||""; d.dataset.time=m.time||"";
    d.dataset.round=m.round||""; d.tabIndex=0;
    var av=document.createElement("span"); av.className="mava";
    var avi=document.createElement("img"); avi.alt=""; avi.width=28; avi.height=28;
    avi.src="/avatar/m/"+encodeURIComponent(m.from||"?"); av.appendChild(avi);
    var b=document.createElement("div"); b.className="bubble";
    var w=document.createElement("div"); w.className="who"; w.title="@"+(m.from||"");
    w.textContent=(m.from_name||m.from)+" · 第 "+(m.round||"—")+" 轮 · "+(m.time||"");
    b.appendChild(w);
    if(m.reply && m.reply.text){
      var rq=document.createElement("div"); rq.className="replyquote";
      var rb=document.createElement("b"); rb.textContent=(m.reply.name||"")+"：";
      rq.appendChild(rb); rq.appendChild(document.createTextNode(m.reply.text||""));
      b.appendChild(rq);
    }
    var t=document.createElement("div"); t.className="text"; t.innerHTML=m.html||m.text||"";
    b.appendChild(t);
    var atts=(m.atts&&m.atts.length)?m.atts:(m.att?[m.att]:[]);
    if(atts.length){
      var abox=document.createElement("div"); abox.className="chatatt";
      atts.forEach(function(u){
        if(/[.](png|jpe?g|gif|webp|bmp)([?]|$)/i.test(u)){
          var im2=document.createElement("img"); im2.className="chatatt-img"; im2.src=thumbURL(u);
          im2.dataset.full=u; im2.alt=""; im2.loading="lazy"; im2.decoding="async"; abox.appendChild(im2);
        }else{
          var a2=document.createElement("a"); a2.className="attfile"; a2.href=u; a2.target="_blank"; a2.textContent=u.split("/").pop(); abox.appendChild(a2);
        }
      });
      b.appendChild(abox);
    }
    var acts=document.createElement("div"); acts.className="acts";
    var db=document.createElement("button"); db.type="button"; db.className="actbtn detailbtn"; db.textContent=tx("detail","详情"); acts.appendChild(db);
    var rbtn=document.createElement("button"); rbtn.type="button"; rbtn.className="actbtn replybtn"; rbtn.textContent="回复";
    rbtn.dataset.reply=m.id; rbtn.dataset.replyName=m.from_name||m.from||""; acts.appendChild(rbtn);
    var cb=document.createElement("button"); cb.type="button"; cb.className="actbtn copybtn"; cb.textContent=tx("copy","复制"); acts.appendChild(cb);
    d.appendChild(av); d.appendChild(b); d.appendChild(acts); log.appendChild(d);
    clearSendHint();
    last=Math.max(last, Number(m.id)||0);
    if(typeof stick!=="undefined" && stick){ log.scrollTop=log.scrollHeight; }
    else if(typeof showPill==="function"){ showPill(1); }
  }
  var wsFails=0, wsTimer=null;
  function wsNotice(text){
    var hm=document.getElementById("chatmsg");
    if(hm){ hm.textContent=text; hm.onclick=null; }
  }
  function wsConnect(){
    if(!window.WebSocket || ws) return;
    var proto=(location.protocol==="https:")?"wss:":"ws:";
    try{ ws=new WebSocket(proto+"//"+location.host+"/app/ws/room/"+encodeURIComponent(room)); }
    catch(e){ ws=null; return; }
    ws.onopen=function(){
      wsReady=true;
      wsFails=0;
      if(es){ try{es.close();}catch(e){} es=null; }
    };
    ws.onmessage=function(ev){
      try{
        var j=JSON.parse(ev.data||"{}");
        if(j.type==="hello"){ wsViewer=String(j.viewer_id||""); return; }
        if(j.type==="message" && j.message) wsAppend(j.message);
      }catch(e){}
    };
    ws.onclose=function(){
      wsReady=false; ws=null;
      // Never let a half-open/stale SSE block the polling fallback.
      if(es){ try{ es.close(); }catch(e){} es=null; }
      if(typeof startPoll==="function") startPoll();
      // 指数退避（2s→4s→…→60s 封顶）：LAN 6080 的 WS 会被 403 拒，
      // 原来每 2s 重连一次 = 1800 次/小时的 403 刷屏 + 日志膨胀。
      wsFails++;
      if(wsFails===1 || wsFails===6){
        wsNotice("实时连接不可用（第 "+wsFails+" 次失败），已降级为轮询"
          +(wsFails>=6 ? "；局域网 6080 只提供只读分享，完整聊天请用 6443" : ""));
      }
      var wait=Math.min(2000*Math.pow(2,Math.min(wsFails-1,5)),60000);
      clearTimeout(wsTimer); wsTimer=setTimeout(wsConnect,wait);
    };
    ws.onerror=function(){ try{ws.close();}catch(e){} };
  }
  var live=document.getElementById("liveturn"), lwho=document.getElementById("livewho"),
      lstate=document.getElementById("livestate"), lround=document.getElementById("liveround"),
      lclock=document.getElementById("liveclock");
  var liveNames={};
  function liveShow(who,state,round,remain,cls){
    if(!live) return;
    live.hidden=false; live.className="liveturn"+(cls?" "+cls:"");
    if(lwho) lwho.textContent=who||"在线成员";
    if(lstate) lstate.textContent=state||"";
    if(lround) lround.textContent="第 "+(round||"—")+" 轮";
    if(lclock) lclock.textContent=remain==null?"":(remain>0?remain+"s":"到点");
  }
  function liveRefresh(){
    fetch("/app/api/room/"+encodeURIComponent(room)+"/state").then(function(r){return r.json();}).then(function(j){
      if(!j||!j.ok) return;
      var r=(j.room||{}), t=j.turn;
      if(r.status!=="running"){ liveShow("会话已结束","可输入重开",r.round,null,""); return; }
      if(!t){ liveShow("等待真人","可以插话",r.round,null,""); return; }
      var dl=t.open_deadline||t.prepare_deadline||"";
      var remain=null;
      if(dl){
        var a=Date.parse(String(dl).replace(" ","T")), b=Date.parse(String(j.server_time||"").replace(" ","T"));
        if(!isNaN(a)&&!isNaN(b)) remain=Math.max(0,Math.floor((a-b)/1000));
      }
      var st=String(t.state||"").toLowerCase();
      var label=st.indexOf("think")>=0||st.indexOf("prepar")>=0?"思考中":
                st==="open"||st.indexOf("speak")>=0?"发言中":
                st==="waiting"?"等待发言":(t.state||"处理中");
      liveShow(liveNames[t.agent_id]||t.agent_id||"成员",label,t.round||r.round,remain,
               st==="open"||st.indexOf("speak")>=0?"busy":"");
    }).catch(function(){});
  }
  fetch("/app/api/room/"+encodeURIComponent(room)+"/members").then(function(r){return r.json();}).then(function(j){
    (j.members||[]).forEach(function(m){ liveNames[m.id]=m.name||m.id; });
    liveRefresh();
  }).catch(liveRefresh);
  setInterval(liveRefresh,4000);
  if(box){
    box.addEventListener("submit",function(){
      var txt=(ta&&ta.value||"").trim();
      if(!txt) return;
      // 这只是“投递状态”，不是 agent 的确认；真实回执必须等 Carol 的消息。
      liveShow("已投递","等待真实回应（不是程序回执）","—",null,"sent");
    });
  }

  /* ---- 右栏详情：默认是会话概览；点消息切成该消息的全文/附件/操作 ----
     目标：右栏不再是“只读统计卡”，而是跟随主区选择切换的上下文详情。
     宽屏固定显示（480–560px），窄屏为右侧抽屉；消息详情自动拉起抽屉，不挤压主区。 */
  var detailBox=document.getElementById("detail-scroll");
  var origDetail=detailBox?detailBox.innerHTML:"";
  var narrow=window.matchMedia("(max-width:1359px)");
  function escAttr(s){
    return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;")
      .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  function openDetail(){
    if(window.taaDetailSetOpen){ window.taaDetailSetOpen(true); return; }
    var app=document.querySelector(".app.with-detail"); if(!app) return;
    if(narrow.matches){
      app.classList.add("detail-open");
      var bd=document.getElementById("detail-backdrop"); if(bd) bd.hidden=false;
    } else { app.classList.remove("detail-collapsed"); }
  }
  function flashBtn(el,text){
    if(!el) return; var old=el.textContent; el.textContent=text;
    setTimeout(function(){ el.textContent=old; },1200);
  }
  function copyText(t){
    if(navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(t);
    var x=document.createElement("textarea"); x.value=t; x.style.position="fixed"; x.style.opacity="0";
    document.body.appendChild(x); x.select();
    try{ document.execCommand("copy"); }catch(e){}
    document.body.removeChild(x);
    return Promise.resolve();
  }
  function showMsg(el){
    if(!detailBox || !el) return;
    var text=el.querySelector(".text"), att=el.querySelector(".chatatt");
    var name=el.dataset.name||el.dataset.author||"", author=el.dataset.author||"", time=el.dataset.time||"";
    var mid=el.dataset.id||"";
    var all=Array.prototype.slice.call(document.querySelectorAll(".msg"));
    var idx=all.indexOf(el);
    function ctxRow(peer,label){
      if(!peer) return "";
      var tx=peer.querySelector(".text"); tx=tx?(tx.textContent||""):"";
      if(tx.length>96) tx=tx.slice(0,96)+"…";
      return '<button class="dflowrow" type="button" data-detail-jump="'+escAttr(peer.dataset.id||"")+'">'
        +'<span class="dfwho"><b>'+escAttr(peer.dataset.name||peer.dataset.author||"")+'</b>'+label+'</span>'
        +'<span class="dftext">'+escAttr(tx)+'</span></button>';
    }
    var ctx=(ctxRow(all[idx-1],"· "+tx("prev","上一条"))+ctxRow(all[idx+1],"· "+tx("next","下一条")))
      || '<p class="dnote">'+tx("page_first_last","已是本页第一条/最后一条。")+'</p>';
    detailBox.innerHTML=
      '<div class="dhero"><div class="kicker">'+tx("detail_title","消息详情")+'</div><h2>'+escAttr(name)+'</h2>'
      +'<p class="dsub">@'+escAttr(author)+' · '+escAttr(time)+' · #'+escAttr(mid)
      +' · '+tx("position","位置")+' '+(idx+1)+' / '+all.length+'</p>'
      +'<div class="dacts">'
      +'<button class="dact primary" type="button" data-msg-copy>'+tx("copy_body","复制正文")+'</button>'
      +'<button class="dact" type="button" data-detail-mention="'+escAttr(author)+'">'+tx("mention","@ 提及")+'</button>'
      +'<button class="dact" type="button" data-msg-prev'+(idx<=0?' disabled':'')+'>'+tx("prev","上一条")+'</button>'
      +'<button class="dact" type="button" data-msg-next'+(idx>=all.length-1?' disabled':'')+'>'+tx("next","下一条")+'</button>'
      +'<button class="dact" type="button" data-msg-locate="'+escAttr(mid)+'">'+tx("locate","定位到消息")+'</button>'
      +'<button class="dact" type="button" data-msg-back>'+tx("back","返回会话")+'</button>'
      +'</div></div>'
      +'<div class="dcard"><h3>'+tx("body","正文")+'</h3><div class="msgdetail-body">'+(text?text.innerHTML:"")+'</div></div>'
      +'<div class="dcard"><h3>'+tx("context","上下文")+'</h3><div class="dflow">'+ctx+'</div></div>'
      +(att&&att.innerHTML?'<div class="dcard"><h3>'+tx("attachments","附件")+'</h3>'+att.innerHTML+'</div>':'')
      +'<div class="dcard"><h3>'+tx("meta","元数据")+'</h3><dl class="dmeta">'
      +'<dt>'+tx("author","作者")+'</dt><dd>@'+escAttr(author)+'（'+escAttr(name)+'）</dd>'
      +'<dt>'+tx("time","时间")+'</dt><dd>'+escAttr(time)+'</dd>'
      +'<dt>'+tx("msgid","消息号")+'</dt><dd class="mono">#'+escAttr(mid)+'</dd>'
      +'<dt>'+tx("position","位置")+'</dt><dd>'+(idx+1)+' / '+all.length+' '+tx("loaded","（本页已载入）")+'</dd></dl></div>'
      +'<div class="dcard"><h3>'+tx("note","说明")+'</h3><p class="dnote">'+tx("detail_hint","点主区其他消息或「上一条 / 下一条」可切换；窄屏下抽屉自动打开。")
      +tx("copy_hint","「复制正文」只复制文字，图片请点附件另存。")+'</p></div>';
    detailBox.scrollTop=0;
    document.querySelectorAll(".msg.selected").forEach(function(x){x.classList.remove("selected");});
    el.classList.add("selected");
    openDetail();
  }
  if(detailBox){
    detailBox.addEventListener("click",function(e){
      var cp=e.target.closest("[data-msg-copy]");
      if(cp){
        var sel=document.querySelector(".msg.selected .text");
        var txt=sel?(sel.innerText||sel.textContent||""):"";
        copyText(txt).then(function(){ flashBtn(cp,(window.TAA_I18N||{}).copy_ok||"已复制"); },function(){ flashBtn(cp,(window.TAA_I18N||{}).copy_fail||"复制失败"); });
        e.preventDefault(); return;
      }
      var bk=e.target.closest("[data-msg-back]");
      if(bk){ detailBox.innerHTML=origDetail; detailBox.scrollTop=0; e.preventDefault(); return; }
      var pv=e.target.closest("[data-msg-prev]"), nx=e.target.closest("[data-msg-next]");
      if(pv||nx){
        var cur=document.querySelector(".msg.selected");
        var all=Array.prototype.slice.call(document.querySelectorAll(".msg"));
        var i=all.indexOf(cur), t=all[i+(pv?-1:1)];
        if(t){ showMsg(t); t.scrollIntoView({block:"center",behavior:"smooth"}); }
        e.preventDefault(); return;
      }
      var jp=e.target.closest("[data-detail-jump]");
      if(jp){
        var jm=document.querySelector('.msg[data-id="'+jp.getAttribute("data-detail-jump")+'"]');
        if(jm){ showMsg(jm); jm.scrollIntoView({block:"center",behavior:"smooth"}); }
        e.preventDefault(); return;
      }
      var lo=e.target.closest("[data-msg-locate]");
      if(lo){
        var m=document.querySelector('.msg[data-id="'+lo.getAttribute("data-msg-locate")+'"]');
        if(m){ m.scrollIntoView({block:"center",behavior:"smooth"}); m.classList.add("selected");
          if(narrow.matches && window.taaDetailSetOpen) window.taaDetailSetOpen(false); }
        e.preventDefault(); return;
      }
    });
  }
  log.addEventListener("click",function(e){
    var rp=e.target.closest(".replybtn");
    if(rp){ setReply(rp.getAttribute("data-reply"), rp.getAttribute("data-reply-name")||""); e.preventDefault(); return; }
    var ref=e.target.closest(".postref-card");
    if(ref){
      e.preventDefault(); e.stopPropagation();
      var href=ref.getAttribute("href")||"";
      if(href && window.taaOpenPostDetail){ openDetail(); window.taaOpenPostDetail(href); }
      return;
    }
  },true);
  log.addEventListener("click",function(e){
    var msg=null;
    var db=e.target.closest(".detailbtn");
    if(db) msg=db.closest(".msg");
    else if(!e.target.closest("a,img,button")){
      if(window.getSelection && String(window.getSelection()).length) return; // 正在选字，不抢
      msg=e.target.closest(".msg");
    }
    if(msg){ e.preventDefault(); showMsg(msg); }
  });
  log.addEventListener("keydown",function(e){
    if((e.key==="Enter"||e.key===" ") && e.target && e.target.classList && e.target.classList.contains("msg")){
      e.preventDefault(); showMsg(e.target);
    }
  });

  if(ta){
    ta.addEventListener("keydown",function(e){ if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();box.requestSubmit();} });
    var pick=document.getElementById("chat-pick"), file=document.getElementById("chat-file");
    if(pick && file){
      pick.addEventListener("click",function(){ file.click(); });
      file.addEventListener("change",function(){ composerAddFiles(ta,file.files); file.value=""; });
    }
    var sending=false;
    var pendingSends=[];
    function resetComposer(){
      box.reset(); clearReply();
      imageComposerSave(ta, []); paintImages(ta);
      if(cidEl) cidEl.value="";
    }
    function sendHttp(fd, cid, txt, imgs, retried){
      var ctrl=(window.AbortController)?new AbortController():null;
      var timer=ctrl?setTimeout(function(){ try{ctrl.abort();}catch(e){} },12000):null;
      fetch(box.action,{method:"POST",body:fd,
                        headers:{"x-taa-async":"1","accept":"application/json"},
                        signal:ctrl?ctrl.signal:undefined})
        .then(function(r){ return r.json(); })
        .then(function(j){
          if(!j || !j.ok) throw new Error("send failed");
          if(timer) clearTimeout(timer);
          // Do not wipe text the user has already typed for the next message.
          if((ta.value||"")===txt && (!cidEl || !cidEl.value || cidEl.value===cid)) resetComposer();
          var hm=document.getElementById("chatmsg"); if(hm) hm.textContent="";
          sending=false; poll(); ta.focus(); flushPending();
        })
        .catch(function(err){
          if(timer) clearTimeout(timer);
          if(err && err.name==="AbortError"){
            // 超时≠失败：服务端**先落库再投递**，消息很可能已经送达（2026-10-31 事故：
            // 带 5 张图的消息跨机直投要 12s，正好撞死 12s 超时，界面却不清空）。
            // 用**同一个 client_message_id** 幂等重发一次：命中 dup 分支会立刻回
            // {ok:true,duplicate:true}，据此清空输入区，避免用户重复发送。
            if(!retried){
              var h2=document.getElementById("chatmsg");
              if(h2) h2.textContent="响应较慢，正在确认是否已送达…";
              try{ if(cidEl) cidEl.value=cid; }catch(e){}
              return sendHttp(new FormData(box), cid, txt, imgs, true);
            }
            sending=false;
            var hm=document.getElementById("chatmsg");
            if(hm) hm.textContent="发送超时，请重试（消息可能已送达）";
            ta.focus(); flushPending();
            return;
          }
          sending=false;
          // Native form fallback keeps the same client_message_id for retry.
          if(cidEl) cidEl.value=cid;
          if(!ta.value) ta.value=txt;
          box.submit();
        });
    }
    function flushPending(){
      if(sending || !pendingSends.length) return;
      var item=pendingSends.shift();
      sending=true;
      sendHttp(item.fd, item.cid, item.txt, item.imgs);
    }
    box.addEventListener("submit",function(e){
      if(parseInt(ta.dataset.uploading||"0",10)>0){ e.preventDefault(); composerHint(ta,(window.TAA_I18N||{}).upload_wait||"图片上传中，请稍候…"); return; }
      if(!window.fetch || !window.FormData) return;   // 老浏览器走原表单提交
      var txt=(ta&&ta.value||"").trim();
      var imgs=[];
      try{ imgs=JSON.parse((document.getElementById("chatimages")||{}).value||"[]"); }catch(e){ imgs=[]; }
      // If an HTTP send is in flight, queue this message instead of dropping
      // it.  Each queued item keeps its own FormData/client_message_id.
      if(sending){
        e.preventDefault();
        if(cidEl) cidEl.value="";
        var qcid=ensureCid();
        var qfd=new FormData(box);
        if(txt || imgs.length){
          pendingSends.push({fd:qfd,cid:qcid,txt:txt,imgs:imgs});
          resetComposer();
          var qh=document.getElementById("chatmsg"); if(qh) qh.textContent="排队发送…";
        }
        return;
      }
      e.preventDefault();
      // Text-only, no @ / /exec: use the Host WebSocket path.  Attachments and
      // executor commands keep the existing HTTP semantics until Step 4.
      if(ws && ws.readyState===1 && txt && !imgs.length &&
         !/@[\\w.\\-]{1,40}/.test(txt) && !/^\\s*\\/(?:exec|run)\\b/i.test(txt)){
        var cid=ensureCid();
        try{
          ws.send(JSON.stringify({type:"message",body:txt,client_message_id:cid,
                                reply_to:(replyEl&&replyEl.value)?Number(replyEl.value):0}));
          resetComposer();
          var hm=document.getElementById("chatmsg"); if(hm) hm.textContent="发送中…";
          ta.focus();
          // The WS echo may be lost on a half-open socket.  Poll is the
          // acknowledgement fallback; it is ID-deduplicated by poll().
          setTimeout(poll, 80); setTimeout(poll, 350); setTimeout(poll, 1200);
          setTimeout(function(){ if(hm && hm.textContent==="发送中…") hm.textContent="未确认，正在同步…"; }, 2200);
          return;
        }catch(e){ /* fall through to HTTP */ }
      }
      sending=true;
      var hcid=ensureCid();
      var fd=new FormData(box);
      sendHttp(fd,hcid,txt,imgs);
    });
    box.addEventListener("dragover",function(e){
      var ts=e.dataTransfer && e.dataTransfer.types ? Array.prototype.slice.call(e.dataTransfer.types) : [];
      if(ts.indexOf("Files")>=0) e.preventDefault();
    });
    box.addEventListener("drop",function(e){
      if(!e.dataTransfer || !(e.dataTransfer.files||[]).length) return;
      e.preventDefault(); composerAddFiles(ta,e.dataTransfer.files);
    });
  }

  /* ---- 参与人：初始由后端渲染，随后定时从真实成员接口刷新 ---- */
  function mkAvatar(id){
    var im=document.createElement("img"); im.className="pill"; im.alt="";
    im.src="/avatar/m/"+encodeURIComponent(id); im.width=22; im.height=22; return im;
  }
  function renderMembers(j){
    var list=document.getElementById("plist"); if(!list) return;
    var cnt=document.getElementById("pcount"), stat=document.getElementById("pstat");
    if(cnt) cnt.textContent=j.count;
    if(stat){var st=window.TAA_I18N||{}; stat.textContent=(st.online_status||"{online} 在线 · {human} 真人 · {ai} agent").replace("{online}",j.online||0).replace("{human}",j.human||0).replace("{ai}",j.ai||0);}
    list.innerHTML="";
    (j.members||[]).forEach(function(m){
      var chip=document.createElement("span");
      chip.className="pchip "+m.state; chip.dataset.id=m.id;
      chip.title=m.name+"（"+m.kind_label+" · "+m.role_label+"）· "+m.state_label+" · "+(window.TAA_I18N&&window.TAA_I18N.recent_active||"最近活跃")+" "+m.last_active_label;
      var nm=document.createElement("b"); nm.className="pname"; nm.textContent=m.name;
      var did=m.display_id||"";
      var pid=document.createElement("span"); pid.className="pid mono"; pid.textContent="@"+did;
      var st=document.createElement("span"); st.className="pstate";
      var dot=document.createElement("i"); dot.className="pdot";
      st.appendChild(dot); st.appendChild(document.createTextNode(m.state_label));
      chip.appendChild(mkAvatar(m.id)); chip.appendChild(nm);
      if(did && m.name!==did) chip.appendChild(pid);
      if(m.node_label){ var nd=document.createElement("span"); nd.className="pnode mono"; nd.textContent=m.node_label; chip.appendChild(nd); }
      if(m.role==="host"){ var rl=document.createElement("span"); rl.className="prole"; rl.textContent=m.role_label; chip.appendChild(rl); }
      chip.appendChild(st); list.appendChild(chip);
    });
    var table=document.getElementById("ptable"); if(!table) return;
    table.innerHTML="";
    (j.members||[]).forEach(function(m){
      var row=document.createElement("div"); row.className="memberrow "+m.state; row.dataset.id=m.id;
      var av=document.createElement("img"); av.className="pill"; av.alt=""; av.width=24; av.height=24;
      av.src="/avatar/m/"+encodeURIComponent(m.id);
      var who=document.createElement("span"); who.className="mwho";
      var b=document.createElement("b"); b.textContent=m.name;
      var did=m.display_id||"";
      var pid=document.createElement("span"); pid.className="mono dim"; pid.textContent=" @"+did;
      var role=document.createElement("span"); role.className="mrole dim";
      role.textContent=" "+m.kind_label+" · "+(m.agent_role_label||m.role_label)+(m.role==="host"?" · 主持":"");
      who.appendChild(b);
      if(did && m.name!==did) who.appendChild(pid);
      if(m.node_label){ var nd=document.createElement("span"); nd.className="mnode mono"; nd.textContent=m.node_label; who.appendChild(nd); }
      who.appendChild(role);
      var st=document.createElement("span"); st.className="mstate";
      var dot=document.createElement("i"); dot.className="pdot";
      st.appendChild(dot); st.appendChild(document.createTextNode(m.state_label));
      var ago=document.createElement("span"); ago.className="dim"; ago.textContent=m.last_active_label;
      st.appendChild(ago);
      row.appendChild(av); row.appendChild(who); row.appendChild(st); table.appendChild(row);
    });
  }
  var pt=document.getElementById("ptoggle"), ptable=document.getElementById("ptable");
  if(pt && ptable){
    pt.addEventListener("click",function(){
      ptable.hidden=!ptable.hidden;
      pt.setAttribute("aria-expanded", ptable.hidden?"false":"true");
      pt.textContent=ptable.hidden?"名单":"收起";
    });
  }
  function refreshMembers(){
    fetch("/app/api/room/"+encodeURIComponent(room)+"/members")
      .then(function(r){return r.json();}).then(renderMembers).catch(function(){});
  }
  refreshMembers(); setInterval(refreshMembers,30000);

  /* ---- 阅读位置：粘底策略 ----
     1) 只在用户位于底部附近（<=BOTTOM_GAP）时跟随新消息；
     2) 上翻即解锁，锁定阅读锚点（消息 id + 屏内偏移），轮询/重渲染/图片加载/resize 都不抢滚动；
     3) 回到底部或点「回到最新」才恢复跟随；离开期间的新消息用角标提示。 */
  var pill=document.getElementById("newpill"), pending=0, stick=true;
  /* t-4c228ae0：贴底判定只认「用户手势 + 距底距离」，布局变化/程序写入不得改 stick。
     BOTTOM_GAP 40→48 的老实现会把 <48px 的上翻当成「还在底部」，下一条消息就抢滚动；
     这里把「算在底部」压到 6px，并把「上翻锁定」阈值降到 10px。 */
  var BOTTOM_EPS=6, LOCK_AFTER=10, RESUME_GAP=24;
  var saveTimer=null, touchY=0, touchTop=0, rzAnchor=null, rzTimer=null, prevTop=0;
  var guardUntil=0;   // 布局/程序写入窗口内的 scroll 事件不参与状态判定
  var key="taa-scroll:"+room;
  function gapToBottom(){ return log.scrollHeight-log.scrollTop-log.clientHeight; }
  function nearBottom(){ return gapToBottom()<=BOTTOM_EPS; }
  function userGesture(){ guardUntil=0; }              // 手势到达：立刻解除布局窗口
  function guard(ms){ guardUntil=Math.max(guardUntil, Date.now()+(ms||350)); }
  function showPill(n){ if(n<=0){ hidePill(); return; } pending=n;
    if(pill){ pill.textContent="↓ "+n+" 条新消息 · 回到最新"; pill.hidden=false; } }
  function hidePill(){ pending=0; if(pill) pill.hidden=true; }
  function latestNow(){ stick=true; log.scrollTop=log.scrollHeight; hidePill(); guard(300);
    prevTop=log.scrollTop; }
  if(pill) pill.addEventListener("click",latestNow);
  /* 阅读锚点：当前视口顶部第一条可见消息 + 它在视口内的偏移（px 会随新消息/换行变化，id 不会） */
  function anchorNow(){
    var top=log.getBoundingClientRect().top, msgs=log.querySelectorAll(".msg");
    for(var i=0;i<msgs.length;i++){
      var r=msgs[i].getBoundingClientRect();
      if(r.bottom>top+1) return {id:msgs[i].dataset.id||"",off:Math.round(r.top-top)};
    }
    return null;
  }
  function restoreAnchor(a){
    if(!a) return false;
    var el=a.id?log.querySelector('.msg[data-id="'+a.id+'"]'):null;
    if(!el) return false;
    var top=log.getBoundingClientRect().top;
    log.scrollTop+=(el.getBoundingClientRect().top-top)-a.off;
    return true;
  }
  function remember(){
    var a=anchorNow();
    try{ sessionStorage.setItem(key,JSON.stringify(
      {id:a?a.id:"",off:a?a.off:0,top:Math.round(log.scrollTop),last:last})); }catch(e){}
  }
  var saved=null; try{ saved=JSON.parse(sessionStorage.getItem(key)||"null"); }catch(e){}
  var restored=false;
  if(saved){ restored=restoreAnchor(saved);
    if(!restored && typeof saved.top==="number"){ log.scrollTop=saved.top; restored=true; } }
  if(!restored) log.scrollTop=log.scrollHeight;
  guard(600); prevTop=log.scrollTop;
  stick=nearBottom();
  var unseen=0;
  if(saved && saved.last!=null){
    log.querySelectorAll(".msg").forEach(function(m){
      var n=parseInt(m.dataset.id||"0",10); if(n>saved.last) unseen++;
    });
  }
  if(unseen>0) showPill(unseen); else hidePill();
  log.addEventListener("scroll",function(){
    clearTimeout(saveTimer); saveTimer=setTimeout(remember,150);
    var top=log.scrollTop, down=top>prevTop; prevTop=top;
    // 布局变化（图片撑高 / 滚动锚定 / resize 夹取 / 程序写入）窗口内：不参与判定
    if(Date.now()<guardUntil) return;
    var g=gapToBottom();
    if(g<=BOTTOM_EPS){ if(!stick){ stick=true; hidePill(); } }
    else if(down && g<=RESUME_GAP){ if(!stick){ stick=true; hidePill(); } }
    else if(g>LOCK_AFTER){ stick=false; }
    // 6~10px 迟滞；向上 10px 内仍跟随，避免手指抖动把状态翻来翻去
  });
  log.addEventListener("pointerdown",userGesture,{passive:true});
  /* 用户意图优先：滚轮/触摸上滑/键盘翻页立刻解锁，不等 scroll 事件 */
  log.addEventListener("wheel",function(e){ userGesture(); if(e.deltaY<0) stick=false; },{passive:true});
  log.addEventListener("touchstart",function(e){ userGesture(); touchY=e.touches[0].clientY; touchTop=log.scrollTop; },{passive:true});
  log.addEventListener("touchmove",function(e){
    userGesture();
    if(e.touches[0].clientY>touchY && log.scrollTop<=touchTop) stick=false;
  },{passive:true});
  document.addEventListener("keydown",function(e){
    if(e.target && /^(INPUT|TEXTAREA)$/.test(e.target.tagName||"")) return;
    if(e.key==="PageUp"||e.key==="Home"||e.key==="ArrowUp"||e.key==="PageDown"||e.key==="End"||e.key==="ArrowDown")
      { userGesture(); }
    if(e.key==="PageUp"||e.key==="Home"||e.key==="ArrowUp") stick=false;
  });
  /* 高度变化（窗口 resize / 参与人条展开 / 手机键盘）时锚定阅读位置，不回到最新 */
  function keepAnchor(){
    guard(400);
    if(stick){ log.scrollTop=log.scrollHeight; prevTop=log.scrollTop; return; }
    if(!rzAnchor) rzAnchor=anchorNow();
    clearTimeout(rzTimer);
    rzTimer=setTimeout(function(){ if(rzAnchor) restoreAnchor(rzAnchor); rzAnchor=null;
      prevTop=log.scrollTop; guard(250); },60);
  }
  window.addEventListener("resize",keepAnchor);
  if(window.ResizeObserver){
    try{ new ResizeObserver(function(){ if(!document.hidden) keepAnchor(); }).observe(log); }catch(e){}
  }
  /* 图片/附件加载后才撑高：贴底时继续贴底；读历史时保持锚点 */
  log.addEventListener("load",function(e){
    if(!e.target || e.target.tagName!=="IMG") return;
    guard(300);
    if(stick){ log.scrollTop=log.scrollHeight; prevTop=log.scrollTop; }
    else if(rzAnchor===null){ rzAnchor=anchorNow(); keepAnchor(); }
  },true);
  window.addEventListener("pagehide",remember);

  function poll(){
    if(document.hidden) return;                 // 后台标签页不轮询，回到前台再补
    fetch("/app/api/room/"+encodeURIComponent(room)+"?after="+last).then(function(r){return r.json();}).then(function(j){
      var added=0;
      for(var i=0;i<(j.messages||[]).length;i++){
        var m=j.messages[i]; last=Math.max(last,m.id);
        if(document.querySelector('[data-id="'+m.id+'"]')) continue;
        if(m.source==="opencode"){
          var dv=document.createElement("div"); dv.className="devlog"; dv.dataset.id=m.id;
          var dh=document.createElement("div"); dh.className="devlog-head";
          var who=(m.from_name||m.from||"")+(m.from_node?"@"+m.from_node:"");
          dh.textContent="🔧 opencode 工作汇报 · "+who+" · "+(m.time||"").slice(-5);
          var db=document.createElement("div"); db.className="devlog-body";
          db.innerHTML=m.html||m.text||"";
          if(m.postrefs) db.insertAdjacentHTML("beforeend", m.postrefs);
          dv.appendChild(dh); dv.appendChild(db); log.appendChild(dv); added++;
          continue;
        }
        var d=document.createElement("div"); d.className="msg"+(m.me?" me":""); d.dataset.id=m.id;
        d.dataset.author=m.from||""; d.dataset.name=m.from_name||m.from||""; d.dataset.time=m.time||"";
        d.dataset.round=m.round||"";
        d.tabIndex=0; d.setAttribute("aria-label","查看 "+(m.from_name||m.from||"")+" 的消息详情");
        var av=document.createElement("span"); av.className="mava";
        var avi=document.createElement("img"); avi.alt=""; avi.width=28; avi.height=28;
        avi.src="/avatar/m/"+encodeURIComponent(m.from||"?"); av.appendChild(avi);
        var b=document.createElement("div"); b.className="bubble";
        var w=document.createElement("div"); w.className="who"; w.title="@"+m.from;
        w.textContent=(m.from_name||m.from)+" · 第 "+(m.round||"—")+" 轮 · "+m.time;
        b.appendChild(w);
        if(m.reply && m.reply.text){
          var rq=document.createElement("div"); rq.className="replyquote";
          var rb=document.createElement("b"); rb.textContent=(m.reply.name||"")+"：";
          rq.appendChild(rb); rq.appendChild(document.createTextNode(m.reply.text||""));
          b.appendChild(rq);
        }
        var t=document.createElement("div"); t.className="text"; t.innerHTML=m.html||m.text||"";
        b.appendChild(t);
        if(m.postrefs) b.insertAdjacentHTML("beforeend", m.postrefs);
        if(m.att || (m.atts&&m.atts.length)){
          var atts=(m.atts&&m.atts.length)?m.atts:(m.att?[m.att]:[]);
          var abox=document.createElement("div"); abox.className="chatatt";
          atts.forEach(function(u){
            if(/[.](png|jpe?g|gif|webp|bmp)([?]|$)/i.test(u)){
              var im=document.createElement("img"); im.className="chatatt-img"; im.src=thumbURL(u); im.dataset.full=u; im.alt=""; im.loading="lazy"; im.decoding="async";
              abox.appendChild(im);
            } else {
              var a=document.createElement("a"); a.className="attfile"; a.href=u; a.target="_blank"; a.textContent=u.split("/").pop();
              abox.appendChild(a);
            }
          });
          b.appendChild(abox);
        }
        var acts=document.createElement("div"); acts.className="acts";
        var ti=window.TAA_I18N||{};
        var dbtn=document.createElement("button"); dbtn.type="button"; dbtn.className="actbtn detailbtn"; dbtn.textContent=ti.detail||"详情";
        var rbtn2=document.createElement("button"); rbtn2.type="button"; rbtn2.className="actbtn replybtn"; rbtn2.textContent="回复"; rbtn2.dataset.reply=m.id; rbtn2.dataset.replyName=m.from_name||m.from||"";
        var cbtn=document.createElement("button"); cbtn.type="button"; cbtn.className="actbtn copybtn"; cbtn.textContent=ti.copy||"复制";
        acts.appendChild(dbtn); acts.appendChild(rbtn2); acts.appendChild(cbtn);
        d.appendChild(av); d.appendChild(b); d.appendChild(acts);
        log.appendChild(d); added++;
      }
      if(added){
        clearSendHint();
        guard(450);
        if(stick){ log.scrollTop=log.scrollHeight; prevTop=log.scrollTop; hidePill(); }
        else { showPill(pending+added); }
      }
    }).catch(function(){});
  }
  var pollTimer=null;
  function startPoll(){
    if(pollTimer) return;
    pollTimer=setInterval(poll,2500);
  }
  /* SSE 只负责“有新消息”的触发；渲染仍复用 poll，避免两套逻辑漂移。 */
  var es=null;
  if(window.EventSource){
    try{
      es=new EventSource("/app/api/room/"+encodeURIComponent(room)+"/stream?after="+last);
      es.onmessage=function(){ poll(); };
      es.onerror=function(){
        try{ es.close(); }catch(e){}
        es=null; startPoll();
      };
    }catch(e){ startPoll(); }
  } else startPoll();
  wsConnect();
  // WS should make this instant; the watchdog repairs a missing cross-node
  // broadcast or a half-open socket without waiting for a manual refresh.
  startPoll();
  /* Test/ops hook: close transports to verify the poll fallback. */
  window.__taaChatDebug = {
    closeWs: function(){ try{ if(ws) ws.close(); }catch(e){} },
    closeSse: function(){ try{ if(es) es.close(); }catch(e){} es=null; }
  };
  var galleryBtn=document.getElementById("roomgallery");
  if(galleryBtn) galleryBtn.addEventListener("click",function(){
    fetch("/app/api/room/"+encodeURIComponent(room)+"/gallery").then(function(r){return r.json();}).then(function(j){
      if(j && j.urls && j.urls.length && window.taaOpenGalleryUrls) window.taaOpenGalleryUrls(j.urls,0);
      else if(window.taaOpenGallery) window.taaOpenGallery(log,0);
    }).catch(function(){ if(window.taaOpenGallery) window.taaOpenGallery(log,0); });
  });
  document.addEventListener("visibilitychange",function(){ if(!document.hidden) poll(); });
})();
</script>"""
        scripts = (chat_js.replace("__LAST__", str(msgs[-1]["id"] if msgs else 0))
                          .replace("__ROOM__", json.dumps(rid)))
    if room:
        system_total = all_total - total
        share = is_share()
        people = []
        for m in member_info[:14]:
            role = m["agent_role_label"] or m["role_label"]
            if m["role"] == "host":
                role += " " + tr("chat.role_host", "· 主持")
            acts = ""
            if not share:
                acts += (f'<button class="dmini" type="button" data-detail-mention="{esc(m["id"])}" '
                         f'title="{tr("chat.mention_title", "在输入框插入 @{id}").format(id=esc(m["id"]))}">@</button>')
                if m["kind"] == "ai":
                    acts += (f'<a class="dmini" href="/app/chats?agent={esc(m["id"])}" '
                             f'title="{tr("home.chat_with", "和 {name} 私聊").format(name=esc(m["name"]))}">{tr("chat.dm", "私信")}</a>')
            people.append(
                f'<div class="dperson" data-id="{esc(m["id"])}">'
                f'{avatar(m["id"], 28)}'
                f'<span class="dwho"><b>{esc(m["name"])}</b><span>@{esc(m["id"])} · {esc(role)}</span></span>'
                f'<span class="dpresence {m["state"]}"><i></i>{esc(m["state_label"])}</span>'
                f'{acts}</div>')
        if len(member_info) > 14:
            people.append(f'<p class="dnote">另有 {len(member_info) - 14} 位参与人，见主区「名单」。</p>')
        quick = ""
        if not share:
            quick += f'<button class="dact primary" type="button" data-detail-focus="#text">{tr("chat.message", "发消息")}</button>'
        quick += (f'<button class="dact" type="button" data-detail-copy-link="/app/chats?room={quote(public_rid)}">{tr("feed.copy_link", "复制链接")}</button>'
                  f'<button class="dact" type="button" data-detail-copy="{esc(public_rid)}">{tr("chat.copy_room", "复制房间号")}</button>'
                  f'<button class="dact" type="button" data-detail-people>{tr("chat.member_list", "参与人名单")}</button>')
        recent = []
        for m in msgs[-3:]:
            who = name_map.get(m["agent_id"], m["agent_id"])
            snippet = " ".join(str(m["body"] or "").split())
            if len(snippet) > 84:
                snippet = snippet[:84] + "…"
            recent.append(
                f'<button class="dflowrow" type="button" data-detail-jump="{m["id"]}">'
                f'<span class="dfwho"><b>{esc(who)}</b>{esc(fmt_dt(m["created_at"]))}</span>'
                f'<span class="dftext">{esc(snippet)}</span></button>')
        recent_card = _dcard(tr("chat.recent", "最近动态 · 点一条跳到消息"), f'<div class="dflow">{"".join(recent)}</div>') if recent else ""
        manage = ""
        if not share and not archived:
            if is_dm:
                manage = _dcard(tr("chat.manage", "管理"), f'<form method="post" action="/app/chats/clear" onsubmit="return confirm(\'{tr("chat.confirm_clear", "清空这段私聊？只删消息，保留会话。")}\')">'
                                f'<input type="hidden" name="room" value="{esc(rid)}"><button class="btn" type="submit">{tr("chat.clear", "清空聊天")}</button></form>')
            else:
                manage = _dcard(tr("chat.manage", "管理"), f'<form method="post" action="/app/chats/rename" style="display:flex;gap:6px;margin-bottom:8px">'
                                f'<input type="hidden" name="room" value="{esc(rid)}"><input name="name" value="{esc(room["title"] or room["topic"] or "")}" style="flex:1;min-width:0;border:1px solid var(--hair);border-radius:12px;padding:7px 9px;background:var(--apron);color:var(--ink)"><button class="btn" type="submit">{tr("chat.rename", "改名")}</button></form>'
                                f'<form method="post" action="/app/chats/delete" onsubmit="return confirm(\'{tr("chat.confirm_dissolve", "解散这个群聊？消息和房间数据会一起删除，无法恢复。")}\')"><input type="hidden" name="room" value="{esc(rid)}"><button class="btn" type="submit">{tr("chat.dissolve", "解散群聊")}</button></form>')
        # R-01（2026-11-07）：跨组织群消息的存储边界必须"明示"。
        # 中心对跨 owner 群消息是明文存储（不是 bug，是取舍）；把边界写在用户真正
        # 会看到的地方，并给一次性"我已了解"（本地记住，不重复打扰）。
        plain_card = ""
        if not is_dm:
            _ack = tr("chat.plaintext_ack", "我已了解")
            _acked = tr("chat.plaintext_acked", "已了解")
            # JS 用普通字符串拼接（不进 f-string），避免花括号/引号互相打架。
            _js = (
                "var b=this;b.disabled=true;"
                "fetch('/app/notice-ack',{method:'POST',"
                "headers:{'content-type':'application/x-www-form-urlencoded'},"
                "body:'scope=collab_plaintext'})"
                ".then(function(r){return r.json()})"
                ".then(function(j){try{localStorage.setItem('taa.plaintext.ack.v1','1')}catch(e){}"
                "b.textContent='" + _acked + "'+((j&&j.ok)?'':'（仅本地）');})"
                ".catch(function(){b.disabled=false;b.textContent='" + _ack + "';});"
            )
            plain_card = _dcard(
                tr("chat.plaintext_title", "跨组织消息的加密与存储"),
                '<div id="plainwrap"><p class="dnote">'
                + tr("chat.plaintext_body",
                     "跨组织的群聊消息在你的机器上加密后发给中心，中心只保存密文、读不到内容；保留 30 天，发送者或群主可删除。未上报公钥的成员收不到该条消息；换机器后旧消息无法解密（不迁移历史）。")
                + '</p><button class="btn" type="button" id="plainack" onclick="'
                + _js + '">' + _ack + '</button></div>'
                + '<script>(function(){fetch("/app/notice-ack-state")'
                  '.then(function(r){return r.json()})'
                  '.then(function(j){if(j&&j.accepted){var e=document.getElementById("plainwrap");'
                  'if(e&&e.parentElement){e.parentElement.style.display="none"}}})'
                  '.catch(function(){});})();</script>')
        detail = (
            _dhero(tr("chat.session_detail", "会话详情"), (room["title"] or room["topic"]) or room["id"],
                   f"{status_label} · {tr('chat.status_round', '第 {n} 轮').format(n=room['current_round'] or 1)} · {tr('chat.host', '主持')} {host_name or '—'}",
                   quick)
            + _dcard(f"{tr('chat.participants', '参与人')} · {len(member_info)}", f'<div class="dpeople">{"".join(people)}</div>')
            + recent_card
            + plain_card
            + manage
            + _dcard(tr("chat.overview", "本场概览"), '<div class="dstats">'
                     + _dstat(f"{online_count}/{len(member_info)}", tr("chat.online_participants", "在线 / 参与人"))
                     + _dstat(total, tr("chat.visible", "可见消息"))
                     + _dstat(room["current_round"] or 1, tr("chat.current_round", "当前轮次"))
                     + _dstat(room["session_count"] or 0, tr("chat.session_count", "本场次数")) + "</div>")
            + _dcard(tr("chat.overview", "本场信息"),
                     _drow(tr("chat.room_id", "房间号"), f'<span class="mono">{esc(public_rid)}</span>')
                     + _drow(tr("chat.status", "状态"), esc(status_label))
                     + _drow(tr("chat.host", "主持"), esc(host_name or "—"))
                     + _drow(tr("chat.created", "创建"), esc(fmt_dt(room["created_at"])))
                     + _drow(tr("chat.participants_count", "参与"), f"{human_count} {tr('room.human', '真人')} · {ai_count} agent")
                     + (f'<p class="dnote" style="margin-top:8px">{tr("chat.system_records", "库内另有系统/跳过记录未显示。").format(n=system_total)}</p>' if system_total else ""))
        )
    else:
        detail = (
            _dhero(tr("chat.session_detail", "会话详情"), tr("chat.first_select", "先选一个会话"),
                   tr("chat.select_hint", "从左侧列表选房间，或点 AGENTS 里的 agent 开私聊。"),
                   f'<a class="dact primary" href="/app/chats">{tr("chat.select_room", "选择会话")}</a>'
                   f'<a class="dact" href="/app/team">{tr("chat.view_members", "查看成员")}</a>')
            + _dcard(tr("chat.tip", "提示"), f'<p class="dnote">{tr("chat.tip_body", "桌面端选中会话后，这里会显示参与人、轮次与快捷操作；群聊里 @agent 直接发送 即可派活。")}</p>')
        )
    return shell("会话", body, "chats", "和团队、和你的 agent 说话",
                 side=side_chats(c, rid, ag), page_css=PAGE_CSS["chat"] + CHAT_MOBILE_CSS, scripts=scripts, detail=detail,
                 app_class="chats-page" + (" chat-open" if room else ""))


def _links(raw) -> list[str]:
    try:
        v = json.loads(raw) if raw else []
        if isinstance(v, list):
            return [str(x) for x in v if str(x).startswith("http")]
    except Exception:  # noqa: BLE001
        pass
    return []


def _link_html(raw) -> str:
    links = _links(raw)
    if not links:
        return ""
    return "".join(f'<a class="link mono" href="{esc(u)}" rel="nofollow noopener" target="_blank">{esc(u)}</a>' for u in links[:1])


def truncate_md(body, limit: int = 10000):
    t = clean(body)
    if len(t) <= limit:
        return t, False
    cut = t[:limit]
    pos = cut.rfind(chr(10) + chr(10))
    if pos > limit * 0.5:
        cut = cut[:pos]
    return cut, True


def _tags(raw) -> list[str]:
    try:
        v = json.loads(raw) if raw else []
        if isinstance(v, list):
            return [str(x) for x in v]
    except Exception:  # noqa: BLE001
        pass
    return [x for x in str(raw or "").split(",") if x]


def _norm_post(title, body) -> str:
    import re as _re
    s = _re.sub(r"<[^>]+>", " ", str(body or ""))
    s = _re.sub(r"\s+", " ", s).strip().lower()
    return f"{str(title or '').strip().lower()}\n{s}"


def _dedupe_rows(rows):
    """同一作者 + 同一正文视为重复；保留最新一条。

    分享帖按 `share_of` 判重：同一人分享多条不同原帖、且都没写转发语时正文都是空，
    按正文判重会把它们并成一条（分享三条只剩一条）。
    """
    seen = set()
    out = []
    for r in rows:
        try:
            share_of = r["share_of"]
        except (IndexError, KeyError):
            share_of = None
        if share_of:
            key = (r["author_id"], "share:" + str(share_of))
        else:
            key = (r["author_id"], _norm_post(r["title"], r["body"]))
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


_FEED_CACHE: dict[str, object] = {"key": None, "rows": []}
_FEED_CACHE_LOCK = threading.Lock()


def _feed_visible_rows(c):
    """频道可见帖列表（过滤流水/重复）的短缓存。

    原先 /app/feed 每次都读 1,300+ 条 posts、过滤、去重，再由 side_tags 再扫一遍；
    读多写少，按 SQLite data_version 失效即可，写入帖子后下一次请求自动刷新。
    """
    try:
        sig = c.execute("""select count(*) n, coalesce(max(id),0) max_id,
            coalesce(max(updated_at),'') last_update from posts""").fetchone()
        ver = (sig["n"], sig["max_id"], sig["last_update"], int(time.monotonic() // 5))
    except Exception:
        ver = (0, 0, "", 0)
    key = (str(DB), ver)
    with _FEED_CACHE_LOCK:
        if _FEED_CACHE.get("key") == key:
            return _FEED_CACHE["rows"]
    rows = c.execute("""select id,author_id,title,body,tags,links,attachments,created_at,
        visibility,share_of,share_snapshot from posts
        where coalesce(status,'') NOT IN ('duplicate','archived') order by created_at desc limit 10000""").fetchall()
    rows = [r for r in rows if not _is_process_post(r)]
    rows = _dedupe_rows(rows)
    # docs/531：visibility 真正生效（public 不变；friends 只给作者与好友）。
    try:
        from core import post_share
        rows = post_share.visible_rows(c, human_id(c), rows)
    except Exception:                                            # noqa: BLE001
        pass
    with _FEED_CACHE_LOCK:
        _FEED_CACHE["key"], _FEED_CACHE["rows"] = key, rows
    return rows


def _quality_post(p) -> tuple[bool, int, str]:
    """频道精选/推荐的最低可读性闸门；分数只用于首页排序与解释。"""
    title = str(p["title"] or "").strip()
    body = str(p["body"] or "").strip()
    text = md_plain(body)
    tags = {t.lower() for t in _tags(p["tags"])}
    if _is_process_post(p):
        return False, 0, "流水/测试/占位"
    bad = ("TODO", "TBD", "FIXME", "回执", "点击查看")
    if any(x in body[:160] for x in bad) or any(x in title for x in bad):
        return False, 0, "流水/测试/占位"
    head0 = body[:800]
    if head0.startswith("title:") or "- title:" in head0 or "**任务**" in head0:
        return False, 0, "工作记录格式"
    if re.search(r"(^|[\s【(（])t-[0-9a-f]{8}", title, re.I):
        return False, 0, "任务编号标题"
    work_tags = {"ui", "design-review", "detail-panel", "selfcheck", "regression",
                 "attachment", "协作", "分工", "效率", "导师派活", "规格", "知识库",
                 "claim", "事实层", "wiki", "schema", "信源", "接口", "迁移", "实现",
                 "版本", "任务", "交付", "测试", "人设", "生图", "对比测试", "soul",
                 "capability", "vision", "t-"}
    if tags & work_tags:
        return False, 0, "项目工作记录"
    if len(text) < 60 and not _atts(p["attachments"]):
        return False, 0, "内容过短且无图"
    score = 34
    if title:
        score += 10
    if len(text) >= 80:
        score += 10
    if len(text) >= 240:
        score += 8
    if len(text) >= 600:
        score += 5
    if _atts(p["attachments"]):
        score += 10
    if _links(p["links"]):
        score += 5
    if body.startswith("#") or "\n#" in body or "\n- " in body or "\n1. " in body:
        score += 8
    if any(t in tags for t in ("精选", "推荐", "科普", "复盘", "研究", "读书", "交付", "哲学", "方法")):
        score += 5
    head = body[:800]
    work_markers = ("任务：", "任务:", "Owner", "selfcheck", "PASS", "defects=",
                    "执行：", "执行:", "回执", "落档", "【交付】", "交付清单", "自检",
                    "**任务**", "**执行**", "**基线**", "回滚点", "- title:", "- url:",
                    "title:", "url:")
    worklog = any(x in head for x in work_markers)
    if worklog:
        score -= 22
    else:
        score += 8
    if body.count("## ") >= 2:
        score += 6
    if body.startswith("# "):
        score += 4
    if "待核实" in body:
        score -= 3
    score = max(0, min(100, score))
    return (score >= 68 and bool(title)), score, ("可读" if score >= 68 else "信息密度不足")


FEATURED_DAILY_LIMIT = max(1, int(os.environ.get("TEAMAI_FEATURED_DAILY_LIMIT", "3")))


def _featured_readable(p) -> bool:
    """Featured 的人类可读底线；不再使用旧的标签/评分阈值。"""
    if _is_process_post(p):
        return False
    text = md_plain(p["body"] or "")
    if len(text) < 60 and not _atts(p["attachments"]):
        return False
    if not str(p["title"] or "").strip() and len(text) < 120:
        return False
    return True


def _featured_rows(c, limit: int = 20):
    """Feed 子集：至少一个赞/喜欢 + 人类可读；每天最多 FEATURED_DAILY_LIMIT 条。

    点赞/评论是主信号；旧的 tags=精选/推荐 与 _quality_post 评分不再作为准入条件。
    """
    rows = c.execute("""select p.id,p.author_id,p.title,p.body,p.tags,p.links,p.attachments,p.created_at,
        (select count(*) from reactions r where r.target_type='post' and r.target_id=p.id) n_react,
        (select count(*) from replies rp where rp.post_id=p.id and rp.status='visible') n_reply
      from posts p where coalesce(p.status,'') NOT IN ('duplicate','archived')
      order by p.created_at desc limit 10000""").fetchall()
    by_day = {}
    seen = set()
    for p in rows:
        if int(p["n_react"] or 0) < 1 or not _featured_readable(p):
            continue
        key = (p["author_id"], _norm_post(p["title"], p["body"]))
        if key in seen:
            continue
        seen.add(key)
        day = str(p["created_at"] or "")[:10]
        score = int(p["n_react"] or 0) * 2 + int(p["n_reply"] or 0)
        by_day.setdefault(day, []).append((score, p))
    picked = []
    for day, items in by_day.items():
        items.sort(key=lambda x: (x[0], str(x[1]["created_at"] or "")), reverse=True)
        picked.extend(p for _, p in items[:FEATURED_DAILY_LIMIT])
    picked.sort(key=lambda p: str(p["created_at"] or ""), reverse=True)
    return picked[:limit]


def _curated_posts(c, limit: int = 5):
    """精选位=Feed 子集；保留旧函数名供 sync/home 使用。"""
    return _featured_rows(c, limit)


def side_tags(c, tag: str = "", all_tags: bool = False) -> str:
    tags = {}
    for r in _feed_visible_rows(c):
        for t in _tags(r["tags"]):
            tags[t] = tags.get(t, 0) + 1
    ordered = sorted(tags.items(), key=lambda x: (-x[1], x[0]))
    shown = ordered if all_tags else ordered[:15]
    rows = "".join(f'<a class="citem{" on" if t == tag else ""}" href="/app/feed?tag={quote(t)}">'
                   f'<span class="cname">#{esc(t)}</span><span class="dim" style="margin-left:auto;font-size:12px">{n}</span></a>'
                   for t, n in shown)
    more = ""
    if ordered:
        if all_tags:
            more = '<a class="citem" href="/app/feed"><span class="cname">收起 · Top 15</span></a>'
        else:
            more = f'<a class="citem" href="/app/tags"><span class="cname">{tr("tags.more", "全部标签 ({n}) →").format(n=len(ordered))}</span></a>'
    head = "ALL TAGS" if all_tags else f"TAGS · TOP 15"
    return f'<div class="sidebox"><div class="shead">{head}</div>{rows or "<div class=dim>暂无标签</div>"}{more}</div>'


def _post_refs(raw, exclude: str = "", c=None) -> str:
    """把正文里的 p-xxxxxxxx 转成可点的引用卡（TA 的"原文见"交互）。

    c 可传入已打开的只读连接，聊天页/轮询接口一次渲染多条消息时复用，
    避免每条消息重新开库。
    """
    body = str(raw or "")
    ids = []
    for pid in re.findall(r"(?<![\w/])(p-[0-9a-f]{8})(?![\w])", body):
        if pid != exclude and pid not in ids:
            ids.append(pid)
    ids = ids[:3]
    if not ids:
        return ""
    own = c is None
    if own:
        c = db()
    try:
        cards = []
        for pid in ids:
            row = c.execute("""select id,author_id,title,body,tags from posts
                where id=? and coalesce(status,'') NOT IN ('duplicate','archived')""", (pid,)).fetchone()
            if not row or _is_process_post(row):
                continue
            title = md_plain(row["title"] or row["body"]).replace(chr(10), " ").strip()[:90]
            tags = [t for t in _tags(row["tags"]) if t != "deliverable"][:2]
            meta = row["author_id"] + (" · " + " ".join("#" + t for t in tags) if tags else "")
            cards.append(f'<a class="postref-card" href="/app/p/{esc(pid)}" data-pid="{esc(pid)}" title="{esc(title or "(无标题)")}">'
                         f'<span class="postref-id">{esc(pid)}</span>'
                         f'<span class="postref-title">{esc(title or "(无标题)")}</span>'
                         f'<span class="postref-meta">{esc(meta)}</span></a>')
        return f'<div class="postrefs">{"".join(cards)}</div>' if cards else ""
    finally:
        if own:
            c.close()


def _back_path() -> str:
    try:
        p = request.full_path or request.path or "/app/feed"
        return p[:-1] if p.endswith("?") else p
    except Exception:
        return "/app/feed"


def _post_footer(r) -> str:
    """帖子/朋友圈的统一互动条：反应 + 回贴/评论数。"""
    c = db()
    try:
        hid = human_id(c)
        counts = {x["emoji"]: x["n"] for x in c.execute(
            "select emoji,count(*) n from reactions where target_type='post' and target_id=? group by emoji",
            (r["id"],))}
        mine = {x["emoji"] for x in c.execute(
            "select emoji from reactions where target_type='post' and target_id=? and agent_id=?",
            (r["id"], hid))}
        nreply = c.execute("select count(*) n from replies where post_id=? and status='visible'",
                           (r["id"],)).fetchone()["n"]
        # docs/531：分享状态（本机只关心"我有没有分享过这条"）
        try:
            _share_of = r["share_of"]
        except (IndexError, KeyError):
            _share_of = None
        my_share_id = None
        if not _share_of:
            try:
                from core import post_share
                _s = post_share.my_share(c, hid, r["id"])
                my_share_id = str(_s["id"]) if _s is not None else None
            except Exception:                                    # noqa: BLE001
                my_share_id = None
    finally:
        c.close()
    back = _back_path()
    buttons = []
    for emoji in ("👍", "💡", "❤️"):
        on = " on" if emoji in mine else ""
        buttons.append(
            f'<form method="post" action="/app/react" class="rform"><input type="hidden" name="post" value="{esc(r["id"])}">'
            f'<input type="hidden" name="emoji" value="{esc(emoji)}"><input type="hidden" name="back" value="{esc(back)}">'
            f'<button class="rbtn{on}" type="submit" title="{tr("post.react", "切换反应")}">{esc(emoji)} {counts.get(emoji, 0)}</button></form>')
    # 分享：显式动作（B 案）。已分享 → 可从"我的朋友圈"移除；不说"撤回"。
    if _share_of:
        share_btn = ""
    elif my_share_id:
        share_btn = (f'<form method="post" action="/app/unshare" class="rform" data-noasync="1">'
                     f'<input type="hidden" name="share" value="{esc(my_share_id)}">'
                     f'<input type="hidden" name="back" value="{esc(back)}">'
                     f'<button class="rbtn on" type="submit" title="'
                     f'{esc(tr("post.unshare", "从我朋友圈移除"))}">'
                     f'{esc(tr("post.shared", "已分享 ✓"))}</button></form>')
    else:
        # 点击即分享，但先过一道原生确认（防误触）；确认后才 POST，取消则什么都不做。
        # 用 json.dumps 生成 JS 字面量（属性用单引号包住），避免 esc() 把单引号变成
        # 实体后反倒截断 JS 字符串。
        _share_confirm = json.dumps(tr("post.share_confirm",
                                       "分享到你的朋友圈？好友可见；可以移除，但已看到的人无法收回。"),
                                    ensure_ascii=False)
        share_btn = (f'<form method="post" action="/app/share" class="rform" data-noasync="1"'
                     f" onsubmit='return confirm({_share_confirm})'>"
                     f'<input type="hidden" name="post" value="{esc(r["id"])}">'
                     f'<input type="hidden" name="back" value="{esc(back)}">'
                     f'<button class="rbtn" type="submit" title="'
                     f'{esc(tr("post.share_tip", "分享到我的朋友圈，好友可见；可以移除，但已看到的人无法收回"))}">'
                     f'↗ {esc(tr("post.share", "分享"))}</button></form>')
    return (f'<div class="postfoot"><span class="ract">{"".join(buttons)}{share_btn}</span>'
            f'<a class="rlink" href="/app/p/{esc(r["id"])}#replies">💬 {tr("post.replies", "回贴")} {nreply}</a></div>')


def _share_snapshot(r):
    """分享帖自带的原帖快照（跨机渲染用）；缺失或损坏 → None。"""
    try:
        raw = r["share_snapshot"]
    except (IndexError, KeyError):
        return None
    if not raw:
        return None
    try:
        snap = json.loads(raw) if isinstance(raw, str) else raw
    except (TypeError, ValueError):
        return None
    if not isinstance(snap, dict):
        return None
    return snap if (snap.get("title") or snap.get("body")) else None


def _share_snapshot_card(snap: dict, src_id: str) -> str:
    """对端没有原帖时的分享卡：内容自包含，**不给死链**（点开 404 比不显示更糟）。"""
    title = str(snap.get("title") or "").strip()
    body = re.sub(r"\s+", " ", str(snap.get("body") or "")).strip()[:120]
    who = esc(display_name(str(snap.get("author") or ""), agent_names_cached()))
    head = esc(title) if title else (esc(body) or esc(str(src_id or "")))
    # 有标题时再给一行正文摘要：跨机分享只有快照，读者靠这两行判断值不值得看。
    sub = (f'<div class="dim" style="margin-top:2px;font-size:13px">{esc(body)}</div>'
           if (title and body) else "")
    when = str(snap.get("created_at") or "").strip()
    stamp = f' · {esc(when)}' if when else ""
    return (f'<div class="sharecard" style="margin:10px 0 0;padding:10px 12px;'
            f'border:1px solid #e0e0e0;border-left:3px solid #78a9ff;border-radius:8px">'
            f'<span class="dim" style="font-size:12px">↗ '
            f'{esc(tr("post.shared_snapshot", "来自好友的分享"))} · {who}{stamp}</span>'
            f'<div style="margin-top:4px;color:#171717">{head}</div>{sub}</div>')


def _share_block(r) -> str:
    """分享卡：正文（转发语）之后嵌一张原帖摘要；原帖不可见则降级，不展示缓存正文。"""
    try:
        src_id = r["share_of"]
    except (IndexError, KeyError):
        return ""
    if not src_id:
        return ""
    src, ok, known = None, False, None
    try:
        from core import post_share
        c = db()
        try:
            # known=None ⇔ 本机从来没有这条帖（跨机收到好友的分享）→ 可用快照；
            # known 有值但 ok=False ⇔ 本地有但已归档/无权看 → 维持"不展示缓存正文"。
            known = post_share.share_of_any(c, src_id)
            src = post_share.share_of_row(c, src_id)
            ok = bool(src) and post_share.can_view(human_id(c), src, conn=c)
        finally:
            c.close()
    except Exception:                                            # noqa: BLE001
        ok = False
    if not ok:
        if known is None:
            snap = _share_snapshot(r)
            if snap:
                return _share_snapshot_card(snap, src_id)
        return ('<div class="sharecard dim" style="margin:10px 0 0;padding:10px 12px;'
                'border:1px dashed #d0d7de;border-radius:8px">原帖已不可见</div>')
    title = str(src["title"] or "").strip()
    body = re.sub(r"\s+", " ", str(src["body"] or "")).strip()[:120]
    who = esc(display_name(src["author_id"], agent_names_cached()))
    head = esc(title) if title else esc(body)
    return (f'<a class="sharecard" href="/app/p/{esc(src_id)}" '
            f'style="display:block;margin:10px 0 0;padding:10px 12px;'
            f'border:1px solid #e0e0e0;border-left:3px solid #0f62fe;border-radius:8px;'
            f'text-decoration:none">'
            f'<span class="dim" style="font-size:12px">↗ '
            f'{esc(tr("post.shared_from", "来自频道"))} · {who}</span>'
            f'<div style="margin-top:4px;color:#171717">{head}</div></a>')


def _post_card(r) -> str:
    raw, cut = truncate_md(r["body"], 10000)
    more = f'<a class="more" href="/app/p/{esc(r["id"])}">{tr("feed.readmore", "阅读全文 →")}</a>' if cut else ""
    moment = any(("lobby" in t.lower() or "朋友圈" in t or "moment" in t.lower()) for t in _tags(r["tags"]))
    return f"""<article class="post card{' moment' if moment else ''}">
        <a class="stretch" href="/app/p/{esc(r["id"])}" aria-label="{tr("post.open", "打开帖子")}"></a>
        <div class="head">
          {avatar(r["author_id"])}
          <div class="by"><b>{esc(display_name(r["author_id"], agent_names_cached()))}</b><span class="dim">{esc(fmt_dt(r["created_at"]))}</span></div>
          <div class="tags">{'<span class="tag del">交付</span>' if 'deliverable' in _tags(r["tags"]) else ''}{''.join(f'<a class="tag" href="/app/feed?tag={esc(t)}">#{esc(t)}</a>' for t in _tags(r["tags"]) if t != 'deliverable')}</div>
        </div>
        {f'<h2 style="margin:12px 0 0;font-size:18px">{esc(r["title"])}</h2>' if r["title"] else ''}
        <div class="body">{md_html(raw)}{more}</div>
        {_share_block(r)}
        {_post_refs(r["body"], r["id"])}
        {_att_html(r["attachments"], "atts", grid=moment)}
        {_link_html(r["links"])}
        {_post_footer(r)}
      </article>"""


def _is_process_post(p) -> bool:
    """论坛只收人读的内容；执行回执/状态流水/测试记录留在会话与工作目录。"""
    title = str(p["title"] or "")
    body = str(p["body"] or "")
    tags = {t.lower() for t in _tags(p["tags"])}
    if tags & {"status", "activity", "standup", "dispatch", "log", "regression",
                "regression-test", "selfcheck", "paste-selftest"}:
        return True
    head = (title + "\n" + body[:500]).lower()
    if "推荐理由" in body[:400] or "原文见" in body[:800]:
        return True
    marks = ("[done]", "[dispatch]", "[start]", "[fail]", "exit=", "执行进度",
             "standup", "paste-selftest", "回归自检", "成本测试", "压测",
             "测试发图", "回执", "todo:", "tbd:", "fixme:", "layout test", "layout-test")
    return any(x in head for x in marks)


def _feed_rows(c, tag: str, offset: int, limit: int, q: str = ""):
    rows = _feed_visible_rows(c)
    if tag:
        rows = [r for r in rows if tag in _tags(r["tags"])]
    if q:
        ql = q.lower()
        rows = [r for r in rows if ql in str(r["title"] or "").lower()
                or ql in str(r["body"] or "").lower()
                or ql in str(r["tags"] or "").lower()]
    return rows[offset:offset + limit]


def _tools_side(active: str = "") -> str:
    items = [
        ("https", "HTTPS / CA 帮助", "/app/help/https"),
        ("sync", "P2P 同步", "/app/peer-sync"),
        ("grants", "跨 Owner 授权", "/app/peer-grants"),
        ("backup", "本机备份", "/app/backup"),
        ("groups", "中心组同步", "/app/peer-groups"),
        ("keys", "Key 帮助", "/app/help/keys"),
    ]
    links = "".join(
        f'<a class="citem{" on" if active == key else ""}" href="{href}">'
        f'<span class="cname">{esc(label)}</span></a>'
        for key, label, href in items)
    links += '<a class="citem" href="/app/settings"><span class="cname">回设置 →</span></a>'
    return f'<div class="sidebox"><div class="shead">LOCAL TOOLS</div>{links}</div>'


def _tools_detail(kicker: str, title: str, lead: str, extra: str = "") -> str:
    return (f'<div class="card" style="padding:16px 18px"><div class="kicker">{esc(kicker)}</div>'
            f'<h2 style="margin:6px 0 8px">{esc(title)}</h2>'
            f'<p class="dim" style="margin:0 0 8px">{lead}</p>{extra}</div>')


def page_peer_sync() -> str:
    c = db()
    try:
        try:
            from core.server import _node_log
            log = _node_log()
            events = len(log.all())
            lamport = log.lamport()
            node = log.node_id
        except Exception:
            events, lamport, node = 0, 0, "unknown"
        try:
            applied = c.execute("select count(*) n from p2p_applied").fetchone()["n"]
        except Exception:
            applied = 0
        try:
            from core import peer_blobs
            blobs = len([p for p in peer_blobs.BLOBS.iterdir() if p.is_file()]) if peer_blobs.BLOBS.exists() else 0
        except Exception:
            blobs = 0
        try:
            from core import peer_sync
            token_state = "configured" if peer_sync.expected_token() else "disabled"
        except Exception:
            token_state = "unknown"
        try:
            cursors = c.execute("select peer,since,updated_at from p2p_cursors order by peer").fetchall()
        except Exception:
            cursors = []
    finally:
        c.close()
    cursor_rows = "".join(
        f'<div class="kv"><span>{esc(x["peer"])}</span><b>{x["since"]} · {esc(x["updated_at"] or "")}</b></div>'
        for x in cursors[:10])
    body = f"""
  <section class="card" style="padding:20px 22px">
    <div class="kicker">P2P SYNC · LOCAL</div>
    <h2 style="margin:6px 0 8px">本地同步状态</h2>
    <p class="dim">中心只做目录/信令；帖子、聊天、附件不走中心正文。</p>
    <div class="kv"><span>Node</span><b class="mono">{esc(node)}</b></div>
    <div class="kv"><span>事件数</span><b>{events}</b></div>
    <div class="kv"><span>Lamport</span><b>{lamport}</b></div>
    <div class="kv"><span>已 apply 的远端事件</span><b>{applied}</b></div>
    <div class="kv"><span>本机 blob</span><b>{blobs}</b></div>
    <div class="kv"><span>Peer token</span><b>{token_state}</b></div>
    {cursor_rows}
    <p class="dim" style="margin:12px 0 0">远端附件 URL 映射为 /app/peer-blob/&lt;sha&gt;/&lt;name&gt;；先从源节点取回并经 sha256 校验。</p>
  </section>"""
    detail = _tools_detail(
        "P2P SYNC", "本地事件与游标",
        "中心只做目录/信令；本页是本机事件、Lamport 时钟与附件 blob 的只读状态。",
        f'<div class="kv"><span>Node</span><b class="mono">{esc(node)}</b></div>'
        f'<div class="kv"><span>Lamport</span><b>{lamport}</b></div>'
        f'<div class="kv"><span>远端游标</span><b>{len(cursors)}</b></div>'
        '<p class="dim" style="margin:10px 0 0">同步不会覆盖本机数据；远端事件按幂等键 apply。</p>')
    return shell("P2P 同步", body, "tools", "中心只做目录/信令",
                 side=_tools_side("sync"), detail=detail)


def page_peer_grants() -> str:
    from core import peer_grants
    # list_grants() 会确保表结构，必须用可写连接；用 db() 会在只读连接上触发 500。
    c = rw()
    try:
        grants = peer_grants.list_grants(c)
    except Exception as exc:  # noqa: BLE001
        grants = []
        err = str(exc)
    else:
        err = ""
    finally:
        c.close()
    rows = []
    for g in grants:
        status = "revoked" if g.get("revoked_at") else g.get("status", "")
        scope = ", ".join(g.get("scopes") or [])
        if g.get("allow_unsigned"):
            scope += " · ⚠ unsigned 兼容"
        rooms = ", ".join(g.get("room_ids") or []) or "全部房间"
        action = ""
        if status == "pending":
            action = ('<form method="post" action="/app/peer-grants/decide" class="inline-form">'
                      f'<input type="hidden" name="grant_id" value="{esc(g["grant_id"])}">'
                      '<input type="hidden" name="action" value="approve">'
                      '<button class="btn primary" type="submit">批准</button></form>')
        elif status == "approved":
            action = ('<form method="post" action="/app/peer-grants/decide" class="inline-form">'
                      f'<input type="hidden" name="grant_id" value="{esc(g["grant_id"])}">'
                      '<input type="hidden" name="action" value="revoke">'
                      '<button class="btn" type="submit">撤销</button></form>')
        rows.append(
            '<tr><td class="mono">' + esc(g.get("grant_id", "")) + '</td>'
            '<td>' + esc(g.get("peer_owner", "")) + '<br><span class="dim">' +
            esc(g.get("peer_node", "")) + '</span></td>'
            '<td>' + esc(g.get("group_id") or "—") + '</td>'
            '<td>' + esc(scope) + '<br><span class="dim">' + esc(rooms) + '</span></td>'
            '<td><span class="tag">' + esc(status) + '</span></td>'
            '<td>' + action + '</td></tr>')
    err = esc(request.args.get("err") or err)
    pending = sum(1 for g in grants if not g.get("revoked_at") and g.get("status") == "pending")
    approved = sum(1 for g in grants if not g.get("revoked_at") and g.get("status") == "approved")
    body = f"""
  <section class="card sec">
    <div class="kicker">P2P GRANTS · OWNER APPROVAL</div>
    <h2 style="margin:6px 0 8px">跨 Owner 协作授权</h2>
    <p class="dim" style="margin:0 0 12px">远程节点先提交请求；本地 Owner 批准后才可读取/写入指定房间。未批准、已撤销的 token 一律拒绝。</p>
    {f'<p class="tag del">{err}</p>' if err else ''}
    <div class="table-wrap">
      <table class="tool-table">
        <thead><tr><th>Grant</th><th>对方 Owner / Node</th><th>组</th><th>范围</th><th>状态</th><th></th></tr></thead>
        <tbody>{''.join(rows) or '<tr><td colspan="6" class="dim">暂无授权请求</td></tr>'}</tbody>
      </table>
    </div>
  </section>"""
    detail = _tools_detail(
        "P2P GRANTS", "谁能读写我的房间",
        "跨 Owner 的读写必须先经过本地 Owner 批准；未批准、已撤销的 token 一律拒绝。",
        f'<div class="kv"><span>待批准</span><b>{pending}</b></div>'
        f'<div class="kv"><span>已批准</span><b>{approved}</b></div>'
        f'<div class="kv"><span>总请求</span><b>{len(grants)}</b></div>'
        '<p class="dim" style="margin:10px 0 0">授权按组/房间与 scopes 限定；撤销立即生效。</p>')
    return shell("跨 Owner 授权", body, "tools", "按组/房间授权，Owner 审批后生效",
                 side=_tools_side("grants"), detail=detail)

def page_backup() -> str:
    from core import peer_backup
    c = db()
    try:
        counts = {}
        for table in ("posts", "replies", "rooms", "room_messages"):
            try:
                counts[table] = c.execute(f"select count(*) from {table}").fetchone()[0]
            except Exception:
                counts[table] = 0
        try:
            blobs = len([p for p in peer_backup.peer_blobs.BLOBS.iterdir() if p.is_file()])
        except Exception:
            blobs = 0
    finally:
        c.close()
    msg = esc(request.args.get("msg") or "")
    try:
        recent_rows = peer_backup.list_backups(8)
    except Exception:
        recent_rows = []
    recent = "".join(
        f'<div class="row"><span class="tag">{("加密" if x.get("encrypted") else "明文")}</span>'
        f'<b style="flex:1">{esc(x.get("name", ""))}</b>'
        f'<span class="dim">{x.get("bytes", 0)} B · {esc(x.get("at", ""))}</span></div>'
        for x in recent_rows) or '<div class="dim">暂无本机备份</div>'
    body = f"""
  <section class="card sec">
    <div class="kicker">LOCAL BACKUP · POSTS / CHAT / BLOBS</div>
    <h2 style="margin:6px 0 8px">本机备份</h2>
    <p class="dim">导出/导入只在本机完成；ZIP 内的每个 blob 和 data.json 都有 sha256。导入先校验，损坏包拒收。</p>
    {f'<p class="tag">{msg}</p>' if msg else ''}
    <div class="kv"><span>帖子</span><b>{counts.get("posts", 0)}</b></div>
    <div class="kv"><span>回贴</span><b>{counts.get("replies", 0)}</b></div>
    <div class="kv"><span>房间</span><b>{counts.get("rooms", 0)}</b></div>
    <div class="kv"><span>房间消息</span><b>{counts.get("room_messages", 0)}</b></div>
    <div class="kv"><span>本机 blob</span><b>{blobs}</b></div>
    <div class="tool-actions">
      <a class="btn primary" href="/app/backup/export">下载明文 ZIP</a>
      <form method="post" action="/app/backup/export" class="tool-form">
        <input type="password" name="passphrase" placeholder="加密密码（可选）" autocomplete="new-password">
        <button class="btn" type="submit">下载加密包</button>
      </form>
      <form method="post" action="/app/backup/save" class="tool-form">
        <input type="password" name="passphrase" placeholder="本地保存密码（可选）" autocomplete="new-password">
        <input name="keep" value="7" size="3" title="保留份数" class="keep-input">
        <button class="btn" type="submit">保存到本机</button>
      </form>
    </div>
    <form method="post" action="/app/backup/import" enctype="multipart/form-data" class="tool-form tool-import">
      <input type="file" name="file" accept=".zip,.taabak,application/zip,application/octet-stream" required>
      <input type="password" name="passphrase" placeholder="加密包密码（可选）" autocomplete="current-password">
      <button class="btn" type="submit">校验并导入</button>
    </form>
    <p class="dim" style="margin:12px 0 0">明文 ZIP 不加密；加密包使用 AES-GCM，密码不落库。导入按主键/消息 id 幂等合并；不会执行包内代码。</p>
    <div class="kicker" style="margin-top:16px">本机保留备份</div>
    <div class="rows">{recent}</div>
  </section>"""
    detail = _tools_detail(
        "LOCAL BACKUP", "本机数据，不离机",
        "导出/导入只在本机完成；ZIP 内每个 blob 与 data.json 都有 sha256，损坏包拒收。",
        f'<div class="kv"><span>帖子</span><b>{counts.get("posts", 0)}</b></div>'
        f'<div class="kv"><span>房间消息</span><b>{counts.get("room_messages", 0)}</b></div>'
        f'<div class="kv"><span>本机 blob</span><b>{blobs}</b></div>'
        '<p class="dim" style="margin:10px 0 0">明文 ZIP 不加密；加密包使用 AES-GCM，密码不落库。</p>')
    return shell("本机备份", body, "tools", "帖子 / 聊天 / 附件备份与恢复",
                 side=_tools_side("backup"), detail=detail)


def page_peer_groups() -> str:
    import os
    c = db()
    try:
        groups = c.execute("select group_id,name,created_by,created_at from collab_groups order by created_at desc").fetchall()
        members = {g["group_id"]: c.execute(
            "select owner_id,role from collab_group_members where group_id=? order by owner_id",
            (g["group_id"],)).fetchall() for g in groups}
    except Exception:
        groups, members = [], {}
    finally:
        c.close()
    base = (os.environ.get("TAA_CENTER_BASE") or "").strip()
    configured = bool(base and (os.environ.get("TAA_OWNER_SESSION") or "").strip())
    rows = []
    for g in groups:
        ms = ", ".join(f'{m["owner_id"]}({m["role"]})' for m in members.get(g["group_id"], []))
        rows.append('<tr><td class="mono">' + esc(g["group_id"]) + '</td><td>' +
                    esc(g["name"]) + '</td><td>' + esc(ms) + '</td><td>' +
                    esc(g["created_at"] or "") + '</td></tr>')
    msg = esc(request.args.get("msg") or "")
    body = f"""
  <section class="card sec">
    <div class="kicker">CENTER COLLAB GROUPS · LOCAL VIEW</div>
    <h2 style="margin:6px 0 8px">中心组同步</h2>
    <p class="dim">中心仍是组成员目录；本机只保存本地镜像。owner session 从进程环境读取，不显示、不写库。</p>
    <div class="kv"><span>中心地址</span><b class="mono">{esc(base or "未配置")}</b></div>
    <div class="kv"><span>Owner session</span><b>{("已配置" if configured else "未配置")}</b></div>
    {f'<p class="tag">{msg}</p>' if msg else ''}
    <form method="post" action="/app/peer-groups/sync" style="margin:12px 0">
      <button class="btn primary" type="submit" {'disabled' if not configured else ''}>从中心同步组</button>
    </form>
    <div class="table-wrap">
      <table class="tool-table">
        <thead><tr><th>Group</th><th>Name</th><th>Owners</th><th>Created</th></tr></thead>
        <tbody>{''.join(rows) or '<tr><td colspan="4" class="dim">本机暂无组；配置环境后同步</td></tr>'}</tbody>
      </table>
    </div>
    <p class="dim" style="margin:12px 0 0">环境变量：TAA_CENTER_BASE / TAA_OWNER_SESSION</p>
  </section>"""
    detail = _tools_detail(
        "CENTER GROUPS", "中心组 → 本地镜像",
        "中心保存组成员目录；本机只保存镜像，不把 owner session 写入页面或数据库。",
        f'<div class="kv"><span>中心地址</span><b class="mono">{esc(base or "未配置")}</b></div>'
        f'<div class="kv"><span>Owner session</span><b>{("已配置" if configured else "未配置")}</b></div>'
        f'<div class="kv"><span>本地组</span><b>{len(groups)}</b></div>'
        '<p class="dim" style="margin:10px 0 0">没有配置环境变量时，同步按钮不可用。</p>')
    return shell("中心组同步", body, "tools", "中心组 → 本地组镜像",
                 side=_tools_side("groups"), detail=detail)


def page_persona_gen(name: str = "", gender: str = "", seed: str = "", template: str = "",
                     hint: str = "", enrich: bool = False, persona: dict | None = None,
                     err: str = "") -> str:
    """只读预览：把 persona_gen 的结果渲染成卡片（**不落盘、不建档**）。

    用途：验证"名字 → 性别 → 模板池 N 选 1"是否符合预期，尤其是中文名的性别推断、
    模板抽中率、以及 LLM 润色（可选）前后的差别。
    """
    from . import persona as _P
    from . import persona_gen as _G

    def opt(v: str, label: str, cur: str) -> str:
        sel = " selected" if v == cur else ""
        return f'<option value="{esc(v)}"{sel}>{esc(label)}</option>'

    _TPL_LABEL = {"female": "女性通用", "female_warm": "温柔", "female_sharp": "锋芒",
                  "male": "男性通用", "male_hustler": "野心", "male_scholar": "学者"}
    tpls = _P.list_templates()
    form = f"""
    <form class="pg-form" method="get" action="/app/persona-gen">
      <label>名字<input name="name" value="{esc(name)}" placeholder="李静 / 张伟 / Emma" required></label>
      <label>性别<select name="gender">{opt("", "自动（按名字推断）", gender)}{
        opt("female", "female", gender)}{opt("male", "male", gender)}</select></label>
      <label>模板<select name="template">{opt("", "自动（池内 N 选 1）", template)}{
        "".join(opt(t, _TPL_LABEL.get(t, t), template) for t in tpls)}</select></label>
      <label>seed<input name="seed" value="{esc(seed)}" placeholder="可复现"></label>
      <label>一句话设定<input name="hint" value="{esc(hint)}" placeholder="供 LLM 润色"></label>
      <label class="pg-check"><input type="checkbox" name="enrich" value="1"{
        " checked" if enrich else ""}> LLM 润色</label>
      <button class="btn" type="submit">生成预览</button>
    </form>"""

    card = ""
    if err:
        card = f'<div class="pg-card pg-err">生成失败：{esc(err)}</div>'
    elif persona:
        s = _G.summary(persona)
        full = _P.render_starter(persona)        # 内存展开衣柜（只读 presets，不落盘）
        wear = (full.get("wardrobe") or {}).get("items") or {}
        tags = "".join(f'<span class="pg-tag">{esc(k)} · {len(v)}</span>' for k, v in wear.items())
        body = full.get("body") or {}
        ident = full.get("identity") or {}
        warn = ""
        if template and not s.get("template", "").startswith((gender or s.get("gender") or "female")[:2]):
            warn = '<div class="pg-warn">所选模板与性别池不符，已在该性别池内重新抽取。</div>'
        card = f"""
        <div class="pg-card">
          {warn}
          <div class="pg-head">
            <b>{esc(s.get("name") or "")}</b>
            <span class="pg-tag">{esc(s.get("gender") or "")}</span>
            <span class="pg-tag">{esc(_TPL_LABEL.get(s.get("template") or "", s.get("template") or ""))}</span>
            <span class="pg-tag">{esc(s.get("age") or "-")} 岁 · {esc(s.get("height_cm") or "-")}cm</span>
          </div>
          <p class="pg-line"><em>外观</em>{esc(body.get("appearance") or "—")}</p>
          <p class="pg-line"><em>自述</em>{esc(ident.get("bio") or "—")}</p>
          <p class="pg-line"><em>语气</em>{esc((full.get("voice") or {}).get("style") or "—")}</p>
          <p class="pg-line"><em>口癖</em>{esc("、".join((full.get("voice") or {}).get("catchphrases") or []) or "—")}</p>
          <p class="pg-line"><em>衣柜</em>{tags or "—"}</p>
          <p class="pg-note">共 {sum(len(v) for v in wear.values())} 件（starter={esc(s.get("wardrobe_starter") or "")}）·
          这些只在本机 persona.yaml，不入库不同步。</p>
        </div>"""

    return f"""
    <style>
      .pg-wrap{{max-width:820px;margin:0 auto}}
      .pg-form{{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin:16px 0 20px}}
      .pg-form label{{display:flex;flex-direction:column;gap:4px;font-size:12px;color:#525252}}
      .pg-form input,.pg-form select{{padding:6px 8px;border:1px solid #e0e0e0;border-radius:6px;
        font:inherit;font-size:13px;background:#fff;min-width:110px}}
      .pg-form .pg-check{{flex-direction:row;align-items:center;gap:6px;font-size:13px}}
      .pg-card{{border:1px solid #e6e9ef;border-radius:12px;padding:18px 20px;background:#fff;
        box-shadow:0 1px 2px rgba(16,24,40,.04)}}
      .pg-head{{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:16px;margin-bottom:10px}}
      .pg-tag{{display:inline-block;background:#eef4ff;color:#1d4ed8;border-radius:999px;
        padding:2px 10px;font-size:12px;line-height:20px}}
      .pg-line{{margin:8px 0;font-size:14px;line-height:1.7;color:#262626}}
      .pg-line em{{font-style:normal;color:#8c8c8c;margin-right:8px;font-size:12px}}
      .pg-note{{margin:12px 0 0;font-size:12px;color:#8c8c8c}}
      .pg-warn{{background:#fff7e6;border:1px solid #ffe0a3;color:#8a5a00;border-radius:8px;
        padding:8px 12px;font-size:13px;margin-bottom:12px}}
      .pg-err{{color:#a8071a;border-color:#ffccc7;background:#fff2f0}}
      .pg-intro{{font-size:13px;color:#525252;line-height:1.8}}
    </style>
    <div class="pg-wrap">
      <p class="pg-intro">按名字生成一份<strong>人格骨架预览</strong>：名字 → 性别 → 模板池 N 选 1，
      确定性可复现（同 name+seed 结果恒定）。<strong>此处只读，不落盘、不建档</strong>；
      真正建档用 <code>teamai persona-gen --id &lt;id&gt; --write</code>。</p>
      {form}
      {card or '<p class="pg-note">填个名字，点「生成预览」。</p>'}
    </div>"""


def page_feed():
    c = db()
    tag = (request.args.get("tag") or "").strip()
    q = (request.args.get("q") or "").strip()[:80]
    all_tags = request.args.get("alltags") == "1"
    view = (request.args.get("view") or "all").strip()
    featured = view == "featured"
    rows = _featured_rows(c, 20) if featured else _feed_rows(c, tag, 0, 10, q)
    posts = "".join(_post_card(r) for r in rows)
    nxt = 0 if featured else len(rows)
    try:
        from core import center_sync
        center = center_sync.center_base()
        scope = f'<div class="card scopenote">{tr("feed.local_scope", "本机频道：本机工作与执行记录；公共发布在中心。")} <a class="btn" href="{esc(center)}/feed" target="_blank" rel="noopener">{tr("feed.center_link", "打开中心频道")} ↗</a></div>'
    except Exception:
        scope = ""
    body = f"""
  {scope}
  <form class="card compose" method="post" action="/app/post">
    <input type="hidden" name="back" value="/app/feed">
    <textarea name="body" maxlength="40000" rows="4" data-image-composer="feedimages" data-preview="feedpreview" placeholder="{tr("feed.write", "写点什么…（可直接粘贴图片）")}"></textarea>
    <input type="hidden" name="images" id="feedimages" value="[]">
    <div id="feedpreview" class="imgpreview"></div>
    <div class="crow">
      <input name="link" placeholder="{tr("feed.link", "链接（可选）")}">
      <input name="tags" placeholder="{tr("feed.tags", "标签（可选，逗号分隔）")}">
      <label class="btn" style="cursor:pointer">{tr("feed.image", "图片")}<input type="file" accept="image/*" multiple style="display:none" onchange="composerAddFiles(document.querySelector('[data-image-composer=feedimages]'),this.files);this.value=''"></label>
      <button class="btn" type="submit">{tr("feed.publish", "发布")}</button>
    </div>
  </form>
  <form class="searchbar" method="get" action="/app/feed">
    {f'<input type="hidden" name="tag" value="{esc(tag)}">' if tag else ''}
    <input name="q" value="{esc(q)}" placeholder="{tr("feed.search_ph", "搜索频道：标题 / 正文 / 标签")}">
    <button class="btn" type="submit">{tr("feed.search", "搜索")}</button>
    {f'<a class="btn" href="/app/feed">{tr("feed.clear", "清除")}</a>' if (q or tag) else ''}
  </form>
  <div class="bar feedtabs"><span class="dim">{f'搜索 “{esc(q)}” · ' if q else ''}{'#' + esc(tag) if tag else (tr("feed.featured_bar", "精选 · 人类可读 + 互动") if featured else tr("feed.bar", "本地频道 · 适合人读的工作与交付记录"))}</span>
    <span><a class="btn{' on' if not featured else ''}" href="/app/feed">{tr("feed.tab_all", "全部")}</a>
    <a class="btn{' on' if featured else ''}" href="/app/feed?view=featured">{tr("feed.tab_featured", "精选")}</a></span>
    {f'<a class="btn" href="/app/feed">{tr("feed.all","全部")}</a>' if tag else ''}</div>
  <div id="feedlist">{posts or f'<div class="empty card"><p>{tr("feed.no_posts", "还没有帖子")}</p></div>'}</div>
  <div id="feedmore" class="feedmore"{' hidden' if featured else ''} data-featured="{1 if featured else 0}" data-next="{nxt}" data-tag="{esc(tag)}" data-q="{esc(q)}">{tr("feed.load_more", "加载更多")}</div>
  <script>
  (function(){{
    var box=document.getElementById("feedlist"), more=document.getElementById("feedmore");
    if(!more || more.dataset.featured==="1") return;
    var busy=false, desktop=window.innerWidth>=900;
    async function load(){{
      if(busy) return; busy=true;
      var off=parseInt(more.dataset.next||"0",10), tag=more.dataset.tag||"", q=more.dataset.q||"";
      try {{
        var r=await fetch("/app/feed/more?offset="+off+"&tag="+encodeURIComponent(tag)+"&q="+encodeURIComponent(q));
        var html=await r.text(); var tmp=document.createElement("div"); tmp.innerHTML=html;
        var cards=[].slice.call(tmp.querySelectorAll("article.post"));
        cards.forEach(function(c){{ box.appendChild(c); }});
        off+=cards.length; more.dataset.next=off;
        if(!cards.length) more.hidden=true;
      }} catch(e) {{}}
      busy=false;
    }}
    more.addEventListener("click", load);
    if(desktop){{ (async function(){{ while(parseInt(more.dataset.next||"0",10)<20){{ var before=parseInt(more.dataset.next||"0",10); await load(); if(more.hidden || parseInt(more.dataset.next||"0",10)===before) break; }} }})(); }}
    else if("IntersectionObserver" in window){{
      new IntersectionObserver(function(es){{ if(es[0].isIntersecting) load(); }},{{rootMargin:"300px"}}).observe(more);
    }}
  }})();
  </script>"""
    total_posts = c.execute("select count(*) n from posts where coalesce(status,'') NOT IN ('duplicate','archived')").fetchone()["n"]
    detail = ('<div class="postdetail-pane" id="feeddetail">'
              + _dhero(tr("feed.detail_title", "帖子详情"), tr("feed.detail_pick", "点一篇帖子，在这里读全文"),
                       tr("feed.detail_sub", "桌面在右栏打开，手机进入全文；长文在栏内独立滚动。"),
                       f'<a class="dact" href="/app/feed">{tr("feed.refresh", "刷新频道")}</a>'
                       f'<a class="dact" href="/app/tags">{tr("feed.all_tags", "全部标签")}</a>'
                       f'<button class="dact primary" type="button" data-detail-focus=".compose textarea">{tr("feed.new", "写新帖")}</button>')
              + _dcard(tr("feed.detail_what", "右栏能做什么"), f'<p class="dnote">{tr("feed.detail_what_note", "· 点中栏任意帖子，全文与图片在右栏展开，不打断阅读位置<br>· 首屏固定「打开全文 / 复制链接 / 回到列表」<br>· 正文、代码块与表格在栏内换行，不产生横向滚动")}</p>')
              + _dcard(tr("nav.feed", "频道"), f'<div class="drow"><span>{tr("feed.readable", "可读帖子")}</span><b>{total_posts}</b></div>'
                       f'<p class="dnote" style="margin-top:8px">{tr("feed.detail_note", "右栏只做阅读与跳转；发布、搜索、标签过滤仍在主区。")}</p>')
              + '</div>')
    feed_js = """<script>
    (function(){
      document.addEventListener("click", function(e){
        if(window.innerWidth<900) return;
        var a=e.target.closest("#feedlist .post .stretch") || e.target.closest("#feedlist .postref-card"); if(!a) return;
        var pane=document.getElementById("feeddetail"); if(!pane) return;
        e.preventDefault();
        var href=a.getAttribute("href");
        if(!href) return;
        pane.innerHTML='<p class="dnote">载入中…</p>';
        fetch(href).then(function(r){return r.text()}).then(function(html){
          var doc=new DOMParser().parseFromString(html,"text/html");
          var art=doc.querySelector(".postdetail"); if(!art) return;
          pane.innerHTML='<div class="dtoolbar"><span class="kicker">帖子详情</span><div class="dacts">'
            +'<a class="dact primary" href="'+href+'">打开全文 →</a>'
            +'<button class="dact" type="button" data-detail-copy-link="'+href+'">复制链接</button>'
            +'<button class="dact" type="button" data-detail-back>回到列表</button></div></div>';
          pane.appendChild(art);
          var sc=document.getElementById("detail-scroll"); if(sc) sc.scrollTop=0;
          document.querySelectorAll(".post.selected").forEach(function(x){x.classList.remove("selected")});
          a.closest(".post").classList.add("selected");
        }).catch(function(){ pane.innerHTML='<p class="dnote">打开失败，请用「打开全文」。</p>'; });
      }, true);
    })();
    </script>"""
    return shell("频道", body, "feed", "适合人读的工作与交付记录", side=side_tags(c, tag, all_tags), page_css=PAGE_CSS["feed"], detail=detail, scripts=feed_js)


def page_tags():
    c = db()
    counts = {}
    for r in _feed_visible_rows(c):
        for t in _tags(r["tags"]):
            counts[t] = counts.get(t, 0) + 1
    ordered = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    chips = "".join(f'<a class="tagchip" data-tag="{esc(t)}" href="/app/feed?tag={quote(t)}">#{esc(t)} <span>{n}</span></a>'
                    for t, n in ordered)
    body = f"""
  <section class="card" style="padding:18px 20px">
    <div class="kicker">{tr("tags.kicker", "频道标签索引")}</div>
    <h2 style="margin:6px 0 8px">{tr("tags.title", "全部标签")} · {len(ordered)}</h2>
    <p class="dim" style="margin:0 0 12px">{tr("tags.note", "标签用于把“值得人读”的内容归类。中间过程文档不要发到这里，留在工作目录给 agent 读。")}</p>
    <input id="tagfilter" class="tagfilter" placeholder="{tr("tags.filter", "筛选标签…")}">
    <div class="tagcloud" id="tagcloud">{chips or f'<div class="dim">{tr("tags.none", "暂无标签")}</div>'}</div>
  </section>
  <style>
  .tagfilter{{width:100%;max-width:420px;box-sizing:border-box;border:1px solid var(--hair);border-radius:12px;padding:9px 12px;font:inherit;background:#fff}}
  .tagcloud{{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}}
  .tagchip{{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--hair);border-radius:999px;padding:5px 10px;font-size:13px;color:var(--ink-soft);background:#fff}}
  .tagchip span{{font-size:12px;color:var(--muted)}}
  .tagchip:hover{{border-color:var(--powder);background:var(--powder-light);color:var(--ink)}}
  </style>
  <script>
  (function(){{
    var f=document.getElementById("tagfilter"), box=document.getElementById("tagcloud");
    if(!f) return;
    f.addEventListener("input",function(){{
      var q=f.value.trim().toLowerCase();
      box.querySelectorAll(".tagchip").forEach(function(a){{
        a.style.display=(!q||a.dataset.tag.toLowerCase().indexOf(q)>=0)?"":"none";
      }});
    }});
  }})();
  </script>"""
    side = side_tags(c)
    top_tags = "".join(
        f'<a class="dlink" href="/app/feed?tag={quote(t)}"><b>#{esc(t)}</b><span class="dim">{n}</span></a>'
        for t, n in ordered[:8])
    detail = (
        _dhero(tr("tags.detail", "标签详情"), tr("tags.all", "频道的全部标签"), tr("tags.count", "{n} 个标签，点击回到频道过滤。").format(n=len(ordered)),
               f'<a class="dact primary" href="/app/feed">{tr("tags.back", "回到频道")}</a>'
               f'<a class="dact" href="/app/tags">{tr("tags.refresh", "刷新标签")}</a>')
        + _dcard(tr("tags.top", "高频标签"), f'<div class="dlist">{top_tags or "<p class=dnote>还没有标签。</p>"}</div>')
        + _dcard(tr("post.note", "说明"), f'<p class="dnote">{tr("tags.note", "标签是频道的人工索引，只用于归类可读内容；中心同步的少量内容标签会更少。")}</p>')
    )
    return shell(tr("tags.all", "全部标签"), body, "feed", tr("tags.subtitle", "频道的全部标签索引"), side=side, page_css=PAGE_CSS["feed"], detail=detail)


def page_moments():
    c = db()
    hid = human_id(c)
    rows = c.execute("""select id,author_id,title,body,tags,links,attachments,created_at,
        visibility,share_of,share_snapshot from posts
        where coalesce(status,'') NOT IN ('duplicate','archived')
        and (kind='moment' or author_id=?)
        and (lower(tags) like '%lobby%' or tags like '%朋友圈%' or lower(tags) like '%moment%')
        and coalesce(title,'') not like '%回执%'
        order by created_at desc limit 60""", (hid,)).fetchall()
    def _moment_life_ok(row) -> bool:
        if _is_process_post(row):
            return False
        low = str(row["body"] or "").lower()
        noise = ("\x1b", "> build ·", "opencode", "```", "def ", "class ",
                 "pull request", "commit")
        return not any(x in low for x in noise)
    rows = [r for r in rows if _moment_life_ok(r)]
    # 本机朋友圈只显示自己的内容，但仍走同一条可见性判定，避免两套逻辑漂移。
    try:
        from core import post_share
        rows = post_share.visible_rows(c, hid, rows)
    except Exception:                                            # noqa: BLE001
        pass
    rows = _dedupe_rows(rows)[:20]
    posts = "".join(_post_card(r) for r in rows)
    try:
        from core import center_sync
        center = center_sync.center_base()
        scope = f'<div class="card scopenote">{tr("moments.local_scope", "本机朋友圈：本机草稿与记录；公共朋友圈在中心。")} <a class="btn" href="{esc(center)}/moments" target="_blank" rel="noopener">{tr("moments.center_link", "打开中心朋友圈")} ↗</a></div>'
    except Exception:
        scope = ""
    body = f"""
  {scope}
  <form class="card compose" method="post" action="/app/post">
    <input type="hidden" name="back" value="/app/moments">
    <input type="hidden" name="tags" value="朋友圈,lobby">
    <textarea name="body" maxlength="40000" rows="4" data-image-composer="momentimages" data-preview="momentpreview" placeholder="{tr("moments.placeholder", "发一条朋友圈…（可直接粘贴图片）")}"></textarea>
    <input type="hidden" name="images" id="momentimages" value="[]">
    <div id="momentpreview" class="imgpreview"></div>
    <div class="crow"><label class="btn" style="cursor:pointer">{tr("feed.image", "图片")}<input type="file" accept="image/*" multiple style="display:none" onchange="composerAddFiles(document.querySelector('[data-image-composer=momentimages]'),this.files);this.value=''"></label><button class="btn primary" type="submit">{tr("moments.post", "发到朋友圈")}</button>
      <span class="dim">{tr("moments.note", "会进入 #lobby / 朋友圈；中间过程文档不要发这里。")}</span></div>
  </form>
  <div class="bar"><span class="dim">{tr("moments.lead", "朋友圈 · #lobby · 适合人读的日常与心情")}</span></div>
  <div id="feedlist" class="momentlist">{posts or f'<div class="empty card"><p>{tr("moments.empty", "还没有朋友圈。发第一条吧。")}</p></div>'}</div>
  <style>
  .momentlist .post{{margin-bottom:12px}}
  </style>"""
    side = side_tags(c)
    race = moment_reward.summary(c)
    next_time = tr("moments.race_next", "下一次扫描：{time}").format(time=race["next_slot"])
    if race["next_day"]:
        next_time = tr("moments.race_next_tomorrow", "下一次扫描：明日 {time}").format(time=race["next_slot"])
    race_html = (
        f'<p class="dnote">{tr("moments.race_caps", "每扫描点最多 1 条 · 单 agent 每天最多 2 条 · 团队每天最多 {n} 条").format(n=race["team_cap"])}</p>'
        f'<p class="dnote">{next_time}</p>'
        f'<p class="dnote">{tr("moments.race_status", "今日已开 {rounds} 轮 · 收集 {candidates} 个候选").format(rounds=race["rounds"], candidates=race["candidates"])}</p>'
        + (f'<p class="dnote">{(tr("moments.race_last_win", "最近赢家：{name}（{slot}）") if race.get("last_post") else tr("moments.race_last", "最近评分最高：{name}（{slot}，未发布）")).format(name=race["last_winner"], slot=race["last_slot"])}</p>' if race.get("last_winner") else "")
        + (f'<p class="dnote"><a href="/app/p/{esc(race["last_post"])}">{tr("moments.race_published", "最近已发布：{post}").format(post=esc(race["last_post"]))}</a></p>' if race.get("last_post") else "")
        + (f'<p class="dnote">{tr("moments.race_local", "本地灰度：只发布 Alice/Bob，每日最多 1 条；其他 agent 只评分。")}</p>' if race.get("publish_mode") == "local" else "")
        + (f'<p class="dnote">{tr("moments.race_dry", "当前为 dry-run：只收集候选，不自动发布。")}</p>' if race["dry_run"] and race.get("publish_mode") == "off" else "")
    )
    detail = ('<div id="momentdetail" class="postdetail-pane">'
              + _dhero(tr("moments.lead", "朋友圈"), tr("moments.subtitle", "#lobby · 日常与见闻"), tr("moments.detail_desc", "九宫格最多 9 图，支持直接粘贴剪贴板图片。"),
                       f'<a class="dact primary" href="/app/feed">{tr("moments.to_feed", "去频道")}</a>'
                       f'<a class="dact" href="/app/moments">{tr("moments.refresh", "刷新")}</a>')
              + _dcard(tr("moments.race_title", "朋友圈赛马"), race_html)
              + _dcard(tr("post.note", "说明"), f'<p class="dnote">{tr("moments.detail_note", "朋友圈放日常、心情与见闻；工作交付与长文请发频道，避免把进度流水混进精选。")}</p>') + "</div>")
    return shell("朋友圈", body, "moments", "朋友圈 · #lobby", side=side, page_css=PAGE_CSS["feed"], detail=detail,
                 scripts=_detail_js("#feedlist .stretch", "momentdetail"))


def page_post(pid: str):
    c = db()
    # docs/531：已归档/重复的帖子直链一律 404（「移除分享」后立即消失，与频道/朋友圈口径一致）。
    r = c.execute("select * from posts where id=? and coalesce(status,'') "
                  "not in ('duplicate','archived')", (pid,)).fetchone()
    # docs/531：friends 可见的帖子，非好友访问直链一律 404（不泄露"存在但无权限"）。
    _visible = True
    if r is not None:
        try:
            from core import post_share
            _visible = post_share.can_view(human_id(c), r, conn=c)
        except Exception:                                        # noqa: BLE001
            _visible = True
    if not r or not _visible:
        body = '<div class="card" style="padding:24px"><p>帖子不存在或已归档。</p><a class="btn" href="/app/feed">返回频道</a></div>'
        return Response(shell("帖子", body, "feed", "未找到", side=side_tags(c), page_css=PAGE_CSS["feed"]), status=404)
    moment = any(("lobby" in t.lower() or "朋友圈" in t or "moment" in t.lower()) for t in _tags(r["tags"]))
    names = agent_names(c)
    who = display_name(r["author_id"], names)
    replies = c.execute("""select id,author_id,body,created_at from replies
        where post_id=? and status='visible' order by id limit 80""", (pid,)).fetchall()
    reply_rows = "".join(
        f'<div class="reply"><div class="rhead"><b>{esc(names.get(x["author_id"], x["author_id"]))}</b>'
        f'<span class="dim">{esc(fmt_dt(x["created_at"]))}</span></div>'
        f'<div class="rbody">{md_html(x["body"])}</div></div>' for x in replies)
    back = "/app/moments" if moment else "/app/feed"
    body = f"""
  <a class="btn" href="{back}">{tr("post.back", "← 返回")}</a>
  <article class="post card postdetail{' moment' if moment else ''}" style="margin-top:12px">
    <div class="head">
      <img class="pill" alt="" src="/avatar/m/{quote(str(r["author_id"]))}" width="44" height="44">
      <div class="by"><b>{esc(who)}</b><span class="dim">{esc(fmt_dt(r["created_at"]))}</span></div>
      <div class="tags">{'<span class="tag del">交付</span>' if 'deliverable' in _tags(r["tags"]) else ''}{''.join(f'<a class="tag" href="/app/feed?tag={esc(t)}">#{esc(t)}</a>' for t in _tags(r["tags"]) if t != 'deliverable')}</div>
    </div>
    {f'<h2 style="margin:14px 0 0;font-size:20px">{esc(r["title"])}</h2>' if r["title"] else ''}
    <div class="body">{md_html(r["body"])}</div>
    <div class="copyline"><button class="btn" type="button" data-copy-target=".postdetail .body">{tr("common.copy", "复制正文")}</button></div>
    {_share_block(r)}
    {_post_refs(r["body"], r["id"])}
    {_att_html(r["attachments"], "atts", grid=moment, detail=True)}
    {_link_html(r["links"])}
    {_post_footer(r)}
  </article>
  <section class="card replies" id="replies">
    <div class="kicker">{'评论' if moment else '回贴'} · {len(replies)}</div>
    <div class="replylist">{reply_rows or f'<p class="dim">{tr("post.none", "还没有回贴。")}</p>'}</div>
    <form class="replyform" method="post" action="/app/reply">
      <input type="hidden" name="post" value="{esc(pid)}">
      <input type="hidden" name="back" value="/app/p/{esc(pid)}#replies">
      <textarea name="body" rows="3" maxlength="2000" placeholder="{tr("post.comment", "评论") if moment else tr("post.replies", "回贴")}…" required></textarea>
      <button class="btn primary" type="submit">发布</button>
    </form>
  </section>
    """
    return shell(r["title"] or "帖子", body, "feed", f"{who} · {fmt_dt(r['created_at'])}",
                 side=side_tags(c, ""), page_css=PAGE_CSS["feed"])


def page_inbox():
    c = db()
    nrows = c.execute("select id,kind,body,read,created_at from notifications order by read asc, id desc limit 30").fetchall()
    unread = c.execute("select count(*) n from notifications where read=0").fetchone()["n"]
    blocked = c.execute("select id,title,assigned_to from tasks where status='blocked' order by created_at desc limit 6").fetchall()
    doing = c.execute("select id,title,assigned_to from tasks where status in ('in_progress','review') order by created_at desc limit 6").fetchall()
    rows = "".join(f"""<div class="row{' unread' if not r["read"] else ''}">
      <span class="tag">{esc(r["kind"])}</span><b style="flex:1">{esc(str(r["body"] or "")[:110])}</b>
      <span class="dim">{esc(fmt_dt(r["created_at"]))}</span>
      {'' if r['read'] else f'<form class="inbox-read" method="post" action="/app/inbox/read"><input type="hidden" name="id" value="{r["id"]}"><button class="btn" type="submit">{tr("inbox.read", "已读")}</button></form>'}
    </div>""" for r in nrows)
    taskrows = "".join(f'<div class="row"><span class="tag w">blocked</span><b style="flex:1">{esc(t["title"])}</b>'
                       f'<span class="dim">{esc(t["assigned_to"] or "未分配")}</span></div>' for t in blocked)
    doingrows = "".join(f'<div class="row"><span class="tag c">doing</span><b style="flex:1">{esc(t["title"])}</b>'
                        f'<span class="dim">{esc(t["assigned_to"] or "未分配")}</span></div>' for t in doing)
    body = f"""
  {_update_panel(compact=True)}
  <section class="card" id="mail" style="padding:16px 18px">
    <div class="kicker">{tr("inbox.sub", "需要你处理的事")} · {unread}</div>
    <form class="inbox-read" method="post" action="/app/inbox/read" style="margin:8px 0"><button class="btn" type="submit">{tr("inbox.markall", "全部标为已读")}</button></form>
    <div class="rows">{rows or f'<div class="dim">{tr("inbox.none", "没有通知")}</div>'}</div>
  </section>
  <section class="card" id="blocked" style="padding:16px 18px;margin-top:12px">
    <div class="kicker">{tr("inbox.blocked", "阻塞任务")}</div><div class="rows">{taskrows or f'<div class="dim">{tr("inbox.empty", "没有")}</div>'}</div>
  </section>
  <section class="card" id="doing" style="padding:16px 18px;margin-top:12px">
    <div class="kicker">{tr("inbox.doing", "进行中 / 待评审")}</div><div class="rows">{doingrows or f'<div class="dim">{tr("inbox.empty", "没有")}</div>'}</div>
  </section>"""
    nb = len(blocked); nd = len(doing)
    try:
        from core import center_sync
        center = center_sync.center_base()
        center_link = f'<a class="citem" href="{esc(center)}/inbox" target="_blank" rel="noopener"><span class="cname">{tr("inbox.center_link", "中心账号通知")} ↗</span></a>'
    except Exception:
        center_link = ""
    side = (f'<div class="sidebox"><div class="shead">{tr("inbox.local_scope", "本地运行提醒")}</div>{center_link}'
            f'<a class="citem" href="#mail"><span class="cname">{tr("inbox.unread", "未读通知")}</span><span class="dim" style="margin-left:auto">{unread}</span></a>'
            f'<a class="citem" href="#blocked"><span class="cname">{tr("inbox.blocked", "阻塞任务")}</span><span class="dim" style="margin-left:auto">{nb}</span></a>'
            f'<a class="citem" href="#doing"><span class="cname">{tr("inbox.doing_short", "进行中")}</span><span class="dim" style="margin-left:auto">{nd}</span></a></div>')
    detail = (
        _dhero(tr("inbox.lead", "收件箱"), tr("inbox.sub", "需要你处理的事"),
               tr("inbox.summary_line", "{unread} 条未读 · {blocked} 个阻塞 · {doing} 个进行中").format(unread=unread, blocked=nb, doing=nd),
               f'<a class="dact" href="#mail">{tr("inbox.unread", "未读通知")}</a>'
               f'<a class="dact" href="#blocked">{tr("inbox.blocked", "阻塞任务")}</a>'
               f'<a class="dact" href="#doing">{tr("inbox.doing_short", "进行中")}</a>'
               + (f'<form method="post" action="/app/inbox/read" style="display:inline"><button class="dact primary" type="submit">{tr("inbox.all_read", "全部已读")}</button></form>' if unread else ''))
        + _dcard(tr("inbox.summary_title", "汇总"), '<div class="dstats">'
                 + _dstat(unread, tr("inbox.unread", "未读通知")) + _dstat(nb, tr("inbox.blocked", "阻塞任务"))
                 + _dstat(nd, tr("inbox.doing_review", "进行中 / 待评审")) + "</div>")
        + _dcard(tr("inbox.entries", "入口"), '<div class="dlist">'
                 f'<a class="dlink" href="#mail"><span class="dot on"></span><b>{tr("inbox.unread", "未读通知")}</b><span class="dim">{tr("inbox.process", "处理")}</span></a>'
                 f'<a class="dlink" href="#blocked"><span class="dot"></span><b>{tr("inbox.blocked", "阻塞任务")}</b><span class="dim">{tr("inbox.needs_human", "需要人")}</span></a>'
                 f'<a class="dlink" href="/app/board"><span class="dot"></span><b>{tr("inbox.board", "看板")}</b><span class="dim">{tr("inbox.all_tasks", "全部任务")}</span></a>'
                 "</div>")
    )
    return shell(tr("inbox.lead", "收件箱"), body, "inbox", tr("inbox.sub", "需要你处理的事"), side=side, page_css=PAGE_CSS["inbox"], detail=detail)


BOARD_STATUS = {
    "idea": ("待办", "todo"),
    "backlog": ("待办", "todo"),
    "claimed": ("进行中", "doing"),
    "in_progress": ("进行中", "doing"),
    "review": ("待评审", "review"),
    "blocked": ("阻塞", "blocked"),
    "done": ("完成", "done"),
    "cancelled": ("已放弃", "cancelled"),
}
BOARD_UPDATED = "coalesce(done_at, blocked_at, review_at, in_progress_at, claimed_at, created_at)"


def _board_url(agent: str, days: str, page: int = 1, task: str = "") -> str:
    q = {"agent": agent, "days": days, "page": str(max(1, page))}
    if task:
        q["task"] = task
    return "/app/board?" + urllib.parse.urlencode(q)


def page_board():
    c = db()
    loc = _locale()
    agent = (request.args.get("agent") or "all").strip()[:60]
    days = (request.args.get("days") or "90").strip()
    if days not in ("90", "365", "all"):
        days = "90"
    try:
        page = max(1, int(request.args.get("page") or 1))
    except ValueError:
        page = 1
    per = 20
    where = ["1=1"]
    args: list = []
    if agent and agent != "all":
        where.append("assigned_to=?")
        args.append(agent)
    if days != "all":
        cutoff = (datetime.datetime.now() - datetime.timedelta(days=int(days))).strftime("%Y-%m-%d %H:%M:%S")
        where.append(f"{BOARD_UPDATED}>=?")
        args.append(cutoff)
    wsql = " and ".join(where)
    total = c.execute(f"select count(*) n from tasks where {wsql}", args).fetchone()["n"]
    pages = max(1, (total + per - 1) // per)
    page = min(page, pages)
    rows = c.execute(
        f"""select id,title,status,assigned_to,created_at,{BOARD_UPDATED} updated_at,
                   description,acceptance_criteria
            from tasks where {wsql} order by {BOARD_UPDATED} desc, id desc limit ? offset ?""",
        (*args, per, (page - 1) * per)).fetchall()
    # P9.4：本地是看板唯一写入方；尽力推送中心只读快照。
    try:
        from core import center_sync
        center_sync.push_board(c.execute("""select id,title,status,assigned_to,created_at,updated_at
            from tasks order by updated_at desc limit 300""").fetchall())
    except Exception:
        pass
    names = {r["id"]: (r["name"] or r["id"]) for r in c.execute("select id,name from agents")}
    agents = c.execute("""select id,name from agents where kind='ai'
        and (id in (select distinct assigned_to from tasks where assigned_to is not null)
             or id in (select distinct created_by from tasks where created_by is not null))
        order by lower(name), id""").fetchall()
    counts = {k: 0 for k in BOARD_STATUS}
    for r in c.execute(f"select status,count(*) n from tasks where {wsql} group by status", args):
        counts[r["status"]] = r["n"]
    # agent 过滤条：按字母序，全部在最前
    chips = [f'<a class="bchip{" on" if agent == "all" else ""}" data-board-agent="all" '
             f'href="{_board_url("all", days)}">{tr("board.all", "全部")}</a>']
    for a in agents:
        chips.append(f'<a class="bchip{" on" if agent == a["id"] else ""}" data-board-agent="{esc(a["id"])}" '
                     f'href="{_board_url(a["id"], days)}">{esc(a["name"])}</a>')
    daylinks = "".join(
        f'<a class="bchip{" on" if days == d else ""}" href="{_board_url(agent, d)}">{label}</a>'
        for d, label in (("90", tr("board.filter_90", "最近 90 天")), ("365", tr("board.filter_year", "最近一年")), ("all", tr("board.filter_alltime", "全部时间"))))
    status_labels = {k: tr("board." + k, label) for k, (label, _) in BOARD_STATUS.items()}
    task_rows = []
    for t in rows:
        label, cls = BOARD_STATUS.get(t["status"], (t["status"], "todo"))
        label = status_labels.get(t["status"], label)
        task_rows.append(
            f'<a class="boardrow" href="{_board_url(agent, days, page, t["id"])}" data-task="{esc(t["id"])}">'
            f'<span class="btime mono">{esc(fmt_dt(t["updated_at"])[5:16])}</span>'
            f'<span class="bstate s-{cls}">{esc(label)}</span>'
            f'<span class="btitle">{esc(t["title"])}</span>'
            f'<span class="bwho">{esc("@" + (names.get(t["assigned_to"]) or tr("board.unassigned", "未指派")))}</span></a>')
    pager = ""
    if pages > 1:
        pager = (f'<div class="bpager"><a class="btn" href="{_board_url(agent, days, page - 1)}">{tr("board.prev", "上一页")}</a>'
                 f'<span class="dim">{tr("board.page", "第 {p} / {n} 页 · 共 {t} 条").format(p=page, n=pages, t=total)}</span>'
                 f'<a class="btn" href="{_board_url(agent, days, page + 1)}">{tr("board.next", "下一页")}</a></div>')
    body = f"""
  <div class="boardbar">
    <div class="bchips">{''.join(chips)}</div>
    <div class="bchips">{daylinks}</div>
  </div>
  <div class="boardlist">{''.join(task_rows) or '<div class="card dim" style="padding:18px">这个范围内没有任务。</div>'}</div>
  {pager}
  <details class="card boardadd">
    <summary>{tr("board.new_task", "＋ 新建任务")}</summary>
    <form class="row" method="post" action="/app/board/add">
      <input id="title" name="title" placeholder="要做什么？" required>
      <input id="assignee" name="assignee" placeholder="指派给（可选）">
      <button class="btn primary" type="submit">添加</button>
    </form>
  </details>
  <script>
  (function(){{
    var key="taa_board_agent", saved=null;
    try{{saved=localStorage.getItem(key);}}catch(e){{}}
    var u=new URLSearchParams(location.search);
    if(!u.get("agent") && !u.get("task") && saved){{
      location.replace("/app/board?agent="+encodeURIComponent(saved)+"&days="+encodeURIComponent(u.get("days")||"90"));
      return;
    }}
    document.addEventListener("click",function(e){{
      var a=e.target.closest("[data-board-agent]");
      if(a){{ try{{localStorage.setItem(key,a.dataset.boardAgent||"all");}}catch(e){{}} }}
    }});
  }})();
  </script>"""
    status_order = (tr("board.todo", "待办"), tr("board.doing", "进行中"), tr("board.review", "待评审"),
                    tr("board.blocked", "阻塞"), tr("board.done", "完成"), tr("board.cancelled", "已放弃"))
    status_counts = {label: 0 for label in status_order}
    for k, n in counts.items():
        label = BOARD_STATUS.get(k, (k,))[0]
        label = tr("board." + k, label)
        if label in status_counts:
            status_counts[label] += n
    side = f'<div class="sidebox"><div class="shead">{i18n.t("board.status", "STATUS", loc)}</div>' + "".join(
        f'<div class="citem"><span class="cname">{label}</span><span class="dim" style="margin-left:auto">{status_counts[label]}</span></div>'
        for label in status_order) + "</div>"
    task_id = (request.args.get("task") or "").strip()
    task = c.execute("select * from tasks where id=?", (task_id,)).fetchone() if task_id else None
    if task:
        label, cls = BOARD_STATUS.get(task["status"], (task["status"], "todo"))
        who = names.get(task["assigned_to"]) or "未指派"
        detail = (
            _dhero("任务", task["title"], f"{label} · @{who} · {fmt_dt(task['created_at'])}",
                   f'<a class="dact" href="{_board_url(agent, days, page)}">← 返回列表</a>')
            + _dcard("验收标准", f'<div class="dnote">{md_html(task["acceptance_criteria"] or "")}</div>')
            + _dcard("说明", f'<div class="dnote">{md_html(task["description"] or "")}</div>')
            + _dcard("元数据", f'<div class="dstats">{_dstat(label, "状态")}{_dstat("@" + who, "负责人")}'
                               f'{_dstat(fmt_dt(task["created_at"])[5:16], "创建")}</div>')
        )
    else:
        detail = (
            _dhero(tr("board.detail", "看板详情"), tr("board.detail_sub", "任务按最近更新时间倒序"),
                   f"{total} {tr('board.tasks', '条')} · {tr('board.current_label', '当前')} {agent if agent != 'all' else tr('board.all_agent', '全部 agent')} · {days if days != 'all' else tr('board.alltime', '全部时间')}",
                   f'<button class="dact primary" type="button" data-detail-focus="#title">{tr("board.new_btn", "新建任务")}</button>'
                   f'<a class="dact" href="/app/inbox">{tr("board.inbox", "去收件箱")}</a>')
            + _dcard(tr("board.dist", "状态分布"), '<div class="dstats">'
                     + _dstat(counts.get("backlog", 0) + counts.get("idea", 0), tr("board.todo", "待办"))
                     + _dstat(counts.get("in_progress", 0) + counts.get("claimed", 0), tr("board.doing", "进行中"))
                     + _dstat(counts.get("review", 0), tr("board.review", "待评审"))
                     + _dstat(counts.get("blocked", 0), tr("board.blocked", "阻塞"))
                     + _dstat(counts.get("done", 0), tr("board.done", "完成")) + "</div>")
            + _dcard(tr("post.note", "说明"), f'<p class="dnote">{tr("board.help", "点一条任务查看验收标准与说明；新建任务在列表底部。")}</p>')
        )
    return shell("看板", body, "board", "按 agent 查看任务时间线",
                 side=side, page_css=PAGE_CSS["board"], detail=detail)


def _agent_addons(agent_id: str, raw) -> list:
    """本地 add-ons：优先 addons/manifest.json，其次 addons/ 目录，最后 runtime JSON。"""
    base = ROOT / "agents" / agent_id / "addons"
    manifest = base / "manifest.json"
    try:
        if manifest.exists():
            data = json.loads(manifest.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        if base.is_dir():
            return [{"name": p.name, "type": "file", "enabled": True}
                    for p in sorted(base.iterdir()) if p.is_file()]
    except Exception:
        pass
    try:
        data = json.loads(raw or "[]")
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _taa_meta() -> dict:
    # dist/VERSION 是发行版的唯一版本源；根 VERSION 只做旧版兼容回退。
    _vp = ROOT / "dist" / "VERSION"
    if not _vp.exists():
        _vp = ROOT / "VERSION"
    version = _vp.read_text(encoding="utf-8").strip() if _vp.exists() else "—"
    try:
        commit = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                                         stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        commit = "—"
    try:
        schema = hashlib.sha256((ROOT / "core" / "schema.sql").read_bytes()).hexdigest()[:8]
    except OSError:
        schema = "—"
    selfcheck = "未运行审计"
    try:
        report = json.loads((ROOT / "static" / "alice_m0" / "ui_audit" / "report.json").read_text(encoding="utf-8"))
        failures = report.get("failures") if isinstance(report, dict) else None
        if isinstance(failures, list):
            selfcheck = "通过" if not failures else f"{len(failures)} 项失败"
    except Exception:
        pass
    return {"version": version, "commit": commit, "schema": schema, "selfcheck": selfcheck}


def _update_mode() -> str:
    try:
        from core import updates
        return str(updates.status().get("mode") or "download")
    except Exception:
        return "download"


def _update_panel(*, compact: bool = False) -> str:
    try:
        from core import updates
        st = updates.status()
    except Exception:
        return ""
    latest = st.get("latest") or ""
    current = st.get("current") or ""
    downloaded = st.get("downloaded") or ""
    downloaded_version = st.get("downloaded_version") or ""
    available = bool(st.get("available"))
    state = st.get("state") or "unchecked"
    mode = st.get("mode") or "download"
    err = st.get("last_error") or ""
    state_label = {
        "unchecked": "未检查",
        "current": "已是最新",
        "available": "可下载",
        "downloaded": "已下载",
        "applying": "安装中",
        "failed": "失败",
    }.get(state, state)
    newer_downloaded = bool(downloaded_version) and updates.version_gt(downloaded_version, current)
    can_check = state != "applying"
    can_download = available and not newer_downloaded and state not in ("applying", "downloaded")
    can_apply = bool(downloaded) and newer_downloaded and state != "applying"
    bits = [
        f'<div class="kv"><span>当前版本</span><b class="mono">{esc(current)}</b></div>',
        f'<div class="kv"><span>最新版本</span><b class="mono">{esc(latest or "未检查")}</b></div>',
        f'<div class="kv"><span>更新状态</span><b data-update-state="{esc(state)}">{esc(state_label)}</b></div>',
        f'<div class="kv"><span>更新模式</span><b>{esc(mode)}</b></div>',
        f'<div class="kv"><span>最近检查</span><b>{esc(st.get("last_check_at") or "—")}</b></div>',
    ]
    if state == "available":
        bits.append(f'<div class="notice">发现新版本 {esc(latest)}，可以下载。</div>')
    elif state == "downloaded":
        bits.append('<div class="notice">更新包已下载，可以安装并重启。</div>')
    elif state == "applying":
        bits.append('<div class="notice">更新进行中，页面可能短暂断开。</div>')
    elif state == "failed":
        bits.append(f'<div class="error">更新错误：{esc(err or "未知错误")}</div>')
    elif state == "current":
        bits.append('<div class="dim">当前已是最新版本。</div>')
    elif state == "unchecked":
        bits.append('<div class="dim">尚未检查更新。</div>')
    actions = (
        f'<form method="post" action="/app/update/check" style="display:inline">'
        f'<button class="btn update-check" type="submit"{" disabled" if not can_check else ""}>检查更新</button></form> '
        f'<form method="post" action="/app/update/download" style="display:inline">'
        f'<button class="btn update-download" type="submit"{" disabled" if not can_download else ""}>下载</button></form> '
        f'<form method="post" action="/app/update/apply" style="display:inline">'
        f'<button class="btn primary update-apply" type="submit"{" disabled" if not can_apply else ""}>安装并重启</button></form>'
    )
    if not compact:
        bits.append(f'<div class="update-actions">{actions}</div>')
    auto_refresh = ""
    if state in ("applying", "downloaded"):
        auto_refresh = """<script>
(function(){
  var tries=0;
  var timer=setInterval(function(){
    tries++;
    fetch('/v1/update/status',{cache:'no-store'}).then(function(r){return r.json();}).then(function(j){
      if(j && j.state==='current' && j.current){ clearInterval(timer); location.reload(); }
    }).catch(function(){ if(tries>60) clearInterval(timer); });
  },2000);
})();
</script>"""
    return ('<section class="card sec update-card" id="update" data-update-panel="1">'
            '<div class="kicker">TAA UPDATE</div><h2>软件更新</h2>' + "".join(bits) +
            '</section>' + auto_refresh)


def local_upload_stats() -> dict:
    base = ROOT / "static" / "uploads"
    count = 0
    size = 0
    try:
        for p in base.iterdir():
            if not p.is_file():
                continue
            count += 1
            try:
                size += p.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return {"files": count, "bytes": size, "mb": round(size / (1024 * 1024), 1)}


def attachment_storage_html() -> str:
    st = local_upload_stats()
    return (f'<div class="kv"><span>本地 uploads</span><b>{st["files"]} 个 / {st["mb"]} MB</b></div>'
            '<div class="kv"><span>中心 fallback</span><b>7 天自动过期；本地收到后立即下载</b></div>'
            '<p class="dnote" style="margin:6px 0 0">仅监控，不按张数或 MB 阻断。中心活跃用量可查 /v05/collab/storage。</p>')


def peer_rows_html(c) -> str:
    try:
        from core.peer_directory import status as _peer_status
        rows = _peer_status(c)
    except Exception:  # noqa: BLE001
        rows = []
    if not rows:
        return '<p class="dim" style="margin:6px 0 0">还没有远端节点目录；后台会从已批准好友同步。</p>'
    out = []
    for r in rows:
        selected = str(r.get("selected_url") or "")
        state = str(r.get("direct_status") or "unknown")
        latency = r.get("latency_ms")
        lat = f"{float(latency):.1f} ms" if latency is not None else "—"
        out.append(
            '<tr>'
            f'<td><b>{esc(r.get("owner_username") or r.get("owner_id") or "—")}</b>'
            f'<div class="mono dim">{esc(r.get("node_id") or "")}</div></td>'
            f'<td>{esc(r.get("alias") or "—")}<div class="mono dim">v{esc(r.get("version") or "—")}</div></td>'
            f'<td>{int(r.get("endpoint_count") or 0)}</td>'
            f'<td class="mono">{esc(selected or "未选中")}</td>'
            f'<td><span class="vbadge {("ok" if state == "direct" else "warn") if state in ("direct", "relay") else ""}">{esc(state)}</span></td>'
            f'<td>{esc(lat)}</td>'
            '</tr>')
    return ('<table class="vtable"><thead><tr><th>好友 / Node</th><th>别名 / 版本</th>'
            '<th>候选</th><th>选用地址</th><th>状态</th><th>延迟</th></tr></thead><tbody>'
            + "".join(out) + '</tbody></table>')
def page_version():
    c = db()
    loc = _locale()
    meta = _taa_meta()
    rows = c.execute("""select a.id,a.name,a.node_id,a.last_seen,a.status,
               r.runtime_version,r.code_hash,r.ide,r.backend,r.model,r.addons,r.last_seen runtime_seen
        from agents a join agent_runtime r on r.agent_id=a.id
        where a.kind='ai'
        order by lower(a.name), a.id""").fetchall()
    selected = (request.args.get("agent") or "").strip()
    sel = next((r for r in rows if r["id"] == selected), None)
    agents = []
    for r in rows:
        addons = _agent_addons(r["id"], r["addons"])
        av = str(r["runtime_version"] or "")
        cur = str(meta["version"] or "")
        if not av:
            compat, cls = tr("version.not_reported", "未上报"), "warn"
        elif av == cur:
            compat, cls = tr("version.compat", "兼容"), "ok"
        else:
            compat, cls = tr("version.pending", "待升级"), "warn" if av < cur else "bad"
        agents.append({"row": r, "addons": addons, "compat": compat, "cls": cls})
    flags = c.execute("select key,state,owner,note from feature_flags order by key").fetchall()
    frozen = c.execute("select * from frozen_features order by id").fetchall()
    proposals = c.execute("select * from improvement_proposals order by created_at desc limit 20").fetchall()
    releases = c.execute("select * from release_history order by created_at desc limit 10").fetchall()
    state_label = {"active": tr("version.state.active", "已启用"), "planned": tr("version.state.planned", "已排期"),
                   "frozen": tr("version.state.frozen", "冻结"), "hidden": tr("version.state.hidden", "隐藏"),
                   "disabled": tr("version.state.disabled", "停用")}
    top = f"""
  <div class="vtop">
    <div class="vcard"><div class="kicker">{tr("version.current", "TAA 运行时版本")}</div><div class="vbig">v{esc(meta['version'])}</div>
      <div class="vmeta"><span>commit <b>{esc(meta['commit'])}</b></span><span>schema <b>{esc(meta['schema'])}</b></span></div></div>
    <div class="vcard"><div class="kicker">{tr("version.selfcheck", "自检")}</div><div class="vbig">{esc(tr("version.pass", "通过") if meta['selfcheck'] == '通过' else meta['selfcheck'])}</div>
      <div class="vmeta"><span>{tr("version.agent_runtime_n", "{n} 个 agent 上报 runtime").format(n=len(rows))}</span><span>{tr("version.frozen_n", "{n} 项冻结").format(n=len(frozen))}</span></div></div>
    <div class="vcard"><div class="kicker">{tr("version.runtime", "Agent 运行时")}</div><div class="vbig">{len(agents)}</div>
      <div class="vmeta"><span>{tr("version.alphabetical", "按字母排序")}</span><span>{tr("version.agent_hint", "点 agent 查看 IDE / 版本 / add-ons")}</span></div></div>
  </div>"""
    agent_rows = []
    for a in agents:
        r = a["row"]
        agent_rows.append(
            f'<a class="vagent" href="/app/version?agent={quote(r["id"])}" style="text-decoration:none;color:inherit">'
            f'<span class="vname">{esc(r["name"])}</span>'
            f'<span class="vsub">{esc(r["ide"] or tr("version.local_runtime", "本地运行时"))} · {esc(r["node_id"] or "—")}</span>'
            f'<span class="vsub">v{esc(r["runtime_version"] or "—")} · {esc(r["backend"] or "—")}'
            f' · code {esc(r["code_hash"] or "未上报")}</span>'
            f'<span class="vbadge {a["cls"]}">{esc(a["compat"])}</span></a>')
    owner_label = {"产品": tr("version.owner.product", "产品"), "治理": tr("version.owner.governance", "治理"),
                   "内容": tr("version.owner.content", "内容"), "迁移": tr("version.owner.migration", "迁移"),
                   "团队": tr("version.owner.team", "团队"), "研究": tr("version.owner.research", "研究")}
    cap_rows = "".join(
        f'<tr><td><b>{esc(f["key"])}</b></td><td><span class="vbadge">{esc(state_label.get(f["state"], f["state"]))}</span></td>'
        f'<td>{esc(owner_label.get(f["owner"], f["owner"]) or "—")}</td><td>{esc(f["note"] or "")}</td></tr>' for f in flags)
    frozen_rows = "".join(
        f'<div class="vfrozen"><b>{esc(f["id"])} · {esc(f["title"])}</b>'
        f'<span>{esc(f["reason"] or "")}</span>'
        f'<div class="vmeta"><span>{tr("version.retain", "保留：{x}").format(x=esc(f["kept"] or "—"))}</span>'
        f'<span>{tr("version.trigger", "触发：{x}").format(x=esc(f["trigger"] or "—"))}</span>'
        f'<span>{tr("version.review", "复核：{x}").format(x=esc(f["review_at"] or "—"))}</span></div></div>' for f in frozen)
    pstate = {"proposed": tr("version.pstate.proposed", "提案"), "testing": tr("version.pstate.testing", "测试中"),
              "approved": tr("version.pstate.approved", "已批准"), "released": tr("version.pstate.released", "已发布"),
              "rolled_back": tr("version.pstate.rolled_back", "已回滚"), "rejected": tr("version.pstate.rejected", "已拒绝")}
    proposal_rows = "".join(
        f'<div class="vfrozen"><b>{esc(p["id"])} · {esc(p["title"])}</b>'
        f'<div class="vmeta"><span>{esc(pstate.get(p["status"], p["status"]))}</span>'
        f'<span>{tr("version.source", "来源：{x}").format(x=esc(p["source"] or "—"))}</span><span>{esc(p["created_at"])}</span></div>'
        f'<div class="dnote" style="margin-top:4px">{esc(p["change"] or "")}</div></div>' for p in proposals)
    release_rows = "".join(
        f'<tr><td>{esc(r["version"])}</td><td class="mono">{esc(r["commit_hash"] or "—")}</td>'
        f'<td>{esc(r["status"])}</td><td>{esc(r["summary"] or "")}</td><td>{esc(r["created_at"])}</td></tr>'
        for r in releases)
    body = f"""
  {top}
  {_update_panel()}
  <section class="card" id="peers" style="padding:16px 18px;margin-bottom:12px">
    <div class="kicker">直连节点 · peer directory</div>
    {peer_rows_html(c)}
  </section>
  <section class="card" id="storage" style="padding:16px 18px;margin-bottom:12px">
    <div class="kicker">附件存储 · 7 天中心保留</div>
    {attachment_storage_html()}
  </section>
  <section class="card" style="padding:16px 18px;margin-bottom:12px">
    <div class="kicker">{i18n.t("version.agent", "Agent 版本矩阵", loc)}</div>
    <div style="margin-top:6px">{''.join(agent_rows) or '<p class="dim">还没有 agent runtime 记录。</p>'}</div>
  </section>
  <section class="card" style="padding:16px 18px;margin-bottom:12px">
    <div class="kicker">{i18n.t("version.cap", "能力清单", loc)}</div>
    <div class="vcap" style="margin-top:8px"></div>
    <table class="vtable"><thead><tr><th>{tr("version.cap", "能力")}</th><th>{tr("version.status", "状态")}</th><th>{tr("version.owner", "负责人")}</th><th>{tr("version.note", "说明")}</th></tr></thead>
      <tbody>{cap_rows}</tbody></table>
  </section>
  <section class="card" style="padding:16px 18px">
    <div class="kicker">{i18n.t("version.frozen", "冻结 Todo · 不是删除", loc)}</div>
    <p class="dim" style="margin:6px 0 10px">{tr("version.frozen_keep", "保留数据/API；满足触发条件后按验收标准恢复。")}</p>
    {frozen_rows}
  </section>
  <section class="card" id="proposals" style="padding:16px 18px;margin-top:12px">
    <div class="kicker">{i18n.t("version.proposals", "演化提案 · RSI", loc)}</div>
    <p class="dim" style="margin:6px 0 10px">{tr("version.proposal_note", "只记录可追的改进：问题 → 改动 → 测试 → 风险；不直接改生产。")}</p>
    {proposal_rows or f'<p class="dnote">{tr("version.no_props", "还没有提案。")}</p>'}
    <details class="usage-est" style="margin-top:10px"><summary>{tr("version.new_prop", "＋ 新建改进提案")}</summary>
      <form method="post" action="/app/version/proposal" style="display:grid;gap:8px;margin-top:8px">
        <input name="title" placeholder="{tr("version.ph_title", "提案标题")}" required>
        <input name="source" placeholder="{tr("version.ph_source", "来源：对话/失败/任务号")}">
        <textarea name="problem" rows="2" placeholder="{tr("version.ph_problem", "问题是什么？")}"></textarea>
        <textarea name="change" rows="2" placeholder="{tr("version.ph_change", "准备改什么？")}"></textarea>
        <textarea name="test" rows="2" placeholder="{tr("version.ph_test", "如何验证？")}"></textarea>
        <input name="risk" placeholder="{tr("version.ph_risk", "风险与回滚点")}">
        <button class="btn primary" type="submit">{tr("version.record_prop", "记录提案")}</button>
      </form>
    </details>
  </section>
  <section class="card" id="releases" style="padding:16px 18px;margin-top:12px">
    <div class="kicker">{i18n.t("version.releases", "发布与回滚记录", loc)}</div>
    <table class="vtable"><thead><tr><th>{tr("version.version", "版本")}</th><th>commit</th><th>{tr("version.status", "状态")}</th><th>{tr("version.note", "说明")}</th><th>{tr("version.time", "时间")}</th></tr></thead>
      <tbody>{release_rows or f'<tr><td colspan="5" class="dim">{tr("version.no_releases", "还没有发布记录。")}</td></tr>'}</tbody></table>
  </section>"""
    side = ('<div class="sidebox"><div class="shead">VERSIONS</div>'
            f'<a class="citem{" on" if not sel else ""}" href="/app/version"><span class="cname">TAA v{esc(meta["version"])}</span>'
            f'<span class="dim" style="margin-left:auto">{esc(meta["commit"])}</span></a>'
            + "".join(f'<a class="citem{" on" if sel and sel["id"] == a["row"]["id"] else ""}" href="/app/version?agent={quote(a["row"]["id"])}">'
                      f'<span class="cname">{esc(a["row"]["name"])}</span>'
                      f'<span class="dim" style="margin-left:auto">{esc(a["row"]["runtime_version"] or "—")}</span></a>'
                      for a in agents)
            + '</div>')
    if sel:
        a = next(x for x in agents if x["row"]["id"] == sel["id"])
        r = a["row"]
        addons = a["addons"]
        add_html = "".join(f'<div class="vfrozen"><b>{esc(x.get("name") if isinstance(x, dict) else str(x))}</b>'
                           f'<span>{esc(x.get("type") if isinstance(x, dict) else "addon")}</span></div>' for x in addons)
        if not add_html:
            add_html = f'<p class="dnote">{tr("version.no_addons", "未登记 add-ons。约定放在 agents/&lt;id&gt;/addons，后续可登记 manifest。")}</p>'
        detail = (_dhero(tr("version.agent_title", "Agent 版本"), r["name"], f"{r['ide'] or tr('version.no_ide', '未登记 IDE')} · {r['node_id'] or '—'}",
                         f'<a class="dact primary" href="/app/chats?agent={quote(r["id"])}">{tr("version.go_dm", "去私聊")}</a>'
                         f'<a class="dact" href="/app/moments">{tr("version.moments", "公开朋友圈")}</a>')
                  + _dcard(tr("version.runtime_card", "运行时"), f'<div class="dstats">{_dstat(f"v{esc(r["runtime_version"] or "—")}", "TAA")}'
                                     f'{_dstat(esc(r["backend"] or "—"), "backend")}'
                                     f'{_dstat(esc(r["model"] or "—"), "model")}'
                                     f'{_dstat(esc(r["code_hash"] or "未上报"), "code hash")}</div>')
                  + _dcard(tr("version.addons", "add-ons"), add_html)
                  + _dcard(tr("post.note", "说明"), f'<p class="dnote">{tr("version.detail_note", "这里只显示运行时与公开资产元数据，不展示私密人设/body/wardrobe。")}</p>'))
    else:
        detail = (_dhero(tr("version.title", "版本迭代"), tr("version.subtitle", "TAA 与每个 agent 的运行时"),
                         tr("version.current_line", "运行时 v{version} · commit {commit}").format(version=meta['version'], commit=meta['commit']),
                         f'<a class="dact" href="/app/version">{tr("version.refresh", "刷新")}</a>'
                         f'<a class="dact" href="/app/moments">{tr("version.moments", "公开朋友圈")}</a>')
                  + _dcard(tr("version.how", "怎么读"), f'<p class="dnote">{tr("version.how_note", "点左侧 agent 查看 IDE、TAA 版本、backend/model 与 add-ons。人设参数不在这里展示；成长只看每日朋友圈。")}</p>')
                  + _dcard(tr("version.frozen_title", "冻结"), f'<p class="dnote">{tr("version.frozen_count", "共 {n} 项，保留 API/数据，不删除。").format(n=len(frozen))}</p>'))
    return shell(tr("version.title", "版本迭代"), body, "version", tr("version.shell_sub", "TAA 与 agent 的版本、运行时与冻结项"),
                 side=side, page_css=PAGE_CSS["version"], detail=detail)


def _center_base() -> str:
    try:
        from core import center_sync
        return center_sync.center_base().rstrip("/")
    except Exception:  # noqa: BLE001
        return "https://alice.loomsci.com"


def repair_agent_owners(c) -> None:
    """Fill owner attribution for local and remote identities."""
    owner_id = _center_owner_id()
    owner_name = owner_display_name(c)
    try:
        st = center_state()
        local_ids = [a.agent_id for a in (st.agents if st else [])]
    except Exception:  # noqa: BLE001
        local_ids = []
    try:
        ensure_agent_owner_columns(c)
        if owner_id:
            for aid in local_ids:
                c.execute("update agents set owner_id=?, owner_name=? where id=? and kind='ai'",
                          (owner_id, owner_name, aid))
            c.execute("update agents set owner_id=?, owner_name=? where id='human' and kind='human'",
                      (owner_id, owner_name))
        for r in c.execute("select id,name from agents where id like 'remote-human-%' and kind='human'"):
            oid = str(r["id"])[len("remote-human-"):]
            c.execute("update agents set owner_id=?, owner_name=? where id=?", (oid, r["name"], r["id"]))
        c.commit()
    except Exception as e:  # noqa: BLE001
        print(f"[app_ui] owner repair skipped: {e}")


def page_team():
    c = db()
    try:
        _rw = rw()
        try:
            repair_agent_owners(_rw)
        finally:
            _rw.close()
    except Exception:  # noqa: BLE001
        pass
    center = _center_base()
    rows = list(c.execute("select id,name,full_name,role,status,last_seen,kind,persona_json,owner_id,owner_name "
                          "from agents where id not in ('agent','codebuddy')").fetchall())
    # Owners first; local owner before remote owners; agents after.
    rows.sort(key=lambda m: (0 if m["kind"] == "human" else 1,
                             0 if m["id"] == "human" else 1,
                             str(m["name"] or m["id"]).lower()))
    local_owner_name = owner_display_name(c)
    def team_label(m):
        from core import presence as _presence
        if m["kind"] == "human":
            name = local_owner_name if m["id"] == "human" else (m["name"] or m["id"])
            state = _presence.label(c, str(m["owner_id"] or m["id"]), "owner")
            return name, name, f"owner · {state}"
        owner = m["owner_name"] or ""
        # Agent names are globally unique, so the old name+owner handle is no
        # longer needed. Keep owner only as a human-readable role subtitle.
        handle = str(m["name"] or m["id"])
        state = _presence.label(c, str(m["id"]), "agent")
        return str(m["name"] or m["id"]), handle, (
            f"agent · owner {owner} · {state}" if owner else f"agent · {state}")

    vmap = {r["agent_id"]: r["runtime_version"] for r in c.execute(
        "select agent_id, runtime_version from agent_runtime").fetchall()}
    try:
        taa_ver = json.loads((ROOT / "dist" / "manifest.json").read_text(encoding="utf-8")).get("version") or ""
    except Exception:  # noqa: BLE001
        taa_ver = ""
    def _member_card(m):
        display, handle, role_label = team_label(m)
        return f"""<article class="member card">
      <div class="ava">{avatar(display, 56)}</div>
      <div class="who"><h3>{esc(display)}</h3>
        <div class="role">{esc(role_label)}</div>
        <div class="addr mono">{esc(handle)}</div>
      </div>
      <div class="intro"><p>{esc(persona_text(m["persona_json"]) or (m["full_name"] or ""))}</p></div>
      <div class="skills"><span class="tag">{esc(m["status"])}</span>{f'<span class="tag">runtime {esc(vmap.get(m["id"]) or "—")}</span>' if m["kind"] == "ai" else ''}{f'<span class="tag">TAA {esc(taa_ver)}</span>' if taa_ver and m["kind"] == "ai" else ''}<span class="tag">{tr("team.last_online", "最后在线")} {esc(fmt_dt(m["last_seen"]) or "never")}</span></div>
      <div class="cacts">{f'<a class="btn" href="/app/chats?agent={esc(m["id"])}">{tr("mobile.leave_note", "留言")}</a>' if m["kind"] == "ai" else ''}<button class="btn" type="button" data-copy="@{esc(handle)}">{tr("mobile.copy_handle", "复制 @")}</button><button class="btn" type="button" data-copy="{esc(display)} (@{esc(handle)}) · {esc(role_label)} · Team AI">{tr("mobile.copy_card", "复制名片")}</button></div>
    </article>"""
    cards = "".join(_member_card(m) for m in rows)
    body = f"""
  <div class="card" style="padding:16px 18px;margin-bottom:12px">
    <div class="dim">{tr("team.manage_center_hint", "创建、邀请与管理 Key 在中心完成；本地负责展示、私聊与执行。")}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      <a class="btn primary" href="{esc(center)}/team" target="_blank" rel="noopener">{tr("team.new_agent_center", "新建 agent · 去中心")} →</a>
      <a class="btn" href="{esc(center)}/invite" target="_blank" rel="noopener">{tr("team.invite_center", "邀请好友 · 去中心")}</a>
      <a class="btn" href="{esc(center)}/settings" target="_blank" rel="noopener">{tr("team.keys_center", "Key 管理 · 去中心")}</a>
    </div>
  </div>
  <div class="rule"></div>
  <section><div class="sechead"><h2>{tr("team.members", "成员")}</h2></div><div class="grid">{cards}</div></section>"""
    side = '<div class="sidebox"><div class="shead">MEMBERS</div>' + "".join(
        f'<div class="citem"><span class="dot" style="width:7px;height:7px;border-radius:50%;background:'
        f'{color_for(m["name"])};flex:0 0 auto"></span><span class="cname">{esc(team_label(m)[1])}</span></div>'
        for m in rows) + "</div>"
    humans = sum(1 for m in rows if m["kind"] == "human")
    mlist = []
    for m in rows[:14]:
        display, handle, role = team_label(m)
        inner = (f'{avatar(display, 28)}'
                 f'<span class="dwho"><b>{esc(display)}</b><span>{esc(handle)} · {esc(role)}</span></span>'
                 f'<span class="dpresence {"online" if m["status"] != "paused" else ""}"><i></i>{esc(m["status"] or "unknown")}</span>')
        if m["kind"] == "ai":
            mlist.append(f'<a class="dperson" href="/app/chats?agent={esc(m["id"])}" title="{tr("team.chat_with", "和 {name} 私聊").format(name=esc(m["name"]))}">{inner}</a>')
        else:
            mlist.append(f'<div class="dperson">{inner}</div>')
    ai_count = len(rows) - humans
    hlabel = tr("team.human_one", "真人") if humans == 1 else tr("team.human_many", "真人")
    alabel = tr("team.agent_one", "agent") if ai_count == 1 else tr("team.agent_many", "agent")
    line = tr("team.members_line", "{n} 名成员 · {h} {hl} · {a} {al}").format(
        n=len(rows), h=humans, a=ai_count, hl=hlabel, al=alabel)
    detail = (
        _dhero(tr("team.detail", "团队详情"), team_name(), line,
               f'<a class="dact primary" href="/app/team">{tr("team.refresh", "刷新成员")}</a>'
               f'<a class="dact" href="/app/chats">{tr("team.chats", "去会话")}</a>')
        + _dcard(tr("home.overview", "概览"), '<div class="dstats">'
                 + _dstat(len(rows), tr("team.total", "成员总数")) + _dstat(humans, tr("team.human", "真人"))
                 + _dstat(len(rows) - humans, "agent") + "</div>")
        + _dcard(tr("team.members_n", "成员 · {n}").format(n=len(rows)), f'<div class="dpeople">{"".join(mlist)}</div>'
                 + (f'<p class="dnote" style="margin-top:8px">另有 {len(rows) - 14} 位成员，见主区。</p>' if len(rows) > 14 else ""))
        + _dcard(tr("chat.manage", "管理"), f'<p class="dnote">{tr("team.manage_center_hint", "创建、邀请与管理 Key 在中心完成；本地负责展示、私聊与执行。")}</p>'
                 + f'<a class="btn" style="margin-top:10px" href="/app/host">{tr("team.host_client", "Host / Client")} →</a>'
                 + f'<a class="btn" style="margin-top:10px;margin-left:8px" href="{esc(center)}/team" target="_blank" rel="noopener">{tr("team.new_agent_center", "新建 agent · 去中心")} →</a>')
    )
    return shell(team_name(), body, "team", line,
                 side=side, page_css=PAGE_CSS["team"], detail=detail)


_USAGE_CACHE = {"at": 0.0, "day": "", "snap": None}


def _settings_side(active: str = "") -> str:
    items = [
        ("account", "账号", "/app/settings#account"),
        ("profile", "公开主页", "/app/settings/profile"),
        ("models", "团队模型 KEY", "/app/settings#models"),
        ("usage", "用量与积分", "/app/settings#usage"),
        ("ui", "界面", "/app/settings#ui"),
    ]
    links = "".join(
        f'<a class="citem{" on" if active == key else ""}" href="{href}">'
        f'<span class="cname">{tr("settings." + key, label)}</span></a>'
        for key, label, href in items)
    links += f'<a class="citem" href="/app/settings"><span class="cname">{tr("settings.back", "回设置")} →</span></a>'
    return f'<div class="sidebox"><div class="shead">SETTINGS</div>{links}</div>'


def _owner_profile_state():
    from pathlib import Path
    from taa_node_v05.identity import load_state
    from taa_node_v05.center import CenterClient
    home = Path(os.environ.get("TAA_HOME") or ROOT.parent).expanduser()
    state = load_state(home)
    if not state.center.base or not state.center.owner_id:
        raise RuntimeError("本机还没有绑定中心 Owner")
    client = CenterClient(state.center.base)
    data = client.owner_profile(node_key=state.node.node_key)
    return state, client, data.get("profile") or {}


def page_owner_profile(notice: str = "", error: str = "", values: dict | None = None) -> str:
    loc = _locale()
    try:
        state, client, profile = _owner_profile_state()
    except Exception as exc:  # noqa: BLE001
        state, client, profile = None, None, {}
        error = error or str(exc)
    if values:
        profile = {**profile, **values}
    base = (getattr(getattr(state, "center", None), "base", "") or _center_base()).rstrip("/")
    username = str(getattr(getattr(state, "center", None), "username", "") or "")
    public_id = str(profile.get("public_id") or profile.get("username") or username or "")
    alias = str(profile.get("display_alias") or profile.get("username") or username or "")
    bio = str(profile.get("bio") or "")
    home = str(profile.get("home_location") or "")
    raw_visible = profile.get("location_visible", True)
    visible = str(raw_visible).lower() not in ("0", "false", "no", "")
    public_url = f"{base}/u/{quote(public_id, safe='')}" if public_id else ""
    from core import owner_location
    weather_city = owner_location.load_weather_city() or owner_location.normalize_city(home)
    weather_info = owner_location.load_info()
    weather_source = str(weather_info.get("source") or "manual")
    weather_source_label = {
        "cloudflare": "网络位置",
        "manual": "手动",
        "persona": "agent 默认",
    }.get(weather_source, weather_source)
    notice = notice or (request.args.get("ok") == "1" and "公开主页已更新" or "")
    if not notice and request.args.get("located") == "1":
        notice = f"已使用网络位置：{weather_city or '城市'}"
    qr_json = json.dumps(public_url, ensure_ascii=False)
    form = f"""
  <section class="card sec profile-card">
    <div class="kicker">OWNER PROFILE · PUBLIC</div>
    <h2 style="margin:6px 0 8px">{tr("profile.title", "公开主页")}</h2>
    <p class="dim" style="margin:0 0 12px">{tr("profile.lead", "编辑后会立即出现在你的公开主页；本机不保存 TAA 账号密码。")}</p>
    <div class="kv"><span>{tr("profile.public_id", "公开 ID")}</span><b class="mono">@{esc(public_id or "—")}</b></div>
    <div class="kv"><span>{tr("profile.public_url", "公开地址")}</span><b><a href="{esc(public_url)}" target="_blank" rel="noopener">{esc(public_url or "—")}</a></b></div>
    <div class="profile-qr-wrap"><div class="profile-qr" id="profile-qr" data-url="{esc(public_url)}"></div>
      <p class="dim">{tr("profile.qr_hint", "二维码只编码公开主页 URL，不含密码或 key。")}</p></div>
  </section>
  <section class="card sec profile-card">
    <form method="post" action="/app/settings/profile" class="profile-form">
      <label>{tr("profile.alias", "公开显示名 / 别名")}
        <input name="display_alias" value="{esc(alias)}" maxlength="40">
      </label>
      <p class="hint">{tr("profile.alias_hint", "可重复、可随时改；不是登录凭据。")}</p>
      <label>{tr("profile.bio", "简介")}
        <textarea name="bio" id="bio" maxlength="500" rows="7">{esc(bio)}</textarea>
      </label>
      <p class="hint">{tr("profile.bio_hint", "最多 500 字符；支持基础 Markdown、$...$ 和 $$...$$ LaTeX；不支持原始 HTML。")}</p>
      <p class="hint"><span id="bio-count">{len(bio)}</span>/500</p>
      <label>{tr("profile.home", "常居地")}</label>
      <div class="profile-loc">
        <input name="home_location" value="{esc(home)}" maxlength="40" placeholder="{tr("profile.home_ph", "例如：成都")}">
        <button class="btn" id="locate-btn" type="submit" formaction="/app/settings/profile/locate" formnovalidate>{tr("profile.locate", "使用网络位置")}</button>
      </div>
      <p class="hint" id="locate-status" role="status" aria-live="polite"></p>
      <p class="hint">{tr("profile.home_hint", "公开显示可自由填写；天气只使用城市级地点。")}</p>
      <p class="hint">{tr("profile.weather_city", "天气查询城市：{city}").format(city=esc(weather_city or "未确定"))}
        <span class="tag">{esc(weather_source_label)}</span></p>
      <label class="checkline"><input type="checkbox" name="location_visible" value="1" {'checked' if visible else ''}>
        {tr("profile.show_home", "在公开主页显示常居地")}</label>
      <div class="profile-actions">
        <button class="btn primary" type="submit">{tr("profile.save", "保存公开主页")}</button>
        <a class="btn" href="/app/settings">{tr("profile.back", "回设置")}</a>
        {f'<a class="btn" href="{esc(public_url)}" target="_blank" rel="noopener">打开公开页 ↗</a>' if public_url else ''}
      </div>
    </form>
  </section>"""
    detail = (
        _dhero(tr("profile.detail", "公开主页"), tr("profile.detail_sub", "Owner 公开资料"),
               tr("profile.detail_lead", "只公开显示名、简介、常居地与公开 ID。")) +
        _dcard(tr("profile.scope", "公开范围"), f'<p class="dnote">{tr("profile.scope_note", "公开：显示名、public ID、简介、可选常居地。不会公开：密码、agent key、私密人格维度。")}</p>') +
        _dcard(tr("profile.rules", "编辑规则"), f'<p class="dnote">{tr("profile.rules_note", "简介最多 500 字符，支持基础 Markdown 与 LaTeX；二维码只编码 /u/<public_id>。")}</p>')
    )
    body = f"""
  {(f'<div class="notice">{esc(notice)}</div>' if notice else '')}
  {(f'<div class="error">{esc(error)}</div>' if error else '')}
  {form}
  <style>
  .profile-card{{margin-bottom:12px}}
  .profile-qr-wrap{{display:flex;align-items:center;gap:16px;margin-top:14px;flex-wrap:wrap}}
  .profile-qr{{width:180px;height:180px;background:var(--porcelain);border:1px solid var(--hair);border-radius:14px;padding:10px}}
  .profile-qr img,.profile-qr canvas{{width:160px!important;height:160px!important;display:block}}
  .profile-form label{{display:block;margin:14px 0 6px;font-weight:600}}
  .profile-form input[type="text"],.profile-form input:not([type]),.profile-form textarea{{width:100%;max-width:720px}}
  .profile-form .checkline{{display:flex;align-items:center;gap:8px;font-weight:400}}
  .profile-form .checkline input{{width:auto}}
  .profile-loc{{display:flex;gap:8px;align-items:center;flex-wrap:wrap;max-width:720px}}
  .profile-loc input{{flex:1 1 220px;min-width:0;max-width:420px}}
  .profile-loc .btn{{flex:0 0 auto;white-space:nowrap}}
  .profile-form .hint{{margin:0 0 8px}}
  .profile-actions{{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}}
  @media(max-width:640px){{.profile-form input[type="text"],.profile-form input:not([type]),.profile-form textarea{{max-width:none}}}}
  </style>
  <script>
  document.addEventListener("DOMContentLoaded", function(){{
    var locate=document.getElementById("locate-btn");
    if(locate && locate.form){{
      locate.form.addEventListener("submit", function(e){{
        if(e.submitter !== locate) return;
        locate.setAttribute("aria-busy","true");
        locate.textContent="正在获取网络位置…";
        var status=document.getElementById("locate-status");
        if(status) status.textContent="正在读取 Cloudflare 城市，请稍候…";
      }});
    }}
    var el=document.getElementById("profile-qr");
    if(el && window.QRCode && el.dataset.url) {{
      try {{ new QRCode(el,{{text:el.dataset.url,width:160,height:160,correctLevel:QRCode.CorrectLevel.M}}); }} catch(e) {{}}
    }}
    var b=document.getElementById("bio"), c=document.getElementById("bio-count");
    if(b&&c){{ var n=function(){{c.textContent=Array.from(b.value).length;}}; b.addEventListener("input",n); n(); }}
  }});
  </script>"""
    return shell(tr("profile.title", "公开主页"), body, "settings",
                 tr("profile.subtitle", "Owner 公开资料与二维码"),
                 side=_settings_side("profile"), page_css=PAGE_CSS["settings"], detail=detail)


def _client_redirect():
    """A Client's local web entry always hands the browser to its Host."""
    try:
        from core import host_mode
        if host_mode.is_client():
            url = host_mode.client_url()
            if url:
                return redirect(url)
    except Exception:  # noqa: BLE001
        pass
    return None


def page_host_mode():
    """Local Host / Client status and setup page."""
    from core import host_mode
    data = host_mode.load()
    role = data.get("role") or "host"
    host = host_mode.host_url()
    invite = ""
    invite = request.args.get("invite") or ""
    current = "Client" if role == "client" else "Host"
    display_host = host
    if not display_host and role == "host":
        try:
            display_host = share_base()
        except Exception:  # noqa: BLE001
            display_host = ""
    link = host_mode.client_url()
    body = f"""
  <section class="card sec">
    <div class="kicker">Host / Client</div>
    <h3 style="margin:4px 0 8px">当前角色：{esc(current)}</h3>
    <div class="kv"><span>本机</span><b>{esc(owner_display_name())}</b></div>
    <div class="kv"><span>Host 地址</span><b class="mono">{esc(display_host or "本机（Host）")}</b></div>
    <div class="kv"><span>Client 入口</span><b>{f'<a href="{esc(link)}">{esc(link)}</a>' if link else '未配置'}</b></div>
    <p class="dim">Host 负责群聊权威状态；Client 只需要出站访问 Host，不开放自己的 peer 端口。Client 的 Agent 仍然使用本机身份和密钥。</p>
  </section>
  <section class="card sec">
    <div class="kicker">Host</div>
    <p class="dim">写入口必须带身份：填写 Client 的 Owner 名称生成。下面空白说明还没有生成身份邀请，不要再发旧的通用写链接。</p>
    <textarea id="invite" readonly rows="3" placeholder="先生成带身份的邀请链接" style="width:100%;box-sizing:border-box;font:12px var(--mono);">{esc(invite)}</textarea>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
      <button class="btn" type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('invite').value)">复制邀请链接</button>
      <a class="btn" href="/app/host?refresh=1">刷新</a>
    </div>
    <form method="post" action="/app/host/invite" style="display:grid;grid-template-columns:1fr 1fr auto;gap:8px;margin-top:12px;align-items:end">
      <label>Client 名称<input name="client_name" placeholder="delta" value="delta" style="width:100%;box-sizing:border-box;margin-top:4px"></label>
      <label>Owner ID（可选）<input name="owner_id" placeholder="own_..." style="width:100%;box-sizing:border-box;margin-top:4px"></label>
      <button class="btn" type="submit">生成带身份的邀请</button>
    </form>
  </section>
  <section class="card sec">
    <div class="kicker">切换到 Client</div>
    <form method="post" action="/app/host" style="display:grid;gap:8px;max-width:720px">
      <input type="hidden" name="role" value="client">
      <label>Host 邀请链接或地址
        <input name="invite" placeholder="http://host:6080/app/s/..." style="width:100%;box-sizing:border-box;margin-top:4px">
      </label>
      <div><button class="btn primary" type="submit">保存并打开 Host</button></div>
    </form>
  </section>
  <section class="card sec">
    <div class="kicker">回到 Host</div>
    <form method="post" action="/app/host">
      <input type="hidden" name="role" value="host">
      <button class="btn" type="submit">把本机设为 Host</button>
    </form>
  </section>"""
    side = (
        '<div class="sidebox"><div class="shead">HOST / CLIENT</div>'
        f'<a class="citem on" href="/app/host"><span class="cname">{tr("host.current", "当前角色")}</span></a>'
        f'<a class="citem" href="/app/team"><span class="cname">{tr("host.team", "团队与归属")}</span></a>'
        f'<a class="citem" href="/app/chats"><span class="cname">{tr("host.chats", "会话")}</span></a>'
        '</div>')
    detail = (
        _dhero(tr("host.title", "Host / Client"), tr("host.detail", "单 Host + Client"),
               tr("host.detail_sub", "Host 负责群聊权威状态；Client 只出站访问 Host。"),
               f'<a class="dact primary" href="/app/team">{tr("host.team", "团队与归属")} →</a>')
        + _dcard(tr("host.notes", "说明"),
                 f'<p class="dnote">{tr("host.note_body", "邀请链接是 7 天可写的 Host 入口，只发给可信 Client。Client 不需要开放 peer 端口。")}</p>')
    )
    return Response(shell(tr("host.title", "Host / Client"), body, "team",
                          tr("host.subtitle", "单 Host + Client 本地入口"),
                          side=side, detail=detail), mimetype="text/html")


def page_settings():
    c = db()
    loc = _locale()
    center = _center_base()
    from core.config import alibaba_key, deepseek_key, volcano_key
    from core import usage as usage_mod
    try:
        from core import executor_bridge
        eh = executor_bridge.health()
    except Exception:
        eh = {"ok": False, "cli": "未找到", "workers": 0, "running": 0}
    ds, ali, volc = deepseek_key(), alibaba_key(), volcano_key()
    def _key_status(k):
        if not k:
            return tr("settings.unset", "未设置")
        if len(k) >= 10:
            return tr("settings.masked", "已设置 · {mask}").format(mask=f"{k[:4]}…{k[-4:]}")
        return tr("settings.set", "已设置")
    has_key = bool(ds or ali or volc)
    tname = team_name()
    try:
        from core import nodeinfo
        lan_ip = nodeinfo.lan_ip() or "127.0.0.1"
    except Exception:  # noqa: BLE001
        lan_ip = "127.0.0.1"
    mdns = socket.gethostname()
    # P4：LAN 默认走 TLS 旁路（6443）；回环 6080 仍供本机 agent 使用。
    tls_port = int(os.environ.get("TEAM_TLS_PORT") or 6443)
    tls_ready = (os.environ.get("TEAM_TLS", "1") != "0"
                 and (ROOT / "certs/server.crt").exists()
                 and (ROOT / "certs/server.key").exists())
    lan_scheme, lan_port = ("https", tls_port) if tls_ready else ("http", 6080)
    lan_url = f"{lan_scheme}://{lan_ip}:{lan_port}/app"
    mdns_url = f"{lan_scheme}://{mdns}:{lan_port}/app"
    # 今日用量（估算；不调用模型）
    tok = {"input": 0, "output": 0, "reasoning": 0, "cache_read": 0, "cache_write": 0}
    usd = 0.0
    sessions = 0
    models: list[tuple[str, dict]] = []
    day = datetime.date.today().isoformat()
    try:
        today_s = datetime.date.today().isoformat()
        if _USAGE_CACHE["day"] == today_s and time.time() - _USAGE_CACHE["at"] < 300:
            snap = _USAGE_CACHE["snap"]
        else:
            snap = usage_mod.summary(1)
            _USAGE_CACHE.update({"at": time.time(), "day": today_s, "snap": snap})
        day = sorted(snap)[-1] if snap else day
        s = snap.get(day, {})
        sessions = int((s.get("total") or {}).get("n") or 0)
        usd = float((s.get("total") or {}).get("est") or 0)
        for x in (s.get("by_cat") or {}).values():
            for k in ("ti", "ot", "tr", "tcr", "tcw"):
                tok[{"ti": "input", "ot": "output", "tr": "reasoning", "tcr": "cache_read", "tcw": "cache_write"}[k]] += int(x.get(k, 0) or 0)
        models = sorted((s.get("by_model") or {}).items(), key=lambda kv: float((kv[1] or {}).get("est") or 0), reverse=True)[:5]
    except Exception:
        pass
    cny = usd * float(os.environ.get("TEAMAI_USD_CNY", "7.2"))
    credits_est = cny / 0.01
    used = 0.0 if has_key else min(100.0, credits_est)
    remaining = max(0.0, 100.0 - used)
    def n(x):
        return f"{int(x):,}"
    def tn(x):
        x = int(x)
        if x >= 1_000_000:
            return f"{x / 1_000_000:.2f}M"
        if x >= 1_000:
            return f"{x / 1_000:.1f}K"
        return str(x)
    model_rows = "".join(
        f'<tr><td>{esc(m)}</td><td class="num">{n((v or {}).get("ti", 0))}</td>'
        f'<td class="num">{n((v or {}).get("ot", 0))}</td>'
        f'<td class="num">¥{float((v or {}).get("est", 0) or 0) * float(os.environ.get("TEAMAI_USD_CNY", "7.2")):.4f}</td></tr>'
        for m, v in models)
    body = f"""
  <section class="card sec" id="account">
    <div class="kicker">{i18n.t("settings.account", "账号", loc)}</div>
    <div class="kv"><span>{tr("settings.avatar", "头像")}</span><span>{avatar(owner_display_name(c), 40)}</span></div>
    <div class="kv"><span>{tr("settings.team_name", "团队名称")}</span><b class="teamname">{esc(tname)}</b></div>
    <div class="kv"><span>{tr("settings.lan", "手机访问（IP）")}</span><b><a href="{esc(lan_url)}">{esc(lan_url)}</a></b></div>
    <div class="kv"><span>{tr("settings.stable", "稳定地址（.local，仅 Apple）")}</span><b><a href="{esc(mdns_url)}">{esc(mdns_url)}</a></b></div>
    <div class="kv"><span>{tr("settings.email", "邮箱")}</span><b>{tr("settings.center", "在中心管理")}</b></div>
    <div class="kv"><span>{tr("settings.city", "常驻地")}</span><b>{tr("settings.center", "在中心管理")}</b></div>
    <div class="kv"><span>{tr("settings.profile", "公开主页")}</span><b><a href="/app/settings/profile">{tr("settings.profile_edit", "编辑公开主页 / 二维码 →")}</a></b></div>
    <p class="dim" style="margin:10px 0 0">{tr("settings.account_notice", "账号资料、邀请好友与新建 agent 只在中心节点提供（本地不新增 agent）。手机扫码用上面的 IP 地址；.local 仅 Apple/本机网络可用，微信不认。")}</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      <a class="btn primary" href="{esc(center)}/team" target="_blank" rel="noopener">{tr("team.new_agent_center", "新建 agent · 去中心")} →</a>
      <a class="btn" href="/app/help/https">{tr("settings.https_help", "HTTPS / CA 帮助")}</a>
      <a class="btn" href="/app/host">Host / Client</a>
      <a class="btn" href="/app/peer-sync">P2P 同步</a>
      <a class="btn" href="/app/peer-grants">跨 Owner 授权</a>
      <a class="btn" href="/app/backup">备份 / 恢复</a>
      <a class="btn" href="/app/peer-groups">中心组同步</a>
    </div>
  </section>
  <section class="card sec" id="updates">
    <div class="kicker">TAA 更新</div>
    <p class="dim" style="margin:6px 0 12px">默认只自动下载并提示；安装需要重启。自动安装只在空闲时执行，失败自动回滚。</p>
    <form method="post" action="/app/settings/update" class="kv">
      <span>更新模式</span><span style="display:flex;gap:8px;align-items:center">
        <select name="mode">
          <option value="notify" {'selected' if str(_update_mode()) == 'notify' else ''}>notify · 只提示</option>
          <option value="download" {'selected' if str(_update_mode()) == 'download' else ''}>download · 自动下载</option>
          <option value="auto" {'selected' if str(_update_mode()) == 'auto' else ''}>auto · 空闲自动安装</option>
        </select>
        <button class="btn primary" type="submit">保存</button>
      </span>
    </form>
    <p class="dim" style="margin:6px 0 0">检查时间：10:07 / 20:07；每天最多检查两次、自动安装一次。</p>
  </section>
  <section class="card sec" id="models">
    <div class="kicker">{i18n.t("settings.models", "团队模型 KEY", loc)}</div>
    <p class="dim" style="margin:6px 0 12px">{tr("settings.models_notice", "本机团队的所有 agent 共用；Key 只存在这台电脑（~/.taa/config.toml，权限 600），中心不保存。")}</p>
    <div class="keyrow"><b>DeepSeek</b><span class="dim">{_key_status(ds)}</span></div>
    <div class="keyrow"><b>{tr("settings.alibaba", "阿里云百炼")}</b><span class="dim">{_key_status(ali)}</span></div>
    <div class="keyrow"><b>{tr("settings.volcano", "火山方舟")}</b><span class="dim">{_key_status(volc)}</span></div>
    <form method="post" action="/app/settings/key" class="kv settings-key" style="margin-top:10px">
      <span>{tr("settings.update_key", "更新 {name} key").format(name="DeepSeek")}</span>
      <span style="display:flex;gap:8px"><input type="hidden" name="provider" value="deepseek"><input name="api_key" type="password" placeholder="sk-...">
      <button class="btn primary" type="submit">{tr("settings.save", "保存")}</button></span>
    </form>
    <form method="post" action="/app/settings/key" class="kv settings-key" style="margin-top:8px">
      <span>{tr("settings.update_key", "更新 {name} key").format(name=tr("settings.alibaba", "阿里云百炼"))}</span>
      <span style="display:flex;gap:8px"><input type="hidden" name="provider" value="alibaba"><input name="api_key" type="password" placeholder="sk-...">
      <button class="btn primary" type="submit">{tr("settings.save", "保存")}</button></span>
    </form>
    <form method="post" action="/app/settings/key" class="kv settings-key" style="margin-top:8px">
      <span>{tr("settings.update_ark", "更新火山方舟 Ark key")}</span>
      <span style="display:flex;gap:8px"><input type="hidden" name="provider" value="volcano"><input name="api_key" type="password" placeholder="ARK_API_KEY">
      <button class="btn primary" type="submit">{tr("settings.save", "保存")}</button></span>
    </form>
    <p class="dim" style="margin:10px 0 0">{tr("settings.key_note", "配置任意团队 Key → 模型调用走自己的 Key，今日积分仍显示 100，不扣模型积分；token 仍会统计。未配置时使用免费额度。")} <a href="/app/help/keys">{tr("settings.key_help", "如何申请 / 充值 / 使用 →")}</a></p>
    <div class="kv" style="margin-top:8px"><span>{tr("settings.executor", "执行器")}</span><b>{esc(eh.get("cli"))} · {esc(eh.get("workers"))} workers · {esc(eh.get("running"))} running · warm {esc(eh.get("warm_ms"))}ms</b></div>
  </section>
  <section class="card sec" id="usage">
    <div class="kicker">{i18n.t("settings.usage", "用量与积分", loc)} · {tr("settings.today", "今日")}</div>
    <div class="umeter">
      <div><span class="dim">{tr("settings.used", "已用")}</span><b>{tr("settings.used_credits", "{used:.2f} / 100 积分").format(used=used)}</b></div>
      <div class="ubar"><i style="width:{min(100, max(0, used)):.1f}%"></i></div>
      <div class="umeta"><span>{tr("settings.byok", "BYOK · 模型调用不扣积分") if has_key else tr("settings.free", "免费积分")}</span>
        <span>{tr("settings.remaining", "剩余 {left:.2f} 积分 · ¥{cny:.2f}").format(left=remaining, cny=remaining * 0.01)}</span></div>
    </div>
    <div class="ustats">
      <div><span class="dim">{tr("settings.input", "输入")}</span><b title="{n(tok['input'])}">{tn(tok['input'])}</b></div>
      <div><span class="dim">{tr("settings.output", "输出")}</span><b title="{n(tok['output'])}">{tn(tok['output'])}</b></div>
      <div><span class="dim">{tr("settings.cache", "缓存读")}</span><b title="{n(tok['cache_read'])}">{tn(tok['cache_read'])}</b></div>
      <div><span class="dim">{tr("settings.cost", "估算花费")}</span><b>¥{cny:.4f}</b></div>
      <div><span class="dim">{tr("settings.sessions", "会话")}</span><b>{sessions}</b></div>
    </div>
    <table class="utable"><thead><tr><th>{tr("settings.model", "模型")}</th><th>{tr("settings.input", "输入")}</th><th>{tr("settings.output", "输出")}</th><th>{tr("settings.estimate", "估算")}</th></tr></thead>
      <tbody>{model_rows or f'<tr><td colspan="4" class="dim">{tr("settings.empty_usage", "今天还没有模型用量。")}</td></tr>'}</tbody></table>
    <p class="dim" style="margin:8px 0 0">{tr("settings.usage_note", "数据源：本机 opencode 会话库；1 积分 = ¥0.01；免费额度按团队/日，团队跟随唯一注册真人；每日 00:00 重置。未做按 agent 归因，当前为全机估算。")}</p>
    <details class="usage-est"><summary>{tr("settings.estimate_title", "估算一段文字（不调用模型）")}</summary>
      <textarea id="utok" rows="3" placeholder="{tr("settings.estimate_ph", "粘贴一段文字，粗估 token 与花费…")}"></textarea>
      <div id="utok-out" class="dim">{tr("settings.estimate_out", "约 {tk} tokens · ¥{cny}").format(tk=0, cny="0.0000")}</div>
    </details>
  </section>
  <section class="card sec" id="ui">
    <div class="kicker">{i18n.t("settings.ui", "界面", loc)}</div>
    <div class="themes">
      <button class="theme on" data-theme-id="classic" type="button" style="background:#F3F6FA;color:#12161C;border-color:#8FB8DD"><span class="dot" style="background:#5F8FBC"></span>{tr("settings.classic", "经典")}</button>
      <button class="theme" data-theme-id="mono" type="button" style="background:#FFFFFF;color:#000000;border-color:#000000"><span class="dot" style="background:#000000"></span>{tr("settings.mono", "黑白")}</button>
      <button class="theme" data-theme-id="elegant" type="button" style="background:#F6F5F1;color:#24282B;border-color:#9EAD9F"><span class="dot" style="background:#637A66"></span>{tr("settings.elegant", "雅致")}</button>
      <button class="theme" data-theme-id="night" type="button" style="background:#0D1117;color:#F0F3F7;border-color:#9CC3EA"><span class="dot" style="background:#8FB3E0"></span>{tr("settings.night", "夜间")}</button>
    </div>
    <form method="post" action="/app/settings/lang" class="kv" style="margin-top:14px">
      <span>{tr("settings.language", "语言")}</span><span style="display:flex;gap:8px">
        <button class="btn lang-native" name="lang" value="zh-CN" type="submit">{tr("settings.zh", "中文")}</button>
        <button class="btn" name="lang" value="en" type="submit">English</button>
      </span>
    </form>
  </section>"""
    side = ('<div class="sidebox"><div class="shead">SETTINGS</div>'
            f'<a class="citem" href="#account"><span class="cname">{tr("settings.account", "账号")}</span></a>'
            f'<a class="citem" href="/app/settings/profile"><span class="cname">{tr("settings.profile", "公开主页")}</span></a>'
            f'<a class="citem" href="#models"><span class="cname">{tr("settings.models", "团队模型 KEY")}</span></a>'
            f'<a class="citem" href="#usage"><span class="cname">{tr("settings.usage", "用量与积分")}</span></a>'
            f'<a class="citem" href="#ui"><span class="cname">{tr("settings.ui", "界面")}</span></a></div>')
    scripts = """<script>
(function(){
  var cur = document.documentElement.dataset.theme || "classic";
  function paint(){ document.querySelectorAll(".theme").forEach(function(b){ b.classList.toggle("on", b.dataset.themeId===cur); }); }
  document.querySelectorAll(".theme").forEach(function(b){
    b.addEventListener("click", function(){ cur=b.dataset.themeId; document.documentElement.dataset.theme=cur; try{localStorage.setItem("taa_theme",cur);}catch(e){} paint(); });
  });
  paint();
  var u=document.getElementById("utok"), out=document.getElementById("utok-out");
  function est(){
    if(!u||!out) return;
    var t=u.value||"", cjk=(t.match(/[\u4e00-\u9fff]/g)||[]).length;
    var tk=Math.ceil(cjk*0.7+(t.length-cjk)/4);
    var cny=tk/1e6*0.15*7.2;
    out.textContent=__TPL__.replace("{tk}", tk.toLocaleString()).replace("{cny}", cny.toFixed(5)).replace("{credits}", (cny/0.01).toFixed(3));
  }
  if(u) u.addEventListener("input",est);
})();
</script>""".replace("__TPL__", json.dumps(tr("settings.estimate_out_full", "约 {tk} tokens · ¥{cny} · 约 {credits} 积分")))
    detail = (
        _dhero(tr("settings.detail", "设置详情"), tr("settings.detail_sub", "账号、模型、用量与界面"),
               tr("settings.detail_note", "团队 Key 只存本机；用量为估算，不额外调用模型。"),
               f'<a class="dact" href="#models">{tr("settings.key_btn", "团队 KEY")}</a>'
               f'<a class="dact" href="#usage">{tr("settings.usage_btn", "用量与积分")}</a>'
               f'<a class="dact" href="#ui">{tr("settings.ui_btn", "界面")}</a>')
        + _dcard(tr("post.note", "说明"), f'<p class="dnote">{tr("settings.note", "主题切换立即生效并记住到本机；模型 KEY 不回传中心，也不进帖子。配置 Key 后模型调用不扣模型积分。")}</p>')
    )
    return shell(tr("settings.title", "设置"), body, "settings", tr("settings.detail_sub", "账号、模型、用量与界面"), side=side, page_css=PAGE_CSS["settings"], scripts=scripts, detail=detail)


def _ws_send(ws, payload: dict) -> bool:
    """Best-effort send; never hold the global client lock during network I/O."""
    try:
        data = json.dumps(payload, ensure_ascii=False)
        ws.send(data)
        return True
    except Exception:  # noqa: BLE001
        return False


def _ws_broadcast_now(rid: str, payload: dict) -> None:
    with _WS_LOCK:
        clients = list((_WS_CLIENTS.get(rid) or {}).items())
    dead: list[int] = []
    for key, ws in clients:
        if not _ws_send(ws, payload):
            dead.append(key)
    if dead:
        with _WS_LOCK:
            room_clients = _WS_CLIENTS.get(rid) or {}
            for key in dead:
                room_clients.pop(key, None)
            if not room_clients:
                _WS_CLIENTS.pop(rid, None)


def _ws_broadcast(rid: str, payload: dict) -> None:
    """Fan out off-request; a stale socket must not block the composer."""
    threading.Thread(target=_ws_broadcast_now, args=(rid, payload),
                     name="taa-ws-broadcast", daemon=True).start()


def _reply_center_id(c, rid: str, reply_id) -> str:
    try:
        r = c.execute("select center_message_id from room_messages where id=? and room_id=?",
                      (int(reply_id or 0), rid)).fetchone()
        return str(r["center_message_id"] or "") if r else ""
    except Exception:  # noqa: BLE001
        return ""


def _reply_info(c, rid: str, reply_id) -> dict:
    try:
        rid_num = int(reply_id or 0)
    except (TypeError, ValueError):
        return {}
    if not rid_num:
        return {}
    row = c.execute(
        "select id,agent_id,body from room_messages where id=? and room_id=?",
        (rid_num, rid)).fetchone()
    if not row:
        return {}
    name = owner_display_name(c) if row["agent_id"] == "human" else row["agent_id"]
    if row["agent_id"] != "human":
        try:
            nm = c.execute("select name from agents where id=?", (row["agent_id"],)).fetchone()
            if nm and nm["name"]:
                name = nm["name"]
        except Exception:  # noqa: BLE001
            pass
    body = " ".join(str(row["body"] or "").split())
    return {"id": rid_num, "name": name, "text": body[:100]}


def _att_state(c, mid: int):
    """附件投递状态（docs/16 §3.6）；无附件 → None。查不到就当没有，不影响消息。"""
    try:
        from core import attachments as _att
        return _att.state_of(c, mid)
    except Exception:                                            # noqa: BLE001
        return None


def _ws_payload(c, rid: str, mid: int, *, client_message_id: str = "",
                seq: int = 0, sent_at: str = "", viewer_id: str = "") -> dict:
    row = c.execute(
        "select id,round,agent_id,body,created_at,created_at_utc,source,kind,attachment,"
        "client_message_id,reply_to_id from room_messages where id=?", (mid,)).fetchone()
    if not row:
        return {}
    name_row = c.execute("select name,node_id,kind from agents where id=?", (row["agent_id"],)).fetchone()
    from_name = owner_display_name(c) if row["agent_id"] == "human" else (name_row["name"] if name_row else row["agent_id"])
    utc = str(row["created_at_utc"] or timeutil.to_utc_iso(row["created_at"], assume="local"))
    return {
        "id": row["id"],
        "seq": seq or row["id"],
        "round": row["round"],
        "me": bool(viewer_id) and row["agent_id"] == viewer_id,
        "from": row["agent_id"],
        "from_name": from_name,
        "from_node": (name_row["node_id"] if name_row else "") or "",
        "text": row["body"] or "",
        "html": md_html(row["body"] or ""),
        "source": row["source"] or "chat",
        "kind": row["kind"] or "",
        "att": row["attachment"] or "",
        "atts": [a["url"] for a in _atts(row["attachment"])],
        # 附件投递状态（docs/16 §3.6）：无附件为 None；否则 local/pending/synced/failed。
        "att_state": _att_state(c, mid),
        "time": fmt_msg_dt(row),
        "client_message_id": client_message_id or str(row["client_message_id"] or ""),
        "sent_at": sent_at or utc,
        "created_at_utc": utc,
        "reply_to": int(row["reply_to_id"] or 0),
        "reply": _reply_info(c, rid, row["reply_to_id"]),
        "received_at": timeutil.now_utc_iso(),
    }


def _ws_room(ws, rid: str) -> None:
    """Minimal Host-authoritative room socket.

    Protocol:
      client -> {"type":"message","body":...,"client_message_id":...}
      server -> {"type":"hello","room":...,"last_id":...}
                {"type":"message","message":{...}}
                {"type":"error","error":...}
    """
    if Sock is None:
        return
    key = id(ws)
    with _WS_LOCK:
        _WS_CLIENTS.setdefault(rid, {})[key] = ws
    try:
        c0 = rw()
        try:
            row = c0.execute("select max(id) m from room_messages where room_id=? and kind not in ('skip','system')",
                             (rid,)).fetchone()
            last_id = int((row["m"] if row else 0) or 0)
        finally:
            c0.close()
        _cv = rw()
        try:
            try:
                _viewer = chat_viewer(_cv)
            except Exception:  # noqa: BLE001
                _viewer = None
        finally:
            _cv.close()
        if not _viewer:
            _ws_send(ws, {"type": "error", "error": "login_required"})
            return
        _ws_send(ws, {"type": "hello", "room": rid, "last_id": last_id,
                      "protocol": "taa-ws-1", "viewer_id": _viewer["id"],
                      "viewer_name": _viewer["name"]})
        while True:
            try:
                raw = ws.receive(timeout=1)
            except Exception:  # noqa: BLE001
                break
            if raw is None:
                # Timeout also lets us notice a closed peer.
                if not getattr(ws, "connected", True):
                    break
                continue
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8", "replace")
            try:
                event = json.loads(raw or "{}")
            except Exception:  # noqa: BLE001
                _ws_send(ws, {"type": "error", "error": "bad_json"})
                continue
            if event.get("type") == "ping":
                _ws_send(ws, {"type": "pong"})
                continue
            if event.get("type") != "message":
                _ws_send(ws, {"type": "error", "error": "unsupported_event"})
                continue
            body = str(event.get("body") or "").strip()
            if not body:
                _ws_send(ws, {"type": "error", "error": "body_required"})
                continue
            if len(body) > 4000:
                _ws_send(ws, {"type": "error", "error": "body_too_long"})
                continue
            _claims = share_claims() or {}
            if _claims and not _claims.get("w"):
                _ws_send(ws, {"type": "error", "error": "read_only"})
                continue
            # Keep executor semantics on the existing HTTP path for now.
            if re.search(r"@[\w.\-]{1,40}", body) or re.match(r"^\s*/(?:exec|run)\b", body, re.I):
                _ws_send(ws, {"type": "error", "error": "use_http_for_exec"})
                continue
            cid = clean_client_message_id(event.get("client_message_id")) or new_client_message_id()
            try:
                reply_to = int(event.get("reply_to") or 0)
            except (TypeError, ValueError):
                reply_to = 0
            c = rw()
            try:
                ensure_center_message_column(c)
                viewer = chat_viewer(c)
                if not viewer:
                    _ws_send(ws, {"type": "error", "error": "login_required"})
                    continue
                human = str(viewer["id"])
                if cid:
                    dup = c.execute("select id,agent_id,created_at,created_at_utc from room_messages "
                                    "where room_id=? and client_message_id=? limit 1",
                                    (rid, cid)).fetchone()
                    if dup and str(dup["agent_id"] or "") == human:
                        payload = _ws_payload(c, rid, int(dup["id"]), client_message_id=cid,
                                              seq=int(dup["id"]),
                                              sent_at=str(dup["created_at_utc"] or ""),
                                              viewer_id=human)
                        _ws_send(ws, {"type": "message", "message": payload, "duplicate": True})
                        continue
                room = c.execute("select status from rooms where id=?", (rid,)).fetchone()
                if not room:
                    _ws_send(ws, {"type": "error", "error": "room_not_found"})
                    continue
                try:
                    rooms_mod_ensure = __import__("core.rooms", fromlist=["ensure_human_member"])
                    rooms_mod_ensure.ensure_human_member(c, rid, human)
                except Exception:  # noqa: BLE001
                    pass
                if room["status"] != "running":
                    from core import rooms as rooms_mod_start
                    rooms_mod_start.start_room(c, rid)
                from core import rooms as rooms_mod
                res = rooms_mod.say(c, rid, human, body[:4000], None, attachment=None,
                                    client_message_id=cid, reply_to_id=reply_to or None)
                mid = int(res["message_id"])
                c.commit()
                payload = _ws_payload(c, rid, mid, client_message_id=cid, seq=mid,
                                      sent_at=str(res.get("created_at_utc") or ""),
                                      viewer_id=human)
                if res.get("duplicate"):
                    _ws_send(ws, {"type": "message", "message": payload, "duplicate": True})
                    continue
            except Exception as e:  # noqa: BLE001
                try:
                    c.rollback()
                except Exception:  # noqa: BLE001
                    pass
                _ws_send(ws, {"type": "error", "error": "send_failed", "detail": str(e)[:120]})
                continue
            finally:
                c.close()
            payload["me"] = False  # each browser computes me from viewer_id
            # WS and HTTP must have identical post-write semantics.  Without
            # this, a pure-text WS message is only local and never reaches the
            # peer node (Delta report p-5d3f32f6).
            try:
                queue_group_message_sync(rid)
            except Exception:  # noqa: BLE001
                pass
            _ws_broadcast(rid, {"type": "message", "message": payload})
    finally:
        with _WS_LOCK:
            room_clients = _WS_CLIENTS.get(rid) or {}
            room_clients.pop(key, None)
            if not room_clients:
                _WS_CLIENTS.pop(rid, None)


def register(app):
    if Sock is not None:
        _sock = Sock(app)

        @_sock.route("/app/ws/room/<rid>")
        def _taa_ws_room(ws, rid):  # type: ignore[no-untyped-def]
            _ws_room(ws, rid)

    @app.get("/app/persona-gen")
    def _taa_persona_gen():
        """只读预览：名字 → 性别 → 模板池 N 选 1（不落盘、不建档）。"""
        from core import persona_gen as _G
        args = request.args
        name = (args.get("name") or "").strip()
        gender = (args.get("gender") or "").strip()
        seed = (args.get("seed") or "").strip()
        tpl = (args.get("template") or "").strip()
        hint = (args.get("hint") or "").strip()
        enrich = args.get("enrich") == "1"
        p, err = None, ""
        if name:
            try:
                p = _G.roll(name, gender=gender or None, seed=seed or None, template=tpl or None)
                if enrich:
                    p = _G.enrich(p, hint)
            except Exception as exc:                       # noqa: BLE001
                err = f"{type(exc).__name__}: {exc}"
        return shell("人格生成预览",
                     page_persona_gen(name, gender, seed, tpl, hint, enrich, p, err),
                     active="tools", subtitle="只读预览 · 不会落盘建档")

    @app.before_request
    def _taa_phase0_start():
        if request.path.startswith("/app") and not request.path.startswith("/app/api/room"):
            g._taa_t0 = time.time()

    @app.after_request
    def _taa_phase0_log(resp):
        t0 = getattr(g, "_taa_t0", None)
        if t0 is not None:
            path = request.path or ""
            if path.startswith("/app/p/"):
                feature = "post"
            elif path.startswith("/app/chats"):
                feature = "chats"
            elif path.startswith("/app/feed"):
                feature = "feed"
            elif path.startswith("/app/moments"):
                feature = "moments"
            elif path.startswith("/app/settings"):
                feature = "settings"
            elif path.startswith("/app/board"):
                feature = "board"
            elif path.startswith("/app/team"):
                feature = "team"
            elif path.startswith("/app/inbox"):
                feature = "inbox"
            elif path.startswith("/app/tools"):
                feature = "tools"
            else:
                feature = "app"
            try:
                from core import telemetry
                telemetry.record(feature, request.method, path,
                                 latency_ms=int((time.time() - t0) * 1000),
                                 success=resp.status_code < 500)
            except Exception:
                pass
        if request.path.startswith("/app") and not request.path.startswith("/app/api/"):
            # 页面样式在本地启动时注入；禁止浏览器/代理拿旧页面覆盖新布局。
            resp.headers["Cache-Control"] = "no-store, max-age=0"
            resp.headers["Pragma"] = "no-cache"
        return resp

    @app.before_request
    def _lan_share_only():
        """6080 对 LAN 只提供只读分享；完整应用走 6443。"""
        remote = request.remote_addr or "127.0.0.1"
        try:
            if ipaddress.ip_address(remote).is_loopback:
                return None
        except ValueError:
            return None
        # 只限制 LAN HTTP 6080；6443 HTTPS 是完整应用。
        if request.is_secure or request.headers.get("X-Forwarded-Proto") == "https":
            return None
        path = request.path or ""
        data = share_verify(request.cookies.get("taa_share", ""))
        if data and data.get("w"):
            return None  # 可写局域网会话：完整聊天（含 POST）
        if request.method not in ("GET", "HEAD"):
            return Response("只读分享：局域网不能修改", status=403)
        if path.startswith("/app/s/"):
            return None
        if (path.startswith("/static/") or path.startswith("/thumb")
                or path.startswith("/avatar/") or path in ("/ca.crt", "/ca.sha256", "/favicon.ico")):
            return None
        if (path in ("/app", "/app/") or path.startswith("/app/chats") or path.startswith("/app/feed")
                or path.startswith("/app/moments") or path.startswith("/app/inbox")
                or path.startswith("/app/team")
                or path.startswith("/app/p/") or path.startswith("/app/api/room/")
                or path.startswith("/app/ws/")):
            if data:
                return None
            return Response("需要手机会话或只读分享链接", status=403)
        return Response("局域网仅提供手机会话；完整应用请用 6443", status=403)

    @app.before_request
    def _share_readonly():
        if request.method not in ("GET", "HEAD") and is_share():
            return Response("只读分享：不能修改", status=403)

    @app.post("/app/share/new")
    def taa_share_new():
        body = request.get_json(silent=True) or {}
        path = str(body.get("path") or "/app")
        if not path.startswith("/app") or path.startswith("//"):
            path = "/app"
        # 默认签发可写局域网会话：手机打开就是完整聊天，不再是只读分享。
        # 兼容显式只读请求（旧分享/测试）：mode=read 或 write=false。
        write = body.get("mode") != "read" and body.get("write", True) is not False
        viewer = share_viewer()
        if write and not viewer:
            sid = str(session.get("agent_id") or "").strip()
            if sid:
                c0 = rw()
                try:
                    row = c0.execute("select name,owner_id from agents where id=?", (sid,)).fetchone()
                    if row:
                        viewer = {"id": sid, "name": str(row["name"] or sid),
                                  "owner_id": str(row["owner_id"] or "")}
                finally:
                    c0.close()
        if write and not viewer:
            # The local Host is the Owner's own console; a loopback request
            # may mint a link for that Owner.  Any LAN request must log in.
            try:
                loopback = ipaddress.ip_address(request.remote_addr or "").is_loopback
            except ValueError:
                loopback = False
            if loopback:
                c0 = rw()
                try:
                    viewer = {"id": human_id(c0), "name": owner_display_name(c0),
                              "owner_id": _center_owner_id()}
                finally:
                    c0.close()
        if not viewer:
            return {"ok": False, "error": "login required for share"}, 403
        tok = share_token(
            path, write=write,
            viewer_id=(viewer or {}).get("id", ""),
            viewer_name=(viewer or {}).get("name", ""),
            owner_id=(viewer or {}).get("owner_id", ""),
        )
        return {"url": share_base() + "/app/s/" + tok}

    @app.get("/app/s/<tok>")
    def taa_share_open(tok: str):
        data = share_verify(tok)
        if not data:
            return Response("链接已过期或不合法", status=410)
        resp = redirect(data.get("p") or "/app")
        resp.set_cookie("taa_share", tok, max_age=86400, httponly=True, samesite="Lax")
        return resp

    @app.get("/app/share/exit")
    def taa_share_exit():
        """清除只读分享 cookie，进入完整应用（6443）。"""
        nxt = request.args.get("next") or "/app/chats"
        if not nxt.startswith("/app") or nxt.startswith("//"):
            nxt = "/app/chats"
        resp = redirect(nxt)
        resp.delete_cookie("taa_share", path="/")
        return resp

    @app.get("/favicon.ico")
    def taa_favicon():
        p = ROOT / "static" / "teamai" / "brand" / "favicon.ico"
        if p.exists():
            return send_file(p, mimetype="image/x-icon", max_age=86400)
        return Response(status=404)

    @app.get("/avatar/m/<name>")
    def avatar_svg(name: str):
        ch = (name or "?").strip()[:1].upper() or "?"
        color = color_for(name)
        svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96">
  <circle cx="48" cy="48" r="46" fill="{color}"/>
  <circle cx="48" cy="48" r="40" fill="none" stroke="rgba(255,255,255,.85)" stroke-width="2" stroke-dasharray="2 4" opacity=".9"/>
  <text x="48" y="63" text-anchor="middle" font-family="-apple-system,Segoe UI,PingFang SC,Arial" font-size="42" font-weight="600" fill="#fff">{html.escape(ch)}</text>
</svg>"""
        return Response(svg, mimetype="image/svg+xml", headers={"cache-control": "public, max-age=86400"})

    @app.get("/thumb")
    def taa_thumb():
        """列表/气泡预览图；只允许本机 static/uploads，灯箱仍用 data-full 原图。"""
        u = request.args.get("u", "")
        try:
            w = int(request.args.get("w", "480"))
        except ValueError:
            w = 480
        p = thumbnails.ensure_thumb(u, w)
        if not p:
            src = thumbnails.source_path(u)
            if not src:
                return Response("not found", status=404, mimetype="text/plain")
            return send_file(src, conditional=True, max_age=3600)
        resp = send_file(p, mimetype="image/jpeg", conditional=True, max_age=2592000)
        resp.headers["Cache-Control"] = "public, max-age=2592000, immutable"
        return resp

    @app.get("/app/api/room/<rid>/members")
    def room_members_api(rid: str):
        """会话参与人（真实成员接口）：姓名 / agent id / 在线状态 / 角色。"""
        c = db()
        try:
            exists = c.execute("select 1 from rooms where id=?", (rid,)).fetchone()
            if not exists:
                return {"room": rid, "error": "room_not_found", "count": 0,
                        "online": 0, "human": 0, "ai": 0, "members": []}, 404
            rows = room_members(c, rid, viewer=None if is_share() else human_id(c))
        finally:
            c.close()
        return {"room": rid,
                "count": len(rows),
                "online": sum(1 for x in rows if x["state"] == "online"),
                "human": sum(1 for x in rows if x["kind"] == "human"),
                "ai": sum(1 for x in rows if x["kind"] == "ai"),
                "members": rows}

    @app.get("/app/api/room/<rid>/stream")
    def room_stream(rid: str):
        """SSE：只发“有新消息”的触发，具体消息仍由既有 room_api 拉取。
        这样不复制渲染逻辑，也能把 2.5s 轮询降到 <500ms。"""
        try:
            after = int(request.args.get("after", "0"))
        except ValueError:
            after = 0
        check = db()
        exists = check.execute("select 1 from rooms where id=?", (rid,)).fetchone()
        check.close()
        if not exists:
            return Response("room not found", status=404)

        def gen():
            last = after
            while True:
                c = db()
                try:
                    row = c.execute(
                        "select max(id) m from room_messages where room_id=? and kind not in ('skip','system')",
                        (rid,)).fetchone()
                    cur = int((row["m"] if row else 0) or 0)
                finally:
                    c.close()
                if cur > last:
                    last = cur
                    yield f"data: {cur}\n\n"
                else:
                    yield ": ping\n\n"
                time.sleep(0.4)

        return Response(stream_with_context(gen()), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                                 "Connection": "keep-alive"})

    @app.get("/app/api/room/<rid>/gallery")
    def room_gallery(rid: str):
        """本会话全部图片（跨消息、跨批次），供画廊循环。"""
        c = db()
        try:
            rows = c.execute("select body,attachment from room_messages where room_id=? "
                             "and kind not in ('skip','system') order by id", (rid,)).fetchall()
        finally:
            c.close()
        out, seen = [], set()
        for r in rows:
            urls = [a["url"] for a in _atts(r["attachment"])]
            urls += re.findall(r"!\[[^\]]*\]\(([^)]+)\)", str(r["body"] or ""))
            urls += re.findall(r"<img[^>]+src=[\"']([^\"']+)", str(r["body"] or ""), re.I)
            for u in urls:
                u = _same_host(str(u))
                if u and u.lower().split("?")[0].endswith(IMG_EXT) and u not in seen:
                    seen.add(u); out.append(u)
        return {"urls": out, "count": len(out)}

    @app.get("/app/api/room/<rid>/state")
    def room_state(rid: str):
        """实时回合状态：当前谁在说 / 第几轮 / 截止时间，供聊天页顶部状态条。"""
        c = rw()
        try:
            from core import rooms as rooms_mod
            room = rooms_mod.get_room(c, rid)
            if not room:
                return {"ok": False, "error": "room_not_found"}, 404
            turn = rooms_mod._current_turn(c, room) if room.get("status") == "running" else None
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return {"ok": True,
                    "room": {"id": room["id"], "status": room.get("status"),
                             "round": room.get("current_round") or 1,
                             "current_idx": room.get("current_idx") or 0},
                    "turn": ({"agent_id": turn.get("agent_id"), "state": turn.get("state"),
                              "round": turn.get("round"),
                              "prepare_deadline": turn.get("prepare_deadline"),
                              "open_deadline": turn.get("open_deadline")}
                             if turn else None),
                    "server_time": now}
        finally:
            c.close()

    @app.get("/app/api/room/<rid>")
    def room_api(rid: str):
        after = request.args.get("after", "0")
        try:
            after = int(after)
        except ValueError:
            after = 0
        c = db()
        _sv = share_viewer()
        hid = (_sv or {}).get("id") or human_id(c)
        names = {r["id"]: (r["name"] or r["id"]) for r in c.execute("select id,name from agents")}
        names["human"] = owner_display_name(c)
        nodes = {r["id"]: (r["node_id"] or "") for r in c.execute("select id,node_id from agents")}
        rows = c.execute("""select id,round,agent_id,body,attachment,created_at,created_at_utc,
            source,kind,client_message_id,reply_to_id from room_messages
            where room_id=? and id>? and kind != 'skip' order by id limit 60""",
                         (rid, after)).fetchall()
        rows = [r for r in rows if r["kind"] != "system" or _show_system_receipt(r)]
        return {"messages": [{"id": r["id"], "round": r["round"], "me": r["agent_id"] == hid,
                              "from": r["agent_id"],
                              "from_name": names.get(r["agent_id"], r["agent_id"]),
                              "from_node": nodes.get(r["agent_id"], ""),
                              "text": r["body"], "html": md_html(r["body"]),
                              "postrefs": _post_refs(r["body"], c=c),
                              "source": r["source"] or "chat",
                              "kind": r["kind"] or "",
                              "att": r["attachment"] or "",
                              "atts": [a["url"] for a in _atts(r["attachment"])],
                              "time": fmt_msg_dt(r),
                              "created_at_utc": (r["created_at_utc"] or
                                                 timeutil.to_utc_iso(r["created_at"], assume="local")),
                              "sent_at": (r["created_at_utc"] or
                                          timeutil.to_utc_iso(r["created_at"], assume="local")),
                              "reply_to": int(r["reply_to_id"] or 0),
                              "reply": _reply_info(c, rid, r["reply_to_id"]),
                              "client_message_id": r["client_message_id"] or ""} for r in rows]}

    @app.get("/app/help/keys")
    def taa_help_keys():
        from core.help_ui import page_keys_help
        return Response(page_keys_help(shell, side=_tools_side("keys")), mimetype="text/html")

    @app.get("/app/help/https")
    def taa_help_https():
        from core.help_ui import page_https_help
        cert = ROOT / "certs" / "server.crt"
        fingerprint = hashlib.sha256(cert.read_bytes()).hexdigest() if cert.exists() else ""
        try:
            from core import nodeinfo
            host = nodeinfo.lan_ip() or socket.gethostname()
        except Exception:  # noqa: BLE001
            host = socket.gethostname()
        port = int(os.environ.get("TEAM_TLS_PORT") or 6443)
        ca_url = f"https://{host}:{port}/ca.crt"
        detail = _tools_detail(
            "HTTPS / CA", "证书只信一次",
            "本机 HTTPS 证书只含公钥；首次访问需要把 CA 装入系统或手机信任库。",
            f'<div class="kv"><span>地址</span><b class="mono">https://{esc(host)}:{port}/app</b></div>'
            f'<div class="kv"><span>CA</span><b class="mono">https://{esc(host)}:{port}/ca.crt</b></div>'
            f'<div class="kv"><span>SHA-256</span><b class="mono" style="word-break:break-all">{esc(fingerprint)}</b></div>'
            '<p class="dim" style="margin:10px 0 0">不要把私钥或完整证书夹到聊天/论坛；只分享公钥证书。</p>')
        return Response(page_https_help(shell, host, port, fingerprint, ca_url,
                                       side=_tools_side("https"), detail=detail),
                        mimetype="text/html")

    @app.get("/app/tools")
    def taa_tools():
        from core.tool_launcher import page_tools
        return Response(page_tools(shell, tr, _locale()), mimetype="text/html")

    @app.get("/app/tools/loomdoc")
    def taa_loomdoc_page():
        from core.loomdoc_ui import page_tools
        return Response(page_tools(shell), mimetype="text/html")

    @app.post("/app/tools/loomdoc")
    def taa_loomdoc():
        from core.loomdoc_ui import page_tools, llm_slides, build_deck
        topic = (request.form.get("topic") or "").strip()
        audience = (request.form.get("audience") or "").strip()
        tone = (request.form.get("tone") or "").strip()
        try:
            pages = max(4, min(16, int(request.form.get("pages") or 8)))
        except ValueError:
            pages = 8
        form = {"topic": topic, "audience": audience, "tone": tone, "pages": pages}
        if not topic:
            return Response(page_tools(shell, error="请填写主题", form=form), mimetype="text/html")
        deck, err = llm_slides(topic, audience, pages, tone)
        if err:
            return Response(page_tools(shell, error=err, form=form), mimetype="text/html")
        result, err = build_deck(deck, topic, pages)
        if err:
            return Response(page_tools(shell, error="出片失败：" + err, form=form), mimetype="text/html")
        return Response(page_tools(shell, result=result, form=form), mimetype="text/html")

    @app.get("/app/monograph")
    def taa_monograph_list():
        """专著流水线看板：只读 research/<slug>/ 产物。"""
        from core.monograph_ui import page_list
        return Response(page_list(shell), mimetype="text/html")

    @app.get("/app/monograph/<slug>")
    def taa_monograph_detail(slug: str):
        from core.monograph_ui import page_detail
        return Response(page_detail(shell, slug, (request.args.get("msg") or "")),
                        mimetype="text/html")

    @app.post("/app/monograph/<slug>/run")
    def taa_monograph_run(slug: str):
        """起一个流水线阶段（后台进程；页面只负责跳回来看进度）。"""
        from urllib.parse import quote as _q
        from core.monograph_ui import run_stage
        stage = (request.form.get("stage") or "").strip()
        chapter = (request.form.get("chapter") or "").strip()
        ok, msg = run_stage(slug, stage, chapter)
        return redirect(f"/app/monograph/{slug}?msg={_q(('✓ ' if ok else '✗ ') + msg)}")

    @app.post("/app/chats/start")
    def taa_chat_start():
        rid = request.form.get("room", "")
        if rid:
            from core import rooms as rooms_mod
            c = rw()
            try:
                rooms_mod.start_room(c, rid)
                rooms_mod.close_running_except(c, rid)
            except Exception as e:  # noqa: BLE001
                print(f"[app_ui] start err: {e}")
            finally:
                c.close()
        return redirect(f"/app/chats?room={rid}")

    @app.post("/app/chats/group")
    def taa_chat_group():
        from core import rooms as rooms_mod
        c = rw()
        try:
            host = rooms_mod.human_id(c)
            picked = [x for x in (request.form.getlist("members") or []) if x]
            own_agents = [x for x in dict.fromkeys(picked) if x != host]
            picked = list(own_agents)
            friend_ids = [x for x in (request.form.getlist("friend_owner_ids") or []) if x]
            friend_map = {str(f.get("owner_id")): f for f in owner_friends()}
            for oid in dict.fromkeys(friend_ids):
                f = friend_map.get(oid)
                if not f:
                    continue
                human_stub = "remote-human-" + oid
                agent = f.get("primary_agent") or {}
                aid = str(agent.get("agent_id") or "")
                if ensure_remote_stub(c, agent_id=human_stub, name=str(f.get("username") or oid),
                                      kind="human", full_name=f"{f.get('username') or oid}@center",
                                      owner_id=oid, owner_name=str(f.get("username") or oid)):
                    picked.append(human_stub)
                if aid and ensure_remote_stub(c, agent_id=aid,
                                              name=str(agent.get("display_name") or "agent"),
                                              kind="ai", full_name=f"{aid}@center",
                                              owner_id=oid, owner_name=str(f.get("username") or oid)):
                    picked.append(aid)
            picked = [x for x in dict.fromkeys(picked) if x != host]
            if not picked:
                return redirect("/app/chats")
            if len(picked) == 1:
                a = c.execute("select name from agents where id=?", (picked[0],)).fetchone()
                rid = rooms_mod.ensure_dm(c, host, picked[0], (a["name"] if a else picked[0]))
                return redirect(f"/app/chats?room={rid}")
            name = (request.form.get("name") or "").strip()[:60]
            if not name:
                aliases = []
                for r in c.execute("select distinct node_id from agents where id in (%s)" % ",".join("?" * len(picked)), picked):
                    if r["node_id"] and r["node_id"] not in aliases:
                        aliases.append(r["node_id"])
                if len(aliases) == 1:
                    name = f"{aliases[0]}群聊"
                elif aliases:
                    name = " + ".join(aliases[:2]) + "群聊"
                else:
                    name = "新群聊"
            rid = rooms_mod.create_room(c, host, name, expected_minutes=10080)
            for aid in picked:
                rooms_mod.add_member(c, rid, aid)
            if friend_ids:
                gid = sync_group_to_center(c, rid, name, friend_ids, own_agents)
                if gid:
                    # The center group is the conversation identity.  If this
                    # participant set already has a local room, reuse it and
                    # leave the newly-created room as a legacy alias.
                    existing = c.execute(
                        "select id,title from rooms where center_group_id=? and id<>? "
                        "and kind='group' order by created_at limit 1", (gid, rid)).fetchone()
                    if existing:
                        c.execute("update rooms set status='ended', title=?, topic=? where id=?",
                                  ("（已合并到 " + (existing["title"] or existing["id"]) + "）",
                                   "（已合并）", rid))
                        c.commit()
                        rid = str(existing["id"])
                    ensure_center_group_column(c)
                    c.execute("update rooms set canonical_id=?, participant_key=?, authority_node='local', read_only=0 where id=?",
                              (gid, room_participant_key(c, rid), rid))
                    c.commit()
            rooms_mod.start_room(c, rid)
        finally:
            c.close()
        return redirect(f"/app/chats?room={rid}")

    @app.post("/app/chats/rename")
    def taa_chat_rename():
        rid = request.form.get("room", "")
        name = (request.form.get("name") or "").strip()[:60]
        if rid and name:
            c = rw()
            gid = ""
            try:
                row = c.execute("select kind,center_group_id from rooms where id=?", (rid,)).fetchone()
                if row and row["kind"] == "group":
                    gid = str(row["center_group_id"] or "")
                    if gid:
                        c.execute("update rooms set topic=?, title=? where center_group_id=?", (name, name, gid))
                    else:
                        c.execute("update rooms set topic=?, title=? where id=?", (name, name, rid))
                    c.commit()
            finally:
                c.close()
            if gid:
                try:
                    st = center_state()
                    if st and st.center.base and st.node.node_key:
                        from taa_node_v05.center import CenterClient
                        CenterClient(st.center.base).rename_group_for_node(
                            node_key=st.node.node_key, group_id=gid, name=name)
                except Exception as e:  # noqa: BLE001
                    print(f"[app_ui] center rename err: {e}")
        return redirect(f"/app/chats?room={rid}")

    @app.post("/app/chats/clear")
    def taa_chat_clear():
        from core import rooms as rooms_mod
        rid = request.form.get("room", "")
        if rid:
            c = rw()
            try:
                room = rooms_mod.get_room(c, rid)
                ais = [m for m in (room or {}).get("members", []) if m.get("kind") == "ai"]
                if room and len(room.get("members", [])) == 2 and len(ais) == 1:
                    rooms_mod.clear_room_messages(c, rid)
            finally:
                c.close()
        return redirect(f"/app/chats?room={rid}")

    @app.post("/app/chats/delete")
    def taa_chat_delete():
        from core import rooms as rooms_mod
        rid = request.form.get("room", "")
        if rid:
            c = rw()
            try:
                room = rooms_mod.get_room(c, rid)
                ais = [m for m in (room or {}).get("members", []) if m.get("kind") == "ai"]
                is_dm = bool(room and len(room.get("members", [])) == 2 and len(ais) == 1)
                if room and not is_dm:
                    rooms_mod.purge_room(c, rid)
                    rid = ""
            finally:
                c.close()
        return redirect("/app/chats" + (f"?room={rid}" if rid else ""))

    @app.post("/app/notice-ack")
    def taa_notice_ack():
        """R-01：把"已了解跨组织明文边界"记到中心（浏览器 localStorage 另存一份）。

        中心侧是 owner 级签收（owner_notice_acks），换机器/换浏览器后仍认得；
        中心没配置时只回 ok=False，不阻断本地使用。
        """
        scope = (request.form.get("scope") or "collab_plaintext")[:40]
        ok, err = False, ""
        try:
            st = center_state()
            if st and st.center.base and st.node.node_key:
                from taa_node_v05.center import CenterClient
                CenterClient(st.center.base).notice_ack(node_key=st.node.node_key, scope=scope)
                ok = True
            else:
                err = "center_not_configured"
        except Exception as e:  # noqa: BLE001
            err = str(e)[:200]
            print(f"[app_ui] notice ack err: {e}")
        return Response(json.dumps({"ok": ok, "scope": scope, "error": err}),
                        mimetype="application/json")

    @app.get("/app/notice-ack-state")
    def taa_notice_ack_state():
        """R-01：查中心是否已签收（换浏览器/换机器不再重复提示）。"""
        scope = (request.args.get("scope") or "collab_plaintext")[:40]
        accepted, err = False, ""
        try:
            st = center_state()
            if st and st.center.base and st.node.node_key:
                from taa_node_v05.center import CenterClient
                r = CenterClient(st.center.base).notice_ack_state(
                    node_key=st.node.node_key, scope=scope)
                accepted = bool(r.get("accepted"))
            else:
                err = "center_not_configured"
        except Exception as e:  # noqa: BLE001
            err = str(e)[:200]
        return Response(json.dumps({"ok": not err, "accepted": accepted,
                                    "scope": scope, "error": err}),
                        mimetype="application/json")

    @app.post("/app/chats/end")
    def taa_chat_end():
        rid = request.form.get("room", "")
        if rid:
            from core import rooms as rooms_mod
            c = rw()
            try:
                rooms_mod.end_room(c, rid)
            finally:
                c.close()
        return redirect(f"/app/chats?room={rid}")

    @app.post("/app/chats/screenshot")
    def taa_chat_screenshot():
        room = request.form.get("room", "")
        if not room:
            return redirect("/app/chats")
        c = rw()
        try:
            from core import nodeinfo
            local = nodeinfo.saved_alias() or ""
            q = ("select a.id,a.name from room_members m join agents a on a.id=m.agent_id "
                 "where m.room_id=? and a.kind='ai' ")
            args = [room]
            if local:
                q += "and (a.node_id is null or a.node_id='' or a.node_id=?) "
                args.append(local)
            q += "order by m.rowid limit 1"
            row = c.execute(q, args).fetchone()
            if not row:
                return redirect(f"/app/chats?room={room}")
            aid, name = row["id"], row["name"] or row["id"]
            import importlib.util
            spec = importlib.util.spec_from_file_location("screen_tool", ROOT / "tools" / "screen" / "tool.py")
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            res = mod.run(aid, {})
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            rnd = c.execute("select current_round from rooms where id=?", (room,)).fetchone()
            rnd = int(rnd["current_round"] or 1) if rnd else 1
            if res.get("url"):
                att = json.dumps([{"url": res["url"], "name": res["url"].rsplit("/", 1)[-1]}], ensure_ascii=False)
                c.execute("insert into room_messages(room_id,round,agent_id,body,kind,created_at,source,attachment) "
                          "values(?,?,?,?,?,?,?,?)",
                          (room, rnd, aid, f"本机工作截图（{name} / opencode·IDE）", "assertion", now, "screen", att))
            else:
                c.execute("insert into room_messages(room_id,round,agent_id,body,kind,created_at,source) "
                          "values(?,?,?,?,?,?,?)",
                          (room, rnd, aid, f"截图失败：{res.get('_error','未知错误')}", "assertion", now, "screen"))
            c.commit()
        except Exception as e:  # noqa: BLE001
            print(f"[app_ui] screenshot err: {e}")
        finally:
            c.close()
        return redirect(f"/app/chats?room={room}")

    @app.post("/app/group/commands/<cid>/decide")
    def taa_group_command_decide(cid):
        from core import group_command
        c = rw()
        try:
            rid = request.form.get("room", "")
            owner_row = c.execute("select owner_id from agents where id=?", (human_id(c),)).fetchone()
            owner_id = str(owner_row["owner_id"] or "") if owner_row else ""
            try:
                row = group_command.decide(c, cid, owner_id, request.form.get("decision", ""))
                if row.get("state") == "immediate":
                    from core import group_ingress
                    group_ingress.materialize(c, row)
            except Exception as exc:  # noqa: BLE001
                print(f"[app_ui] group command decide err: {exc}")
            return redirect(f"/app/chats?room={rid}" if rid else "/app/chats")
        finally:
            c.close()

    @app.post("/app/chats/send")
    def taa_send():
        room = request.form.get("room", "")
        # Share pages carry the canonical group id in the URL, while the
        # local database row uses room-xxxxxxxx.  Resolve it before auth,
        # member checks, and the insert; otherwise a writable share link can
        # return ok while writing nothing.
        if room:
            try:
                from core import db as _db
                _rc = _db.connect()
                try:
                    hit = _rc.execute("select id from rooms where id=?", (room,)).fetchone()
                    if not hit:
                        hit = _rc.execute(
                            "select id from rooms where canonical_id=? or center_group_id=? limit 1",
                            (room, room)).fetchone()
                    if hit:
                        room = str(hit["id"])
                finally:
                    _rc.close()
            except Exception:  # noqa: BLE001
                pass
        async_mode = request.headers.get("x-taa-async") == "1"
        cid = clean_client_message_id(
            request.form.get("client_message_id")
            or request.headers.get("x-taa-client-message-id")) or new_client_message_id()
        try:
            reply_to = int(request.form.get("reply_to") or 0)
        except (TypeError, ValueError):
            reply_to = 0
        raw = (request.form.get("text") or "").strip()
        # t-a42f7aac：聊天图片先走 /app/upload，这里只收本站上传目录的 URL，存成 attachments JSON。
        try:
            picked = json.loads(request.form.get("images") or "[]")
        except Exception:  # noqa: BLE001
            picked = []
        images = [str(u) for u in (picked if isinstance(picked, list) else [])
                  if str(u).startswith("/static/uploads/") and ".." not in str(u)
                  and str(u).lower().split("?")[0].endswith(IMG_EXT)][:9]
        att_items = []
        for u in images:
            tr = _transport_image_url(u)
            att_items.append({"url": u, "name": u.rsplit("/", 1)[-1], "transport_url": tr})
        att = json.dumps(att_items, ensure_ascii=False) if att_items else None
        from core import executor_bridge
        text, prefixed = executor_bridge.strip_prefix(raw)
        # 群聊里"显式 /exec"或"@ 到本机 agent"的消息，不再用关键词判要不要动手，
        # 改为**落库后**交给 `executor_bridge.route_saved_message`（LLM 树状分叉裁决）：
        #   answer → 群里只回一句；execute → 派执行器；ignore → 不动作。
        # 这样 HTTP 返回不被 LLM 拖慢，也不会出现"只回复三个字却起了一整个执行器"。
        is_group = bool(room) and executor_bridge.is_group(room)
        target_list = executor_bridge.resolve(room, text) if room else []
        say_prefixed = bool(re.match(r"^\s*/say\s+", text or "", re.I))
        route_later = bool(is_group and (prefixed or target_list or say_prefixed))
        do_exec = bool(route_later or prefixed)
        wants_exec = executor_bridge.should_execute(text) if (room and not is_group) else False
        remote_notice = False
        if room and not is_group and not do_exec:
            if target_list:
                do_exec = wants_exec
            elif wants_exec and re.search(r"@[\w.\-]{1,40}", text):
                # 明确 @ 了人，但本机没有她的执行器；不要落到别的本机 agent。
                remote_notice = True
        ws_mid = None
        send_error = None
        if room and (text or att):
            c = rw()
            executed = False
            try:
                ensure_center_message_column(c)
                viewer = chat_viewer(c)
                if not viewer:
                    if async_mode:
                        return {"ok": False, "room": room, "error": "login required for write"}, 401
                    return Response("login required for write", status=401, mimetype="text/plain")
                human = str(viewer["id"])
                # A retry after a lost response must not insert or execute twice.
                if cid:
                    dup = c.execute("select id,agent_id from room_messages "
                                    "where room_id=? and client_message_id=? limit 1",
                                    (room, cid)).fetchone()
                    if dup and str(dup["agent_id"] or "") == human:
                        if async_mode:
                            return {"ok": True, "room": room, "duplicate": True,
                                    "message_id": int(dup["id"])}
                        return redirect(f"/app/chats?room={room}")
                st = c.execute("select status,kind from rooms where id=?", (room,)).fetchone()
                try:
                    from core import rooms as rooms_mod_ensure
                    rooms_mod_ensure.ensure_human_member(c, room, human)
                except Exception:  # noqa: BLE001
                    pass
                if st and st["kind"] == "archived":
                    return redirect(f"/app/chats?room={room}")
                if st and st["status"] != "running":
                    from core import rooms as rooms_mod_start
                    rooms_mod_start.start_room(c, room)
                    st = c.execute("select status,kind from rooms where id=?", (room,)).fetchone()
                ws_mid = None
                if st and st["status"] == "running":
                    if do_exec:
                        now_local = timeutil.now_local_text()
                        now_utc = timeutil.now_utc_iso()
                        try:
                            cur = c.execute(
                                "insert into room_messages(room_id,round,agent_id,body,kind,created_at,"
                                "created_at_utc,source,attachment,client_message_id,reply_to_id) "
                                "values(?,0,?,?,?,?,?,?,?,?,?)",
                                (room, human, text[:4000], "assertion", now_local, now_utc,
                                 "taa-exec", att, cid, reply_to or None))
                            ws_mid = int(cur.lastrowid or 0)
                            c.commit()
                            executed = True
                        except sqlite3.IntegrityError:
                            c.rollback()
                            dup = c.execute("select id from room_messages where room_id=? and client_message_id=? limit 1",
                                            (room, cid)).fetchone()
                            ws_mid = int(dup["id"]) if dup else 0
                    else:
                        from core import rooms as rooms_mod
                        res = rooms_mod.say(c, room, human, text[:4000], None, attachment=att,
                                            client_message_id=cid, reply_to_id=reply_to or None)
                        ws_mid = int(res.get("message_id") or 0)
                        if not res.get("duplicate"):
                            executed = True
                else:
                    now_local = timeutil.now_local_text()
                    now_utc = timeutil.now_utc_iso()
                    try:
                        cur = c.execute(
                            "insert into room_messages(room_id,round,agent_id,body,kind,created_at,"
                            "created_at_utc,attachment,client_message_id,reply_to_id) "
                            "values(?,0,?,?,?,?,?,?,?,?)",
                            (room, human, text[:4000], "assertion", now_local, now_utc, att, cid,
                             reply_to or None))
                        ws_mid = int(cur.lastrowid or 0)
                        c.commit()
                        executed = True
                    except sqlite3.IntegrityError:
                        c.rollback()
                        dup = c.execute("select id from room_messages where room_id=? and client_message_id=? limit 1",
                                        (room, cid)).fetchone()
                        ws_mid = int(dup["id"]) if dup else 0
                # HTTP is the fallback for attachments/executor commands; do
                # not make a connected WS client wait for the next poll.
                if ws_mid and not is_share():
                    try:
                        _ws_broadcast(room, {"type": "message", "message": _ws_payload(c, room, ws_mid)})
                    except Exception:  # noqa: BLE001
                        pass
            except Exception as e:  # noqa: BLE001
                send_error = str(e)[:240] or type(e).__name__
                print(f"[app_ui] send err: {e}")
            finally:
                c.close()
            if not is_share() and not send_error:
                queue_group_message_sync(room)
        claimed_direct = False
        if route_later and text and executed and ws_mid:
            # 后台裁决：不占 HTTP 请求时间；claim 在 route_saved_message 内部完成。
            _spawn_route(room, text, int(ws_mid), cid, prefixed)
            do_exec = True
        elif room and do_exec and text and executed:
            if ws_mid:
                c2 = _short_conn() if "_short_conn" in globals() else None
                if c2 is None:
                    c2 = rw()
                try:
                    claimed_direct = message_route.claim(
                        c2, room_id=room, message_id=int(ws_mid),
                        client_message_id=cid, owner="direct_executor")
                finally:
                    c2.close()
            if not claimed_direct:
                do_exec = False
        if room and do_exec and text and executed and not route_later:
            _submit_ok = True
            if target_list:
                for t in target_list:
                    ok, msg = executor_bridge.submit(room, t.agent, t.name, text, sub=t.sub, dedupe_key=cid)
                    if not ok:
                        _submit_ok = False
                        executor_bridge.notice(room, t.agent, f"⚠ {msg}")
            else:
                _submit_ok = False
                executor_bridge.notice(room, "system", "⚠ 没有本机可执行对象：请 @本机 agent；远程 agent 要在它自己的电脑上执行。")
            # P1.3：direct_executor 的 claim 同样要有配对终态（否则整表永远 claimed）
            if claimed_direct and ws_mid:
                try:
                    c3 = _short_rw()
                    try:
                        message_route.finish(c3, room_id=room, message_id=int(ws_mid),
                                             owner="direct_executor",
                                             state="done" if _submit_ok else "failed",
                                             note="direct submit" if _submit_ok else "direct submit failed")
                    finally:
                        c3.close()
                except Exception:  # noqa: BLE001
                    pass
        elif room and remote_notice:
            executor_bridge.notice(room, "system", "⚠ 该 @ 目标不在本机执行器：本机不代跑；请等目标 agent 在它自己的电脑上线处理。")
        if async_mode:
            if send_error:
                return {"ok": False, "room": room, "error": send_error}, 409
            return {"ok": True, "room": room, "message_id": ws_mid, "duplicate": False}
        if send_error:
            return Response(f"send failed: {send_error}", status=409, mimetype="text/plain")
        return redirect(f"/app/chats?room={room}")

    @app.post("/app/post")
    def taa_post():
        title = (request.form.get("title") or "").strip()[:200]
        body = (request.form.get("body") or "").strip()
        link = (request.form.get("link") or "").strip()
        tags = [t.strip() for t in (request.form.get("tags") or "").split(",") if t.strip()]
        try:
            images = [str(u).strip() for u in json.loads(request.form.get("images") or "[]")]
        except Exception:  # noqa: BLE001
            images = []
        images = [u for u in images if u.startswith("/static/uploads/")][:9]
        body_all = body
        if body_all or images:
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c = rw()
            author_id = human_id(c)
            norm = _norm_post(title, body_all)
            for old in c.execute("select id,title,body from posts where author_id=? order by created_at desc limit 500",
                                 (author_id,)).fetchall():
                if _norm_post(old["title"], old["body"]) == norm:
                    c.close()
                    return redirect(f"/app/p/{old['id']}")
            atts = json.dumps([{"url": u, "name": u.rsplit("/", 1)[-1]} for u in images],
                              ensure_ascii=False) if images else None
            back_form = (request.form.get("back") or "/app/feed").strip()
            post_kind = "moment" if (back_form == "/app/moments" or "lobby" in tags or "朋友圈" in tags) else "public_channel"
            c.execute("insert into posts(id,channel_id,author_id,type,title,body,links,tags,status,reuse_count,created_at,updated_at,kind,visibility,attachments) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      ("p-" + os.urandom(4).hex(), "#general", author_id, "note", title, body_all[:40000],
                       json.dumps([link], ensure_ascii=False) if link else None,
                       json.dumps(tags, ensure_ascii=False) if tags else None, "published", 0, now, now, post_kind, "public", atts))
            c.commit(); c.close()
        return redirect(request.form.get("back") or "/app/feed")

    @app.post("/app/fetch-image")
    def taa_fetch_image():
        """t-df77daf8：网页图片粘贴的跨源兜底（服务端抓取，带 SSRF/大小/类型护栏）。"""
        url = (request.form.get("url") or "").strip()
        err = _remote_image_error(url)
        if err:
            return {"ok": False, "error": err}, 400
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 (compatible; TeamAI-image-fetch)",
                          "Accept": "image/*"})
        try:
            with urllib.request.urlopen(req, timeout=8) as resp:
                err = _remote_image_error(resp.geturl())
                if err:
                    return {"ok": False, "error": err}, 400
                raw = resp.read(IMG_MAX_BYTES + 1)
                ctype = (resp.headers.get_content_type() or "").lower()
        except Exception:  # noqa: BLE001
            return {"ok": False, "error": "抓取图片失败"}, 502
        if len(raw) > IMG_MAX_BYTES:
            return {"ok": False, "error": _upload_reject(
                "too_large", name=urllib.parse.urlsplit(url).netloc, ext="(remote)",
                mime=ctype, size=len(raw))}, 413
        if not ctype.startswith("image/"):
            ctype = _sniff_image_type(raw)
        if not ctype:
            return {"ok": False, "error": "目标不是图片"}, 415
        return Response(raw, mimetype=ctype, headers={"Cache-Control": "no-store"})

    @app.get("/app/diag")
    def app_diag():
        """docs/532 · P-E：一键下载脱敏诊断包（等价 `teamai diag export`）。"""
        from core import diag as _diag
        try:
            data = _diag.build_zip()
        except Exception as exc:                                 # noqa: BLE001
            return f"诊断包生成失败：{type(exc).__name__}: {exc}", 500
        stamp = time.strftime("%Y%m%d-%H%M%S")
        return Response(data, mimetype="application/zip", headers={
            "Content-Disposition": f'attachment; filename="taa-diag-{stamp}.zip"',
            "Cache-Control": "no-store"})

    @app.post("/app/upload")
    def taa_upload():
        f = request.files.get("file")
        if not f:
            return {"ok": False, "error": _upload_reject("no_file")}, 400
        ext = pathlib.Path(f.filename or "paste.png").suffix.lower()
        if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
            return {"ok": False, "error": _upload_reject(
                "bad_ext", name=f.filename or "", ext=ext,
                mime=f.mimetype or "")}, 400
        raw = f.read(IMG_MAX_BYTES + 1)
        if len(raw) > IMG_MAX_BYTES:
            # 截断读只能看到「已超限」，真实体积取请求体长度（含 multipart 头，误差百字节级）
            return {"ok": False, "error": _upload_reject(
                "too_large", name=f.filename or "", ext=ext, mime=f.mimetype or "",
                size=int(request.content_length or 0) or len(raw))}, 400
        name = hashlib.sha1(raw).hexdigest()[:16] + ext
        out = ROOT / "static" / "uploads" / name
        out.parent.mkdir(parents=True, exist_ok=True)
        if not out.exists():
            out.write_bytes(raw)
        local_url = f"/static/uploads/{name}"
        transport_url = _transport_image_url(local_url)
        return {"ok": True, "url": local_url, "transport_url": transport_url,
                "bytes": len(raw), "transport_bytes": (ROOT / transport_url.lstrip("/")).stat().st_size
                if transport_url.startswith("/static/") and (ROOT / transport_url.lstrip("/")).is_file() else len(raw)}

    @app.post("/app/react")
    def taa_react():
        post_id = (request.form.get("post") or "").strip()
        emoji = (request.form.get("emoji") or "").strip()[:8]
        back = (request.form.get("back") or "/app/feed").strip()
        if not back.startswith("/app") or back.startswith("//"):
            back = "/app/feed"
        async_mode = request.headers.get("x-taa-async") == "1"
        if not post_id or emoji not in ("👍", "💡", "❤️"):
            if async_mode:
                return {"ok": False, "error": "bad request"}, 400
            return redirect(back)
        mine, count = False, 0
        c = rw()
        try:
            hid = human_id(c)
            row = c.execute("select 1 from reactions where target_type='post' and target_id=? "
                            "and agent_id=? and emoji=?", (post_id, hid, emoji)).fetchone()
            if row:
                c.execute("delete from reactions where target_type='post' and target_id=? "
                          "and agent_id=? and emoji=?", (post_id, hid, emoji))
            else:
                c.execute("insert or ignore into reactions(target_type,target_id,agent_id,emoji) "
                          "values('post',?,?,?)", (post_id, hid, emoji))
                mine = True
            c.commit()
            count = c.execute("select count(*) n from reactions where target_type='post' "
                              "and target_id=? and emoji=?", (post_id, emoji)).fetchone()["n"]
        finally:
            c.close()
        if async_mode:
            return {"ok": True, "post": post_id, "emoji": emoji, "mine": mine, "count": count}
        return redirect(back)

    @app.post("/app/reply")
    def taa_reply():
        post_id = (request.form.get("post") or "").strip()
        body = (request.form.get("body") or "").strip()
        back = (request.form.get("back") or f"/app/p/{post_id}#replies").strip()
        if not back.startswith("/app") or back.startswith("//"):
            back = f"/app/p/{post_id}#replies"
        if post_id and body:
            c = rw()
            try:
                if c.execute("select 1 from posts where id=?", (post_id,)).fetchone():
                    hid = human_id(c)
                    c.execute("insert into replies(post_id,author_id,depth,kind,body,status) "
                              "values(?,?,1,'comment',?,'visible')", (post_id, hid, body[:2000]))
                    c.commit()
            finally:
                c.close()
        return redirect(back)

    @app.post("/app/share")
    def taa_post_share():
        """docs/531：显式「分享到我的朋友圈」（B 案，红心不动）。"""
        post_id = (request.form.get("post") or "").strip()
        back = (request.form.get("back") or "/app/feed").strip()
        if not back.startswith("/app") or back.startswith("//"):
            back = "/app/feed"
        res = {"ok": False, "error": "not_found"}
        if post_id:
            c = rw()
            try:
                from core import post_share
                res = post_share.share_post(c, human_id(c), post_id,
                                           note=request.form.get("note") or "")
            finally:
                c.close()
        if request.headers.get("x-taa-async") == "1":
            code = 200 if res.get("ok") else (403 if res.get("error") == "forbidden" else 400)
            return res, code
        return redirect(back)

    @app.post("/app/unshare")
    def taa_post_unshare():
        """docs/531：移除我的分享（软删 archived；UI 只说「移除」，不说「撤回」）。"""
        sid = (request.form.get("share") or "").strip()
        back = (request.form.get("back") or "/app/moments").strip()
        if not back.startswith("/app") or back.startswith("//"):
            back = "/app/moments"
        res = {"ok": False, "error": "not_found"}
        if sid:
            c = rw()
            try:
                from core import post_share
                res = post_share.unshare_post(c, human_id(c), sid)
            finally:
                c.close()
        if request.headers.get("x-taa-async") == "1":
            code = 200 if res.get("ok") else (403 if res.get("error") == "forbidden" else 400)
            return res, code
        return redirect(back)

    @app.post("/app/settings/lang")
    def taa_lang():
        lang = (request.form.get("lang") or "zh-CN").strip()
        if lang not in i18n.SUPPORTED:
            lang = i18n.DEFAULT
        resp = redirect("/app/settings#ui")
        resp.set_cookie("taa_lang", lang, max_age=31536000, httponly=True, samesite="Lax")
        return resp

    @app.post("/app/settings/key")
    def taa_key():
        from core.config import save_taa_key
        provider = (request.form.get("provider") or "deepseek").strip()
        key = (request.form.get("api_key") or "").strip()
        if key:
            save_taa_key(provider, key)
        return redirect("/app/settings#models")

    @app.post("/app/inbox/read")
    def taa_inbox_read():
        nid = (request.form.get("id") or "").strip()
        c = rw()
        if nid.isdigit():
            c.execute("update notifications set read=1 where id=?", (int(nid),))
        else:
            c.execute("update notifications set read=1 where read=0")
        c.commit(); c.close()
        return redirect("/app/inbox")

    @app.post("/app/board/add")
    def taa_board_add():
        title = (request.form.get("title") or "").strip()
        who = (request.form.get("assignee") or "").strip() or None
        if title:
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c = rw()
            c.execute("insert into tasks(id,title,status,created_by,assigned_to,created_at) values(?,?,?,?,?,?)",
                      ("t-" + os.urandom(4).hex(), title[:200], "backlog", "jiyanjiang", who, now))
            c.commit(); c.close()
        return redirect("/app/board")

    @app.post("/app/board/move")
    def taa_board_move():
        tid = request.form.get("id", "")
        to = request.form.get("to", "")
        if tid:
            # P1.4：看板拖拽不得绕过状态机直写 done（旧实现 update tasks set status='done'）。
            # 拖回 todo 不是评审路径，仍可直写；拖到 done 必须走人工评审 review(approved)。
            from core import tasks as _tasks
            c = rw()
            try:
                row = c.execute("SELECT status FROM tasks WHERE id=?", (tid,)).fetchone()
                if not row:
                    return Response("任务不存在", status=404, mimetype="text/plain; charset=utf-8")
                if to == "todo":
                    c.execute("update tasks set status='backlog' where id=?", (tid,))
                    c.commit()
                else:
                    try:
                        _tasks.review(c, tid, "jiyanjiang", "approved")
                        c.commit()
                    except _tasks.TaskError as e:
                        c.rollback()
                        return Response(
                            f"不能直接标记完成：{e}（当前状态 {row[0]}；"
                            "只有 review 中的任务可被人工批准为 done）",
                            status=409, mimetype="text/plain; charset=utf-8")
                return redirect("/app/board")
            finally:
                c.close()
        return redirect("/app/board")

    @app.post("/app/host/invite")
    def taa_host_invite():
        try:
            if not ipaddress.ip_address(request.remote_addr or "").is_loopback:
                return Response("Host / Client 只能在本机设置", status=403, mimetype="text/plain")
        except ValueError:
            return Response("Host / Client 只能在本机设置", status=403, mimetype="text/plain")
        from core import host_mode
        name = (request.form.get("client_name") or "").strip()[:40]
        oid = (request.form.get("owner_id") or "").strip()[:80]
        if not name:
            return Response("client name required", status=400, mimetype="text/plain")
        if not oid:
            _c = rw()
            try:
                _row = _c.execute("select owner_id from agents where kind='human' and lower(name)=lower(?) "
                                  "and owner_id is not null limit 1", (name,)).fetchone()
                oid = str(_row["owner_id"]) if _row else ""
            finally:
                _c.close()
        if not oid:
            import hashlib as _hash
            oid = "guest-" + _hash.sha1(name.encode("utf-8")).hexdigest()[:12]
        vid = "remote-human-" + oid
        tok = share_token("/app/chats", hours=24 * 7, write=True,
                          viewer_id=vid, viewer_name=name, owner_id=oid)
        url = share_base().rstrip("/") + "/app/s/" + tok
        return redirect("/app/host?invite=" + urllib.parse.quote(url, safe=""))
    @app.route("/app/host", methods=["GET", "POST"])
    def taa_host_mode():
        # Role switching and invite generation are local-admin actions.  A
        # Client holding a writable chat token must never be able to demote
        # the Host or mint another invite.
        try:
            if not ipaddress.ip_address(request.remote_addr or "").is_loopback:
                return Response("Host / Client 只能在本机设置", status=403, mimetype="text/plain")
        except ValueError:
            return Response("Host / Client 只能在本机设置", status=403, mimetype="text/plain")
        from core import host_mode
        if request.method == "POST":
            role = request.form.get("role", "host")
            if role == "client":
                base, token = host_mode.parse_invite(request.form.get("invite", ""))
                if not base:
                    return Response("Host 地址无效", status=400, mimetype="text/plain")
                host_mode.save(role="client", host_url=base, share_token=token)
            else:
                host_mode.save(role="host")
            return redirect("/app/host")
        return page_host_mode()

    @app.get("/app")
    @app.get("/app/")
    def taa_home():
        client = _client_redirect()
        if client is not None:
            return client
        # 手机 = 分发页（docs/329）；桌面仍以会话为操作首页。
        if _is_mobile():
            return Response(page_mobile_home(), mimetype="text/html")
        return redirect("/app/chats")

    @app.get("/app/home")
    def taa_legacy_home():
        # 旧 Home 的内容并入本地 Feed。
        return redirect("/app/feed")

    @app.get("/app/chats")
    def taa_chats():
        client = _client_redirect()
        if client is not None:
            return client
        raw_room = (request.args.get("room") or "").strip()
        if raw_room and not raw_room.startswith("grp_"):
            _c = db()
            try:
                _row = _c.execute("select center_group_id from rooms where id=?", (raw_room,)).fetchone()
                if _row and _row["center_group_id"]:
                    from urllib.parse import quote as _quote
                    return redirect(f"/app/chats?room={_quote(str(_row['center_group_id']), safe='')}")
            finally:
                _c.close()
        r = page_chats()
        return r if isinstance(r, Response) else Response(r, mimetype="text/html")

    @app.get("/app/feed/more")
    def taa_feed_more():
        c = db()
        try:
            off = max(0, int(request.args.get("offset", "0")))
        except ValueError:
            off = 0
        tag = (request.args.get("tag") or "").strip()
        q = (request.args.get("q") or "").strip()[:80]
        rows = _feed_rows(c, tag, off, 10, q)
        return Response("".join(_post_card(r) for r in rows), mimetype="text/html")

    @app.get("/app/graph/<rid>/<int:mid>.png")
    def taa_graph_png(rid: str, mid: int):
        path = ROOT / "rooms" / rid / f"msg-{mid}.png"
        if not path.exists():
            return Response("no graph", status=404)
        return send_file(path, mimetype="image/png")

    @app.get("/app/p/<pid>")
    def taa_post_page(pid: str):
        return page_post(pid)

    @app.get("/app/peer-blob/<sha256>/<path:name>")
    def taa_peer_blob(sha256, name):
        from core import peer_blobs
        try:
            p = peer_blobs.blob_path(sha256)
        except ValueError:
            return Response("bad sha", status=400)
        if not p.is_file():
            return Response("blob not synced", status=404)
        import mimetypes as _mt
        return send_file(p, mimetype=_mt.guess_type(name)[0] or "application/octet-stream",
                         as_attachment=False, download_name=name)

    @app.get("/app/peer-sync")
    def taa_peer_sync():
        return Response(page_peer_sync(), mimetype="text/html")

    @app.get("/app/peer-grants")
    def taa_peer_grants():
        return Response(page_peer_grants(), mimetype="text/html")

    @app.post("/app/peer-grants/decide")
    def taa_peer_grants_decide():
        from core import peer_grants
        c = rw()
        try:
            actor = human_id(c)
            gid = (request.form.get("grant_id") or "").strip()
            action = (request.form.get("action") or "").strip()
            try:
                if action == "approve":
                    peer_grants.approve_grant(c, gid, actor)
                elif action == "revoke":
                    peer_grants.revoke_grant(c, gid, actor)
                else:
                    raise ValueError("bad action")
                return redirect("/app/peer-grants")
            except Exception as e:
                return redirect("/app/peer-grants?err=" + quote(str(e), safe=""))
        finally:
            c.close()

    @app.get("/app/backup")
    def taa_backup_page():
        return Response(page_backup(), mimetype="text/html")

    @app.route("/app/backup/export", methods=["GET", "POST"])
    def taa_backup_export():
        from core import peer_backup
        passphrase = (request.form.get("passphrase") or "").strip() or None
        c = rw()
        try:
            suffix = ".taabak" if passphrase else ".zip"
            out = pathlib.Path(tempfile.mkdtemp(prefix="taa-backup-")) / ("taa-backup" + suffix)
            info = peer_backup.export_bundle(out, c, passphrase=passphrase)
        except Exception as exc:  # noqa: BLE001
            return Response(f"backup failed: {esc(str(exc))}", status=500, mimetype="text/plain")
        finally:
            c.close()
        return send_file(out, as_attachment=True, download_name=out.name,
                         mimetype="application/zip", max_age=0)

    @app.post("/app/backup/save")
    def taa_backup_save():
        from core import peer_backup
        passphrase = (request.form.get("passphrase") or "").strip() or None
        try:
            keep = int(request.form.get("keep") or 7)
        except ValueError:
            keep = 7
        c = rw()
        try:
            info = peer_backup.save_backup(c, passphrase=passphrase, keep=keep)
            msg = f"已保存 {info['name']}（保留 {info['keep']} 份，清理 {info['removed']} 份）"
        except Exception as exc:  # noqa: BLE001
            msg = "保存失败：" + str(exc)
        finally:
            c.close()
        return redirect("/app/backup?msg=" + quote(msg, safe=""))

    @app.post("/app/backup/import")
    def taa_backup_import():
        from core import peer_backup
        f = request.files.get("file")
        if not f:
            return redirect("/app/backup?msg=" + quote("未选择 ZIP", safe=""))
        tmp = pathlib.Path(tempfile.mkdtemp(prefix="taa-backup-in-")) / "upload.zip"
        f.save(tmp)
        passphrase = (request.form.get("passphrase") or "").strip() or None
        c = rw()
        try:
            res = peer_backup.import_bundle(tmp, c, passphrase=passphrase)
            msg = "导入完成：" + ", ".join(f"{k}+{v}" for k, v in res["added"].items())
        except Exception as exc:  # noqa: BLE001
            msg = "导入失败（已拒收）：" + str(exc)
        finally:
            c.close()
        return redirect("/app/backup?msg=" + quote(msg, safe=""))

    @app.get("/app/peer-groups")
    def taa_peer_groups():
        return Response(page_peer_groups(), mimetype="text/html")

    @app.post("/app/peer-groups/sync")
    def taa_peer_groups_sync():
        from core import peer_groups
        c = rw()
        try:
            res = peer_groups.sync_from_env(c)
            msg = f"同步完成：{res.get('groups', 0)} 个组"
        except Exception as exc:  # noqa: BLE001
            msg = "同步失败：" + str(exc)
        finally:
            c.close()
        return redirect("/app/peer-groups?msg=" + quote(msg, safe=""))

    @app.get("/app/feed")
    def taa_feed():
        return Response(page_feed(), mimetype="text/html")

    @app.get("/app/tags")
    def taa_tags():
        return Response(page_tags(), mimetype="text/html")

    @app.get("/app/moments")
    def taa_moments():
        return Response(page_moments(), mimetype="text/html")

    @app.get("/app/inbox")
    def taa_inbox():
        return Response(page_inbox(), mimetype="text/html")

    @app.get("/app/board")
    def taa_board():
        return Response(page_board(), mimetype="text/html")

    @app.get("/app/team")
    def taa_team():
        return Response(page_team(), mimetype="text/html")

    def _updates_json(fn):
        from core import updates
        try:
            data = fn()
        except Exception as exc:  # noqa: BLE001
            data = {"ok": False, "error": str(exc), **updates.status()}
        return Response(json.dumps(data, ensure_ascii=False), mimetype="application/json")

    @app.get("/app/api/peer/storage")
    def taa_peer_storage_api():
        return {"ok": True, **local_upload_stats(), "center_retention_days": 7}

    @app.get("/app/api/peer/status")
    def taa_peer_status_api():
        from core.peer_directory import status as _peer_status
        c = db()
        try:
            return {"ok": True, "nodes": _peer_status(c)}
        finally:
            c.close()

    @app.get("/v1/update/status")
    def taa_update_status_api():
        from core import updates
        return Response(json.dumps({"ok": True, **updates.status()}, ensure_ascii=False),
                        mimetype="application/json")

    @app.post("/v1/update/check")
    def taa_update_check_api():
        from core import updates
        return _updates_json(lambda: updates.start_check(manual=True))

    @app.post("/v1/update/download")
    def taa_update_download_api():
        from core import updates
        return _updates_json(lambda: updates.download(force=True))

    @app.post("/v1/update/apply")
    def taa_update_apply_api():
        from core import updates
        return _updates_json(lambda: updates.apply(manual=True))

    @app.post("/v1/update/settings")
    def taa_update_settings_api():
        from core import updates
        body = request.get_json(silent=True) or request.form or {}
        mode = str(body.get("mode") or "download").strip()
        if mode not in ("notify", "download", "auto"):
            mode = "download"
        st = updates._load()
        st["mode"] = mode
        st["auto_apply"] = mode == "auto"
        updates._save(st)
        return Response(json.dumps({"ok": True, **updates.status()}, ensure_ascii=False),
                        mimetype="application/json")

    @app.post("/app/update/check")
    def taa_update_check():
        from core import updates
        updates.start_check(manual=True)
        return redirect("/app/version#update")

    @app.post("/app/update/download")
    def taa_update_download():
        from core import updates
        updates.download(force=True)
        return redirect("/app/version#update")

    @app.post("/app/update/apply")
    def taa_update_apply():
        from core import updates
        updates.apply(manual=True)
        return redirect("/app/version#update")

    @app.post("/app/settings/update")
    def taa_update_settings():
        from core import updates
        mode = (request.form.get("mode") or "download").strip()
        if mode not in ("notify", "download", "auto"):
            mode = "download"
        st = updates._load()
        st["mode"] = mode
        st["auto_apply"] = mode == "auto"
        updates._save(st)
        return redirect("/app/settings#updates")

    @app.get("/app/version")
    def taa_version():
        return Response(page_version(), mimetype="text/html")

    @app.post("/app/version/proposal")
    def taa_proposal():
        title = (request.form.get("title") or "").strip()[:120]
        if title:
            c = rw()
            try:
                hid = human_id(c)
                c.execute("""insert into improvement_proposals(id,title,source,problem,change,test,risk,status,created_by)
                    values(?,?,?,?,?,?,?,?,?)""",
                    ("R-" + os.urandom(3).hex(), title,
                     (request.form.get("source") or "").strip()[:200],
                     (request.form.get("problem") or "").strip()[:1000],
                     (request.form.get("change") or "").strip()[:1000],
                     (request.form.get("test") or "").strip()[:1000],
                     (request.form.get("risk") or "").strip()[:500], "proposed", hid))
                c.commit()
            finally:
                c.close()
        return redirect("/app/version#proposals")

    @app.get("/app/settings/profile")
    def taa_owner_profile():
        return Response(page_owner_profile(), mimetype="text/html")

    @app.post("/app/settings/profile/locate")
    def taa_owner_profile_locate():
        try:
            state, client, profile = _owner_profile_state()
            from core import weather as weather_mod
            from core import owner_location
            geo = weather_mod.center_geo(state.center.base)
            city = owner_location.normalize_city((geo or {}).get("city", "")) or str((geo or {}).get("city") or "").strip()
            if not city:
                raise RuntimeError("Cloudflare 没有返回城市；请手动填写")
            fields = {
                "display_alias": str(profile.get("display_alias") or profile.get("username") or ""),
                "bio": str(profile.get("bio") or ""),
                "home_location": city,
                "location_visible": "1" if str(profile.get("location_visible", True)).lower() not in ("0", "false", "no", "") else "0",
            }
            client.update_owner_profile(node_key=state.node.node_key, **fields)
            owner_location.set_weather_city(city, source="cloudflare")
        except Exception as exc:  # noqa: BLE001
            return Response(page_owner_profile(error=str(exc)),
                            status=400, mimetype="text/html")
        return redirect("/app/settings/profile?located=1")

    @app.post("/app/settings/profile")
    def taa_owner_profile_save():
        fields = {
            "display_alias": (request.form.get("display_alias") or "").strip()[:40],
            "bio": (request.form.get("bio") or "").strip(),
            "home_location": (request.form.get("home_location") or "").strip()[:40],
            "location_visible": "1" if request.form.get("location_visible") == "1" else "0",
        }
        if len(fields["bio"]) > 500:
            return Response(page_owner_profile(error="简介最多 500 字符", values=fields),
                            status=400, mimetype="text/html")
        try:
            state, client, _ = _owner_profile_state()
            from core import owner_location
            client.update_owner_profile(node_key=state.node.node_key, **fields)
            owner_location.set_weather_city(owner_location.normalize_city(fields["home_location"]),
                                            source="manual")
        except Exception as exc:  # noqa: BLE001
            return Response(page_owner_profile(error=str(exc), values=fields),
                            status=400, mimetype="text/html")
        return redirect("/app/settings/profile?ok=1")

    @app.get("/app/settings")
    def taa_settings():
        return Response(page_settings(), mimetype="text/html")
