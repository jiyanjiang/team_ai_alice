"""中心好友（owner 级）→ 本机可见性（agent 级）的投影（docs/532 · P-B）。

为什么需要它
------------
两套好友模型此前互不相通：
  * 中心站 `owner_friendships`（**owner 级**，approved）是好友真相源；
  * 本机 `friendships`（**agent 级**）只由 `project_members` / `team` 派生。
后果：A 邀请 B、中心已互为好友，但 B 在本机 `/app/feed` 仍看不到 A 的
`visibility='friends'` 帖 —— `docs/531` 的"好友可见"对真人好友等于没接。

做法
----
本模块只落一张小表 `center_friends(owner_id, username, synced_at)`，**不复制 agent 行**：
好友名下的 agent 可能还没同步到本机（要等消息到达才建 stub），
所以判定时按 `agents.owner_id ∈ center_friends` 现算，agent 一出现就自动生效。

边界
----
* 只增/更新，不删（删好友以中心为准，走显式动作，不在这里猜）。
* 只对**本机 owner 一侧**的 viewer 扩展（远端 owner 的好友关系不由本机解释）。
* 取不到本机 owner 身份时**不放宽**（宁可少给，不给错）。
"""

from __future__ import annotations

import sqlite3
import time

_CACHE: dict = {"at": 0.0, "owner": ""}
_CACHE_TTL = 300.0


def ensure_tables(conn) -> None:
    conn.execute("""
        create table if not exists center_friends(
            owner_id      text primary key,
            username      text,
            primary_agent text,
            synced_at     text
        )
    """)


def local_owner_id() -> str:
    """本机绑定的中心 Owner id（取不到返回空串；5 分钟缓存）。"""
    now = time.monotonic()
    if _CACHE["owner"] and now - float(_CACHE["at"] or 0) < _CACHE_TTL:
        return str(_CACHE["owner"])
    owner = ""
    try:
        from pathlib import Path
        import os
        from taa_node_v05.identity import load_state
        home = Path(os.environ.get("TAA_OWNER_HOME") or os.environ.get("TAA_HOME")
                    or os.environ.get("TAA_V05_HOME") or "~/.taa").expanduser()
        state = load_state(home)
        owner = str(getattr(getattr(state, "center", None), "owner_id", "") or "")
    except Exception:                                            # noqa: BLE001
        owner = ""
    _CACHE["at"], _CACHE["owner"] = now, owner
    return owner


def project(conn, friends) -> dict:
    """把中心 approved 好友落表（幂等）。friends 支持 owner_friends() 的返回形状。"""
    ensure_tables(conn)
    n = 0
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    for f in friends or []:
        if not isinstance(f, dict):
            continue
        if str(f.get("status") or "approved") != "approved":
            continue
        oid = str(f.get("owner_id") or f.get("friend_id") or "").strip()
        if not oid:
            continue
        pa = f.get("primary_agent") or {}
        paid = str(pa.get("agent_id") or pa.get("id") or "") if isinstance(pa, dict) else ""
        conn.execute(
            "insert into center_friends(owner_id,username,primary_agent,synced_at) values(?,?,?,?) "
            "on conflict(owner_id) do update set username=coalesce(nullif(excluded.username,''),username), "
            "primary_agent=coalesce(nullif(excluded.primary_agent,''),primary_agent), synced_at=excluded.synced_at",
            (oid, str(f.get("username") or f.get("friend_username") or "")[:120], paid, now),
        )
        n += 1
    if n:
        conn.commit()
    return {"owners": n}


def approved_owners(conn) -> set[str]:
    try:
        return {str(r["owner_id"]) for r in conn.execute("select owner_id from center_friends")}
    except sqlite3.Error:
        return set()


def friend_agents(conn, viewer: str) -> set[str]:
    """viewer 视角下「自己人」的 agent id 集合（viewer 自己除外）。

    两类都算：
      * **同一 owner 名下的其他 agent**：主人与自家 agent 互为自己人。owner 归属是本机
        真相，不依赖中心；缺这条会出现「自家 agent 发的 friends 帖，主人自己反而看不到
        —— 而远端好友那台机器因为把该 agent 当'好友名下 agent'，反倒能看到」的颠倒。
      * **中心 approved 好友名下的 agent**（`center_friends` 投影）：跨机好友全靠这条。
    远端 owner 的 agent 作 viewer 时不吃这些（好友关系由它自己那台机器解释）。
    """
    if not viewer:
        return set()
    try:
        row = conn.execute("select kind, owner_id from agents where id=?", (viewer,)).fetchone()
    except sqlite3.Error:
        return set()
    if row is None:
        return set()
    try:
        v_owner = str(row["owner_id"] or "")
        v_kind = str(row["kind"] or "")
    except (IndexError, KeyError):
        return set()
    mine = local_owner_id()
    # 只有"本机 owner 一侧"的 viewer 才吃这些；远端 owner 的 agent 交给中心判定。
    if v_owner:
        if not mine or v_owner != mine:
            return set()
    elif v_kind != "human":
        return set()

    out: set[str] = set()
    if v_owner:
        try:
            out |= {str(r["id"]) for r in conn.execute(
                "select id from agents where owner_id=? and id<>?", (v_owner, viewer))}
        except sqlite3.Error:
            pass
    owners = approved_owners(conn)
    if owners:
        ph = ",".join("?" * len(owners))
        try:
            out |= {str(r["id"]) for r in conn.execute(
                f"select id from agents where owner_id in ({ph}) and id<>?",
                (*sorted(owners), viewer))}
        except sqlite3.Error:
            pass
    return out
