#!/bin/sh
# TAA 安装器薄壳（2026-11-08 重写）。
#
# 真正的逻辑在 bootstrap.py（跨平台、只用标准库）；本文件只做一件事：
# 找一个 ≥3.11 的解释器，然后把参数原样转交。这样 install.sh 与 install.ps1
# 共用同一份安装逻辑，不会出现"两份代码各自演化"的漂移。
#
# 兼容性：本文件必须是 POSIX sh（Debian/Ubuntu 的 /bin/sh 是 dash），
# 不能出现 pipefail / [[ ]] / 数组。中心 bootstrap 用 `sh -s --` 调它。
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BOOT="$ROOT/bootstrap.py"
[ -f "$BOOT" ] || BOOT="$ROOT/scripts/taa_bootstrap.py"
if [ ! -f "$BOOT" ]; then
  echo "x 包里没有 bootstrap.py（包不完整）：$ROOT" >&2
  exit 2
fi

try() {
  _py="$1"
  shift
  command -v "$_py" >/dev/null 2>&1 || return 1
  "$_py" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' \
    >/dev/null 2>&1 || return 1
  exec "$_py" "$BOOT" "$@"
}

if [ -n "${TAA_PYTHON:-}" ]; then
  try "$TAA_PYTHON" "$@" || true
fi
for p in python3.13 python3.12 python3.11 python3 python; do
  try "$p" "$@" || true
done

# uv 兜底：单文件，自带 Python 下载；离线时这一步会失败，属预期
if command -v uv >/dev/null 2>&1; then
  exec uv run --python 3.12 "$BOOT" "$@"
fi

cat >&2 <<'EOF'
x 需要 Python 3.11+
  macOS  : brew install python@3.12     （或 brew install uv）
  Linux  : sudo apt install python3.12 python3.12-venv
  Windows: winget install Python.Python.3.12（本机请用 install.ps1）
  也可以用 TAA_PYTHON=/path/to/python3.12 指定解释器。
EOF
exit 3
