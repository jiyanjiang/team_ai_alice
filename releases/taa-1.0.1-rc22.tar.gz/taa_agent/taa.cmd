@echo off
rem TAA launcher shim for Windows (2026-11-08).
rem Real logic lives in launcher.py; this only picks an interpreter.
setlocal
set "ROOT=%~dp0"
if defined TAA_HOME (set "H=%TAA_HOME%") else (set "H=%USERPROFILE%\.taa")

set "PY="
if exist "%H%\venv\Scripts\python.exe" set "PY=%H%\venv\Scripts\python.exe"
if not defined PY (
  where py >nul 2>nul && set "PY=py -3"
)
if not defined PY set "PY=python"

%PY% "%ROOT%launcher.py" %*
exit /b %ERRORLEVEL%
