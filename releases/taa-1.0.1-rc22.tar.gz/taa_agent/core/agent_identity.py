"""命名规范：owner 是唯一句柄（不含点），agent 是 `<短名>.<owner>`。

为什么要有这条规范
------------------
跨机事件只带 agent id，而**两台机器的 owner agent 都叫 `human`**。接收端按
id 找人时会直接撞上自己的 owner，于是对端的帖子在自己这边署了本机的名
（Delta 侧把 jiyanjiang 的帖显示成 Owner 就是这么来的）。

名字里带上 owner 句柄后就无歧义了：

* owner：`jiyanjiang`，中心 `owners.username` 唯一，且**禁止出现点号**；
* agent：`alice.jiyanjiang`，点号作分隔符，短名在 owner 内唯一；
* `system` 等系统账号不套规范，它们不属于任何 owner。

事件侧只需把这几个字段带过去（`author_name` / `author_owner` /
`author_owner_name`），接收端直接用，不再本地猜名字。
"""
from __future__ import annotations

MAX_NAME = 64
SEP = "."


def clean_owner(value: str) -> str:
    """owner 句柄：去空白，且不允许点号（点号是 agent 名的分隔符）。"""
    raw = str(value or "").strip()
    if not raw:
        return ""
    return raw.replace(SEP, "-").replace(" ", "").replace("@", "-")[:MAX_NAME]


def valid_owner(value: str) -> bool:
    raw = str(value or "").strip()
    return bool(raw) and SEP not in raw and " " not in raw and "@" not in raw


def agent_name(short: str, owner: str) -> str:
    """`<短名>.<owner>`；短名统一小写，与 `alice.jiyanjiang` 一致。"""
    s = str(short or "").strip().lower().replace(SEP, "-").replace(" ", "")
    o = clean_owner(owner)
    if not s:
        s = "agent"
    if not o:
        return s[:MAX_NAME]
    return f"{s}{SEP}{o}"[:MAX_NAME]


def split_name(name: str) -> tuple[str, str]:
    """`alice.jiyanjiang` → (`alice`, `jiyanjiang`)；没有点则 owner 为空。"""
    raw = str(name or "").strip()
    if SEP not in raw:
        return raw, ""
    short, _, owner = raw.partition(SEP)
    return short, owner


def is_qualified(name: str) -> bool:
    return SEP in str(name or "")


def has_placeholder_owner(name: str) -> bool:
    """`alice.Owner` 的 owner 段是占位符 → 这个署名不可信。"""
    return split_name(name)[1].lower() in _PLACEHOLDER_OWNERS


def is_placeholder_name(value) -> bool:
    """整名就是占位符（`Owner` / `human` / `agent.Owner`）→ 不可作为署名。"""
    text = str(value or "").strip().lower()
    return (text in _PLACEHOLDER_OWNERS
            or text.endswith((".owner", ".human", "@owner", "@human")))


# 占位句柄：老库把真人默认叫 `Owner`/`human`，绝不能当 owner 句柄用，
# 否则本机 agent 会被命名成 `alice.Owner`，全站署名都带上 Owner。
_PLACEHOLDER_OWNERS = {"owner", "human", "leader"}


def _usable_owner(value) -> str:
    name = clean_owner(value)
    if not name or name.lower() in _PLACEHOLDER_OWNERS:
        return ""
    return name


def local_owner_handle(conn) -> str:
    """本机 owner 的句柄（规范：裸用户名，如 `jiyanjiang`）。

    取值顺序：`agents.owner_name`（`repair_agent_owners` 写入真名）→ human 行 name
    → 任一 human 行的 owner_name。占位名一律视为"拿不到"，不做降级猜测。
    """
    try:
        row = conn.execute(
            "SELECT owner_name FROM agents WHERE id='human' AND kind='human'").fetchone()
        if row and _usable_owner(row["owner_name"]):
            return _usable_owner(row["owner_name"])
    except Exception:                                            # noqa: BLE001
        pass
    try:
        row = conn.execute(
            "SELECT name FROM agents WHERE id='human' AND kind='human'").fetchone()
        if row and _usable_owner(row["name"]):
            return _usable_owner(row["name"])
    except Exception:                                            # noqa: BLE001
        pass
    try:
        row = conn.execute(
            "SELECT owner_name FROM agents WHERE kind='human' AND owner_name<>'' "
            "ORDER BY (id='human') DESC LIMIT 1").fetchone()
        if row and _usable_owner(row["owner_name"]):
            return _usable_owner(row["owner_name"])
    except Exception:                                            # noqa: BLE001
        pass
    return ""


def ensure_local_agent_names(conn) -> list[tuple[str, str, str]]:
    """把**本机** AI agent 归一到 `<短名>.<owner>`；返回 [(id, 旧名, 新名)]。

    幂等：已带点的不动。远端 agent 一律不碰——它们的名字由对方自报，
    本地擅自改名只会让两边对不上。
    """
    owner = local_owner_handle(conn)
    if not owner:
        return []
    try:
        rows = conn.execute(
            "SELECT id, name, full_name, owner_name, kind FROM agents "
            "WHERE kind='ai' AND id NOT IN ('system')").fetchall()
    except Exception:                                            # noqa: BLE001
        return []
    changed: list[tuple[str, str, str]] = []
    for r in rows:
        aid = str(r["id"] or "")
        name = str(r["name"] or "").strip()
        old_full = str(r["full_name"] or "").strip()
        oname = str(r["owner_name"] or "").strip()
        if not aid or not name:
            continue
        if is_qualified(name):
            # 历史脏名 `alice.Owner`（owner 句柄曾是占位符）仍要修，不能固化。
            if split_name(name)[1].lower() not in _PLACEHOLDER_OWNERS:
                continue
        # 只归一属于本机的 agent：owner_name 已填且不是本机 owner 的，说明是远端。
        if oname and oname != owner:
            continue
        short = split_name(name)[0] or "agent"
        new = agent_name(short, owner)
        if not new or new == name:
            continue
        # full_name 语义是 `<name>@<node>`：后缀保留，前缀跟着改名。
        suffix = ("@" + old_full.rsplit("@", 1)[1]) if "@" in old_full else "@local"
        full = (new + suffix)[:128]
        try:
            conn.execute("UPDATE agents SET name=?, full_name=? WHERE id=?",
                         (new, full, aid))
        except Exception:                                        # noqa: BLE001
            # full_name 有 UNIQUE 约束：冲突时只改 name，不阻塞其它 agent。
            try:
                conn.execute("UPDATE agents SET name=? WHERE id=?", (new, aid))
            except Exception:                                    # noqa: BLE001
                continue
        changed.append((aid, name, new))
    if changed:
        try:
            conn.commit()
        except Exception:                                        # noqa: BLE001
            pass
    return changed
