"""媒体工具：Bing 搜图 / 火山方舟文生图 / 本地图库 / 网页截图。

密钥来源（优先级）：环境变量（ARK_API_KEY / DASHSCOPE_API_KEY）> 项目 `config.yaml`
的 `providers.ark_api_key` / `providers.dashscope_api_key` > 本地 `~/Downloads/working/api-key.txt`
（+ Loom_City/config.yaml 兜底）。`ark_model` / `ark_endpoint` 同样走 config。
生成/下载的图片落到 static/uploads，返回可放进聊天室的 URL。
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import tarfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from . import redaction

ROOT = Path(__file__).resolve().parent.parent
UPLOAD_DIR = ROOT / "static" / "uploads"

# 可上传附件类型（图片 + 文档/数据/压缩包；db 允许，但须过隐私扫描）
UPLOAD_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg",
               ".mp4", ".webm", ".mov", ".m4v",
               ".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".log",
               ".pdf", ".zip", ".tar", ".gz", ".tgz", ".db", ".sqlite", ".sqlite3",
               ".docx", ".xlsx", ".pptx", ".epub"}
TEXT_EXTS = {".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".log", ".svg"}
UPLOAD_MAX = 50 * 1024 * 1024          # 50MB
# 媒体密钥文件（开发机约定位置）。TAA_KEY_FILE 可覆盖，便于自检/隔离部署；
# 注意这条路径在很多机器上根本不存在，读取必须永远允许失败（见 _read_key_file）。
KEY_FILE = Path(os.environ.get("TAA_KEY_FILE")
                or (Path.home() / "Downloads" / "working" / "api-key.txt")).expanduser()
LOOM_CFG = Path.home() / "Downloads" / "Loom_City" / "config.yaml"
LOCAL_IMAGE_DIRS = [Path.home() / "Downloads" / "reddit" / "images",
                    Path.home() / "Downloads" / "reddit" / "downloads"]

ARK_ENDPOINT = "https://ark.cn-beijing.volces.com/api/v3/images/generations"
ARK_MODEL = "doubao-seedream-4-5-251128"
# 阿里百炼（DashScope）通义万相：异步任务制（提交 → 轮询 → 取 URL）
ALI_IMAGE_ENDPOINT = ("https://dashscope.aliyuncs.com/api/v1/services/aigc/"
                      "text2image/image-synthesis")
ALI_TASK_ENDPOINT = "https://dashscope.aliyuncs.com/api/v1/tasks/"
ALI_IMAGE_MODEL = "wanx2.1-t2i-turbo"
ALI_DEFAULT_SIZE = "1024*1024"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def _read_key_file() -> dict:
    """读本地密钥文件；**任何 IO/权限异常都当"没有这份文件"**。

    2026-11-09 实测事故：`KEYS = _resolve_keys()` 在导入期执行，本机
    `~/Downloads/working/api-key.txt` 存在但不可读（macOS 权限），
    PermissionError 直接让 `core.server` 导入失败 → 整站起不来，
    而安装器只报 "did not become ready"。媒体能力可以降级，启动不能陪葬。
    """
    out = {}
    try:
        if not KEY_FILE.is_file():
            return out
        txt = KEY_FILE.read_text(errors="ignore")
    except OSError:
        return out
    for line in txt.splitlines():
        s = line.strip()
        m = re.search(r"(sk-[A-Za-z0-9]{16,})", s)
        if m and "阿里" in s or (m and ("Tongyi" in s)):
            out.setdefault("dashscope", m.group(1))
        if m and "DeepSeek" in s:
            out["deepseek"] = m.group(1)
        if s.startswith("api-key-"):
            for c in [x.strip().strip('"').strip("'") for x in s.split("|")]:
                if re.match(r"^[0-9a-fA-F-]{32,}$", c) and c.count("-") == 4:
                    out["ark"] = c
        if "AIzaSy" in s:
            mm = re.search(r"(AIzaSy[A-Za-z0-9_\-]{20,})", s)
            if mm:
                out["google"] = mm.group(1)
    # 兜底：Loom_City/config.yaml 的 deepseek（同样是可缺省的外部文件）
    if "deepseek" not in out:
        try:
            if LOOM_CFG.is_file():
                mm = re.search(r'deepseek_api_key:\s*"([^"]+)"',
                               LOOM_CFG.read_text(errors="ignore"))
                if mm:
                    out["deepseek"] = mm.group(1)
        except OSError:
            pass
    return out


def _cfg_provider(field: str, env: str, default=None):
    """读项目 config.yaml 的 `providers.<field>`；环境变量优先（config.get 已处理）。

    只读 config.yaml / 环境变量，不碰本地 api-key 文件（那由 `_read_key_file` 兜底）。
    """
    try:
        from . import config as _config
        return _config.get(f"providers.{field}", default, env=env)
    except Exception:
        return default


def _resolve_keys() -> dict:
    """优先级：环境变量 > config.yaml `providers.*` > 本地 api-key 文件。"""
    out = _read_key_file()
    for name, field, env in (("ark", "ark_api_key", "ARK_API_KEY"),
                             ("dashscope", "dashscope_api_key", "DASHSCOPE_API_KEY")):
        v = _cfg_provider(field, env)
        if v:
            out[name] = str(v).strip()
    # 设置页写入 ~/.taa/config.toml 的 [llm] Key 也要生效。
    try:
        from . import config as _config
        if not out.get("ark") and _config.volcano_key():
            out["ark"] = _config.volcano_key()
        if not out.get("dashscope") and _config.alibaba_key():
            out["dashscope"] = _config.alibaba_key()
    except Exception:
        pass
    return out


def _resolve_keys_safe() -> dict:
    """导入期兜底：密钥解析再出别的意外，也不能让 core.server 整个导入失败。"""
    try:
        return _resolve_keys()
    except Exception:                                            # noqa: BLE001
        return {}


KEYS = _resolve_keys_safe()


def has_key(name: str) -> bool:
    return bool(_resolve_keys_safe().get(name))


def _save_bytes(data: bytes, ext: str = ".png") -> str:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    name = hashlib.sha256(data).hexdigest()[:16] + ext
    (UPLOAD_DIR / name).write_bytes(data)
    return f"/static/uploads/{name}"


def _scan_upload(data: bytes, ext: str) -> dict:
    """对上传内容做隐私扫描：文本直扫；zip/tar 扫成员名+抽检文本；二进制扫原始字节。"""
    findings: list[dict] = []
    if ext in TEXT_EXTS:
        findings += redaction.scan(data[:400000].decode("utf-8", "ignore"))["findings"]
    elif ext == ".zip":
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for n in z.namelist()[:200]:
                    findings += redaction.scan(n)["findings"]
                    try:
                        chunk = z.read(n)[:200000]
                    except Exception:
                        continue
                    enc = "utf-8" if os.path.splitext(n)[1].lower() in TEXT_EXTS else "latin-1"
                    findings += redaction.scan(chunk.decode(enc, "ignore"))["findings"]
        except Exception:
            pass
    elif ext in (".tar", ".gz", ".tgz"):
        try:
            with tarfile.open(fileobj=io.BytesIO(data)) as t:
                for m in t.getmembers()[:200]:
                    findings += redaction.scan(m.name)["findings"]
                    if m.isfile():
                        f = t.extractfile(m)
                        if f:
                            enc = "utf-8" if os.path.splitext(m.name)[1].lower() in TEXT_EXTS else "latin-1"
                            findings += redaction.scan(f.read(200000).decode(enc, "ignore"))["findings"]
        except Exception:
            pass
    else:  # 二进制（db/pdf/docx…）：原始字节扫高危模式
        findings += redaction.scan(data[:400000].decode("latin-1", "ignore"))["findings"]
    counts = {"high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["level"]] += 1
    return {"counts": counts, "findings": findings}


def save_upload(data: bytes, filename: str, *, allow_risky: bool = False) -> dict:
    """保存一个通用附件（图片/文档/数据/压缩包）。含类型/大小/隐私门禁。

    allow_risky=True 时，即使命中 high 风险也放行（但会在返回值里标记 risky，供审计/质检）。
    """
    ext = os.path.splitext(filename or "")[1].lower()
    if ext not in UPLOAD_EXTS:
        raise ValueError(f"unsupported type: {ext or '(none)'}")
    if len(data) > UPLOAD_MAX:
        raise ValueError(f"too large ({len(data)} > {UPLOAD_MAX})")
    rep = _scan_upload(data, ext)
    if rep["counts"]["high"] > 0 and not allow_risky:
        raise ValueError(f"redaction: {rep['counts']['high']} high-risk hit in file (denied)")
    url = _save_bytes(data, ext)
    return {"url": url, "name": filename, "ext": ext, "size": len(data),
            "high": rep["counts"]["high"], "medium": rep["counts"]["medium"],
            "risky": rep["counts"]["high"] > 0}


def _fetch(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": url})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def download_image(url: str) -> str:
    """下载网络图片到 static/uploads，返回本地 URL。"""
    data = _fetch(url, timeout=60)
    ext = os.path.splitext(urllib.parse.urlparse(url).path)[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        ext = ".jpg"
    return _save_bytes(data, ext)


# ------------------------------------------------------------------ 火山方舟文生图
def _ark_model() -> str:
    return str(_cfg_provider("ark_model", "ARK_MODEL", ARK_MODEL) or ARK_MODEL)


def _ark_endpoint() -> str:
    return str(_cfg_provider("ark_endpoint", "ARK_ENDPOINT", ARK_ENDPOINT) or ARK_ENDPOINT)


def ark_generate(prompt: str, size: str = "2K") -> str:
    key = _resolve_keys().get("ark")
    if not key:
        raise RuntimeError("未找到火山方舟密钥：请设环境变量 ARK_API_KEY，或 config.yaml "
                           "providers.ark_api_key，或写入 ~/Downloads/working/api-key.txt")
    body = json.dumps({
        "model": _ark_model(), "prompt": prompt, "response_format": "url",
        "size": size, "watermark": False, "sequential_image_generation": "disabled",
        "stream": False,
    }).encode("utf-8")
    req = urllib.request.Request(_ark_endpoint(), data=body, method="POST", headers={
        "Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    with urllib.request.urlopen(req, timeout=180) as r:
        d = json.loads(r.read().decode())
    items = d.get("data") or []
    if not items:
        raise RuntimeError(f"Ark 未返回图片：{str(d)[:200]}")
    return download_image(items[0]["url"])


# --------------------------------------------------- 阿里百炼（通义万相）文生图
def _ali_image_model() -> str:
    return str(_cfg_provider("ali_image_model", "ALI_IMAGE_MODEL",
                             ALI_IMAGE_MODEL) or ALI_IMAGE_MODEL)


def _normalize_size(size) -> str:
    """万相要 `宽*高`；把调用方惯用的 2K/4K 归一化，其余原样透传。"""
    s = str(size or "").strip().lower()
    if not s or s in ("2k", "4k"):
        return str(_cfg_provider("ali_image_size", "ALI_IMAGE_SIZE",
                                 ALI_DEFAULT_SIZE) or ALI_DEFAULT_SIZE)
    m = re.fullmatch(r"(\d{2,4})\s*[x*]\s*(\d{2,4})", s)
    if m:
        return f"{m.group(1)}*{m.group(2)}"
    return str(_cfg_provider("ali_image_size", "ALI_IMAGE_SIZE",
                             ALI_DEFAULT_SIZE) or ALI_DEFAULT_SIZE)


def ali_generate(prompt: str, size: str = ALI_DEFAULT_SIZE,
                 negative_prompt: str = "", model: str = "",
                 timeout: int = 240) -> str:
    """阿里百炼通义万相出图 → 下载到 static/uploads，返回本地 URL。

    无头 HTTP：提交异步任务（X-DashScope-Async）→ 轮询 → 取 results[0].url。
    密钥只经 `_resolve_keys()` 读取，不打印、不落盘。
    """
    key = _resolve_keys().get("dashscope")
    if not key:
        raise RuntimeError("未找到阿里百炼密钥：请设 DASHSCOPE_API_KEY，或 config.yaml "
                           "providers.dashscope_api_key，或写入 ~/Downloads/working/api-key.txt")
    body = {
        "model": model or _ali_image_model(),
        "input": {"prompt": prompt},
        "parameters": {"size": _normalize_size(size), "n": 1,
                       "prompt_extend": False, "watermark": False},
    }
    if negative_prompt:
        body["input"]["negative_prompt"] = negative_prompt
    headers = {"Content-Type": "application/json",
               "Authorization": f"Bearer {key}",
               "X-DashScope-Async": "enable"}
    req = urllib.request.Request(ALI_IMAGE_ENDPOINT,
                                 data=json.dumps(body).encode("utf-8"),
                                 method="POST", headers=headers)
    with urllib.request.urlopen(req, timeout=90) as r:
        sub = json.loads(r.read().decode())
    task_id = (sub.get("output") or {}).get("task_id")
    if not task_id:
        raise RuntimeError(f"阿里百炼未返回 task_id：{str(sub)[:300]}")

    poll_headers = {"Authorization": f"Bearer {key}"}
    deadline = time.time() + max(10, int(timeout))
    while time.time() < deadline:
        req = urllib.request.Request(ALI_TASK_ENDPOINT + task_id, headers=poll_headers)
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read().decode())
        out = d.get("output") or {}
        st = out.get("task_status")
        if st == "SUCCEEDED":
            results = out.get("results") or []
            if not results or not results[0].get("url"):
                raise RuntimeError(f"阿里百炼任务 {task_id} 成功但无图片")
            return download_image(results[0]["url"])
        if st in ("FAILED", "CANCELED", "UNKNOWN"):
            raise RuntimeError(f"阿里百炼任务 {task_id} 状态 {st}：{str(d)[:300]}")
        time.sleep(3)
    raise RuntimeError(f"阿里百炼任务 {task_id} 超时（{timeout}s）")


def image_engine() -> str:
    """默认出图引擎：ark（火山方舟）> ali（阿里百炼）。可用 config/env 覆盖。"""
    v = str(_cfg_provider("image_engine", "IMAGE_ENGINE", "ark") or "ark").strip().lower()
    return v if v in ("ali", "ark", "auto") else "ark"


def image_provider_available() -> bool:
    """是否已配置 OpenAI 兼容出图端点（`TEAMAI_IMAGE_URL` + `TEAMAI_IMAGE_KEY`）。"""
    from . import image_provider
    return image_provider.available("openai")


def _provider_order(engine: str | None = None) -> list[str]:
    """候选 provider 顺序：显式 engine 优先，其余按配置顺序回退。

    顺序来源：`TEAMAI_IMAGE_PROVIDER_ORDER`（逗号分隔）> 缺省 `ark,ali`；
    若配置了 OpenAI 兼容端点（`TEAMAI_IMAGE_URL` + `TEAMAI_IMAGE_KEY`），自动追加 `openai`。
    老用户（只有火山/阿里 key）顺序不变，行为完全不变。
    """
    from . import image_provider
    raw = (os.environ.get("TEAMAI_IMAGE_PROVIDER_ORDER") or "").strip()
    order = [p.strip().lower() for p in raw.split(",") if p.strip()] or ["ark", "ali"]
    if "openai" not in order and image_provider.available("openai"):
        order.append("openai")
    eng = (engine or image_engine()).strip().lower()
    if eng and eng != "auto":
        order = [eng] + [p for p in order if p != eng]
    return order


def generate_image_with_engine(prompt: str, size: str | None = None,
                               engine: str | None = None,
                               negative_prompt: str = "") -> tuple[str, str]:
    """统一出图入口，返回 (url, 实际 provider)。

    engine: ark | ali | openai | auto | 已注册第三方名。
    逐个 provider 尝试（见 `_provider_order`），全失败才抛错——单家故障不影响出图。
    negative_prompt 仅阿里支持；其余忽略。
    """
    keys = _resolve_keys()
    order = _provider_order(engine)
    errors: list[str] = []
    for name in order:
        if name == "ark":
            if not keys.get("ark"):
                errors.append("ark：未配置密钥")
                continue
            try:
                return ark_generate(prompt, size or "2K"), "ark"
            except Exception as e:  # noqa: BLE001
                errors.append(f"ark：{e}")
        elif name == "ali":
            if not keys.get("dashscope"):
                errors.append("ali：未配置密钥")
                continue
            try:
                return ali_generate(prompt, size or ALI_DEFAULT_SIZE,
                                    negative_prompt=negative_prompt), "ali"
            except Exception as e:  # noqa: BLE001
                errors.append(f"ali：{e}")
        else:
            from . import image_provider
            fn = image_provider.get(name)
            if not fn:
                hint = ("（需 TEAMAI_IMAGE_URL / TEAMAI_IMAGE_KEY）"
                        if name == "openai" else "（未注册，可用 image_provider.register 接入）")
                errors.append(f"{name}：未知 provider{hint}")
                continue
            try:
                # provider 只回远端 URL，落盘仍走这里，存储语义不变
                return download_image(fn(prompt, size=size or "",
                                         negative_prompt=negative_prompt)), name
            except Exception as e:  # noqa: BLE001
                errors.append(f"{name}：{e}")
    if errors and all("未配置密钥" in e for e in errors):
        # 一个 key 都没有：给最短的可行路径，而不是罗列"已尝试 arc/ali"
        raise RuntimeError(
            "未找到生图密钥：请配置火山 ARK_API_KEY 或阿里百炼 DASHSCOPE_API_KEY，"
            "或用 TEAMAI_IMAGE_URL / TEAMAI_IMAGE_KEY 接入自有 OpenAI 兼容服务")
    hint = ""
    if not image_provider_available():
        hint = "；如需接入自有出图服务：设 TEAMAI_IMAGE_URL / TEAMAI_IMAGE_KEY（OpenAI 兼容）"
    raise RuntimeError("出图失败（已尝试 " + "、".join(order) + "）："
                       + "；".join(errors[:4]) + hint)


def generate_image(prompt: str, size: str | None = None,
                   engine: str | None = None, negative_prompt: str = "") -> str:
    """兼容旧调用：只返回图片 URL；需要实际引擎时用 generate_image_with_engine。"""
    return generate_image_with_engine(prompt, size=size, engine=engine,
                                      negative_prompt=negative_prompt)[0]


# ------------------------------------------------------------------ Bing 搜图
def bing_images(query: str, n: int = 8) -> list[str]:
    url = "https://www.bing.com/images/search?q=" + urllib.parse.quote(query) + "&form=HDRSC2&first=1"
    html = _fetch(url, timeout=30).decode("utf-8", "ignore")
    urls = re.findall(r'murl&quot;:&quot;(.*?)&quot;', html)
    if not urls:
        urls = re.findall(r'"murl":"(.*?)"', html)
    out, seen = [], set()
    for u in urls:
        u = u.replace("\\/", "/")
        if u.startswith("http") and u not in seen:
            seen.add(u)
            out.append(u)
        if len(out) >= n:
            break
    return out


# ------------------------------------------------------------------ 本地图库
def local_library(limit: int = 60) -> list[str]:
    files = []
    for d in LOCAL_IMAGE_DIRS:
        if d.exists():
            for p in sorted(d.rglob("*")):
                if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
                    files.append(p)
    return [str(p) for p in files[:limit]]


def local_copy(path: str) -> str:
    p = Path(path)
    if not p.exists() or p.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
        raise ValueError("invalid local image")
    return _save_bytes(p.read_bytes(), p.suffix.lower())


# ------------------------------------------------------------------ 网页截图 / 操作（把网址当工具）
def screenshot(url: str, full: bool = False, wait_ms: int = 2500) -> str:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={"width": 1440, "height": 1000})
        pg.goto(url, wait_until="domcontentloaded", timeout=45000)
        pg.wait_for_timeout(wait_ms)
        png = pg.screenshot(full_page=full)
        b.close()
    return _save_bytes(png, ".png")


def browse(url: str, actions: list | None = None, full: bool = False, wait_ms: int = 2500) -> dict:
    """打开网址并执行操作序列（fill/click/press/wait），返回截图 + 页面文本。

    actions 例：[{"type":"fill","selector":"textarea","value":"..."},
                 {"type":"click","selector":"button:has-text('开始分析')"},
                 {"type":"wait","ms":8000}]
    """
    actions = actions or []
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={"width": 1440, "height": 1000})
        pg.goto(url, wait_until="domcontentloaded", timeout=45000)
        for a in actions:
            t = a.get("type")
            try:
                if t == "fill":
                    pg.fill(a["selector"], a.get("value", ""))
                elif t == "click":
                    pg.click(a["selector"], timeout=15000)
                elif t == "press":
                    pg.press(a.get("selector", "body"), a.get("key", "Enter"))
                elif t == "wait":
                    pg.wait_for_timeout(int(a.get("ms", 1000)))
            except Exception as e:
                print(f"[browse] action {t} failed: {e}")
        pg.wait_for_timeout(wait_ms)
        png = pg.screenshot(full_page=full)
        try:
            text = pg.inner_text("body")[:6000]
        except Exception:
            text = ""
        try:  # 附上页面链接（标题 -> URL），供引用
            links = pg.eval_on_selector_all(
                "a[href]", "els => els.slice(0,80).map(e => "
                "((e.innerText||'').trim().replace(/\\s+/g,' ').slice(0,70) + ' -> ' + e.href))")
            links = [x for x in links if x and not x.startswith(" -> ") and x.split(" -> ")[0]]
            if links:
                text += "\n\n[页面链接（标题 -> URL）]\n" + "\n".join(links[:40])
        except Exception:
            pass
        b.close()
    return {"screenshot": _save_bytes(png, ".png"), "text": text}
