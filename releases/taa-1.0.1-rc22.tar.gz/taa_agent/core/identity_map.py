"""本机节点身份的唯一口径：把 v0.5 身份 ID 与历史主机别名收敛成一个等价类。

为什么需要这一层
----------------
`events` 表长期用 `nodeinfo.detect()["alias"]`（如 `MBP32G`）当 `node_id`，
而握手 / 中心站 `node_key` 用 `identity.json` 的 `node.node_id`（`nod_*`）。
两套 ID 各自自洽，于是「事件里的 node_id」与「身份 ID」长期对不上：
按 node 判归属、防回声、审计都会错位。

事件是 append-only 且带签名，**历史不能被改写**（改 node_id 就会改事件哈希、
签名作废、与中心副本对不上）。所以策略是：

* 新写入统一走 `canonical_node_id()`（优先 `nod_*`，取不到才回落别名）；
* 所有「是不是我自己」的判断统一走 `is_self()`，同时认 `nod_*` 与旧别名。

不要在本模块之外再手写 `node_id == 某个字符串`。
"""
from __future__ import annotations

import os
import pathlib
import threading

_LOCK = threading.RLock()
_CACHE: dict | None = None


def _home() -> pathlib.Path:
    return pathlib.Path(
        os.environ.get("TAA_V05_HOME") or os.environ.get("TAA_HOME") or "~/.taa"
    ).expanduser()


def _identity_node_id() -> str:
    try:
        from taa_node_v05.identity import load_state

        return str(getattr(load_state(_home()).node, "node_id", "") or "").strip()
    except Exception:                                                    # noqa: BLE001
        return ""


def _nodeinfo() -> dict:
    try:
        from . import nodeinfo

        return nodeinfo.detect() or {}
    except Exception:                                                    # noqa: BLE001
        return {}


def _build() -> dict:
    info = _nodeinfo()
    alias = str(info.get("alias") or "").strip()
    hostname = str(info.get("hostname") or "").strip()
    env_alias = str(os.environ.get("TEAM_NODE_ALIAS") or "").strip()
    ident = _identity_node_id()

    # canonical 优先身份 ID；未认领的机器只能退回别名（等认领后自动收敛）。
    canonical = ident or alias or hostname or "node"

    order = [canonical, ident, alias, env_alias, hostname]
    seen: set[str] = set()
    aliases: list[str] = []
    for item in order:
        key = str(item or "").strip()
        if not key:
            continue
        low = key.lower()
        if low in seen:
            continue
        seen.add(low)
        aliases.append(key)
    return {"canonical": canonical, "aliases": tuple(aliases)}


def load() -> dict:
    """返回 `{"canonical": str, "aliases": tuple[str, ...]}`（进程内缓存）。"""
    global _CACHE
    with _LOCK:
        if _CACHE is None:
            _CACHE = _build()
        return _CACHE


def reset() -> None:
    """清缓存（测试 / 换身份后热更新用）。"""
    global _CACHE
    with _LOCK:
        _CACHE = None


def canonical_node_id() -> str:
    return str(load()["canonical"])


def aliases() -> tuple[str, ...]:
    return tuple(load()["aliases"])


def is_self(node_id) -> bool:
    """`node_id` 是否指向本机（兼容 `nod_*` 与历史别名 / 主机名）。"""
    nid = str(node_id or "").strip().lower()
    if not nid:
        return False
    return nid in {a.lower() for a in aliases()}


def same_node(a, b) -> bool:
    """两个 node_id 是否指同一节点（都必须是本机别名之一）。"""
    return is_self(a) and is_self(b)
