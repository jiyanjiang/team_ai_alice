"""群附件加密容器（TAAE v1）。

设计目标
--------
* **一个 CEK，两段密文**：元信息（文件名 / MIME）与正文各自独立 nonce，
  共用同一把随机 CEK；CEK 逐成员用 X25519 信封各封一份（与群消息同构）。
* **自带魔数**：没有 `TAAE` 头的字节一律视为升级前的明文附件，走原流程，
  升级不需要迁移历史文件。
* **文件名也加密**：只加密正文、把文件名留在 HTTP 头里，等于遮一半。

容器布局（全部大端）::

    magic  4B  "TAAE"
    ver    1B
    nonce_meta 12B
    nonce_data 12B
    meta_len 4B | meta_ct
    data_len 4B | data_ct
    keys_len 4B | keys_json

* `meta_ct` 解开是 JSON `{"name": ..., "mime": ...}`；
* `data_ct` 解开就是原始文件字节；
* `keys_json` 是 `{node_id: <encrypt_for 信封>}`，与群消息的 keys 同构。

约束（与群消息一致，不得放宽）
------------------------------
* 缺公钥的成员**跳过**，调用方必须提示「该成员收不到」，绝不回落明文；
* 一个收件人都没有 → 调用方不应调用本模块；
* 解密失败一律抛异常，由调用方显示「无法解密」，不猜内容、不落空文件。
"""
from __future__ import annotations

import json
import os
import struct
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from taa_node_v05.crypto import b64d, b64e, decrypt, encrypt_for

MAGIC = b"TAAE"
VERSION = 1

#: 明文上限（对用户口径是 2MB，实际放宽到 3MB）
MAX_PLAIN_BYTES = 3 * 1024 * 1024
#: 容器上限：3MB 明文 + base64/JSON 膨胀 + 每成员一份 CEK 信封
MAX_WIRE_BYTES = 4 * 1024 * 1024 + 512 * 1024

_HDR = struct.Struct(">4sB12s12s")
_LEN = struct.Struct(">I")
_MAX_META = 64 * 1024
_MAX_KEYS = 256 * 1024


def is_container(raw: bytes | bytearray | memoryview) -> bool:
    """字节串是否是 TAAE 容器（只看魔数，不做完整性判断）。"""
    try:
        return len(raw) >= _HDR.size and bytes(raw[:4]) == MAGIC
    except Exception:                                                # noqa: BLE001
        return False


def seal(recipients: dict[str, str], data: bytes,
         name: str = "", mime: str = "") -> bytes:
    """加密一份附件，返回 TAAE 容器字节。

    `recipients = {node_id: enc_pubkey}`；公钥为空/缺失的成员被跳过，
    调用方必须把这些人显式告知用户。
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("data must be bytes-like")
    cek = os.urandom(32)
    aead = AESGCM(cek)
    nonce_meta, nonce_data = os.urandom(12), os.urandom(12)

    meta = json.dumps({
        "name": str(name or "")[:200],
        "mime": str(mime or "")[:120],
    }, ensure_ascii=False).encode("utf-8")
    meta_ct = aead.encrypt(nonce_meta, meta, None)
    data_ct = aead.encrypt(nonce_data, bytes(data), None)

    keys: dict[str, Any] = {}
    for node_id, pub in (recipients or {}).items():
        if not pub:
            continue
        keys[str(node_id)] = encrypt_for(pub, b64e(cek))
    keys_blob = json.dumps(keys, ensure_ascii=False).encode("utf-8")

    out = bytearray()
    out += _HDR.pack(MAGIC, VERSION, nonce_meta, nonce_data)
    out += _LEN.pack(len(meta_ct))
    out += meta_ct
    out += _LEN.pack(len(data_ct))
    out += data_ct
    out += _LEN.pack(len(keys_blob))
    out += keys_blob
    return bytes(out)


def _take_len(raw: bytes, off: int, limit: int) -> tuple[int, int]:
    if off + _LEN.size > len(raw):
        raise ValueError("truncated_container")
    (n,) = _LEN.unpack_from(raw, off)
    off += _LEN.size
    if n < 0 or n > limit or off + n > len(raw):
        raise ValueError("bad_section_length")
    return n, off


def open_blob(raw: bytes, node_id: str,
              private_b64: str) -> tuple[bytes, str, str]:
    """解开一份 TAAE 附件，返回 `(data, name, mime)`。

    失败一律抛异常（`ValueError` 格式问题 / `KeyError` 没有本机密钥 /
    `InvalidTag` 密文被改），由调用方转成「无法解密」。
    """
    if not is_container(raw):
        raise ValueError("not_a_container")
    magic, ver, nonce_meta, nonce_data = _HDR.unpack_from(raw, 0)
    if magic != MAGIC:
        raise ValueError("bad_magic")
    if int(ver) != VERSION:
        raise ValueError("unsupported_container_version")

    off = _HDR.size
    mlen, off = _take_len(raw, off, _MAX_META)
    meta_ct = raw[off:off + mlen]
    off += mlen
    dlen, off = _take_len(raw, off, len(raw))
    data_ct = raw[off:off + dlen]
    off += dlen
    klen, off = _take_len(raw, off, _MAX_KEYS)
    keys_blob = raw[off:off + klen]

    keys: dict[str, Any] = {}
    if keys_blob:
        keys = json.loads(keys_blob.decode("utf-8"))
    env = (keys or {}).get(str(node_id))
    if not env:
        raise KeyError("no_key_for_node")

    cek = b64d(decrypt(env, private_b64))
    aead = AESGCM(cek)
    meta = json.loads(aead.decrypt(nonce_meta, meta_ct, None).decode("utf-8") or "{}")
    data = aead.decrypt(nonce_data, data_ct, None)
    return data, str(meta.get("name") or ""), str(meta.get("mime") or "")
