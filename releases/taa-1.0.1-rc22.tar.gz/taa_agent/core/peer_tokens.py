"""本机持有的对端凭据（正规 grant 路线的**请求方**一侧）。

为什么不放进 data.db：

`core.peer_grants` 里那张 `peer_grants` 表存的是 `token_hash` —— 那是**校验方**
的视角（对方带明文来，我比哈希）。而本机作为**请求方**必须自己保留一份明文，
后续才能带着它去拉对方的事件（`/v1/peer/events`）。

明文一旦混进业务库就会跟着走：data.db 会被导出、备份、随升级包分发。
所以令牌单独放 `$TAA_HOME/peer_tokens.json`，文件权限 0600，按 node_id 索引；
撤销或轮换时删条目即可。

两条硬约束：
  1) 明文**只进不出**：本模块不提供"取全部明文"的接口，列表一律掩码；
  2) 与 `TAA_PEER_TOKEN` 明确分开 —— 那个是本地/测试用的 wildcard，
     设了就绕过 grant（`scopes=["*"]`），正规路线下必须保持不设。
"""
from __future__ import annotations

import json
import os
import pathlib
import secrets

FILE_NAME = "peer_tokens.json"
MIN_TOKEN_LEN = 16


def _path() -> pathlib.Path:
    """凭据文件路径：与其它本机私有文件同住 TAA_HOME（唯一口径）。"""
    from .db import taa_home
    return pathlib.Path(taa_home()).expanduser() / FILE_NAME


def _read() -> dict:
    p = _path()
    try:
        raw = p.read_text(encoding="utf-8")
    except FileNotFoundError:
        return {}
    except OSError:
        return {}
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write(data: dict) -> None:
    """原子写 + 0600：先写同目录临时文件再 replace，避免半截 JSON。"""
    p = _path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(f".{FILE_NAME}.{secrets.token_hex(4)}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1, sort_keys=True)
        os.replace(tmp, p)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass


def get_token(node_id: str) -> str:
    """取某节点的明文令牌；没有则空串（调用方据此跳过该节点，不整体停摆）。"""
    nid = str(node_id or "").strip()
    if not nid:
        return ""
    entry = _read().get(nid)
    if not isinstance(entry, dict):
        return ""
    return str(entry.get("token") or "")


def get_base(node_id: str) -> str:
    """取登记时记下的对端地址（通常是 web 端口）；没有则空串。

    与 `get_token` 分开：拉取层只需要地址来排候选顺序，不需要碰明文。
    """
    nid = str(node_id or "").strip()
    if not nid:
        return ""
    entry = _read().get(nid)
    if not isinstance(entry, dict):
        return ""
    return str(entry.get("base") or "")


def set_token(node_id: str, token: str, *, grant_id: str = "",
              owner: str = "", base: str = "") -> dict:
    """登记/更新本机对某节点的令牌。返回掩码后的条目（便于日志与 UI）。"""
    nid = str(node_id or "").strip()
    raw = str(token or "").strip()
    if not nid:
        raise ValueError("node_id required")
    if len(raw) < MIN_TOKEN_LEN:
        raise ValueError(f"token must be at least {MIN_TOKEN_LEN} chars")
    data = _read()
    entry = {
        "token": raw,
        "grant_id": str(grant_id or "").strip(),
        "owner": str(owner or "").strip(),
        "base": str(base or "").strip().rstrip("/"),
    }
    data[nid] = entry
    _write(data)
    return mask_entry(nid, entry)


def delete_token(node_id: str) -> bool:
    """撤销/轮换时删除；不存在返回 False（幂等，不报错）。"""
    nid = str(node_id or "").strip()
    data = _read()
    if nid not in data:
        return False
    data.pop(nid, None)
    _write(data)
    return True


def mask(token: str) -> str:
    """只露首尾各 4 位：日志/UI 里绝不出现完整令牌。"""
    raw = str(token or "")
    if len(raw) <= 12:
        return "*" * len(raw)
    return f"{raw[:4]}…{raw[-4:]}"


def mask_entry(node_id: str, entry: dict | None = None) -> dict:
    e = entry if isinstance(entry, dict) else (_read().get(str(node_id)) or {})
    return {
        "node_id": str(node_id or ""),
        "token": mask(str(e.get("token") or "")),
        "grant_id": str(e.get("grant_id") or ""),
        "owner": str(e.get("owner") or ""),
        "base": str(e.get("base") or ""),
    }


def list_masked() -> list[dict]:
    """列出本机持有的令牌（**掩码**）。供诊断页/CLI 展示用。"""
    return [mask_entry(nid, entry) for nid, entry in sorted(_read().items())
            if isinstance(entry, dict)]


def new_token() -> str:
    """生成 32 字节随机令牌（64 hex），满足 request_grant 的 ≥16 长度要求。"""
    return secrets.token_hex(32)
