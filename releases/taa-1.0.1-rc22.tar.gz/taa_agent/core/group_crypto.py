"""群聊 E2EE 的本地胶水：取成员公钥（缓存）、封、解。

模型（与 1:1 一致，以**机器**为单位）：
- 每台机器一个 X25519 密钥对，公钥在中心登记（register / claim 时上报）；
- 发送方为每条消息生成随机 CEK，正文用 AES-GCM 加密，再对每个成员的 node 公钥
  各封一份 CEK；中心只搬密文；
- 换机器不迁移历史：旧消息用旧机私钥加密，新机读不到是**设计选择**，UI 会明说。

失败语义（重要）：
- 一个成员公钥都拿不到 → 抛错，调用方**不发送**（保持本地待同步），绝不回落明文；
- 部分成员缺公钥 → 照常发送，但返回 missing 列表，调用方要显式提示"这些人收不到"。
"""
from __future__ import annotations

import time
from typing import Any

from taa_node_v05.crypto import open_from, seal_for_many

_KEY_TTL = 60.0
_cache: dict[str, tuple[float, dict[str, str], list[str]]] = {}


def member_keys(st, client, gid: str, refresh: bool = False
                ) -> tuple[dict[str, str], list[str]]:
    """返回 (recipients{node_id: pub}, missing_owner_ids)。

    60 秒缓存：群消息可能连发多条，不必每条都问一次中心。
    """
    now = time.time()
    hit = _cache.get(gid)
    if hit and not refresh and now - hit[0] < _KEY_TTL:
        return hit[1], hit[2]
    data = client.group_member_keys(node_key=st.node.node_key, group_id=gid)
    recipients: dict[str, str] = {}
    missing: list[str] = []
    for m in data.get("members") or []:
        owner_id = str(m.get("owner_id") or "")
        node_id = str(m.get("node_id") or "")
        pub = str(m.get("enc_pubkey") or "")
        if node_id and pub:
            recipients[node_id] = pub
        elif owner_id:
            missing.append(owner_id)
    _cache[gid] = (now, recipients, missing)
    return recipients, missing


def seal_group(st, client, gid: str, text: str
               ) -> tuple[str, dict[str, Any], list[str]]:
    """加密一条群消息，返回 (body_enc, keys, missing_owner_ids)。"""
    recipients, missing = member_keys(st, client, gid)
    if not recipients:
        raise RuntimeError("no_recipient_keys")
    body_enc, keys = seal_for_many(recipients, text)
    return body_enc, keys, missing


def open_group(m: dict, st) -> str:
    """解开一条中心来的群消息；解不开时抛异常，由调用方显示"无法解密"。"""
    node_id = str(st.node.node_id or "")
    priv = str(st.node.enc_privkey or "")
    if not node_id or not priv:
        raise KeyError("no_local_key")
    return open_from(str(m.get("body_enc") or ""), m.get("keys") or {}, node_id, priv)
