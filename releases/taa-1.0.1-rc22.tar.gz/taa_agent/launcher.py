#!/usr/bin/env python3
"""TAA 本地启动器（跨平台）—— 取代 274 行 bash 版 `taa`。

为什么必须重写（2026-11-08）：
bash 版依赖 `nohup` / `kill -TERM -pgid` / `ps` / `lsof`，Windows 没有对等语义；
"发行包要能在 Windows 原生跑（不装 Git Bash）"就要求启动路径也是跨平台的。
平台差异（venv 路径、进程组、detach、浏览器打开）全部走 `taa_plat`。

**输出关键字不要改**：安装器、升级器、自检脚本都按
`TAA_ALREADY_RUNNING=` / `LOCAL_UI_STARTED=` / `AGENTS_STARTED=` 这些行判定。

用法：taa [start|open|status|stop|url] [--no-open] [--no-agents] [--port N]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import taa_plat as plat  # noqa: E402

ROOT = Path(__file__).resolve().parent
HOME_DIR = Path(os.environ.get("TAA_HOME") or plat.default_home())
PORT = int(os.environ.get("TAA_HTTP_PORT") or 6080)
URL = f"http://127.0.0.1:{PORT}/app/bridge"
RUN_DIR = HOME_DIR / "run"
PID_FILE = RUN_DIR / "web.pid"
LOG = RUN_DIR / "web.log"


def _lock_pid(lock: Path) -> int:
    """读 `.supervisor.<agent>.lock` 里的 pid；兼容纯 pid 与 JSON 两种格式。

    兼容性缺口的代价（docs/546 C6）：`int(raw)` 遇到 JSON 会 ValueError → 被吞成 0，
    于是"活着的锁"被当成死锁，`stop` 里甚至会 `lock.unlink()` 把活锁删掉。
    """
    try:
        raw = (lock.read_text(encoding="utf-8") or "").strip()
    except OSError:
        return 0
    if not raw:
        return 0
    if raw.startswith("{"):
        try:
            return max(0, int((json.loads(raw) or {}).get("pid") or 0))
        except (TypeError, ValueError):
            return 0
    try:
        return max(0, int(raw))
    except ValueError:
        return 0


def _py() -> str:
    """启动用的解释器：TAA_PYTHON → 本机 venv → 当前解释器。"""
    explicit = (os.environ.get("TAA_PYTHON") or "").strip()
    if explicit and plat.probe_python(explicit):
        return explicit
    vp = plat.venv_python(HOME_DIR / "venv")
    if plat.probe_python(vp):
        return str(vp)
    return sys.executable


def health(timeout: float = 1.0) -> dict | None:
    try:
        with plat.no_proxy_opener().open(f"http://127.0.0.1:{PORT}/v1/health", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:                            # noqa: BLE001
        return None


def is_taa() -> bool:
    h = health()
    return bool(h) and h.get("service") == "teamai"


def wait_ready(timeout: float = 30.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if is_taa():
            return True
        time.sleep(0.2)
    return False


def doc(name: str) -> dict:
    p = HOME_DIR / name
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:                            # noqa: BLE001
        return {}


def agent_ids() -> list[str]:
    out: list[str] = []
    for a in doc("identity.json").get("agents") or []:
        aid = str((a or {}).get("agent_id") or "").strip()
        if aid and aid not in out:
            out.append(aid)
    return out


def host_bind() -> str:
    return "127.0.0.1" if str(doc("host.json").get("role") or "") == "client" else "0.0.0.0"


def agent_base() -> str:
    h = doc("host.json")
    if h.get("role") == "client" and h.get("host_url"):
        return str(h["host_url"]).rstrip("/")
    return f"http://127.0.0.1:{PORT}"


def _ensure_data_dirs() -> None:
    """把 agents / bootstrap / static/uploads 收拢到 TAA_HOME 并做链接。

    实现放在 taa_plat（安装器与启动器共用一份，避免逻辑漂移）。
    """
    for rel in plat.ensure_data_dirs(ROOT, HOME_DIR):
        print(f"[warn] {rel} 无法建链接，已复制回 app 目录（占用额外空间）", file=sys.stderr)


def _bootstrap_db(py: str) -> None:
    db = Path(os.environ.get("TEAMAI_DB") or (HOME_DIR / "data.db"))
    if db.exists() and db.stat().st_size > 0:
        return
    env = plat.local_env()
    env.update({"TAA_HOME": str(HOME_DIR),
                "TEAMAI_DB": str(db),
                "TEAMAI_UI_DB": str(db),
                "TEAMAI_EVENTS_DB": str(Path(os.environ.get("TEAMAI_EVENTS_DB") or (HOME_DIR / "events.db")))})
    import subprocess
    subprocess.run([py, "-c", "from core import bootstrap; bootstrap.bootstrap()"],
                   cwd=str(ROOT), env=env, capture_output=True, text=True)


def start_agents(py: str, base: str) -> None:
    if (os.environ.get("TAA_START_AGENTS") or "1") != "1":
        print("AGENTS_STARTED=NO")
        return
    ids = agent_ids()
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    if not ids:
        print("AGENTS_STARTED=NO")
        print("AGENTS_HINT=no-local-agent-key")
        return
    for a in ids:
        pidf = RUN_DIR / f"agent-{a}.pid"
        lock = ROOT / "runtime" / f".supervisor.{a}.lock"
        # lock 是权威：自更新/重启可能留下过期 pidfile
        if lock.exists():
            lockpid = _lock_pid(lock)
            if lockpid and plat.is_alive(lockpid):
                pidf.write_text(str(lockpid), encoding="utf-8")
                print(f"AGENT_ALREADY_RUNNING={a} pid={lockpid}")
                continue
        if pidf.exists():
            try:
                old = int((pidf.read_text(encoding="utf-8") or "0").strip() or 0)
            except Exception:                    # noqa: BLE001
                old = 0
            if old and plat.is_alive(old):
                same = lock.exists() and (lock.read_text(encoding="utf-8").strip() == str(old))
                if same:
                    print(f"AGENT_ALREADY_RUNNING={a} pid={old}")
                    continue
                print(f"AGENT_MIGRATE={a} old_pid={old} (chatroom-only -> supervisor)")
                plat.kill_tree(old)
                time.sleep(0.3)
                plat.kill_tree(old, force=True)
            pidf.unlink(missing_ok=True)
        env = plat.local_env()
        env.update({"TAA_HOME": str(HOME_DIR), "TEAMAI_URL": base, "TEAMAI_HTTP_PORT": str(PORT)})
        pid = plat.spawn_detached(
            [py, str(ROOT / "runtime" / "supervisor.py"), "--as", a, "--role", "executor",
             "--interval", "30", "--url", base, "--no-autoupdate"],
            cwd=ROOT, log_path=RUN_DIR / f"agent-{a}.log", env=env)
        pidf.write_text(str(pid), encoding="utf-8")
        print(f"AGENT_STARTED={a} pid={pid}")
    print("AGENTS_STARTED=YES")


def stop_agents() -> None:
    for pidf in sorted(RUN_DIR.glob("agent-*.pid")):
        a = pidf.stem[len("agent-"):]
        lock = ROOT / "runtime" / f".supervisor.{a}.lock"
        pid = 0
        try:
            pid = int((pidf.read_text(encoding="utf-8") or "0").strip() or 0)
        except Exception:                        # noqa: BLE001
            pid = 0
        if lock.exists():
            try:
                lockpid = int((lock.read_text(encoding="utf-8") or "0").strip() or 0)
            except Exception:                    # noqa: BLE001
                lockpid = 0
            if lockpid and plat.is_alive(lockpid):
                pid = lockpid
        if pid and plat.is_alive(pid):
            plat.kill_tree(pid)                  # supervisor 是进程组组长：连子进程一起停
            time.sleep(0.5)
            plat.kill_tree(pid, force=True)
            print(f"AGENT_STOPPED={a} pid={pid}")
        pidf.unlink(missing_ok=True)
    for lock in ROOT.glob("runtime/.supervisor.*.lock"):
        pid = _lock_pid(lock)                    # JSON/纯 pid 都认，避免误删活锁
        if not pid or not plat.is_alive(pid):
            lock.unlink(missing_ok=True)


def agent_status() -> None:
    n = live = 0
    for pidf in sorted(RUN_DIR.glob("agent-*.pid")):
        n += 1
        try:
            pid = int((pidf.read_text(encoding="utf-8") or "0").strip() or 0)
        except Exception:                        # noqa: BLE001
            pid = 0
        if pid and plat.is_alive(pid):
            live += 1
            print(f"AGENT_RUNNING={pidf.stem[len('agent-'):]} pid={pid}")
    print(f"AGENT_PROCESSES={n}")
    print(f"AGENT_RUNNING_COUNT={live}")


def do_start(no_open: bool) -> int:
    py = _py()
    base = agent_base()
    if is_taa():
        print("TAA_ALREADY_RUNNING=YES")
        print(f"LOCAL_UI_URL={URL}")
        start_agents(py, base)
        if not no_open:
            plat.open_url(URL)
        return 0
    if health() is not None:
        print(f"x port {PORT} is used by another service", file=sys.stderr)
        return 2

    RUN_DIR.mkdir(parents=True, exist_ok=True)
    _ensure_data_dirs()
    _bootstrap_db(py)

    env = plat.local_env()
    env.update({"TAA_HOME": str(HOME_DIR),
                "TAA_V05_HOME": os.environ.get("TAA_V05_HOME") or str(HOME_DIR),
                "TAA_HTTP_PORT": str(PORT),
                "TAA_HTTP_HOST": os.environ.get("TAA_HTTP_HOST") or host_bind(),
                "TAA_PYTHON": py})
    pid = plat.spawn_detached(
        [py, "-m", "core.server", "serve", "--host", env["TAA_HTTP_HOST"],
         "--port", str(PORT), "--no-bootstrap"],
        cwd=ROOT, log_path=LOG, env=env)
    PID_FILE.write_text(str(pid), encoding="utf-8")
    if not wait_ready():
        print(f"x local TAA did not become ready; see {LOG}", file=sys.stderr)
        try:
            lines = LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-30:]
            print("\n".join(lines), file=sys.stderr)
        except Exception:                        # noqa: BLE001
            pass
        return 1
    print("LOCAL_UI_STARTED=YES")
    print(f"LOCAL_UI_URL={URL}")
    start_agents(py, base)
    if not no_open:
        plat.open_url(URL)
    return 0


def do_stop() -> int:
    stop_agents()
    pid = 0
    if PID_FILE.exists():
        try:
            pid = int((PID_FILE.read_text(encoding="utf-8") or "0").strip() or 0)
        except Exception:                        # noqa: BLE001
            pid = 0
    if pid and plat.is_alive(pid):
        plat.kill_tree(pid)
        time.sleep(0.5)
        plat.kill_tree(pid, force=True)
    PID_FILE.unlink(missing_ok=True)
    print("LOCAL_UI_STOPPED=YES")
    return 0


def do_status() -> int:
    if is_taa():
        print("LOCAL_UI_RUNNING=YES")
        print(f"LOCAL_UI_URL={URL}")
        if PID_FILE.exists():
            print(f"LOCAL_UI_PID={(PID_FILE.read_text(encoding='utf-8') or '').strip()}")
        agent_status()
    else:
        print("LOCAL_UI_RUNNING=NO")
        print(f"LOCAL_UI_URL={URL}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="taa", description="TAA 本地启动器（跨平台）")
    ap.add_argument("action", nargs="?", default="start",
                    choices=["start", "open", "status", "stop", "url"])
    ap.add_argument("--no-open", action="store_true", help="不自动打开浏览器")
    ap.add_argument("--no-agents", action="store_true", help="只起服务，不起 agent")
    ap.add_argument("--port", type=int, default=None, help="覆盖端口（默认 6080）")
    a = ap.parse_args(argv)

    global PORT, URL
    if a.port:
        PORT = int(a.port)
        URL = f"http://127.0.0.1:{PORT}/app/bridge"
    if a.no_agents:
        os.environ["TAA_START_AGENTS"] = "0"

    if a.action in ("start", "open"):
        return do_start(no_open=a.no_open and a.action == "start")
    if a.action == "stop":
        return do_stop()
    if a.action == "status":
        return do_status()
    print(URL)
    return 0


if __name__ == "__main__":
    sys.exit(main())
