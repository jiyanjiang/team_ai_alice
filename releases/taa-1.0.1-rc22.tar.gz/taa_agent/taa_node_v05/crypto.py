"""X25519 + AES-GCM message envelopes.

Private keys are local-only. The center receives ciphertext envelopes and
public keys, never plaintext.
"""
from __future__ import annotations

import base64
import json
import os
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ENVELOPE_VERSION = 1


def b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def generate_keypair() -> tuple[str, str]:
    private = X25519PrivateKey.generate()
    private_raw = private.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return b64e(private_raw), b64e(public_raw)


def public_from_private(private_b64: str) -> str:
    private = X25519PrivateKey.from_private_bytes(b64d(private_b64))
    return b64e(private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    ))


def _derive(shared: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"taa-v05-mailbox",
        info=b"x25519-aesgcm",
    ).derive(shared)


def encrypt_for(recipient_public_b64: str, plaintext: str) -> dict[str, Any]:
    recipient = X25519PublicKey.from_public_bytes(b64d(recipient_public_b64))
    ephemeral = X25519PrivateKey.generate()
    shared = ephemeral.exchange(recipient)
    key = _derive(shared)
    nonce = os.urandom(12)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext.encode("utf-8"), None)
    ephemeral_public = ephemeral.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return {
        "v": ENVELOPE_VERSION,
        "alg": "x25519-aesgcm",
        "epk": b64e(ephemeral_public),
        "nonce": b64e(nonce),
        "ct": b64e(ciphertext),
    }


def decrypt(envelope: dict[str, Any] | str, recipient_private_b64: str) -> str:
    if isinstance(envelope, str):
        envelope = json.loads(envelope)
    if int(envelope.get("v") or 0) != ENVELOPE_VERSION or envelope.get("alg") != "x25519-aesgcm":
        raise ValueError("unsupported envelope")
    recipient = X25519PrivateKey.from_private_bytes(b64d(recipient_private_b64))
    ephemeral = X25519PublicKey.from_public_bytes(b64d(str(envelope["epk"])))
    shared = recipient.exchange(ephemeral)
    key = _derive(shared)
    plaintext = AESGCM(key).decrypt(b64d(str(envelope["nonce"])), b64d(str(envelope["ct"])), None)
    return plaintext.decode("utf-8")


# ---- 群聊（一对多）：一条消息一个 CEK，按成员公钥各封一份 ----
GROUP_ENVELOPE_VERSION = 1


def seal_for_many(recipients: dict[str, str], plaintext: str) -> tuple[str, dict[str, Any]]:
    """群聊加密：返回 (body_enc, keys)。

    recipients = {node_id: enc_pubkey}。公钥为空/缺失的成员**跳过**——调用方必须
    把这些人显式告知用户（"该成员收不到"），绝不因此回落明文。
    body_enc 是 JSON 字符串（中心不解析内容，只搬运）。
    """
    cek = os.urandom(32)
    nonce = os.urandom(12)
    ct = AESGCM(cek).encrypt(nonce, plaintext.encode("utf-8"), None)
    payload = {"v": GROUP_ENVELOPE_VERSION, "alg": "aesgcm-cek",
               "nonce": b64e(nonce), "ct": b64e(ct)}
    keys: dict[str, Any] = {}
    for node_id, pub in recipients.items():
        if not pub:
            continue
        keys[str(node_id)] = encrypt_for(pub, b64e(cek))
    return json.dumps(payload, ensure_ascii=False), keys


def open_from(body_enc: str, keys: dict[str, Any] | str,
              my_node_id: str, recipient_private_b64: str) -> str:
    """群聊解密：用自己 node 的信封解出 CEK，再解正文。"""
    if isinstance(keys, str):
        keys = json.loads(keys) if keys else {}
    if isinstance(body_enc, str):
        body_enc = json.loads(body_enc)
    env = (keys or {}).get(str(my_node_id))
    if not env:
        raise KeyError("no_key_for_node")
    cek = b64d(decrypt(env, recipient_private_b64))
    return AESGCM(cek).decrypt(b64d(str(body_enc["nonce"])),
                               b64d(str(body_enc["ct"])), None).decode("utf-8")


# ---- 附件（二进制）：同一套 CEK 信封，正文按 bytes 处理 ----
#
# 与 seal_for_many 的唯一区别是**不做 utf-8 编码**，也不要求调用方先 base64：
# 附件动辄 MB 级，base64 会凭空膨胀 33%，正好吃掉附件大小阈值。
# 信封的 alg 单独标记，避免文本/二进制两种信封被误用。

BYTES_ALG = "aesgcm-cek-bytes"


def seal_bytes_for_many(recipients: dict[str, str],
                        data: bytes) -> tuple[str, dict[str, Any]]:
    """附件加密：返回 (body_enc, keys)，语义与 `seal_for_many` 完全一致。

    * `recipients = {node_id: enc_pubkey}`；公钥缺失的成员**跳过**，
      调用方必须显式提示「该成员收不到」，绝不因此回落明文；
    * `body_enc` 仍是 JSON 字符串（中心只搬运、不解析）；
    * 空数据允许通过（0 字节附件是合法输入，但调用方通常已在更早处拦截）。
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("data must be bytes-like")
    cek = os.urandom(32)
    nonce = os.urandom(12)
    ct = AESGCM(cek).encrypt(nonce, bytes(data), None)
    payload = {"v": GROUP_ENVELOPE_VERSION, "alg": BYTES_ALG,
               "nonce": b64e(nonce), "ct": b64e(ct)}
    keys: dict[str, Any] = {}
    for node_id, pub in recipients.items():
        if not pub:
            continue
        keys[str(node_id)] = encrypt_for(pub, b64e(cek))
    return json.dumps(payload, ensure_ascii=False), keys


def open_bytes_from(body_enc: str | dict[str, Any], keys: dict[str, Any] | str,
                    my_node_id: str, recipient_private_b64: str) -> bytes:
    """附件解密：用自己 node 的信封解出 CEK，返回原始字节。

    与 `open_from` 的差异：**校验 alg**，拒绝解文本信封，避免把消息正文
    当附件落盘；失败一律抛异常，由调用方显示「无法解密」，不猜内容。
    """
    if isinstance(keys, str):
        keys = json.loads(keys) if keys else {}
    if isinstance(body_enc, str):
        body_enc = json.loads(body_enc)
    if not isinstance(body_enc, dict):
        raise ValueError("bad_envelope")
    if str(body_enc.get("alg") or "") != BYTES_ALG:
        raise ValueError("not_a_bytes_envelope")
    env = (keys or {}).get(str(my_node_id))
    if not env:
        raise KeyError("no_key_for_node")
    cek = b64d(decrypt(env, recipient_private_b64))
    return AESGCM(cek).decrypt(b64d(str(body_enc["nonce"])),
                               b64d(str(body_enc["ct"])), None)
