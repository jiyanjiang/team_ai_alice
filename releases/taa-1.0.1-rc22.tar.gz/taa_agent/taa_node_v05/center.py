"""Minimal HTTP client for the v0.5 center API."""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class CenterError(RuntimeError):
    def __init__(self, status: int, body: dict[str, Any] | str):
        self.status = status
        self.body = body
        super().__init__(f"center HTTP {status}: {body}")


class CenterClient:
    def __init__(self, base: str, timeout: int = 15):
        self.base = base.rstrip("/")
        self.timeout = timeout

    def _request(self, method: str, path: str, body: dict[str, Any] | None = None,
                 token: str = "") -> dict[str, Any]:
        headers = {
            "content-type": "application/json",
            "accept": "application/json",
            "user-agent": "TAA-Node/0.5.1",
        }
        if token:
            headers["authorization"] = "Bearer " + token
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return json.loads(raw.decode("utf-8")) if raw else {}
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "ignore")
            try:
                parsed: dict[str, Any] | str = json.loads(raw)
            except json.JSONDecodeError:
                parsed = raw[:500]
            raise CenterError(exc.code, parsed) from exc
        except urllib.error.URLError as exc:
            raise CenterError(0, str(exc)) from exc

    def register_node(self, *, node_id: str, node_key: str, alias: str,
                      fingerprint_hash: str, version: str = "0.5.1",
                      enc_pubkey: str = "") -> dict[str, Any]:
        return self._request("POST", "/v05/node/register", {
            "node_id": node_id,
            "node_key": node_key,
            "alias": alias,
            "fingerprint_hash": fingerprint_hash,
            "version": version,
            "enc_pubkey": enc_pubkey,
        })

    def owner_register(self, *, username: str, password: str, email: str = "",
                       ref: str = "") -> dict[str, Any]:
        body: dict[str, Any] = {"username": username, "password": password, "email": email}
        if ref:
            body["ref"] = ref
        return self._request("POST", "/v05/owner/register", body)

    def username_available(self, *, username: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v05/owner/username-available?username=" + urllib.parse.quote(username),
        )

    def owner_profile(self, *, node_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/profile", None, node_key)

    def update_owner_profile(self, *, node_key: str, **fields: Any) -> dict[str, Any]:
        return self._request("PATCH", "/v05/owner/profile", fields, node_key)

    def owner_login(self, *, username: str, password: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/login", {
            "username": username, "password": password,
        })

    def claim_node(self, *, owner_token: str, claim_token: str) -> dict[str, Any]:
        return self._request("POST", "/v05/node/claim", {"claim_token": claim_token}, owner_token)

    def node_me(self, *, node_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/node/me", None, node_key)

    def refresh_claim(self, *, node_key: str) -> dict[str, Any]:
        return self._request("POST", "/v05/node/claim-token", {}, node_key)

    def heartbeat(self, *, node_key: str, endpoint: str = "", version: str = "0.5.1",
                  app: str = "", endpoints: list[dict[str, str]] | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"endpoint": endpoint, "version": version}
        if app:
            body["app"] = app
        if endpoints:
            body["endpoints"] = endpoints
        return self._request("POST", "/v05/node/heartbeat", body, node_key)

    def register_agent(self, *, node_key: str, agent_id: str, agent_key: str,
                       display_name: str) -> dict[str, Any]:
        return self._request("POST", "/v05/agent/register", {
            "agent_id": agent_id, "agent_key": agent_key, "display_name": display_name,
        }, node_key)

    def rename_agent(self, *, node_key: str, agent_id: str,
                     display_name: str) -> dict[str, Any]:
        return self._request("POST", "/v05/agent/rename", {
            "agent_id": agent_id, "display_name": display_name,
        }, node_key)

    def set_primary_agent(self, *, node_key: str, agent_id: str) -> dict[str, Any]:
        """声明本 owner 的对外代表（首席）。中心侧保证同一 owner 只有一个。"""
        return self._request("POST", "/v05/agent/primary", {
            "agent_id": agent_id,
        }, node_key)

    def agent_me(self, *, agent_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/agent/me", None, agent_key)

    def reset_owner_password(self, *, node_id: str, node_key: str, password: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/reset-password", {
            "node_id": node_id, "node_key": node_key, "password": password,
        })

    def lookup_agent(self, *, agent_key: str, agent_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/agent/lookup?agent_id={urllib.parse.quote(agent_id)}",
                             None, agent_key)

    def send_encrypted(self, *, agent_key: str, to_agent_id: str,
                       ciphertext: dict[str, Any] | str) -> dict[str, Any]:
        return self._request("POST", "/v05/agent/send", {
            "to_agent_id": to_agent_id, "ciphertext": ciphertext,
        }, agent_key)

    def inbox(self, *, agent_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/agent/inbox", None, agent_key)

    def presence(self, *, owner_token: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/presence", None, owner_token)

    def friend_request(self, *, owner_token: str, to_owner_id: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/friends/request",
                             {"to_owner_id": to_owner_id}, owner_token)

    def friend_approve(self, *, owner_token: str, from_owner_id: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/friends/approve",
                             {"from_owner_id": from_owner_id}, owner_token)

    def friends(self, *, owner_token: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/friends", None, owner_token)

    def friend_nodes(self, *, owner_token: str, owner_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/owner/friends/{owner_id}/nodes", None, owner_token)

    def friends_for_node(self, *, node_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/friends", None, node_key)

    def notices_for_node(self, *, node_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/owner/notices", None, node_key)

    def mark_notices_read_for_node(self, *, node_key: str,
                                   notice_ids: list[str] | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if notice_ids:
            body["notice_ids"] = notice_ids
        return self._request("POST", "/v05/owner/notices/read", body, node_key)

    def notice_ack_state(self, *, node_key: str,
                         scope: str = "collab_plaintext") -> dict[str, Any]:
        """R-01：查询"跨组织明文边界"是否已签收（GET /v05/owner/notice-ack）。

        注意与三件易混的东西区分：
        - `/v05/owner/notices`：系统通知（未读/已读），不是这个；
        - `group_command.pending_consent`：跨机执行同意（10s 窗口），也不是这个；
        - 本方法：用户是否知道"跨组织群消息在中心是明文"。
        """
        return self._request("GET", f"/v05/owner/notice-ack?scope={scope}", None, node_key)

    def notice_ack(self, *, node_key: str,
                   scope: str = "collab_plaintext") -> dict[str, Any]:
        return self._request("POST", "/v05/owner/notice-ack", {"scope": scope}, node_key)

    def friend_request_for_node(self, *, node_key: str, to_owner_id: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/friends/request",
                             {"to_owner_id": to_owner_id}, node_key)

    def friend_approve_for_node(self, *, node_key: str, from_owner_id: str) -> dict[str, Any]:
        return self._request("POST", "/v05/owner/friends/approve",
                             {"from_owner_id": from_owner_id}, node_key)

    def grant_node(self, *, owner_token: str, node_id: str, grantee_owner_id: str,
                   scopes: list[str]) -> dict[str, Any]:
        return self._request("POST", "/v05/node/grant", {
            "node_id": node_id, "grantee_owner_id": grantee_owner_id, "scopes": scopes,
        }, owner_token)

    def catalog(self, *, owner_token: str, node_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/node/{node_id}/catalog", None, owner_token)

    def create_group(self, *, owner_token: str, name: str,
                     member_owner_ids: list[str] | None = None) -> dict[str, Any]:
        return self._request("POST", "/v05/collab/groups", {
            "name": name, "member_owner_ids": member_owner_ids or [],
        }, owner_token)

    def groups(self, *, owner_token: str) -> dict[str, Any]:
        return self._request("GET", "/v05/collab/groups", None, owner_token)

    def groups_for_node(self, *, node_key: str) -> dict[str, Any]:
        return self._request("GET", "/v05/collab/groups", None, node_key)

    def group_for_node(self, *, node_key: str, group_id: str) -> dict[str, Any]:
        return self._request("GET", "/v05/collab/groups/" + urllib.parse.quote(group_id, safe=""),
                             None, node_key)

    def create_group_for_node(self, *, node_key: str, name: str,
                              member_owner_ids: list[str],
                              member_agent_ids: list[str] | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "member_owner_ids": member_owner_ids}
        if member_agent_ids:
            body["member_agent_ids"] = member_agent_ids
        return self._request("POST", "/v05/collab/groups", body, node_key)

    def add_group_member_for_node(self, *, node_key: str, group_id: str,
                                  owner_id: str, agent_id: str = "") -> dict[str, Any]:
        return self._request("POST", f"/v05/collab/groups/{urllib.parse.quote(group_id, safe='')}/members",
                             {"owner_id": owner_id, "agent_id": agent_id}, node_key)

    def friend_nodes_for_node(self, *, node_key: str, owner_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/owner/friends/{urllib.parse.quote(owner_id, safe='')}/nodes",
                             None, node_key)

    def rename_group_for_node(self, *, node_key: str, group_id: str, name: str) -> dict[str, Any]:
        return self._request("POST", f"/v05/collab/groups/{urllib.parse.quote(group_id, safe='')}/name",
                             {"name": name}, node_key)

    def group_messages_for_node(self, *, node_key: str, group_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/collab/groups/{urllib.parse.quote(group_id, safe='')}/messages",
                             None, node_key)

    def send_group_message_for_node(self, *, node_key: str, group_id: str,
                                    body: str, agent_id: str = "",
                                    client_message_id: str = "",
                                    attachments: list[str] | None = None,
                                    reply_to: str = "",
                                    body_enc: str = "",
                                    keys: dict[str, Any] | None = None,
                                    enc_v: int = 0,
                                    sender_node_id: str = "") -> dict[str, Any]:
        payload: dict[str, Any] = {"body": body, "agent_id": agent_id}
        if client_message_id:
            payload["client_message_id"] = client_message_id
        if attachments:
            payload["attachments"] = attachments
        if reply_to:
            payload["reply_to"] = reply_to
        # 群聊 E2EE：有密文就把明文位置留空，中心只搬密文。
        if body_enc:
            payload["body"] = ""
            payload["body_enc"] = body_enc
            payload["keys"] = keys or {}
            payload["enc_v"] = enc_v or 1
            if sender_node_id:
                payload["sender_node_id"] = sender_node_id
        return self._request("POST", f"/v05/collab/groups/{urllib.parse.quote(group_id, safe='')}/messages",
                             payload, node_key)

    def group_member_keys(self, *, node_key: str, group_id: str) -> dict[str, Any]:
        """取群成员公钥（群聊 E2EE 的收件人目录）。"""
        return self._request(
            "GET",
            f"/v05/collab/groups/{urllib.parse.quote(group_id, safe='')}/keys",
            None, node_key)

    def upload_group_file_for_node(self, *, node_key: str, group_id: str,
                                   name: str, data: bytes,
                                   content_type: str = "application/octet-stream") -> dict[str, Any]:
        path = f"/v05/collab/groups/{urllib.parse.quote(group_id, safe='')}/files"
        req = urllib.request.Request(self.base + path, data=data, method="POST", headers={
            "Authorization": "Bearer " + node_key,
            "content-type": content_type or "application/octet-stream",
            "x-taa-filename": name[:120],
            "content-length": str(len(data)),
            "accept": "application/json",
            "user-agent": "TAA-CenterClient/1",
        })
        try:
            with urllib.request.urlopen(req, timeout=max(self.timeout, 30)) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8")
            except Exception:
                body = str(exc)
            raise CenterError(exc.code, body) from exc

    def add_group_member(self, *, owner_token: str, group_id: str,
                         owner_id: str = "", agent_id: str = "") -> dict[str, Any]:
        body: dict[str, Any] = {"owner_id": owner_id, "agent_id": agent_id}
        return self._request("POST", f"/v05/collab/groups/{group_id}/members", body, owner_token)

    def group(self, *, owner_token: str, group_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v05/collab/groups/{group_id}", None, owner_token)
