"""跨局域网朋友圈 · 中心站信箱客户端（P2P 直连失败时的兜底）。

与 hub_client.py 的分工
-----------------------
* `hub_client.py`：面向**自建 hub**（`core/hub.py` 起的 Flask 服务），
  协议 `/v1/hub/*`、`X-Hub-Token`、按 token 分组。
* 本模块：面向**中心站**（alice.loomsci.com），协议 `/v05/hub/*`、
  `Authorization: Bearer <node_key>`、按 `owner_friendships` 过滤好友。

为什么要有第二个客户端
----------------------
自建 hub 需要一个公网可跑的进程；中心站本身就是常开的公网节点，
且它知道谁是好友，隐私可以在服务端切开，不必靠接收端自律。

两条铁律
--------
1. **P2P 优先**：直连能通时，事件走直连；中心只做兜底。
   推送总是增量进行（每条事件只推一次），拉取则只在「存在非 direct 对端」时才做。
2. **24 小时**：中心过期即删，不做补拉。本地拿不到就永久没有，这是明确取舍。

与 hub_client 的另一个关键差异
------------------------------
`hub_client._pull()` 只做 `log.merge()`，事件进了 `events.db` 却永远不会
变成 `posts` 行。本模块在 merge 之后补 `peer_sync.apply_events()`，
这才是「好友能看见」的最后一步。
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime

UA = "taa-center-hub/1"
PUSH_CURSOR = "center_hub_push_rowid"
PULL_CURSOR = "center_hub_pull_seq"

# 与中心站 src/hub.ts 的 HUB_EVENT_TYPES 必须一致；不一致会被中心判 invalid。
HUB_TYPES = frozenset({"post.created", "reply.created", "post.deleted"})

MAX_PAYLOAD_BYTES = 8000          # 中心硬限 8KB，这里留一点余量
MAX_EVENT_ID = 120


def _bytes(obj) -> int:
    return len(json.dumps(obj, ensure_ascii=False).encode("utf-8"))


def _iso_to_ts(v) -> float:
    """中心存的是 ISO8601；本地 events.ts 是 REAL。"""
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except Exception:                                        # noqa: BLE001
        return time.time()


def _shrink(payload: dict) -> dict | None:
    """把 payload 压到中心上限以内；压不下来返回 None（该条跳过）。

    顺序：分享快照正文 → 正文 → 附件。每步都留 `_trimmed` 标记，
    让接收端知道这是一条被裁剪过的事件，而不是内容本来就这么短。
    """
    p = dict(payload or {})
    if _bytes(p) <= MAX_PAYLOAD_BYTES:
        return p

    snap = p.get("share_snapshot")
    if isinstance(snap, dict) and snap.get("body"):
        s = dict(snap)
        s["body"] = str(s["body"])[:200]
        p["share_snapshot"] = s
        if _bytes(p) <= MAX_PAYLOAD_BYTES:
            p["_trimmed"] = "share_snapshot"
            return p

    body = str(p.get("body") or "")
    while body and _bytes(p) > MAX_PAYLOAD_BYTES:
        body = body[: max(1, int(len(body) * 0.8))]
        p["body"] = body
    if _bytes(p) <= MAX_PAYLOAD_BYTES:
        p["_trimmed"] = "body"
        return p

    p["attachments"] = []
    p["_trimmed"] = "attachments"
    return p if _bytes(p) <= MAX_PAYLOAD_BYTES else None


def _norm_incoming(e: dict) -> dict | None:
    """中心返回的扁平结构 → events 表期望的形状。"""
    eid = str(e.get("id") or "").strip()
    typ = str(e.get("type") or "").strip()
    if not eid or not typ:
        return None
    return {
        "id": eid[:MAX_EVENT_ID],
        "lamport": int(e.get("lamport") or 0),
        # 只认事件原本的 node_id；0062 之前写入中心的老行此列为空，就保持为空，
        # 由 _pull 的闸门拦在 posts 之外。用 owner_id 冒充 node_id 正是老 bug 的一半
        # （回传事件带着别人的 node_id，签名必然对不上，整批被拒）。
        "node_id": str(e.get("node_id") or "")[:80],
        "type": typ,
        "payload": e.get("payload") if isinstance(e.get("payload"), dict) else {},
        "ts": _iso_to_ts(e.get("ts")),
    }


class CenterHubClient:
    """只出站的中心站信箱客户端；任何失败都不影响本机。"""

    def __init__(self, log, conn_factory, base: str, node_key: str, *,
                 owner_id: str = "", interval: float = 15.0, batch: int = 100,
                 timeout: float = 12.0, force_pull: bool = False):
        self.log = log
        self.conn_factory = conn_factory
        self.base = (base or "").rstrip("/")
        self.node_key = (node_key or "").strip()
        # 自己推上去的事件没必要再拉回来：省流量，也避免重复 apply。
        self.owner_id = (owner_id or "").strip()
        self.node_id = str(getattr(log, "node_id", "") or "").strip()
        # 联调开关：直连正常时也强制拉中心（验证跨机链路用，平时关闭）。
        self.force_pull = bool(force_pull)
        self.interval = max(3.0, float(interval or 15))
        self.batch = max(1, min(int(batch or 100), 200))
        self.timeout = max(3.0, float(timeout or 12))

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._last_ok = 0.0
        self._last_error = ""
        self._pushed = 0
        self._pulled = 0
        self._applied = 0
        # 中心里 node_id 为空的事件（部署 0062 之前写入的旧行）来源不明：
        # 留在事件日志可追溯，但绝不折叠成 posts。
        self._skipped_no_node = 0
        self._ticks = 0
        self._fail_streak = 0

    # ---------------- 生命周期 ----------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="center-hub", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=3)

    def _loop(self) -> None:
        while not self._stop.is_set():
            ok = self.tick()
            self._fail_streak = 0 if ok else min(self._fail_streak + 1, 4)
            delay = self.interval * (2 ** self._fail_streak if self._fail_streak else 1)
            self._stop.wait(min(delay, self.interval * 8))

    # ---------------- 一轮 ----------------
    def tick(self) -> bool:
        with self._lock:
            self._ticks += 1
        try:
            self._push()
            if self._need_pull():
                self._pull()
        except Exception as e:                               # noqa: BLE001
            with self._lock:
                self._last_error = f"{type(e).__name__}: {str(e)[:180]}"
            return False
        with self._lock:
            self._last_ok = time.time()
            self._last_error = ""
        return True

    def _need_pull(self) -> bool:
        """P2P 优先：所有对端都直连正常时，不占用中心流量。

        只要存在一个 `direct_status != 'direct'` 的对端（离线/跨网/探测失败），
        就开启中心拉取 —— 中心会返回全部好友事件，重复的由 events 主键去重。
        """
        if self.force_pull:
            return True
        conn = self.conn_factory()
        try:
            rows = conn.execute("SELECT direct_status FROM peer_nodes").fetchall()
        except Exception:                                    # noqa: BLE001
            return True
        finally:
            conn.close()
        if not rows:
            return True                                      # 一个对端都没有：先拉，等握手后自然判定
        for r in rows:
            try:
                st = str(r["direct_status"] or "")
            except (IndexError, KeyError, TypeError):
                return True
            if st != "direct":
                return True
        return False

    # ---------------- 推送 ----------------
    def _push(self) -> None:
        cursor = int(self.log.meta_get(PUSH_CURSOR, 0) or 0)
        for _ in range(5):
            events, new_cursor = self.log.own_since(cursor, self.batch)
            if not events:
                return
            batch = []
            for e in events:
                typ = str(e.get("type") or "")
                if typ not in HUB_TYPES:
                    continue
                payload = _shrink(e.get("payload") or {})
                if payload is None:
                    continue
                batch.append({
                    "id": str(e.get("id") or "")[:MAX_EVENT_ID],
                    "type": typ,
                    "lamport": int(e.get("lamport") or 0),
                    # 必须带原始 node_id：中心只按 owner 分组，若不带，
                    # 对端拉回时会把它当成 node_id，导致自己的事件回传后被判"无签名"。
                    "node_id": str(e.get("node_id") or "")[:80],
                    "payload": payload,
                })
            if batch:
                d = self._post("/v05/hub/events", {"events": batch})
                with self._lock:
                    self._pushed += int(d.get("accepted") or 0)
            # 无论本批有没有可推事件，游标都要前进，否则会卡在同一批。
            self.log.meta_set(PUSH_CURSOR, new_cursor)
            cursor = int(new_cursor)
            if len(events) < self.batch:
                return

    # ---------------- 拉取 ----------------
    def _pull(self) -> None:
        cursor = int(self.log.meta_get(PULL_CURSOR, 0) or 0)
        for _ in range(5):
            d = self._get(f"/v05/hub/events?since={cursor}&limit={self.batch}")
            raw = d.get("events") or []
            norm = [x for x in (_norm_incoming(e) for e in raw) if x]
            # 防回声：自己和本节点产生的事件不该再被处理一遍。
            # 这些事件本来就没有签名，混进来会让整批被 peer_sign 判拒。
            # 本机历史上用过别名（MBP32G）作 node_id，故用等价类而不是单值。
            from . import identity_map
            mine = {v for v in (self.owner_id, self.node_id, *identity_map.aliases()) if v}
            if mine:
                norm = [x for x in norm if x["node_id"] not in mine]
            # 0062 之前写入中心的行 node_id 为空：来源不明，直接丢弃（不写事件日志、
            # 不折叠成 posts）。空 node_id 一旦进库，回传时就是一串"无签名外来事件"。
            valid = [x for x in norm if str(x.get("node_id") or "").strip()]
            skipped = len(norm) - len(valid)
            if valid:
                try:
                    self.log.merge(valid)
                except Exception:                            # noqa: BLE001
                    # 事件日志写失败不阻塞后续 apply：本地帖子表才是用户可见的部分。
                    pass
                applied = self._apply(valid)
                with self._lock:
                    self._applied += applied
            with self._lock:
                self._pulled += len(norm)
                self._skipped_no_node += skipped
            nxt = int(d.get("next_since") or cursor)
            self.log.meta_set(PULL_CURSOR, nxt)
            cursor = nxt
            if not d.get("more"):
                return

    def _apply(self, events: list[dict]) -> int:
        """merge 之后的关键一步：把事件折叠成 posts / replies 行。

        少了这一步，事件只躺在 events.db 里，`/app/moments` 永远看不到。
        """
        if not events:
            return 0
        conn = self.conn_factory()
        try:
            from . import peer_sync
            return int(peer_sync.apply_events(conn, events) or 0)
        except Exception as e:                               # noqa: BLE001
            with self._lock:
                self._last_error = f"apply: {type(e).__name__}: {str(e)[:140]}"
            return 0
        finally:
            try:
                conn.close()
            except Exception:                                # noqa: BLE001
                pass

    # ---------------- HTTP ----------------
    def _headers(self) -> dict:
        return {"content-type": "application/json", "user-agent": UA,
                "authorization": "Bearer " + self.node_key}

    def _post(self, path: str, body: dict) -> dict:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.base + path, data=data, method="POST",
                                     headers=self._headers())
        return self._open(req)

    def _get(self, path: str) -> dict:
        req = urllib.request.Request(self.base + path, headers=self._headers())
        return self._open(req)

    def _open(self, req) -> dict:
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = (e.read().decode("utf-8", "ignore") or "")[:180]
            except Exception:                                # noqa: BLE001
                pass
            raise RuntimeError(f"center hub HTTP {e.code}: {detail}") from e

    # ---------------- 状态 ----------------
    def status(self) -> dict:
        with self._lock:
            now = time.time()
            return {
                "enabled": True,
                "base": self.base,
                "connected": bool(self._last_ok and now - self._last_ok < self.interval * 4),
                "last_ok_at": self._last_ok or None,
                "last_error": self._last_error,
                "push_cursor": int(self.log.meta_get(PUSH_CURSOR, 0) or 0),
                "pull_cursor": int(self.log.meta_get(PULL_CURSOR, 0) or 0),
                "pushed": self._pushed,
                "pulled": self._pulled,
                "applied": self._applied,
                "skipped_no_node": self._skipped_no_node,
                "ticks": self._ticks,
            }


def node_key_from_identity() -> str:
    """从 ~/.taa/identity.json 取本机 node_key；取不到返回空串。"""
    try:
        from taa_node_v05.identity import load_state
        import os
        import pathlib
        home = pathlib.Path(os.environ.get("TAA_HOME", "~/.taa")).expanduser()
        state = load_state(home)
        return str(getattr(getattr(state, "node", None), "node_key", "") or "")
    except Exception:                                        # noqa: BLE001
        return ""
