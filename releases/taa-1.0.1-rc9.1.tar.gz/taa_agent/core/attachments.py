"""附件 manifest（docs/specs/alice_personal/16 §3.2 / §4）。

一句话：**消息只存引用，内容按 sha256 寻址，状态单独记。**

四条口径：

  * **内容寻址**：`attachment_blobs` 以 sha256 为主键，同一份文件只登记一次；
    `ref_count` 记"有几条消息在用它"，GC 只清没人引用的。
  * **消息侧幂等**：`message_attachment` 上 `(message_id, sha256)` 唯一，
    重复登记（重发/重试/回放）不会多出行。
  * **不写绝对路径**：`path` 只存 `static/uploads/` 下的文件名。跨机只传 sha256，
    对端自己去取——这也是 docs/16 §3.3「消息里不放本机绝对路径」的落点。
  * **状态机**：`local → pending → synced / failed`。S2 只推进到 `local`（本机已有），
    跨机投递在 S3 里把 pending/synced/failed 真正写进来。

计算 sha256 / 复制到 blob 库这件事**不在这里重复实现**，复用 `core/peer_blobs.py`
（帖子与事件线已经用同一套；两份实现必然漂移）。
"""
from __future__ import annotations

import json
import sqlite3
import time

from . import peer_blobs

# 同一条消息里各附件状态的"最差优先"排序：一条失败就不要报"已同步"。
_STATE_ORDER = {"failed": 0, "pending": 1, "local": 2, "synced": 3}
STATES = tuple(_STATE_ORDER)


def _items(raw) -> list:
    """把 attachment 的历史三种形状统一成 list：单 URL 字符串 / dict / JSON 数组。"""
    if not raw:
        return []
    if isinstance(raw, str):
        s = raw.strip()
        if s[:1] in ("[", "{"):
            try:
                v = json.loads(s)
            except (TypeError, ValueError):
                return [s]
        else:
            return [s]
    else:
        v = raw
    if isinstance(v, dict):
        return [v]
    return v if isinstance(v, list) else []


def rel_path(url) -> str | None:
    """`/static/uploads/<name>` → `<name>`；其它来源 / 可疑名字 → None。

    绝不返回带目录的成分：这条值会进库，跨机也会看，必须能过脱敏扫描。
    """
    u = str(url or "")
    marker = "/static/uploads/"
    if marker not in u:
        return None
    name = u.split(marker, 1)[1].split("?", 1)[0].split("#", 1)[0].rsplit("/", 1)[-1]
    if not name or name in (".", "..") or "/" in name or "\\" in name:
        return None
    return name


def manifests(raw) -> list[dict]:
    """把附件值解析成 manifest 列表（只收能拿到 sha256 的本机文件）。"""
    out = []
    for it in _items(raw):
        m = peer_blobs.enrich_attachment(it)
        if not m or not m.get("sha256"):
            continue                       # 远端 URL / 文件缺失：留原文，不伪造 manifest
        out.append(m)
    return out


def register_message(conn, message_id: int, room_id: str | None, raw) -> list[dict]:
    """登记一条消息的附件；幂等（同消息同 sha 只一行）。返回 manifest 列表。"""
    ms = manifests(raw)
    if not ms:
        return []
    for m in ms:
        sha = str(m["sha256"])
        try:
            conn.execute(
                "INSERT OR IGNORE INTO attachment_blobs(sha256,size,mime,path) VALUES(?,?,?,?)",
                (sha, int(m.get("size") or 0), m.get("mime"), rel_path(m.get("url"))))
            cur = conn.execute(
                "INSERT OR IGNORE INTO message_attachment"
                "(message_id,room_id,sha256,name,mime,size,local_url,status) "
                "VALUES(?,?,?,?,?,?,?,'local')",
                (int(message_id), room_id, sha, m.get("name"), m.get("mime"),
                 int(m.get("size") or 0), m.get("url")))
            if cur.rowcount:               # 只有真的新增引用才加计数
                conn.execute("UPDATE attachment_blobs SET ref_count=ref_count+1 WHERE sha256=?",
                             (sha,))
        except sqlite3.Error as e:          # 单条失败不拖垮整条消息
            print(f"[attachments] 登记失败 sha={sha[:12]}: {e}")
    conn.commit()
    return ms


def for_message(conn, message_id: int) -> list[dict]:
    try:
        rows = conn.execute(
            "SELECT sha256,name,mime,size,local_url,remote_url,status FROM message_attachment "
            "WHERE message_id=? ORDER BY id", (int(message_id),)).fetchall()
    except sqlite3.Error:
        return []
    return [dict(r) for r in rows]


def state_of(conn, message_id: int) -> str | None:
    """一条消息的附件总体状态（最差优先）；没有附件 → None。"""
    rows = for_message(conn, message_id)
    if not rows:
        return None
    return min((str(r["status"] or "local") for r in rows),
               key=lambda s: _STATE_ORDER.get(s, 9))


def set_status(conn, message_id: int, sha256: str, status: str,
               remote_url: str | None = None) -> bool:
    """推进某条附件的投递状态（S3 跨机投递调用；S2 只用于测试与回填）。"""
    if status not in _STATE_ORDER:
        raise ValueError(f"bad attachment status: {status}")
    cur = conn.execute(
        "UPDATE message_attachment SET status=?, remote_url=coalesce(?,remote_url) "
        "WHERE message_id=? AND sha256=?", (status, remote_url, int(message_id), str(sha256)))
    conn.commit()
    return bool(cur.rowcount)


def gc(conn, days: float = 30, now: float | None = None) -> dict:
    """清掉**没人引用**且超过 TTL 的 blob 登记行；仍被消息引用的绝不动。

    只删库里的登记，不删磁盘文件——删文件是不可逆动作，留给人工/存储治理。
    """
    if days <= 0:
        return {"removed": 0, "kept": 0}
    cutoff = time.strftime("%Y-%m-%d %H:%M:%S",
                           time.localtime((time.time() if now is None else float(now)) - days * 86400))
    try:
        rows = conn.execute(
            "SELECT b.sha256 FROM attachment_blobs b WHERE b.ref_count<=0 AND b.created_at<?",
            (cutoff,)).fetchall()
        for r in rows:
            conn.execute("DELETE FROM attachment_blobs WHERE sha256=?", (r["sha256"],))
        kept = conn.execute("SELECT count(*) n FROM attachment_blobs").fetchone()["n"]
        conn.commit()
    except sqlite3.Error as e:
        print(f"[attachments] gc 失败：{e}")
        return {"removed": 0, "kept": 0, "error": str(e)}
    return {"removed": len(rows), "kept": int(kept)}
