"""P2P 事件拉取循环（docs/532 · P-C，修 docs/513 N3）。

背景：`peer_sync.sync_from_peer` 之前**全仓无调用点** —— 事件只推不拉。
对端把结果帖写在自己库里，本机永远不会去取，于是 `/app/p/<id>` 在本机 404，
这就是"死链"的根因。

做法：按 `peer_nodes`（中心下发的节点目录）逐个增量拉，游标由
`p2p_cursors` 维护（在 `sync_from_peer` 内部），拉回来的消息由
`apply_events` 直接派活（source='p2p'）。

边界：
* 令牌**按节点取**：`core.peer_tokens` 里登记的 grant 明文优先，
  `TAA_PEER_TOKEN` 只作测试/兼容回退。正规 grant 路线下该环境变量必须**不设**——
  它在 `peer_grants.authorize()` 里是 wildcard（scopes=["*"]），设了就绕过授权。
* 同一节点可能有多个候选地址（peer server 与 web 常是两个口），
  端点层失败（404/连不上）就换下一个；见 `peer_candidates`。
* 单次最多拉 `TAA_PEER_PULL_PEERS`（默认 5）个对端，避免一轮卡太久。
* 单个对端失败只记进返回值，不抛、不影响其它对端，更不影响主循环。
* 节流 `TAA_PEER_PULL_SECONDS`（默认 20 秒），`force=True` 可绕过。
"""

from __future__ import annotations

import json
import os
import time

from . import peer_sync

_LAST: dict = {"at": 0.0}


def _token() -> str:
    return (os.environ.get("TAA_PEER_TOKEN") or "").strip()


def _token_for(node_id: str) -> str:
    """按节点取令牌：本机登记的 grant 令牌优先；环境变量只作测试/兼容回退。"""
    try:
        from . import peer_tokens
        tok = peer_tokens.get_token(node_id)
        if tok:
            return tok
    except Exception:                                            # noqa: BLE001
        pass
    return _token()


def _endpoint_unusable(exc: Exception) -> bool:
    """这个地址不像事件接口（404/405）或根本连不上 → 值得换下一个候选。

    503 表示「端口对了，但授权没过」（`peer sync disabled`），换口无意义，不重试。
    """
    import urllib.error
    if isinstance(exc, urllib.error.HTTPError):
        return exc.code in (404, 405, 501)
    return isinstance(exc, (urllib.error.URLError, ConnectionError, TimeoutError, OSError))


# 对外别名：发起 grant 的那一侧（app_ui）也要用同一套"该换端口了吗"的判断，
# 免得两处各写一份、日后一处改一处忘。
endpoint_unusable = _endpoint_unusable


def _int_env(name: str, default: int, floor: int = 1) -> int:
    try:
        return max(floor, int(os.environ.get(name, str(default))))
    except (TypeError, ValueError):
        return default


def _allow_unsigned() -> bool:
    return str(os.environ.get("TAA_PEER_ALLOW_UNSIGNED") or "") not in ("", "0", "false", "False")


def peer_candidates(conn, limit: int | None = None) -> list[tuple[str, list[str]]]:
    """[(node_id, [候选 base...])]：本机登记地址优先，其次 selected_url，最后 endpoint_json。

    为什么要"多候选"：同一台机器在目录里可能同时登记两个口 —— peer server
    （只认 `/peer/v1/groups/.../messages|files`）和 web（`/v1/peer/events` 在
    web 侧）。目录字段区分不了哪个是哪个，所以按序试：某个口回 404 或连不上，
    就换下一个（见 `pull_all`）。

    旧实现有个隐 bug：`endpoint_json` 是 `[{kind,url,...}]`，用 `str(ep)` 取地址
    时 dict 转串不以 http 开头 → 永远被跳过，实际只剩 selected_url 一条。
    这里改为显式读 `url` 字段，同时兼容纯字符串数组的历史数据。
    """
    try:
        # 不过滤节点：`direct_status` 是 probe_all 的一次性探测结果，失败就永久
        # 降级成 relay（真机实测：能连的节点也停在 relay、selected_url 还被清空），
        # 拿它当闸门会把唯一可用的对端也挡掉（2026-11-10 踩过）。
        rows = conn.execute(
            "select node_id, selected_url, endpoint_json from peer_nodes "
            "order by coalesce(latency_ms, 99999)").fetchall()
    except Exception:                                            # noqa: BLE001
        return []
    try:
        from . import peer_tokens
    except Exception:                                            # noqa: BLE001
        peer_tokens = None

    out: list[tuple[str, list[str]]] = []
    seen: set[str] = set()
    for r in rows:
        node_id = str(r["node_id"] or "")
        cands: list[str] = []
        if peer_tokens is not None:
            try:
                reg = peer_tokens.get_base(node_id)
            except Exception:                                    # noqa: BLE001
                reg = ""
            if reg.startswith("http"):
                cands.append(reg)
        sel = str((r["selected_url"] or "")).strip()
        if sel.startswith("http"):
            cands.append(sel)
        # 候选只用「本机登记的地址」和「目录里探测到的地址」。
        # **不再**把 endpoint_json 里的 url 当候选：那是对端自报的，常见它自己的
        # 回环或另一个网段（真机：对端私网地址每次拖满超时，一轮 pull 被拉到分钟级）。
        uniq: list[str] = []
        for u in cands:
            base = u.rstrip("/")
            if not base or base in seen:
                continue
            seen.add(base)
            uniq.append(base)
        if uniq:
            out.append((node_id, uniq))
    return out[:limit] if limit else out


def peer_bases(conn, limit: int | None = None) -> list[tuple[str, str]]:
    """[(node_id, base_url)]：每个节点只给首选地址（向后兼容：测试与诊断用）。"""
    return [(nid, bases[0]) for nid, bases in peer_candidates(conn, limit) if bases]


def pull_all(conn, *, force: bool = False, limit: int | None = None) -> dict:
    """拉一轮。返回结构化结果，绝不抛异常。"""
    now = time.time()
    every = _int_env("TAA_PEER_PULL_SECONDS", 20, floor=5)
    if not force and now - float(_LAST["at"] or 0) < every:
        return {"ok": True, "skipped": "interval", "peers": 0}
    _LAST["at"] = now

    cap = limit if limit is not None else _int_env("TAA_PEER_PULL_PEERS", 5, floor=1)
    targets = peer_candidates(conn, cap)
    if not targets:
        return {"ok": True, "skipped": "no_token", "peers": 0}
    # 全都没有令牌才整轮跳过；部分节点有令牌时只跳过那部分（新增节点不该拖累老节点）。
    if not _token() and not any(_token_for(nid) for nid, _ in targets):
        return {"ok": True, "skipped": "no_token", "peers": 0}

    max_eps = _int_env("TAA_PEER_PULL_ENDPOINTS", 3, floor=1)
    results: list[dict] = []
    errors: list[str] = []
    skipped: list[dict] = []
    applied = 0
    for node_id, bases in targets:
        token = _token_for(node_id)
        if not token:
            skipped.append({"node": node_id, "reason": "no_token"})
            continue
        last_exc: Exception | None = None
        last_base = bases[0]
        ok_node = False
        for base in bases[:max_eps]:
            last_base = base
            try:
                # 单个候选给短超时、不重试：地址表里常混着历史/跨网段地址，
                # 30s×3 的默认值会让一轮拉取卡几分钟（实时性直接归零）。
                res = peer_sync.sync_from_peer(base, token, conn, log=None,
                                               allow_unsigned=_allow_unsigned(),
                                               timeout=8, attempts=1)
            except Exception as exc:                             # noqa: BLE001
                last_exc = exc
                if not _endpoint_unusable(exc):
                    break
                continue
            applied += int(res.get("applied") or 0)
            results.append({"node": node_id, "peer": base,
                            "events": int(res.get("events") or 0),
                            "applied": int(res.get("applied") or 0),
                            "next_since": int(res.get("next_since") or 0),
                            "ok": bool(res.get("ok"))})
            for e in res.get("blob_errors") or []:
                errors.append(f"{base}: blob {e}")
            ok_node = True
            break
        if not ok_node and last_exc is not None:
            errors.append(f"{last_base}: {type(last_exc).__name__}: {last_exc}"[:200])
    return {"ok": not errors, "peers": len(targets), "applied": applied,
            "results": results, "errors": errors[:10], "skipped_nodes": skipped}
