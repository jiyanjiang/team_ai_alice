#!/usr/bin/env python3
"""TAA 安装引导器 —— 跨平台，只用标准库。

设计约束（2026-11-08，Win 冷装 1 小时事故后重写）：
1. **不依赖 bash**：`install.sh` / `install.ps1` 只是 10 行壳，逻辑全在这里；
2. **不写死 venv 路径**：一律走 `taa_plat.venv_python()`（Windows 是 Scripts/python.exe）；
3. **uv 优先**：有 uv 就用（建 venv 毫秒级、装依赖秒级）；没有则标准库 venv + pip；
4. **校验不靠 shell 工具**：sha256 用 hashlib（MSYS 的 sha256sum 会输出反斜杠转义，
   字符串比较必然误判 —— 2026-11-08 Win 实测）；
5. **失败要可归因**：每段计时写进 `install-timings.json`，慢就是缺陷，不是"网络问题"。

用法：
    python3 bootstrap.py [--home DIR] [--port N] [--no-browser] [--skip-deps]
                         [--source DIR] [--dry-run]
    py -3 bootstrap.py ...
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import taa_plat as plat  # noqa: E402

# 2026-11-09 Owner 定：**禁用清华**。
# 教育网镜像（TUNA）只对校园网内快，普通家宽/移动网络跨网访问常掉到几十 KB/s，
# 把它当"国内加速源"是普遍错误。实测同一 4.85MB wheel：阿里 10.5–15.1MB/s、
# 腾讯 8.4–19.7MB/s、官方 5.6–6.1MB/s。顺序 = 阿里首选、腾讯次选、官方兜底，
# 运行时再按实际测速在可用源里挑最快的（见 pick_index）。
INDEX_CANDIDATES = (
    "https://mirrors.aliyun.com/pypi/simple",
    "https://mirrors.cloud.tencent.com/pypi/simple",
    "https://pypi.org/simple",
)
DEFAULT_INDEX = INDEX_CANDIDATES[0]


def probe_index(url: str, timeout: float = 2.5) -> float | None:
    """测一次索引往返（读前 2KB 就断开）；返回秒数，失败返回 None。

    DNS 解析卡住时 urllib 的 timeout 不生效，所以放到线程里 join 限时。
    """
    box: list[float | None] = []

    def run() -> None:
        t0 = time.time()
        try:
            req = urllib.request.Request(f"{url.rstrip('/')}/pip/",
                                         headers={"user-agent": "TAA-Installer/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                r.read(2048)
            box.append(round(time.time() - t0, 2))
        except Exception:                                        # noqa: BLE001
            box.append(None)

    th = threading.Thread(target=run, name="taa-index-probe", daemon=True)
    th.start()
    th.join(timeout + 1.5)
    return box[0] if box else None


def pick_index(explicit: str = "") -> tuple[str, list[tuple[str, float | None]]]:
    """选 pip 源：显式指定优先，否则按实测往返时间挑最快的可达源。"""
    if explicit:
        return explicit, []
    results = [(u, probe_index(u)) for u in INDEX_CANDIDATES]
    usable = [(u, t) for u, t in results if t is not None]
    best = min(usable, key=lambda x: x[1])[0] if usable else DEFAULT_INDEX
    return best, results


def _short_host(url: str) -> str:
    return url.split("//")[-1].split("/")[0]


class Timer:
    def __init__(self) -> None:
        self.t0 = time.time()
        self.marks: dict[str, float] = {}

    def mark(self, name: str) -> float:
        now = time.time()
        self.marks[name] = round(now - self.t0, 2)
        return self.marks[name]

    def since(self, name: str, start: float) -> float:
        d = round(time.time() - start, 2)
        self.marks[name] = d
        return d


def _log(msg: str) -> None:
    print(msg, flush=True)


def _err(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def parse_args(argv: list[str]) -> tuple[argparse.Namespace, list[str]]:
    ap = argparse.ArgumentParser(prog="bootstrap.py", add_help=True,
                                 description="TAA installer (cross-platform)")
    ap.add_argument("--home", default=None, help="安装根目录（默认 ~/.taa）")
    ap.add_argument("--port", type=int, default=None, help="本地端口（默认 6080）")
    ap.add_argument("--no-browser", action="store_true", help="装完不打开浏览器")
    ap.add_argument("--skip-deps", action="store_true", help="跳过依赖安装（排障用）")
    ap.add_argument("--source", default=None, help="包根目录（默认脚本所在目录）")
    ap.add_argument("--dry-run", action="store_true", help="只打印计划，不落盘")
    # 中心 bootstrap 会把这些透传进来；包内不消费，但必须接受，不能报 unknown option
    ap.add_argument("--center", default=None)
    ap.add_argument("--ref", default=None)
    ap.add_argument("--base", default=None)
    ap.add_argument("--from", dest="from_peer", default=None)
    ap.add_argument("--key", default=None, help="已废弃（安装器不再需要 agent key）")
    args, unknown = ap.parse_known_args(argv)
    return args, unknown


def find_uv_python() -> tuple[list[str], str] | None:
    """最后手段：让 uv 自己下一份 Python（uv 存在时）。"""
    uv = plat.uv_path()
    if not uv:
        return None
    _log("[deps] 未找到 Python 3.11+，尝试 uv python install 3.12")
    r = subprocess.run([uv, "python", "install", "3.12"], capture_output=True, text=True)
    if r.returncode != 0:
        _err((r.stderr or r.stdout or "").strip()[:300])
        return None
    r = subprocess.run([uv, "python", "find", "3.12"], capture_output=True, text=True)
    if r.returncode != 0:
        return None
    path = (r.stdout or "").strip().splitlines()[-1].strip()
    ver = plat.probe_python(path) if path else None
    return ([path], ver) if ver else None


def python_hint() -> str:
    if plat.IS_WIN:
        return ("需要 Python 3.11+：\n"
                "  winget install Python.Python.3.12\n"
                "  或安装 uv（单文件，无需管理员）：winget install astral-sh.uv\n"
                "  装好后重开终端再跑；也可用 TAA_PYTHON 指定解释器路径。")
    if plat.IS_MAC:
        return ("需要 Python 3.11+：brew install python@3.12\n"
                "  或 brew install uv（uv 会自带 Python）")
    return ("需要 Python 3.11+：sudo apt install python3.12 python3.12-venv\n"
            "  或 curl -LsSf https://astral.sh/uv/install.sh | sh")


def write_timings(home: Path, t: Timer, extra: dict | None = None) -> None:
    data = {"schema": 1, "platform": sys.platform, "arch": platform.machine(),
            "python": platform.python_version(), "total_s": t.mark("total"),
            "marks": t.marks}
    if extra:
        data.update(extra)
    try:
        home.mkdir(parents=True, exist_ok=True)
        (home / "install-timings.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass
    _log("TIMINGS=" + json.dumps(t.marks, ensure_ascii=False))


def do_upgrade(src: Path, home: Path, port: int, no_browser: bool, t: Timer,
               base_exe: str = "") -> int:
    """已有安装：走 taa_upgrade.py（原子替换 + 回滚），不在活目录上覆盖。"""
    venv = home / "venv"
    vpy = plat.venv_python(venv)
    rebuild = False
    if not venv.exists():
        _log("[upgrade] 未发现 venv，先建一个再升级")
        rebuild = True
    elif not plat.probe_python(vpy):
        _log("[upgrade] 现有 venv 不是可用的 Python 3.11+，重建后再升级")
        rebuild = True

    skip_deps = (os.environ.get("TAA_UPGRADE_SKIP_DEPS") or "").strip() == "1"
    if rebuild and skip_deps:
        _err("[upgrade] 警告：venv 要重建，却又设了 TAA_UPGRADE_SKIP_DEPS=1——")
        _err("          新 venv 里没有任何依赖，升级后的服务几乎必然起不来。")
        if sys.stdin.isatty():
            ans = input("[upgrade] 仍要继续？[y/N] ").strip().lower()
            if ans not in ("y", "yes"):
                _err("[upgrade] 已取消：去掉 TAA_UPGRADE_SKIP_DEPS 后重跑")
                return 4
        else:
            _err("[upgrade] 非交互模式下不替你做这个决定，已中止：去掉 TAA_UPGRADE_SKIP_DEPS 后重跑")
            return 4

    if rebuild:
        if venv.exists():
            bak = plat.backup_venv(venv)
            _log(f"[upgrade] 旧 venv 已移开：{bak}")
        st = time.time()
        ok, how = plat.create_venv(venv, base_py=None if plat.uv_path() else (base_exe or sys.executable))
        t.since("venv", st)
        if not ok:
            _err(f"x 建 venv 失败：{how}")
            return 4
        vpy = plat.venv_python(venv)

    _log("[upgrade] existing install detected")
    cmd = [str(vpy), str(src / "taa_upgrade.py"), "--source", str(src),
           "--home", str(home), "--port", str(port), "--python", str(vpy)]
    if no_browser:
        cmd.append("--no-open")
    st = time.time()
    rc = subprocess.run(cmd, cwd=str(src)).returncode
    t.since("upgrade", st)
    # 模板由 taa_upgrade.py 的 stage 阶段补（升级路径唯一真相源，别在这里再补一份）
    write_timings(home, t, {"mode": "upgrade", "rc": rc})
    return rc


def main(argv: list[str] | None = None) -> int:
    args, unknown = parse_args(list(sys.argv[1:] if argv is None else argv))
    if unknown:
        _err(f"[warn] 忽略未知参数：{' '.join(unknown)}（中心 bootstrap 透传的新参数不应让安装失败）")

    t = Timer()
    home = Path(args.home or os.environ.get("TAA_HOME") or plat.default_home())
    dest = home / "app"
    port = int(args.port or os.environ.get("TAA_HTTP_PORT") or 6080)
    src = Path(args.source or Path(__file__).resolve().parent)
    if not (src / "VERSION").exists() and (src.parent / "VERSION").exists():
        src = src.parent
    explicit_index = (os.environ.get("UV_DEFAULT_INDEX")
                      or os.environ.get("PIP_INDEX_URL") or "").strip()
    index_url = explicit_index or DEFAULT_INDEX

    plat_name = "windows" if plat.IS_WIN else ("macos" if plat.IS_MAC else sys.platform)
    _log(f"PLATFORM={plat_name} ARCH={platform.machine()} PYTHON={platform.python_version()}")
    _log(f"TAA_HOME={home}")
    _log(f"SOURCE={src}")
    _log(f"PORT={port}")
    if plat.uv_path():
        _log(f"UV={plat.uv_path()}")
    if args.ref or os.environ.get("TAA_REF"):
        _log(f"REF={args.ref or os.environ.get('TAA_REF')}")

    if not (src / "VERSION").exists():
        _err(f"x 包不完整：{src} 下没有 VERSION（--source 指向包根目录）")
        return 2
    if args.dry_run:
        _log("[dry-run] 将执行：复制 → venv → deps → launch → 自检（本次未落盘）")
        return 0

    # `--ref` 必须落盘：注册（/v05/claim 或本机 /setup/）时带上，中心据此
    # 直接把邀请人写成 approved 好友。只打印日志等于这个参数没用。
    # 这里**不能** import taa_node_v05（它依赖 cryptography，而 bootstrap 跑在
    # 系统解释器上、venv 还没建好）。所以只写字面量文件，文件名与
    # `taa_node_v05/identity.py` 的 REF_FILE 保持一致。
    _raw = str(args.ref or os.environ.get("TAA_REF", "")).strip().lower()
    _ref = "".join(ch for ch in _raw if ch.isalnum() or ch in "_-")[:64]
    if _ref:
        try:
            home.mkdir(parents=True, exist_ok=True)
            (home / "ref.txt").write_text(_ref + "\n", encoding="utf-8")
            _log(f"REF_SAVED={_ref}（注册时自动建立好友）")
            os.environ["TAA_REF"] = _ref
        except Exception as e:                                      # noqa: BLE001
            _log(f"[warn] 推荐码未能落盘：{e}")

    # ---- 1. 找解释器 -------------------------------------------------------
    st = time.time()
    found = plat.find_python(explicit=os.environ.get("TAA_PYTHON"), home=home)
    if not found:
        found = find_uv_python()
    t.since("detect_python", st)
    if not found:
        _err("x " + python_hint())
        return 3
    cmd, ver = found
    _log(f"PYTHON={cmd[0]} {ver}")
    base_exe = cmd[0] if len(cmd) == 1 else sys.executable
    if not plat.probe_python(base_exe):
        base_exe = sys.executable

    # ---- 2. 升级分支 -------------------------------------------------------
    if (home / "identity.json").exists() and dest.exists():
        return do_upgrade(src, home, port, args.no_browser, t, base_exe)

    # ---- 3. 复制运行时 -----------------------------------------------------
    _log(f"[install] 复制运行时 → {dest}")
    st = time.time()
    dest.mkdir(parents=True, exist_ok=True)
    how_copy = plat.copy_tree(src, dest, excludes=("agents", "bootstrap", "static/uploads"))
    failed = plat.ensure_data_dirs(dest, home)
    for rel in failed:
        _err(f"[warn] {rel} 无法建链接（Windows 需 junction），已复制回 app 目录")
    # `agents/` 被整目录排除（防私有记忆进包），但 `_templates/*.yaml` 是**运行时必需**：
    # 缺它则在 /setup/ 建首个 agent 时 rng.choice([]) → IndexError，装完即不可用。
    n_tpl = plat.seed_templates(src, home)
    if n_tpl:
        _log(f"[install] 人设模板 {n_tpl} 个 → agents/_templates")
    else:
        _err("[warn] 包里没有 agents/_templates/*.yaml：装完建首个 agent 会崩")
    t.since("layout", st)
    _log(f"[install] 复制完成（{how_copy}），数据目录={'/'.join(plat.DATA_DIRS)}")

    # ---- 4. venv -----------------------------------------------------------
    venv = home / "venv"
    vpy = plat.venv_python(venv)
    if not plat.probe_python(vpy):
        if venv.exists():
            bak = plat.backup_venv(venv)
            _log(f"[deps] 现有 venv 不可用（不是 3.11+ 或已损坏），移开并重建：{bak}")
        st = time.time()
        # 有 uv 就让 uv 自己取 3.12（可代下、venv 覆盖率最好）；没有才退回本机解释器
        ok, how = plat.create_venv(venv, base_py=None if plat.uv_path() else base_exe)
        t.since("venv", st)
        if not ok:
            _err(f"x 建 venv 失败：{how}")
            return 4
        vpy = plat.venv_python(venv)
        if not plat.probe_python(vpy):
            _err(f"x venv 建好了但解释器跑不起来：{vpy}")
            return 4
        _log(f"[deps] venv 就绪（{how}）：{vpy}")
    else:
        t.marks["venv"] = 0.0
        _log(f"[deps] 复用已有 venv：{vpy}")

    # ---- 5. 依赖 -----------------------------------------------------------
    if args.skip_deps:
        _log("[deps] --skip-deps：跳过依赖安装")
    else:
        # 到此才测源：upgrade 分支不该为测速多花时间。
        if not explicit_index:
            index_url, probes = pick_index()
            _log("[deps] 源测速：" + " / ".join(
                f"{_short_host(u)}={'x' if s is None else f'{s}s'}"
                for u, s in probes))
            _log(f"[deps] 选用 index={index_url}")
        req = dest / "requirements-core.txt"
        if not req.exists():
            _err(f"x 缺 {req}")
            return 5
        st = time.time()
        ok, how = plat.install_deps(vpy, req, index_url=index_url)
        t.since("deps", st)
        if not ok:
            _err(f"x 依赖安装失败（{how}）\n  可重试：\"{vpy}\" -m pip install -r \"{req}\" -i {index_url}")
            return 5
        _log(f"[deps] 核心依赖就绪（{how}，{t.marks['deps']}s）")

        # 图片增强（Pillow 4.85MB）可选：默认不装，缩略图走 sips / 原图兜底。
        # 论证图已取消，playwright（41MB + 185MB chromium）不再安装。
        image_req = dest / "requirements-image.txt"
        if (os.environ.get("TAA_IMAGE") or "0").strip() == "1" and image_req.exists():
            st = time.time()
            ok, how = plat.install_deps(vpy, image_req, index_url=index_url)
            if ok:
                _log(f"[deps] 图片增强就绪（{how}，{t.since('image', st)}s）")
            else:
                _err("[deps] 图片增强未装成：缩略图走原图/系统工具兜底")
        else:
            _log("[deps] 跳过图片增强（默认；TAA_IMAGE=1 可装 Pillow）")

    # ---- 6. 启动 -----------------------------------------------------------
    launcher = dest / "launcher.py"
    if not launcher.exists():
        launcher = dest / "taa_launcher.py"
    env = plat.local_env()
    env.update({"TAA_HOME": str(home), "TAA_HTTP_PORT": str(port), "TAA_PYTHON": str(vpy)})
    st = time.time()
    if launcher.exists():
        cmd = [str(vpy), str(launcher), "start"] + (["--no-open"] if args.no_browser else [])
        rc = subprocess.run(cmd, cwd=str(dest), env=env).returncode
    else:
        _err("x 包里没有 launcher.py，无法启动（包不完整）")
        rc = 6
    t.since("start", st)
    if rc != 0:
        _err(f"x 启动失败（rc={rc}），日志：{home / 'run' / 'web.log'}")
        write_timings(home, t, {"mode": "install", "rc": rc})
        return rc

    # ---- 7. 自检报告（只读，失败不阻断）----------------------------------
    st = time.time()
    report = dest / "scripts" / "install_report.py"
    if report.exists():
        subprocess.run([str(vpy), str(report), "--home", str(home), "--port", str(port)],
                       cwd=str(dest), env=env)
    t.since("selfcheck", st)

    _log("")
    _log(f"TAA_HOME={home}")
    _log(f"TAA_APP={dest}")
    _log(f"LOCAL_UI_URL=http://127.0.0.1:{port}/app/bridge")
    if (os.environ.get("TAA_REF") or args.ref):
        _log("NEXT=浏览器里完成认领（/setup/），--ref 会自动建立好友关系")
    write_timings(home, t, {"mode": "install", "rc": 0})
    return 0


if __name__ == "__main__":
    sys.exit(main())
