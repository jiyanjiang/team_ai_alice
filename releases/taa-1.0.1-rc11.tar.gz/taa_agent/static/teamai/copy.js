(function(){
  if (window.__taaCopyInit) return; window.__taaCopyInit = 1;
  var L = window.TAA_COPY || {};
  function label(k, d){ return (L && L[k]) || d; }
  function textOf(el){
    if (!el) return "";
    if (el.matches && (el.matches("textarea") || el.matches("input"))) return el.value || "";
    return el.innerText || el.textContent || "";
  }
  function fallbackCopy(t){
    return new Promise(function(resolve, reject){
      try {
        var ta = document.createElement("textarea");
        ta.value = t; ta.setAttribute("readonly", ""); ta.style.position = "fixed";
        ta.style.left = "-9999px"; ta.style.top = "0"; document.body.appendChild(ta);
        ta.focus(); ta.select(); ta.setSelectionRange(0, ta.value.length);
        var ok = document.execCommand("copy"); document.body.removeChild(ta);
        ok ? resolve() : reject(new Error("copy_failed"));
      } catch (e) { reject(e); }
    });
  }
  function copyText(t){
    t = String(t == null ? "" : t);
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(t).catch(function(){ return fallbackCopy(t); });
    }
    return fallbackCopy(t);
  }
  function flash(btn, ok){
    var old = btn.getAttribute("data-old") || btn.textContent;
    btn.setAttribute("data-old", old);
    btn.textContent = ok ? label("copied", "Copied") : label("failed", "Failed");
    btn.classList.toggle("done", ok);
    setTimeout(function(){ btn.textContent = old; btn.classList.remove("done"); }, 1200);
  }
  function valueFor(el){
    if (el.hasAttribute("data-copy")) return el.getAttribute("data-copy");
    if (el.hasAttribute("data-copy-md")) return el.getAttribute("data-copy-md");
    var sel = el.getAttribute("data-copy-target");
    if (sel) { var t = document.querySelector(sel); return t ? textOf(t) : ""; }
    var src = el.getAttribute("data-copy-src");
    if (src) { var im = document.querySelector(src); return im ? (im.currentSrc || im.src || "") : ""; }
    return "";
  }
  document.addEventListener("click", function(e){
    var b = e.target.closest("[data-copy],[data-copy-target],[data-copy-md],[data-copy-src]");
    if (!b) return;
    e.preventDefault();
    var t = valueFor(b);
    copyText(t).then(function(){ flash(b, true); }, function(){ flash(b, false); });
  });
  function addPreButtons(){
    document.querySelectorAll("pre").forEach(function(pre){
      if (pre.closest("[data-no-copy],.keyprompt,.keyout,.nokeycopy")) return;
      if (pre.closest(".pre-wrap")) return;
      var wrap = document.createElement("div"); wrap.className = "pre-wrap";
      pre.parentNode.insertBefore(wrap, pre); wrap.appendChild(pre);
      var b = document.createElement("button"); b.type = "button"; b.className = "copyx";
      b.textContent = label("copy", "Copy"); b.setAttribute("aria-label", label("copy", "Copy"));
      b.addEventListener("click", function(){
        var code = pre.querySelector("code") || pre;
        copyText(textOf(code)).then(function(){ flash(b, true); }, function(){ flash(b, false); });
      });
      wrap.appendChild(b);
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", addPreButtons);
  else addPreButtons();
})();