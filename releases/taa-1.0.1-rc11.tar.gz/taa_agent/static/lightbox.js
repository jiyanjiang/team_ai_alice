/* 相册灯箱（移动端适配）：点群聊图片 → 全屏相册，左右滑动/箭头/键盘切换。
   纯原生，无依赖。openLightbox(imgEl) 会收集当前聊天区所有图片成相册。 */
(function () {
  let list = [], idx = 0, ov = null, imgEl = null, countEl = null;
  function ensure() {
    if (ov) return;
    ov = document.createElement("div");
    ov.className = "lb";
    ov.setAttribute("aria-hidden", "true");
    ov.innerHTML =
      '<button class="lb-btn lb-close" aria-label="关闭">✕</button>' +
      '<button class="lb-btn lb-prev" aria-label="上一张">‹</button>' +
      '<button class="lb-btn lb-next" aria-label="下一张">›</button>' +
      '<div class="lb-count"></div>' +
      '<img class="lb-img" alt="">';
    document.body.appendChild(ov);
    imgEl = ov.querySelector(".lb-img");
    countEl = ov.querySelector(".lb-count");
    ov.querySelector(".lb-close").addEventListener("click", close);
    ov.querySelector(".lb-prev").addEventListener("click", function (e) { e.stopPropagation(); go(-1); });
    ov.querySelector(".lb-next").addEventListener("click", function (e) { e.stopPropagation(); go(1); });
    ov.addEventListener("click", function (e) { if (e.target === ov) close(); });
    document.addEventListener("keydown", function (e) {
      if (!ov.classList.contains("open")) return;
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") go(-1);
      else if (e.key === "ArrowRight") go(1);
    });
    // 触摸滑动（单指；双指交给浏览器缩放）
    let x0 = 0, y0 = 0, n0 = 0, moved = false;
    ov.addEventListener("touchstart", function (e) {
      n0 = e.touches.length; if (n0 === 1) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; moved = false; }
    }, { passive: true });
    ov.addEventListener("touchmove", function (e) {
      if (n0 === 1 && e.touches.length === 1) {
        if (Math.abs(e.touches[0].clientX - x0) > 10 || Math.abs(e.touches[0].clientY - y0) > 10) moved = true;
      }
    }, { passive: true });
    ov.addEventListener("touchend", function (e) {
      if (n0 !== 1 || !moved) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - x0, dy = t.clientY - y0;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? 1 : -1);
      moved = false;
    }, { passive: true });
  }
  // 按「容器」归集相册：九宫格 → 同一格；帖子 → 同一帖；群聊 → 全聊天区（原行为）。
  // ★ 2026-10-14 修：原实现只认 `img.msg-img`（群聊），而 #lobby 九宫格用的是 `mgrid-img`，
  //   点九宫格时 list.indexOf(el) === -1 → 相册里装的是群聊图片，用户感觉"切不了上一张/下一张"。
  function scopeOf(el) {
    if (!el || !el.closest) return { sel: "img.msg-img", root: document };
    var dm = el.closest(".dm-msgs");                   // 私聊 DM：整段会话内归集（t-2451ccad）
    if (dm) return { sel: "img.dm-img", root: dm };
    var g = el.closest(".mgrid");                      // #lobby 朋友圈九宫格
    if (g) return { sel: "img.mgrid-img", root: g };
    var box = el.closest(".post-atts, .thread-body, .post-body");
    if (box && box.querySelectorAll("img.post-img").length > 1) return { sel: "img.post-img", root: box };
    if (el.classList && el.classList.contains("msg-img")) return { sel: "img.msg-img", root: document };
    var c = el.closest(".post-atts, .msg, .moment, article, .card") || document;
    return { sel: "img.zoomable", root: c };
  }
  function collect(el) {
    try {
      var s = scopeOf(el);
      var all = Array.prototype.slice.call(s.root.querySelectorAll(s.sel))
        .filter(function (im) { return im.getAttribute("src"); });
      if (all.length) return all;
    } catch (e) {}
    return el ? [el] : [];
  }
  function show() {
    const im = list[idx];
    if (!im) return;
    imgEl.src = im.currentSrc || im.src;
    countEl.textContent = (idx + 1) + " / " + list.length;
    countEl.style.display = list.length > 1 ? "" : "none";
    // 预取相邻
    try {
      [-1, 1].forEach(function (d) {
        const nm = list[idx + d];
        if (nm) { const p = new Image(); p.src = nm.currentSrc || nm.src; }
      });
    } catch (e) {}
  }
  function go(d) { if (!list.length) return; idx = (idx + d + list.length) % list.length; show(); }
  function open(el) {
    ensure();
    list = collect(el);
    idx = Math.max(0, list.indexOf(el));
    if (!list.length) { list = [el]; idx = 0; }
    show();
    ov.classList.add("open");
    ov.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
  function close() {
    if (!ov) return;
    ov.classList.remove("open");
    ov.setAttribute("aria-hidden", "true");
    imgEl.removeAttribute("src");
    document.body.style.overflow = "";
  }
  window.openLightbox = open;
  window.closeLightbox = close;
})();
