/* 聊天滚动「粘底 / 上翻锁定」控制器（t-4c228ae0）
 *
 * 问题（旧实现）：pollRoom 每秒执行一次 `if (chatStick) sc.scrollTop = sc.scrollHeight`，
 * 而 chatStick 由 `scrollHeight - scrollTop - clientHeight < 40` 在 scroll 事件里现算。
 * 这样一来，**任何**引起滚动的事件（用户手势、布局夹取、图片/公式/mermaid 撑高、
 * transcript 窗口滑动、窗口 resize、程序写入）都会被当成「用户意图」，一次误判就会被
 * 每秒一次的强制回底固化成「几秒后自动跳回最新」。
 *
 * 三条不变量：
 *   1) follow 只由「用户手势 + 距底距离」决定，布局变化/程序写入永不改变它；
 *   2) 锁定后用**消息锚点**（data-mid + 屏内偏移）恢复位置，而不是记 scrollTop 数字；
 *   3) 只有 follow === true 时才允许写 scrollTop = scrollHeight。
 *
 * 依赖 DOM：每条消息带 data-mid（见 board.js renderMessages）。
 */
(function (global) {
  "use strict";

  var BOTTOM_EPS = 4;     // 距底 ≤4px 才算「在底部」
  var LOCK_AFTER = 10;    // 距底 >10px 的上翻就锁定（旧实现是 40px，20px 的上翻会被吞掉）
  var RESUME_GAP = 24;    // 向下滚到距底 ≤24px 视为「主动回到最新」
  var GESTURE_MS = 800;   // 手势后这段时间内的 scroll 事件才算用户滚动

  function nowMs() { return (global.performance && performance.now) ? performance.now() : Date.now(); }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function create(el, opts) {
    opts = opts || {};
    var onChange = typeof opts.onChange === "function" ? opts.onChange : function () {};

    var follow = true;      // 用户是否还想跟随最新
    var anchor = null;      // { id, delta } 或 { top }
    var unseen = 0;         // 锁定期间到达的新消息数
    var lastSeen = 0;       // 已见过的最大消息 id
    var lastUser = 0;       // 最近一次用户手势时间
    var lastTop = 0;        // 上一次 scroll 位置，用来判断方向
    var suppress = 0;       // 自己写 scrollTop 时压掉的 scroll 事件
    var destroyed = false;
    var ro = null;
    var roRaf = 0;

    function gap() { return el.scrollHeight - el.scrollTop - el.clientHeight; }
    function emit() { onChange({ follow: follow, unseen: unseen }); }
    function userGesture() { lastUser = nowMs(); }

    function write(v) {
      var max = Math.max(0, el.scrollHeight - el.clientHeight);
      var target = clamp(v, 0, max);
      if (Math.abs(el.scrollTop - target) < 0.5) return;
      suppress++;
      el.scrollTop = target;
      // scroll 事件在下一帧派发；用 rAF 抵消这次抑制标记
      requestAnimationFrame(function () { suppress = Math.max(0, suppress - 1); });
    }

    function firstVisible() {
      var box = el.getBoundingClientRect();
      var nodes = el.querySelectorAll("[data-mid]");
      for (var i = 0; i < nodes.length; i++) {
        var r = nodes[i].getBoundingClientRect();
        if (r.bottom > box.top + 1 && r.top < box.bottom - 1) return nodes[i];
      }
      return null;
    }

    function captureAnchor() {
      var n = firstVisible();
      if (!n) { anchor = { top: el.scrollTop }; return; }
      anchor = {
        id: n.getAttribute("data-mid"),
        delta: n.getBoundingClientRect().top - el.getBoundingClientRect().top
      };
    }

    /* 把锚点消息拉回锁定时的屏幕位置（只做差值修正，不关心内容总高） */
    function restore() {
      if (destroyed || follow || !anchor) return;
      if (anchor.id != null) {
        var n = el.querySelector('[data-mid="' + anchor.id + '"]');
        if (!n) return;                       // 被窗口挤出：保持当前 scrollTop
        var delta = n.getBoundingClientRect().top - el.getBoundingClientRect().top;
        if (Math.abs(delta - anchor.delta) < 1) return;
        write(el.scrollTop + (delta - anchor.delta));
      } else {
        write(anchor.top);
      }
    }

    function toBottom() { write(el.scrollHeight); }

    function onScroll() {
      if (destroyed || suppress > 0) return;
      // 非手势引起的 scroll（布局夹取 / 滚动锚定 / 程序写入）不参与状态判定
      if (nowMs() - lastUser > GESTURE_MS) return;
      var top = el.scrollTop, down = top > lastTop;
      lastTop = top;
      var g = gap();
      if (g <= BOTTOM_EPS) {
        if (!follow) { follow = true; anchor = null; unseen = 0; emit(); }
      } else if (down && g <= RESUME_GAP) {
        // 向下滚回底部附近：恢复跟随（验收 #3）
        if (!follow) { follow = true; anchor = null; unseen = 0; emit(); }
      } else if (g > LOCK_AFTER) {
        if (follow) { follow = false; emit(); }
        // 每次用户滚动都刷新锚点：否则「锁定后用户又拖到别处」会把旧锚点当成复位目标
        captureAnchor();
      }
      // 4~10px 之间保持原状态（迟滞，避免抖动）
    }

    function onKey(e) {
      var k = e.key;
      if (k === "PageUp" || k === "PageDown" || k === "ArrowUp" || k === "ArrowDown" ||
          k === "Home" || k === "End" || k === " " || k === "Spacebar") userGesture();
    }

    function observeContent() {
      if (ro) { ro.disconnect(); ro = null; }
      var content = el.firstElementChild;
      if (!content || typeof ResizeObserver === "undefined") return;
      ro = new ResizeObserver(function () {
        if (roRaf) return;
        roRaf = requestAnimationFrame(function () {
          roRaf = 0;
          if (destroyed) return;
          if (follow) toBottom(); else restore();
        });
      });
      ro.observe(content);
    }

    /* 一次渲染前：记锚点、累计未读数 */
    function beginRender(tx) {
      if (destroyed) return;
      if (!follow) captureAnchor();
      var list = tx || [];
      var maxId = 0, arrived = 0;
      for (var i = 0; i < list.length; i++) {
        var id = Number(list[i] && list[i].id) || 0;
        if (id > maxId) maxId = id;
        if (id > lastSeen) arrived++;
      }
      if (!follow && arrived > 0) unseen += arrived;
      if (maxId > lastSeen) lastSeen = maxId;
      emit();
    }

    /* 一次渲染后：跟随则贴底；锁定则把锚点放回原处（含两次延迟重排） */
    function endRender() {
      if (destroyed) return;
      observeContent();
      if (follow) {
        toBottom();
        lastTop = el.scrollTop;
        requestAnimationFrame(toBottom);
      } else {
        restore();
        requestAnimationFrame(restore);
        setTimeout(restore, 120);
        setTimeout(restore, 400);
      }
    }

    function toLatest() {
      follow = true; anchor = null; unseen = 0; emit();
      toBottom();
      lastTop = el.scrollTop;
      requestAnimationFrame(toBottom);
    }

    function reset() {
      follow = true; anchor = null; unseen = 0; lastSeen = 0; emit();
      toBottom();
      lastTop = el.scrollTop;
      requestAnimationFrame(toBottom);
    }

    function state() { return { follow: follow, unseen: unseen, gap: gap() }; }

    function destroy() {
      destroyed = true;
      if (ro) { ro.disconnect(); ro = null; }
      el.removeEventListener("scroll", onScroll);
      el.removeEventListener("wheel", userGesture);
      el.removeEventListener("touchstart", userGesture);
      el.removeEventListener("touchmove", userGesture);
      el.removeEventListener("pointerdown", userGesture);
      el.removeEventListener("load", restore, true);
      document.removeEventListener("keydown", onKey, true);
      global.removeEventListener("resize", onResize);
    }

    function onResize() {
      if (destroyed) return;
      if (follow) toBottom(); else restore();
    }

    el.addEventListener("scroll", onScroll, { passive: true });
    el.addEventListener("wheel", userGesture, { passive: true });
    el.addEventListener("touchstart", userGesture, { passive: true });
    el.addEventListener("touchmove", userGesture, { passive: true });
    el.addEventListener("pointerdown", userGesture, { passive: true });
    el.addEventListener("load", restore, true);   // 图片/视频解码后重排
    document.addEventListener("keydown", onKey, true);
    global.addEventListener("resize", onResize);

    emit();
    return {
      beginRender: beginRender,
      endRender: endRender,
      toLatest: toLatest,
      reset: reset,
      state: state,
      destroy: destroy
    };
  }

  global.ChatScroller = { create: create };
})(window);
