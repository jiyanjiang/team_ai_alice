"""screen.capture —— 截取**本机屏幕**（用于汇报 opencode/IDE 界面）。

- 在**运行工具的机器**上截屏：A 的 agent → A 屏；B 的 agent（本地执行）→ B 屏。
- 产出到 `static/uploads/screen-*.png`，返回可访问 URL。
- 隐私：仅本机、仅当前屏幕；不涉及远端。
- macOS 需"屏幕录制"权限；首次会弹窗授权。
"""
from __future__ import annotations

import platform
import subprocess
import time
from pathlib import Path

NAME = "screen.capture"
DESCRIPTION = "截取本机屏幕（含 opencode/IDE 界面），返回图片 URL；仅本机执行"
SCHEMA = {"full": "bool?"}


def _root() -> Path:
    return Path(__file__).resolve().parents[2]


def run(agent: str, args: dict) -> dict:
    root = _root()
    out_dir = root / "static" / "uploads"
    out_dir.mkdir(parents=True, exist_ok=True)
    name = f"screen-{agent}-{int(time.time())}.png"
    out = out_dir / name
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.run(["screencapture", "-x", str(out)], timeout=30, check=True)
        elif system == "Linux":
            try:
                subprocess.run(["import", "-window", "root", str(out)], timeout=30, check=True)
            except Exception:
                subprocess.run(["gnome-screenshot", "-f", str(out)], timeout=30, check=True)
        else:
            return {"_error": f"暂不支持 {system} 屏幕截图"}
    except Exception as e:  # noqa: BLE001
        return {"_error": f"截屏失败（可能缺屏幕录制权限）：{e}"}
    if not out.exists():
        return {"_error": "截屏未产生文件（检查屏幕录制权限）"}
    return {"url": f"/static/uploads/{name}", "note": "本机屏幕截图", "machine": platform.node()}
