"""email.send —— 一键发信工具（IDE / agent / 群聊均可激发）。

- 触发①（IDE/agent）：`POST /v1/tools/email.send/call` body={"args":{...}}（见 SCHEMA）。
- 触发②（群聊即控制台）：在房间内让 agent 以 `tool email.send` 指定参数调用。
- 触发③（终端一键）：`teamai email --to ... --subject ... --body ... [--file f] [--attach f]`。

隐私：本工具**不内置任何账号/授权码**；SMTP 配置由 config.yaml(`smtp.*`, gitignored) 或环境变量提供。
"""
from __future__ import annotations

NAME = "email.send"
DESCRIPTION = "发送邮件（正文/文件并入/附件）。SMTP 取 config.yaml smtp.* 或环境变量；IDE/agent 一键调用"
SCHEMA = {
    "to": "str | list[str]  # 收件人",
    "subject": "str          # 主题",
    "body": "str?            # 纯文本正文",
    "html": "str?            # HTML 正文（可选）",
    "files": "list[str]?     # 作为正文并入的文件路径（如 .md）",
    "attachments": "list[str]?  # 作为附件的文件路径",
}


def run(agent: str, args: dict) -> dict:
    from core.emailer import send
    return send(
        to=args.get("to"),
        subject=args.get("subject", ""),
        body=args.get("body", "") or "",
        html=args.get("html"),
        files=args.get("files"),
        attachments=args.get("attachments"),
    )
