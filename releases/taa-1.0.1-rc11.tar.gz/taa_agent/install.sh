#!/usr/bin/env bash
# TAA 1.x integrated installer. No agent key; the Owner claim happens in the browser.
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TAA_HOME="${TAA_HOME:-$HOME/.taa}"
DEST="$TAA_HOME/app"
PORT="${TAA_HTTP_PORT:-6080}"
NO_OPEN=0
SKIP_DEPS=0

while [ $# -gt 0 ]; do
  case "$1" in
    --no-browser) NO_OPEN=1; shift ;;
    --skip-deps) SKIP_DEPS=1; shift ;;
    --port) PORT="$2"; shift 2 ;;
    --home) TAA_HOME="$2"; DEST="$TAA_HOME/app"; shift 2 ;;
    -h|--help)
      cat <<EOF
TAA installer

Usage: $0 [--home DIR] [--port N] [--no-browser] [--skip-deps]

Install the local runtime into \$TAA_HOME/app, create a venv, then start
the local app. No agent key is required.
EOF
      exit 0
      ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

python_ok() {
  candidate="$1"
  [ -n "$candidate" ] || return 1
  if [ -x "$candidate" ]; then
    :
  elif command -v "$candidate" >/dev/null 2>&1; then
    :
  else
    return 1
  fi
  # 门槛 3.11：bin/taa 读配置用 tomllib（3.11 才进标准库），见 docs/194。
  "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)' >/dev/null 2>&1
}

find_python() {
  if [ -n "${TAA_PYTHON:-}" ]; then
    if python_ok "$TAA_PYTHON"; then
      printf '%s\n' "$TAA_PYTHON"
      return 0
    fi
    echo "x TAA_PYTHON=$TAA_PYTHON 不是 Python 3.11+" >&2
    return 1
  fi
  # 顺序 = 3.12（开发/回归基线）优先，其次 3.13、3.11，最后系统 python3。
  # 先试已存在的 TAA venv：system /usr/bin/python3 may be an Xcode
  # placeholder that exists but cannot run (common on fresh macOS).
  for candidate in \
    "$TAA_HOME/venv/bin/python" \
    python3.12 python3.13 python3.11 python3; do
    if python_ok "$candidate"; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

PY="$(find_python)" || {
  echo "x 需要 Python 3.11+；系统 Python 不可用时请设置 TAA_PYTHON=/path/to/python3.12" >&2
  exit 3
}

# venv 复用护栏：门槛曾在 beta 期为 3.10，老机器上的 venv 可能还是 3.10；
# 直接复用会在运行时因缺 tomllib（3.11 才进标准库）起不来。损坏的 venv 同理。
# 旧目录**移开备份、不删除**：重建失败时还能人肉搬回来。
ensure_venv() {
  venv_dir="$1"
  base_py="$2"
  if [ -x "$venv_dir/bin/python" ] && python_ok "$venv_dir/bin/python"; then
    return 0
  fi
  if [ -e "$venv_dir" ]; then
    backup="$venv_dir.bak.$(date +%Y%m%d-%H%M%S)"
    echo "[deps] 现有 venv 不是可用的 Python 3.11+，移开并重建：$backup" >&2
    mv "$venv_dir" "$backup"
  fi
  "$base_py" -m venv "$venv_dir"
}

# Existing install: use the atomic upgrade path, never rsync over live app.
if [ -f "$TAA_HOME/identity.json" ] && [ -d "$DEST" ]; then
  # 升级同样要跑 pip 与新版服务，解释器只能是 $TAA_HOME/venv 里的那个：
  # 缺失 / 低于 3.11 / 损坏，一律先按 ensure_venv 重建，绝不把系统解释器交给
  # taa_upgrade.py——那会把依赖装进系统 Python（外管环境直接失败）。
  VENV_REBUILD=0
  if [ ! -e "$TAA_HOME/venv" ]; then
    echo "[upgrade] 未发现 $TAA_HOME/venv，先建一个再升级"
    VENV_REBUILD=1
  elif ! python_ok "$TAA_HOME/venv/bin/python"; then
    echo "[upgrade] 现有 venv 不是可用的 Python 3.11+，重建后再升级"
    VENV_REBUILD=1
  fi
  # 空 venv + 跳过依赖 = 新版服务必然缺 Flask 起不来（只能回滚）。
  # 交互终端问一句；非交互（curl | bash、IDE 代跑）不替用户拍板，直接退出。
  if [ "$VENV_REBUILD" = "1" ] && [ "${TAA_UPGRADE_SKIP_DEPS:-0}" = "1" ]; then
    echo "[upgrade] 警告：venv 要重建，却又设了 TAA_UPGRADE_SKIP_DEPS=1——" >&2
    echo "          新 venv 里没有任何依赖，升级后的服务几乎必然起不来。" >&2
    if [ -t 0 ]; then
      printf "[upgrade] 仍要继续？[y/N] " >&2
      read -r _ans || _ans=""
      case "$_ans" in
        y|Y|yes|YES) echo "[upgrade] 按你的选择继续" >&2 ;;
        *) echo "[upgrade] 已取消：去掉 TAA_UPGRADE_SKIP_DEPS 后重跑" >&2; exit 4 ;;
      esac
    else
      echo "[upgrade] 非交互模式下不替你做这个决定，已中止：去掉 TAA_UPGRADE_SKIP_DEPS 后重跑" >&2
      exit 4
    fi
  fi
  ensure_venv "$TAA_HOME/venv" "$PY"
  UPGRADE_PY="$TAA_HOME/venv/bin/python"
  echo "[upgrade] existing install detected"
  # 包内布局：install.sh 与 VERSION/taa_upgrade.py 同级（SRC=包根）；
  # 仓内布局：本脚本在 scripts/ 下，包根是它的上一级。旧实现直接把脚本所在目录
  # 当包根——仓内跑升级会得到 "package VERSION missing"（2026-10-31 撞到）。
  SRC="$ROOT"
  [ -f "$SRC/VERSION" ] || SRC="$(CDPATH= cd -- "$ROOT/.." && pwd)"
  UPGRADE_ARGS=(--source "$SRC" --home "$TAA_HOME" --port "$PORT" --python "$UPGRADE_PY")
  [ "$NO_OPEN" = "1" ] && UPGRADE_ARGS+=(--no-open)
  "$UPGRADE_PY" "$SRC/taa_upgrade.py" "${UPGRADE_ARGS[@]}"
  exit $?
fi

mkdir -p "$DEST" "$TAA_HOME"
if [ "$ROOT" != "$DEST" ]; then
  # Upgrade-safe copy. The live app intentionally contains symlinks for
  # agents/bootstrap/uploads; copying onto those symlinks fails on macOS.
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude=/agents --exclude=/bootstrap --exclude=/static/uploads       "$ROOT/" "$DEST/"
  else
    # Portable fallback: temporarily remove the three data links.
    for rel in agents bootstrap static/uploads; do
      [ -L "$DEST/$rel" ] && rm -f "$DEST/$rel"
    done
    cp -R "$ROOT/." "$DEST/"
  fi
  mkdir -p "$TAA_HOME/agents" "$TAA_HOME/bootstrap" "$TAA_HOME/static/uploads"
  if [ -d "$ROOT/agents" ]; then
    cp -R "$ROOT/agents/." "$TAA_HOME/agents/" 2>/dev/null || true
  fi
  for rel in agents bootstrap static/uploads; do
    if [ -L "$DEST/$rel" ]; then
      rm -f "$DEST/$rel"
    elif [ -d "$DEST/$rel" ]; then
      rm -rf "$DEST/$rel"
    fi
    mkdir -p "$(dirname "$DEST/$rel")"
    ln -s "$TAA_HOME/$rel" "$DEST/$rel"
  done
fi

if [ "$SKIP_DEPS" != "1" ]; then
  ensure_venv "$TAA_HOME/venv" "$PY"
  "$TAA_HOME/venv/bin/python" -m pip install --upgrade pip >/dev/null
  "$TAA_HOME/venv/bin/python" -m pip install -r "$DEST/requirements-core.txt"
  # 渲染能力（论证图/穿搭图）：playwright + chromium。**失败不致命**——
  # pillow + 系统中文字体（core/fonts.py）兜底，中文不会出豆腐块。
  # 日志写 install-render.log，安装报告的自检项「中文渲染」会给出实际状态。
  RENDER_LOG="$TAA_HOME/install-render.log"
  # 渲染栈要下 185MB Chromium，属于**可选能力**（失败走 pillow 兜底）。安装 e2e 计时
  # 不该把它算进"5 分钟装完"，故给一个显式开关：TAA_SKIP_RENDER=1。
  if [ "${TAA_SKIP_RENDER:-0}" = "1" ]; then
    echo "[install] TAA_SKIP_RENDER=1：跳过渲染栈（论证图走 pillow 兜底，中文正常）"
  elif [ -f "$DEST/requirements-render.txt" ]; then
    if "$TAA_HOME/venv/bin/python" -m pip install -r "$DEST/requirements-render.txt" >>"$RENDER_LOG" 2>&1; then
      # macOS 没有 GNU timeout，用 venv python 包一层：下载卡住时到点放弃，
      # 不让安装无限期停在 90%（2026-11-05 实测需人工中断才继续）。
      # 默认 420s，可用 TAA_RENDER_TIMEOUT 覆盖。
      TAA_RENDER_TIMEOUT="${TAA_RENDER_TIMEOUT:-420}" \
        "$TAA_HOME/venv/bin/python" -c '
import os, subprocess, sys
t = int(os.environ.get("TAA_RENDER_TIMEOUT", "420"))
try:
    sys.exit(subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"],
                            timeout=t).returncode)
except subprocess.TimeoutExpired:
    print(f"[install] chromium 下载超过 {t}s，放弃（不阻塞安装）", file=sys.stderr)
    sys.exit(124)
' >>"$RENDER_LOG" 2>&1 \
        || echo "[install] chromium 未装成：论证图走 pillow 兜底（中文正常），详见 $RENDER_LOG"
    else
      echo "[install] playwright 未装成：论证图走 pillow 兜底（中文正常），详见 $RENDER_LOG"
    fi
  fi
  PY="$TAA_HOME/venv/bin/python"
fi

export TAA_HOME TAA_PYTHON="$PY" TAA_HTTP_PORT="$PORT"
cd "$DEST"
if [ "$NO_OPEN" = "1" ]; then
  "$DEST/taa" start --no-open
else
  "$DEST/taa" start
fi
echo "TAA_HOME=$TAA_HOME"
echo "TAA_APP=$DEST"
echo "LOCAL_UI_URL=http://127.0.0.1:$PORT/app/bridge"

# P2.1 安装后自检报告（只读、纯标准库）：装完立刻回答「能不能用、哪一步没过」。
# 报告失败不阻断安装（安装本身已完成），但会把原因与下一步打印出来并落盘。
REPORT_PY="$PY"
[ -x "$TAA_HOME/venv/bin/python" ] && REPORT_PY="$TAA_HOME/venv/bin/python"
echo ""
"$REPORT_PY" "$DEST/scripts/install_report.py" --home "$TAA_HOME" --port "$PORT" || true
