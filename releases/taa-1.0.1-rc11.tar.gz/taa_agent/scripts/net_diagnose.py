#!/usr/bin/env python3
"""Network/DNS diagnostic for TAA model endpoints (no API key, no request body).

TAA beta.43 has two layers of DNS protection:
  * Python: `core.net_retry` installs a `dig` fallback around getaddrinfo.
  * OpenCode: `core/opencode_dns_guard.js` preloads a Node `dig` fallback.

This script reports both the **raw OS resolver** and the **guarded path** so a
macOS mDNSResponder negative-cache hit is visible instead of looking like an
API-key or service outage.

Run when the UI shows:
    Error: getaddrinfo ENOTFOUND api.deepseek.com
Exit code 0 means the guarded path can resolve and reach both endpoints.
"""
from __future__ import annotations

import argparse
import json
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
try:
    from core import net_retry as _nr
    _RAW_LOOKUP = _nr._ORIG_GETADDRINFO
    _GUARDED_LOOKUP = socket.getaddrinfo
except Exception:  # noqa: BLE001
    _nr = None
    _RAW_LOOKUP = socket.getaddrinfo
    _GUARDED_LOOKUP = socket.getaddrinfo

HOSTS = ("api.deepseek.com", "alice.loomsci.com")
LOOPS = 5


def _resolver_snapshot() -> list[str]:
    if sys.platform != "darwin":
        return []
    try:
        p = subprocess.run(["scutil", "--dns"], capture_output=True, text=True, timeout=3)
        out = []
        for line in p.stdout.splitlines():
            line = line.strip()
            if "nameserver[" in line or line.startswith("domain :"):
                out.append(line)
        return out[:12]
    except Exception:  # noqa: BLE001
        return []


def _probe(host: str) -> dict:
    raw_ok = guarded_ok = 0
    ips: set[str] = set()
    raw_errors: list[str] = []
    for _ in range(LOOPS):
        try:
            infos = _RAW_LOOKUP(host, 443, type=socket.SOCK_STREAM)
            raw_ok += 1
            ips.update(str(x[4][0]) for x in infos)
        except Exception as exc:  # noqa: BLE001
            raw_errors.append(f"{type(exc).__name__}: {exc}")
        try:
            infos = _GUARDED_LOOKUP(host, 443, type=socket.SOCK_STREAM)
            guarded_ok += 1
            ips.update(str(x[4][0]) for x in infos)
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.15)
    dig_ip = _nr._dig_address(host) if _nr else None
    result = {"host": host, "dns_ok": raw_ok, "guarded_ok": guarded_ok,
              "dns_loops": LOOPS, "ips": sorted(ips), "raw_errors": raw_errors[:3],
              "dig_ip": dig_ip, "https": None, "https_error": ""}
    if not guarded_ok:
        return result
    try:
        req = urllib.request.Request("https://" + host + "/", method="HEAD",
                                     headers={"User-Agent": "TAA-net-diagnose"})
        with urllib.request.urlopen(req, timeout=8) as r:
            result["https"] = r.status
    except urllib.error.HTTPError as exc:
        result["https"] = exc.code  # e.g. 401/403 still proves reachability
    except Exception as exc:  # noqa: BLE001
        result["https_error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    hostname = socket.gethostname()
    resolvers = _resolver_snapshot()
    rows = [_probe(h) for h in HOSTS]
    ok = all(r["guarded_ok"] == LOOPS and r["https"] for r in rows)
    if args.json:
        print(json.dumps({"hostname": hostname, "resolvers": resolvers,
                          "hosts": rows, "ok": ok}, ensure_ascii=False, indent=2))
        return 0 if ok else 1
    print("== TAA net_diagnose ==")
    print("hostname:", hostname)
    if resolvers:
        print("system resolvers (scutil --dns):")
        for line in resolvers:
            print("  " + line)
    elif Path("/etc/resolv.conf").exists():
        print("resolv.conf:")
        print("\n".join(Path("/etc/resolv.conf").read_text(errors="ignore").splitlines()[:8]))
    for r in rows:
        print(f"\n[{r['host']}]")
        raw_state = "OK" if r["dns_ok"] == r["dns_loops"] else "FLAKY/FAIL"
        guard_state = "OK" if r["guarded_ok"] == r["dns_loops"] else "FLAKY/FAIL"
        print(f"  dns raw:     {raw_state} ({r['dns_ok']}/{r['dns_loops']})")
        print(f"  dns guarded: {guard_state} ({r['guarded_ok']}/{r['dns_loops']})"
              + (f"  dig={r['dig_ip']}" if r["dig_ip"] else ""))
        print(f"  ips: {', '.join(r['ips']) or '-'}")
        for err in r["raw_errors"]:
            print("  raw error:", err)
        if r["https"]:
            print("  https:", r["https"], "(reachable)")
        else:
            print("  https: FAIL", r["https_error"] or "skipped (DNS failed)")
    if any(r["dns_ok"] < LOOPS and r["guarded_ok"] == LOOPS for r in rows):
        print("\nNOTE: raw getaddrinfo failed but TAA's dig guard resolved the host.")
    print("\nRESULT", "PASS" if ok else "FAIL")
    if not ok:
        print("建议：若 raw DNS 与 dig 都失败，检查 Wi-Fi/VPN；"
              "需要时可让管理员执行 `sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder`。")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
