#!/usr/bin/env python3
"""agent_procs —— agent 进程树的公共判定：单实例锁 / 孤儿扫描 / 优雅停止 / 父存活。

为什么单独成模块（docs/specs/alice_personal/16 §2）：
  supervisor、restart_agent、门禁测试三处都要回答同样四个问题——
  「这个 pid 还是原来那个进程吗」「哪些是本 agent 的孤儿」「怎么停才算优雅」
  「父进程还在吗」。各写一份必然漂移，出事时三个口径互相打架。

四件事的口径（全部可单测，不依赖真实 agent）：

  * 锁文件：JSON `{pid, start, at}`；兼容旧格式（纯 pid 文本）。
  * 判活：pid 存在 **且** 启动指纹一致。指纹不符 = PID 被复用 → 视为过期锁，
    否则机器重启后 pid 号被别的进程占住，supervisor 会永远起不来。
  * 孤儿：PPID 为 1（被 reparent）或 PPID 已死。只认**孤儿**，不碰活着的进程树——
    正常子进程的 PPID 是 supervisor，不会被误杀。
  * 停止：SIGTERM → 宽限 → SIGKILL。宽限期可配（TEAMAI_STOP_GRACE，默认 5s）。
"""
from __future__ import annotations

import json
import os
import re
import signal
import subprocess
import time
from pathlib import Path

# 停的顺序：先 supervisor（否则它会继续拉起子进程），再 worker。
KINDS = ("supervisor", "loop", "dispatcher", "chatroom_agent")
AGENT_RE = re.compile(r"(?:/|^)(?:runtime|dist)/"
                      r"(?:supervisor|loop|dispatcher|chatroom_agent)\.py\b")
DEFAULT_GRACE = float(os.environ.get("TEAMAI_STOP_GRACE", "5"))


# ---------------------------------------------------------------- 进程存在性

def alive(pid) -> bool:
    """pid 是否存活（信号 0 探测；无权限也视为存活——宁可不动别人的进程）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def proc_start(pid) -> str | None:
    """进程启动指纹（防 PID 复用）。取不到返回 None —— 调用方退回只看 pid。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return None
    # Linux：/proc/<pid>/stat 第 22 字段（自开机起的 jiffies），不随重启变化。
    try:
        raw = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8", errors="replace")
        tail = raw[raw.rfind(")") + 2:].split()
        if len(tail) > 19:
            return f"jiffies:{tail[19]}"
    except OSError:
        pass
    # macOS / BSD：ps 的 lstart（人类可读的精确启动时刻）。
    try:
        out = subprocess.check_output(["ps", "-o", "lstart=", "-p", str(pid)],
                                      text=True, timeout=5).strip()
        if out:
            return f"lstart:{out}"
    except Exception:                                    # noqa: BLE001
        pass
    return None


def zombie(pid) -> bool:
    """是否僵尸进程（已退出但父进程还没 wait）。

    不加这一条，`stop()` 会对着已经 TERM 掉的僵尸再补一次 SIGKILL，
    日志里出现"term=[A] kill=[A]"的假象，让人误以为它不肯退。
    """
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    try:
        raw = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8", errors="replace")
        tail = raw[raw.rfind(")") + 2:].split()
        return bool(tail) and tail[0] == "Z"
    except OSError:
        pass
    try:
        out = subprocess.check_output(["ps", "-o", "state=", "-p", str(pid)],
                                      text=True, timeout=5).strip()
        return out.upper().startswith("Z")
    except Exception:                                    # noqa: BLE001
        return False


def parent_alive(initial_ppid: int) -> bool:
    """子进程侧的父存活判定：PPID 变了（被 reparent）= 父已死。

    比"pid 是否还能 kill 到"可靠：父被 SIGKILL 后子进程会被 reparent 到 launchd/init，
    PPID 立刻变化；而 pid 本身可能被系统复用，用 pid 判活会出现假存活。
    启动时 PPID 已经是 1（自己就是孤儿）→ 恒为 True，不误杀。
    """
    try:
        initial = int(initial_ppid)
    except (TypeError, ValueError):
        return True
    if initial <= 1:
        return True
    try:
        return os.getppid() == initial
    except Exception:                                    # noqa: BLE001
        return True


# ---------------------------------------------------------------- 进程扫描

def scan(agent: str, root=None, ps_output: str | None = None) -> list[dict]:
    """同一 agent 的 runtime 进程（不含自己），按停的顺序排好。

    `ps_output` 可注入，便于门禁单测解析逻辑而不真起进程。
    `root` 给了就只认同一个部署目录，避免同机多份部署互相误杀。
    """
    if ps_output is None:
        try:
            ps_output = subprocess.check_output(["ps", "-axo", "pid=,ppid=,command="],
                                                text=True, timeout=20)
        except Exception:                                # noqa: BLE001
            return []
    me = os.getpid()
    root_s = str(root) if root else ""
    found: list[dict] = []
    for line in (ps_output or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        try:
            pid, ppid = int(parts[0]), int(parts[1])
        except ValueError:
            continue
        cmd = parts[2]
        if pid == me or not AGENT_RE.search(cmd):
            continue
        # 只匹配 --as <agent>，避免误伤同机其他 agent
        if not re.search(r"(?:^|\s)--as\s+" + re.escape(str(agent)) + r"(?:\s|$)", cmd):
            continue
        if root_s and root_s not in cmd:
            continue
        kind = next((k for k in KINDS if f"{k}.py" in cmd), "unknown")
        found.append({"pid": pid, "ppid": ppid, "kind": kind, "cmd": cmd})
    found.sort(key=lambda x: KINDS.index(x["kind"]) if x["kind"] in KINDS else 99)
    return found


def orphans(agent: str, root=None, ps_output: str | None = None) -> list[dict]:
    """本 agent 的孤儿进程：PPID 为 1（被 reparent）或 PPID 已不存在。"""
    out = []
    for p in scan(agent, root=root, ps_output=ps_output):
        if p["ppid"] == 1 or not alive(p["ppid"]):
            out.append(p)
    return out


def stop(procs, grace: float | None = None, protect=()) -> dict:
    """SIGTERM → 宽限 → SIGKILL。返回 {"term": [...], "kill": [...]}。

    `protect` 里的 pid 一律不动（例如正在执行任务、有 heartbeat 的子进程）。
    """
    grace = DEFAULT_GRACE if grace is None else float(grace)
    protect_pids = set()
    for p in protect or ():
        try:
            protect_pids.add(int(p.get("pid") if isinstance(p, dict) else p))
        except (TypeError, ValueError):
            continue
    termed: list[int] = []
    for p in procs or ():
        pid = p.get("pid") if isinstance(p, dict) else p
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            continue
        if pid in protect_pids or not alive(pid):
            continue
        try:
            os.kill(pid, signal.SIGTERM)
            termed.append(pid)
        except OSError:
            pass
    deadline = time.time() + max(0.0, grace)
    while time.time() < deadline and any(alive(p) for p in termed):
        time.sleep(0.1)
    killed: list[int] = []
    for pid in termed:
        if alive(pid) and not zombie(pid):
            try:
                os.kill(pid, signal.SIGKILL)
                killed.append(pid)
            except OSError:
                pass
    return {"term": termed, "kill": killed}


# ---------------------------------------------------------------- 忙碌标记（心跳保护）

# 标记过期时间：超过这个时长没更新，就不再认为"正在执行任务"（防进程被 SIGKILL 后残留）。
BUSY_TTL = float(os.environ.get("TEAMAI_BUSY_TTL", "300"))
# 停机时给正在执行的任务留的收尾时间（docs/16 §2.5「不杀有 heartbeat 的任务」）。
BUSY_WAIT = float(os.environ.get("TEAMAI_BUSY_WAIT", "60"))


def busy_path(root, agent: str) -> Path:
    return Path(root) / "runtime" / f".busy.{agent}.json"


def write_busy(root, agent: str, task_id: str = "") -> Path:
    """标记"本进程正在执行任务"。停机时据此给它留收尾时间，不直接 SIGKILL。"""
    p = busy_path(root, agent)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"pid": os.getpid(), "task_id": str(task_id or ""),
                             "ts": time.time()}, ensure_ascii=False), encoding="utf-8")
    return p


def clear_busy(root, agent: str) -> None:
    try:
        busy_path(root, agent).unlink()
    except FileNotFoundError:
        pass


def read_busy(root, agent: str, ttl: float | None = None,
              now: float | None = None) -> dict | None:
    """读忙碌标记；过期 / 损坏 / 进程已死 → None。"""
    p = busy_path(root, agent)
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, TypeError, ValueError):
        return None
    if not isinstance(d, dict):
        return None
    try:
        pid = int(d.get("pid") or 0)
        ts = float(d.get("ts") or 0)
    except (TypeError, ValueError):
        return None
    ttl = BUSY_TTL if ttl is None else float(ttl)
    now = time.time() if now is None else float(now)
    if not pid or (now - ts) > ttl or not alive(pid):
        return None
    return {"pid": pid, "task_id": str(d.get("task_id") or ""), "ts": ts}


# ---------------------------------------------------------------- 单实例锁

def read_lock(path: Path) -> dict:
    """读锁文件 {pid, start}；兼容旧格式（纯 pid 文本）；坏内容返回 {}。"""
    try:
        raw = Path(path).read_text(encoding="utf-8").strip()
    except OSError:
        return {}
    if not raw:
        return {}
    if raw.startswith("{"):
        try:
            d = json.loads(raw)
        except (TypeError, ValueError):
            return {}
        try:
            return {"pid": int(d.get("pid") or 0), "start": str(d.get("start") or "")}
        except (TypeError, ValueError):
            return {}
    try:
        return {"pid": int(raw), "start": ""}
    except ValueError:
        return {}


def write_lock(path: Path, pid: int | None = None) -> None:
    pid = int(pid or os.getpid())
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps({
        "pid": pid, "start": proc_start(pid) or "",
        "at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }, ensure_ascii=False), encoding="utf-8")


def lock_is_live(path: Path) -> tuple[bool, int]:
    """锁是否被**活着的同一个进程**持有。返回 (live, pid)。"""
    info = read_lock(path)
    pid = info.get("pid") or 0
    if not pid or not alive(pid):
        return False, pid
    want = info.get("start") or ""
    if want:
        got = proc_start(pid) or ""
        # 取不到当前指纹时保守认为还活着（宁可拒绝启动，也不双跑）。
        if got and got != want:
            return False, pid
    return True, pid


def acquire_lock(path: Path, takeover: bool = False, agent: str = "",
                 root=None, grace: float | None = None) -> tuple[bool, str]:
    """拿单实例锁。返回 (ok, reason)，reason ∈ created|stale|took_over|running。

    ok=False 只有一种情形：已有**活着的**实例且没给 takeover。
    takeover=True 时先停同 agent 的旧树再接管（自动更新/人工重启路径用）。
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, json.dumps({
            "pid": os.getpid(), "start": proc_start(os.getpid()) or "",
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }, ensure_ascii=False).encode())
        os.close(fd)
        return True, "created"
    except FileExistsError:
        pass
    live, pid = lock_is_live(path)
    if live and not takeover:
        return False, f"running:{pid}"
    if live and takeover and agent:
        stop(scan(agent, root=root), grace=grace, protect=(os.getpid(),))
    write_lock(path)
    return True, ("took_over" if live else "stale")
