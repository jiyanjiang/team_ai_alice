#!/usr/bin/env python3
"""teamai —— 团队AI 工作区命令行客户端（agent 与人都可用，自包含、可分发）。

常用：
    python cli/teamai.py bootstrap
    python cli/teamai.py join --url https://127.0.0.1:6030 --token <enroll> \
        --agent-id carol --name Carol --ca certs/server.crt
    python cli/teamai.py handshake --as carol
    python cli/teamai.py agents / board / tasks --for bob
    python cli/teamai.py create --as alice --title ... --desc ... --ac ...
    python cli/teamai.py claim <task_id> --as bob --reason ...
    python cli/teamai.py review <task_id> --as alice --decision approved --score 0.9
    python cli/teamai.py mint-token --as alice --max-uses 3
    python cli/teamai.py sync --as alice
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import platform
import secrets
import shutil
import socket
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
BASE = os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030").rstrip("/")
SSL_CTX: ssl.SSLContext | None = None
try:  # DNS/network retry for the optional memory-reflection call
    from core.net_retry import urlopen_retry as _urlopen_retry
except Exception:  # noqa: BLE001
    _urlopen_retry = urllib.request.urlopen


# ------------------------------------------------------------------ transport
def _ssl_context(ca: str | None, insecure: bool) -> ssl.SSLContext | None:
    if not BASE.startswith("https"):
        return None
    if insecure:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    cafile = ca or os.environ.get("TEAMAI_CA")
    return ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()


def _canonical(method: str, path: str, body: bytes, ts: str, nonce: str) -> bytes:
    body_hash = hashlib.sha256(body or b"").hexdigest()
    return f"{method.upper()}\n{path}\n{body_hash}\n{ts}\n{nonce}".encode("utf-8")


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    return hmac.new(key.encode("utf-8"), _canonical(method, path, body, ts, nonce),
                    hashlib.sha256).hexdigest()


def _key(agent_id: str) -> dict:
    p = ROOT / "agents" / agent_id / ".key"
    if not p.exists():
        sys.exit(f"no key for agent '{agent_id}'. Run: python cli/teamai.py bootstrap (or join)")
    return json.loads(p.read_text(encoding="utf-8"))


def call(method: str, path: str, body: dict | None = None, agent_id: str | None = None,
         enroll_token: str | None = None, bearer: str | None = None) -> dict:
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else b""
    req = urllib.request.Request(BASE + path, data=data if body is not None else None, method=method)
    req.add_header("Content-Type", "application/json")
    if agent_id:
        k = _key(agent_id)
        ts = str(int(time.time()))
        nonce = secrets.token_hex(8)
        sig = _sign(k["key"], method, path, data, ts, nonce)
        req.add_header("X-TeamAI-Key", k["key_id"])
        req.add_header("X-TeamAI-Timestamp", ts)
        req.add_header("X-TeamAI-Nonce", nonce)
        req.add_header("X-TeamAI-Signature", sig)
        _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
        if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    elif enroll_token:
        req.add_header("X-Enroll-Token", enroll_token)
    elif bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
    try:
        with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8"))
        except Exception:
            payload = {"error": str(e)}
        sys.exit(f"HTTP {e.code}: {payload.get('error', payload)}")
    except urllib.error.URLError as e:
        sys.exit(f"cannot reach {BASE}: {e.reason}")


def _root_token() -> str:
    p = ROOT / "bootstrap" / "enroll.key"
    if not p.exists():
        sys.exit("no root token (bootstrap/enroll.key). Run server/bootstrap first.")
    return p.read_text(encoding="utf-8").strip()


def _download_signed(url_path: str, dest: Path, agent_id: str) -> str:
    k = _key(agent_id)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    sig = _sign(k["key"], "GET", url_path, b"", ts, nonce)
    req = urllib.request.Request(BASE + url_path)
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", sig)
    _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
    if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    with urllib.request.urlopen(req, timeout=120, context=SSL_CTX) as r:
        data = r.read()
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def _verify_manifest(m: dict, pubkey_b64: str) -> bool:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(pubkey_b64))
        canon = json.dumps({k: v for k, v in m.items() if k not in ("signature", "ok")},
                           sort_keys=True, ensure_ascii=False).encode()
        pub.verify(base64.urlsafe_b64decode(m["signature"]), canon)
        return True
    except Exception:
        return False


def _pin_and_verify(manifest: dict, fingerprint: str | None = None) -> None:
    """验签 + TOFU 固定公钥 + 防回滚（serial 单调）。"""
    rt = ROOT / "runtime"
    rt.mkdir(exist_ok=True)
    pin = rt / ".server_pubkey"
    if pin.exists():
        if not _verify_manifest(manifest, pin.read_text().strip()):
            sys.exit("manifest signature invalid (pinned key)")
    else:
        pub = manifest.get("pubkey")
        if not pub or not _verify_manifest(manifest, pub):
            sys.exit("manifest unsigned or invalid signature")
        if fingerprint and manifest.get("key_fingerprint") != fingerprint:
            sys.exit(f"server fingerprint mismatch: {manifest.get('key_fingerprint')} != {fingerprint}")
        pin.write_text(pub, encoding="utf-8")
        print(f"  pinned server key fingerprint: {manifest.get('key_fingerprint')}")
    inst = rt / ".installed.json"
    if inst.exists():
        try:
            prev = json.loads(inst.read_text(encoding="utf-8"))
            if prev.get("_serial", 0) > manifest.get("serial", 0):
                sys.exit(f"manifest serial rolled back: {manifest.get('serial')} < {prev.get('_serial')}")
        except SystemExit:
            raise
        except Exception:
            pass


def ensure_runtime(manifest: dict, agent_id: str | None = None, enroll_token: str | None = None) -> list:
    """验签后按 sha256 校验本地 runtime/，只下载缺失或变更的程序。"""
    _pin_and_verify(manifest)
    rt = ROOT / "runtime"
    rt.mkdir(exist_ok=True)
    installed, changed = {}, []
    for p in manifest.get("programs", []):
        dest = rt / f"{p['name']}.py"
        ok = dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest() == p["sha256"]
        if not ok:
            got = (_download_signed(p["url"], dest, agent_id) if agent_id
                   else _download(p["url"], dest, enroll_token))
            ok = got == p["sha256"]
            changed.append({"name": p["name"], "ok": ok})
        if ok:
            installed[p["name"]] = {"version": p["version"], "sha256": p["sha256"]}
    installed["_serial"] = manifest.get("serial", 0)
    (rt / ".installed.json").write_text(json.dumps(installed, ensure_ascii=False, indent=2), encoding="utf-8")
    return changed


def _packages() -> list:
    p = ROOT / "runtime" / ".installed.json"
    if not p.exists():
        return []
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []
    return [{"name": k, "sha256": v.get("sha256")} for k, v in d.items()
            if isinstance(v, dict) and "sha256" in v]


def _download(url_path: str, dest: Path, enroll_token: str) -> str:
    req = urllib.request.Request(BASE + url_path)
    req.add_header("X-Enroll-Token", enroll_token)
    with urllib.request.urlopen(req, timeout=120, context=SSL_CTX) as r:
        data = r.read()
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def _print(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))


# ------------------------------------------------------------------ hardware
def _run(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


def detect_hardware() -> dict:
    system = platform.system()
    ram = 0.0
    if system == "Darwin":
        out = _run(["sysctl", "-n", "hw.memsize"])
        if out.isdigit():
            ram = round(int(out) / (1024 ** 3))
    elif system == "Linux":
        try:
            for line in open("/proc/meminfo", encoding="utf-8"):
                if line.startswith("MemTotal"):
                    ram = round(int(line.split()[1]) / (1024 ** 2))
        except OSError:
            pass
    alias = os.environ.get("TEAM_NODE_ALIAS")
    if not alias:
        base = "MAC"
        if system == "Darwin":
            name = ""
            for line in _run(["system_profiler", "SPHardwareDataType"]).splitlines():
                if line.strip().startswith("Model Name:"):
                    name = line.split(":", 1)[1].strip()
            base = {"MacBook Pro": "MBP", "MacBook Air": "MBA", "Mac mini": "MINI",
                    "iMac": "IMAC", "Mac Studio": "STUDIO", "Mac Pro": "PRO"}.get(name, "MAC")
        elif system == "Windows":
            base = "PC"
        else:
            base = "WS"
        alias = f"{base}{int(ram)}G"
    try:
        usage = shutil.disk_usage(os.path.expanduser("~"))
        total, free = round(usage.total / 1024 ** 3), round(usage.free / 1024 ** 3)
    except Exception:
        total, free = 0, 0
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import nodeinfo as _ni
        lan_ip = _ni._lan_ip()
    except Exception:
        lan_ip = "127.0.0.1"
    ides = [i for i in ("opencode", "code", "cursor", "qoder", "codebuddy", "nvim")
            if shutil.which(i)]
    return {"hostname": socket.gethostname().split(".")[0], "alias": alias,
            "os": f"{system} {platform.release()}", "arch": platform.machine(),
            "cpu_model": platform.processor() or "unknown", "cpu_cores": os.cpu_count() or 0,
            "ram_gb": ram, "disk_total_gb": total, "disk_free_gb": free, "lan_ip": lan_ip,
            "python_version": platform.python_version(), "available_ides": ides, "is_main": 0}


def _persona(agent_id: str, name: str) -> dict:
    p = ROOT / "agents" / agent_id / "persona.yaml"
    if p.exists():
        try:
            import yaml
            return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:
            pass
    return {"id": agent_id, "name": name, "role": "executor",
            "identity": {"avatar": "🙂", "motto": "初来乍到，请多关照。"}}


# ------------------------------------------------------------------ commands
def cmd_bootstrap(_args):
    from core import bootstrap
    _print(bootstrap.bootstrap())


def cmd_join(args):
    global BASE, SSL_CTX
    if not getattr(args, "url", None):
        sys.exit("--url required")
    BASE = args.url.rstrip("/")
    SSL_CTX = _ssl_context(args.ca, args.insecure)
    aid, name = args.agent_id, args.name or args.agent_id.capitalize()

    man = call("GET", "/v1/bootstrap/manifest", enroll_token=args.token)
    print(f"manifest protocol={man['protocol']} runtime={man['runtime_version']} "
          f"programs={[p['name'] for p in man['programs']]}")
    changed = ensure_runtime(man, enroll_token=args.token)
    if any(not c["ok"] for c in changed):
        sys.exit("integrity check failed")
    print("  runtime:", "up-to-date" if not changed else f"downloaded {[c['name'] for c in changed]}")

    # 工具 / 截图依赖：新节点常缺 playwright Chromium（否则 tools/*.py 直接抛错）——best-effort
    try:
        import sys as _sys2
        if str(ROOT) not in _sys2.path:
            _sys2.path.insert(0, str(ROOT))
        from core.deps import ensure_chromium
        _d = ensure_chromium(quiet=False)
        print(f"  deps: chromium {_d.get('action')} ok={_d.get('ok')}")
    except Exception as _e:  # noqa: BLE001
        print(f"  deps: chromium ensure skipped ({_e})")

    persona = _persona(aid, name)
    persona.setdefault("id", aid)
    persona.setdefault("name", name)
    res = call("POST", "/v1/enroll", {"agent_id": aid, "name": name, "persona": persona},
               enroll_token=args.token)
    (ROOT / "agents" / aid).mkdir(parents=True, exist_ok=True)
    (ROOT / "agents" / aid / ".key").write_text(
        json.dumps({"key_id": res["key_id"], "key": res["key"]}, ensure_ascii=False), encoding="utf-8")
    os.chmod(ROOT / "agents" / aid / ".key", 0o600)
    if res.get("recovery_code"):
        (ROOT / "agents" / aid / ".recovery").write_text(res["recovery_code"], encoding="utf-8")
        os.chmod(ROOT / "agents" / aid / ".recovery", 0o600)
    print(f"enrolled {aid}; recovery_code saved to agents/{aid}/.recovery")

    hw = detect_hardware()
    hs = call("POST", "/v1/handshake",
              {"hardware": hw, "protocol_version": man["protocol"],
               "runtime_version": man["runtime_version"],
               "capabilities": [], "packages": _packages()},
              agent_id=aid)
    try:
        import sys as _sys
        if str(ROOT) not in _sys.path:
            _sys.path.insert(0, str(ROOT))
        from core import nodeinfo as _ni
        _ni.save_alias(hw.get("alias"))
    except Exception:
        pass
    print(f"joined as {hs['identity']}  role={hs['role']}  sync={hs['sync_interval_min']}min")
    _print_update(hs)
    _print_briefing(hs)


def _print_update(hs: dict):
    u = hs.get("update") or {}
    if u.get("required"):
        print(f"  update available: stale={u.get('stale')} (manifest {u.get('manifest_version')})")


def _print_briefing(hs: dict):
    b = hs.get("briefing") or {}
    if hs.get("onboarding"):
        print("  onboarding:", json.dumps(hs["onboarding"], ensure_ascii=False))
    if b.get("channels"):
        print("  channels:", ", ".join(b["channels"]))
    for r in b.get("constitution", []):
        print(f"    · {r.get('rule_key')}: {r.get('content')}")
    for s in b.get("next_steps", []):
        print("    →", s)


def cmd_issue_key(args):
    d = call("POST", "/v1/agents/issue",
             {"agent_id": args.agent_id, "name": args.name}, enroll_token=_root_token())
    print(f"agent: {d['agent_id']}  (created={d['created']})")
    print(f"key_id: {d['key_id']}")
    print(f"key:    {d['key']}")
    print(f"→ 交给该 agent 的 IDE：写入 agents/{d['agent_id']}/.key 或作为环境变量；"
          f"随后 `teamai hello --agent {d['agent_id']}`")


def cmd_hello(args):
    global BASE, SSL_CTX
    if getattr(args, "url", None):
        BASE = args.url.rstrip("/")
        SSL_CTX = _ssl_context(getattr(args, "ca", None), getattr(args, "insecure", False))
    man = call("GET", "/v1/health")
    hs = call("POST", "/v1/handshake",
              {"hardware": detect_hardware(), "protocol_version": man["protocol"],
               "runtime_version": man["runtime_version"], "capabilities": [], "packages": _packages()},
              agent_id=args.agent)
    print(f"identity: {hs['identity']}  role={hs['role']}  node={hs['node_id']}  "
          f"sync={hs['sync_interval_min']}min")
    _print_update(hs)
    _print_briefing(hs)
    if hs.get("card"):
        print("  card(JSON):")
        print(json.dumps(hs["card"], ensure_ascii=False, indent=2))
    changed = ensure_runtime(hs.get("briefing", {}).get("manifest", {}), agent_id=args.agent)
    print("  runtime:", "up-to-date" if not changed else f"downloaded {[c['name'] for c in changed]}")

    # 工具 / 截图依赖：新节点常缺 playwright Chromium（否则 tools/*.py 直接抛错）——best-effort
    try:
        import sys as _sys2
        if str(ROOT) not in _sys2.path:
            _sys2.path.insert(0, str(ROOT))
        from core.deps import ensure_chromium
        _d = ensure_chromium(quiet=False)
        print(f"  deps: chromium {_d.get('action')} ok={_d.get('ok')}")
    except Exception as _e:  # noqa: BLE001
        print(f"  deps: chromium ensure skipped ({_e})")


def cmd_card(args):
    _print(call("GET", "/v1/agent-card", agent_id=args.as_agent)["card"])


# ------------------------------------------------------------------ chat room (docs/11)
def cmd_room_create(args):
    body = {"topic": args.topic, "channel_id": args.channel, "expected_minutes": args.minutes,
            "rating": getattr(args, "rating", "general")}
    lv = getattr(args, "level", None)
    if lv:
        body["content_level"] = lv
    d = call("POST", "/v1/rooms", body, agent_id=args.as_agent)
    print("room:", d["room_id"])


def cmd_self_update(args):
    """客户端节点自更新：从 A 拉签名 bundle → 验签 → precheck → 快照 → 替换本地代码（保留 agents/data）。"""
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from core import apply as apply_mod, distribution
    from_ver = distribution.runtime_version()
    m, data = apply_mod.fetch_bundle(args.from_peer, args.token)
    to_ver = m.get("runtime_version", "")
    print(f"来源 {args.from_peer}：runtime={to_ver} protocol={m.get('protocol')}")
    if not args.force and not apply_mod.version_gt(to_ver, from_ver):
        sys.exit(f"不是升级：{from_ver} -> {to_ver}（如需强制加 --force）")
    res = apply_mod.apply_bundle(data, cur_version=from_ver, cur_major=1,
                                 install_deps=bool(args.install_deps))
    if not res.get("ok"):
        sys.exit(f"更新失败于 {res.get('stage')}：{res.get('log') or res.get('precheck')}")
    print(f"已更新 {from_ver} -> {to_ver}（快照 {res.get('snapshot')}）")
    print("重启 agent 驱动后生效；回滚：teamai 无服务端时用 .snapshots 手动还原")


def cmd_pw_login(args):
    """打开浏览器登录 physicsworld，登录态存入 agents/<id>/.pwprofile（供工具复用）。"""
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from playwright.sync_api import sync_playwright
    prof = ROOT / "agents" / args.as_agent / ".pwprofile"
    prof.mkdir(parents=True, exist_ok=True)
    url = args.url or "https://physicsworld.com/login/"
    with sync_playwright() as pw:
        ctx = pw.chromium.launch_persistent_context(str(prof), headless=False,
                                                    viewport={"width": 1440, "height": 1000})
        pg = ctx.new_page()
        pg.goto(url, wait_until="domcontentloaded", timeout=45000)
        print(f"已打开登录页（profile={prof}）。请在窗口里登录…")
        if _sys.stdin.isatty():
            try:
                input("登录完成后按回车保存并关闭…")
            except EOFError:
                pass
        else:
            print("（非交互终端）最多等待 3 分钟…")
            pg.wait_for_timeout(180000)
        ctx.close()
    print(f"登录态已保存到 {prof}")


def cmd_tool_publish(args):
    d = call("POST", "/v1/tools/publish",
             {"name": args.name, "version": args.version, "force": args.force},
             agent_id=args.as_agent)
    print(f"已发布工具 {d['name']} v{d['version']} sha={d['sha256'][:12]} → #{d.get('channel', 'tools')}")


def cmd_tool_list(args):
    d = call("GET", "/v1/tools/packages", agent_id=args.as_agent)
    print("市场工具包：")
    for p in d["packages"]:
        print(f"  {p['name']} v{p['version']} sha={p['sha256'][:12]} "
              f"by={p['created_by']} @{p['created_at']}")
    print("已安装（可调用）：")
    for t in call("GET", "/v1/tools", agent_id=args.as_agent)["tools"]:
        print(f"  {t['name']} — {t.get('description', '')[:50]}")


def cmd_tool_install(args):
    d = call("POST", "/v1/tools/install", {"name": args.name, "sha": args.sha},
             agent_id=args.as_agent)
    print(f"已安装 {d['name']} → {d['installed_to']}；已加载：{d.get('loaded')}")


def cmd_offer(args):
    """把本机发行版推送给对端（双向同步）。"""
    import urllib.request
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from core import distribution, nodeinfo
    m = distribution.manifest()
    data = distribution.bundle()
    body = json.dumps({"manifest": m, "bundle_b64": base64.b64encode(data).decode(),
                       "node": nodeinfo.detect().get("alias")}).encode()
    req = urllib.request.Request(args.to.rstrip("/") + "/v1/federation/offer",
                                 data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    if args.token:
        req.add_header("X-Enroll-Token", args.token)
    with urllib.request.urlopen(req, timeout=300, context=SSL_CTX) as r:
        d = json.loads(r.read().decode())
    print(f"已推送发行版 v{d.get('version')} → {args.to}（node={d.get('node')}）")


def cmd_versions(args):
    d = call("GET", "/v1/federation/versions", agent_id=args.as_agent)
    s = d["self"]
    print(f"本机 {s['node']}: v{s['version']} sha={s['bundle_sha'][:12]} serial={s['serial']}")
    for p in d.get("peers", []):
        tag = "⚠分歧" if p.get("diverged") else "✓一致"
        print(f"  对端 {p['node_id']}: v{p['version']} "
              f"sha={(p.get('bundle_sha') or '')[:12]} {tag} @{p.get('received_at')}")


def cmd_adopt_offer(args):
    d = call("POST", "/v1/federation/adopt-offer", {"node": args.node}, agent_id=args.as_agent)
    print(f"已采纳 {d.get('node')} v{d.get('version')}（快照 {d.get('snapshot')}）；重启后生效")


def cmd_workgroup(args):
    """创建/复用缺省跨机工作群（human + 本地 agent + 远程 agent）。"""
    members = [m.strip() for m in (args.agents or "alice,carol").split(",") if m.strip()]
    topic = args.topic or "跨机工作群"
    d = call("GET", "/v1/rooms", agent_id=args.as_agent)
    existing = next((r for r in d.get("rooms", [])
                     if r.get("status") == "running" and r.get("topic") == topic), None)
    if existing:
        rid = existing["id"]
        print(f"复用进行中的工作群：{rid}")
    else:
        body = {"topic": topic, "expected_minutes": int(args.minutes),
                "rating": getattr(args, "rating", "general")}
        if getattr(args, "level", None):
            body["content_level"] = args.level
        rid = call("POST", "/v1/rooms", body, agent_id=args.as_agent)["room_id"]
        for m in members:
            try:
                d = call("POST", f"/v1/rooms/{rid}/invite",
                         {"agent_id": m, "force": True}, agent_id=args.as_agent)
                print(f"  拉入 {m}: {'ok' if d.get('added') else d}")
            except SystemExit:
                print(f"  （拉入 {m} 失败，跳过）")
        call("POST", f"/v1/rooms/{rid}/start", {}, agent_id=args.as_agent)
        print(f"已建工作群：{rid}")
    print(f"成员：human, {', '.join(members)}")
    print(f"查看：Web 侧栏「读书会」→ {rid}")
    print(f"     或 CLI: teamai room {rid} --as human")


def cmd_room_share(args):
    d = call("POST", f"/v1/rooms/{args.room_id}/share",
             {"as_agent": args.as_agent_id}, agent_id=args.as_agent)
    print(f"share token: {d['token']}  (as_agent={d.get('as_agent')})")
    print(f"url: {d.get('url')}")


def cmd_rooms(args):
    for r in call("GET", "/v1/rooms", agent_id=args.as_agent)["rooms"]:
        print(f"  {r['id']} [{r['status']:<7}] round={r['current_round']} {r['topic']}")


def cmd_room(args):
    d = call("GET", f"/v1/rooms/{args.room_id}", agent_id=args.as_agent)
    cur = d.get("current_turn")
    print(f"room {d['room']['id']} [{d['room']['status']}] topic={d['room']['topic']}")
    print(f"  members: {', '.join(m['agent_id'] for m in d['room']['members'])}")
    if cur:
        print(f"  >>> 当前发言: {cur['agent_id']}  state={cur['state']}  "
              f"prepare_deadline={cur['prepare_deadline']}  open_deadline={cur['open_deadline']}  "
              f"now={cur['server_time']}")
    print("  arena:", ", ".join(f"{a['agent_id']}#{a['rank']}({a['score']})" for a in d["arena"]) or "-")
    for m in d["transcript"]:
        print(f"    [{m['round']}] {m['author'] or m['agent_id']} ({m['kind']}, {m['score']}): {(m['body'] or '')[:80]}")


def cmd_room_invite(args):
    d = call("POST", f"/v1/rooms/{args.room_id}/invite",
             {"agent_id": args.agent_id, "force": getattr(args, "force", False)},
             agent_id=args.as_agent)
    state = "added" if d.get("added") else ("accepted" if d.get("accepted") else "declined")
    print(f"  {d['agent_id']}: {state} — {d.get('reason', '')}")


def cmd_room_start(args):
    call("POST", f"/v1/rooms/{args.room_id}/start", {}, agent_id=args.as_agent)
    print("started")


def cmd_room_say(args):
    d = call("POST", f"/v1/rooms/{args.room_id}/say",
             {"body": args.body, "kind": args.kind, "attachment": getattr(args, "attach", None)},
             agent_id=args.as_agent)
    print(f"said: score={d['score']} novelty={d['novelty']} rehash={d['rehash']}")


def cmd_room_skip(args):
    call("POST", f"/v1/rooms/{args.room_id}/skip", {}, agent_id=args.as_agent)
    print("skipped")


def cmd_media_keys(args):
    print(call("GET", "/v1/media/keys", agent_id=args.as_agent))


def cmd_media_search(args):
    d = call("POST", "/v1/media/search", {"query": args.query, "n": args.n}, agent_id=args.as_agent)
    for u in d.get("results", []):
        print(u)


def cmd_media_gen(args):
    d = call("POST", "/v1/media/generate", {"prompt": args.prompt, "size": args.size}, agent_id=args.as_agent)
    print(d.get("url"))


def cmd_media_library(args):
    d = call("GET", "/v1/media/library", agent_id=args.as_agent)
    for p in d.get("images", []):
        print(p)


def cmd_media_shot(args):
    d = call("POST", "/v1/media/screenshot", {"url": args.target, "full": args.full}, agent_id=args.as_agent)
    print(d.get("url"))


def cmd_media_browse(args):
    import json as _json
    acts = _json.loads(args.actions) if args.actions else []
    d = call("POST", "/v1/media/browse", {"url": args.target, "actions": acts, "full": args.full},
             agent_id=args.as_agent)
    print("screenshot:", d.get("screenshot"))
    print("text:", (d.get("text") or "")[:400])


def cmd_init_agent(args):
    soul = getattr(args, "soul", None)
    if getattr(args, "soul_file", None):
        from pathlib import Path
        soul = Path(args.soul_file).read_text(encoding="utf-8")
    d = call("POST", "/v1/agent/init",
             {"id": args.agent_id, "name": args.name, "template": args.template,
              "avatar": args.avatar, "height_cm": args.height,
              "say": getattr(args, "say", None), "soul": soul},
             agent_id=args.as_agent)
    v = d.get("view", {}) or {}
    tag = "建档" if d.get("created") else "更新"
    soul = v.get("soul")
    soul_txt = (soul.get("identity") if isinstance(soul, dict) else soul) or ""
    print(f"{tag} {d['agent_id']}: gender={v.get('gender')} avatar={v.get('avatar')} "
          f"height={(v.get('body') or {}).get('height_cm')} soul={str(soul_txt)[:24]}")
    if d.get("key"):
        print(f"  key_id={d['key_id']}\n  key={d['key']}")


def cmd_soul_evolve(args):
    aid = getattr(args, "agent_id", None) or args.as_agent
    d = call("POST", f"/v1/agents/{aid}/soul/evolve",
             {"change": args.change, "reason": args.reason}, agent_id=args.as_agent)
    print(f"soul 演化 {aid}: {args.change}")


def cmd_proposal(args):
    d = call("POST", "/v1/proposals",
             {"title": args.title, "summary": args.summary, "kind": args.kind,
              "target_version": args.version, "artifact_hash": args.artifact,
              "capability": args.capability, "priority": args.priority,
              "topic": args.topic, "bundle_url": args.bundle}, agent_id=args.as_agent)
    p = d["proposal"]
    print(f"proposal {p['proposal_id']}: {p['title']} [{p['status']}] weight={p.get('weight')}")


def cmd_proposals(args):
    for p in call("GET", "/v1/proposals", agent_id=args.as_agent)["proposals"]:
        print(f"[w={p.get('weight')}] {p['proposal_id']} [{p['status']}] {p['title']}  "
              f"(adopt={len(p['adopted_by'])} reject={len(p['rejected_by'])})")


def cmd_conflicts(args):
    d = call("GET", "/v1/proposals/conflicts", agent_id=args.as_agent)
    for g in d["conflicts"]:
        print(f"topic={g['topic']} ({g['count']} 个提案) → 推荐 {g['winner']} {g['winner_title']}")
        for p in g["proposals"]:
            print(f"   [score={p.get('score')} w={p['weight']} borda={p.get('borda')}] "
                  f"{p['proposal_id']} {p['title']}")


def cmd_rank(args):
    order = [x.strip() for x in args.order.split(",") if x.strip()]
    d = call("POST", "/v1/proposals/rank",
             {"topic": args.topic, "order": order}, agent_id=args.as_agent)
    print(f"rank {d['topic']}: {d['order']}")


def cmd_proposal_show(args):
    print(json.dumps(call("GET", f"/v1/proposals/{args.pid}",
                          agent_id=args.as_agent)["proposal"], ensure_ascii=False, indent=2))


def cmd_proposal_vote(args):
    vote = "adopt" if args.cmd == "adopt" else "reject"
    p = call("POST", f"/v1/proposals/{args.pid}/vote",
             {"vote": vote, "reason": args.reason}, agent_id=args.as_agent)["proposal"]
    print(f"{vote} {p['proposal_id']} -> {p['status']} (adopt={len(p['adopted_by'])})")


def cmd_updates(args):
    for u in call("GET", f"/v1/updates?since={args.since}",
                  agent_id=args.as_agent)["updates"]:
        print(f"{u['seq']} [{u['kind']}] {u['node_id']}: {u['title']}")


def cmd_command(args):
    payload = json.loads(args.payload) if args.payload else None
    d = call("POST", f"/v1/agents/{args.agent_id}/command",
             {"cmd": args.cmd, "payload": payload}, agent_id=args.as_agent)
    print(f"指令已下发：{d['cmd']} → {args.agent_id}（#{d['command_id']}）")


def cmd_whois(args):
    d = call("GET", f"/v1/agents/{args.agent_id}/origin", agent_id=args.as_agent)
    print(f"{d['agent']}: {d['verdict']}")
    print(f"  node={d['node_id']} alias={d.get('node_alias')} node_lan_ip={d.get('node_lan_ip')}")
    print(f"  last_handshake_ip={d.get('last_handshake_ip')} at {d.get('last_handshake_at')}")
    print(f"  gossip peers={list((d.get('peers') or {}).keys())}")


def cmd_verify(args):
    d = call("GET", "/v1/nodes", agent_id=args.as_agent)
    remotes = [n for n in d["nodes"] if not n.get("local")]
    peers = call("GET", "/v1/node/peers", agent_id=args.as_agent).get("peers", {})
    print(f"本机节点: {d.get('self')}")
    print(f"远程节点: {[n['alias'] for n in remotes] or '（无）'}")
    print(f"gossip 对端: {list(peers.keys()) or '（无）'}")
    print("agent 来源：")
    for a in call("GET", "/v1/agents", agent_id=args.as_agent)["agents"]:
        try:
            o = call("GET", f"/v1/agents/{a['id']}/origin", agent_id=args.as_agent)
            print(f"  {a['id']:<12} {o['verdict']:<14} node={o.get('node_id')} ip={o.get('last_handshake_ip')}")
        except Exception:
            pass
    ok = bool(remotes) or bool(peers)
    print("\n结论: " + ("✅ 已有远程节点接入（可做跨机测试）" if ok
                        else "⚠ 尚无远程节点（局域网内没有其他 Team AI 节点在跑）"))


def cmd_apply(args):
    d = call("POST", f"/v1/proposals/{args.pid}/apply",
             {"source_peer": args.from_peer, "token": args.token, "yes": args.yes,
              "install_deps": args.install_deps}, agent_id=args.as_agent)
    print(f"apply {args.pid}: runtime={d.get('runtime_version')} "
          f"snapshot={d.get('snapshot')} ({d.get('note')})")


def cmd_precheck(args):
    d = call("POST", f"/v1/proposals/{args.pid}/precheck",
             {"source_peer": args.from_peer, "token": args.token}, agent_id=args.as_agent)
    pc = d["precheck"]
    print(f"precheck: ok={pc['ok']} staged={pc['staged_version']} "
          f"current={pc['current_version']} protocol_major={pc['protocol_major']}")
    for e in pc["errors"]:
        print("  ERROR:", e)
    for w in pc["warnings"]:
        print("  warn:", w)


def cmd_rollback(args):
    d = call("POST", "/v1/federation/rollback", {}, agent_id=args.as_agent)
    print(f"rollback -> {d.get('restored')} ({d.get('note')})")


def cmd_snapshots(args):
    for s in call("GET", "/v1/federation/snapshots", agent_id=args.as_agent)["snapshots"]:
        print(f"{s['name']}  {s['size']}B  {s['at']}")


def cmd_update(args):
    d = call("POST", "/v1/federation/update",
             {"source_peer": args.from_peer, "token": args.token,
              "target_version": args.version, "dry_run": args.dry_run,
              "install_deps": args.install_deps, "force": args.force},
             agent_id=args.as_agent)
    if d.get("dry_run"):
        pc = d["precheck"]
        print(f"dry-run {d['from_version']} -> {d['to_version']} precheck_ok={pc['ok']}")
        for e in pc["errors"]:
            print("  ERROR:", e)
        for w in pc["warnings"]:
            print("  warn:", w)
        return
    print(f"update {d.get('from_version')} -> {d.get('to_version')} "
          f"snapshot={d.get('snapshot')} preserved_ok={d.get('preserved_ok')} "
          f"agents={d.get('agents_before')}->{d.get('agents_after')} "
          f"restart_required={d.get('restart_required')}")


def cmd_rollout(args):
    peers = [x.strip() for x in args.peers.split(",") if x.strip()]
    d = call("POST", "/v1/peers/update",
             {"peers": peers, "token": args.token, "dry_run": args.dry_run,
              "install_deps": args.install_deps, "force": args.force},
             agent_id=args.as_agent)
    for r in d["results"]:
        print(f"{r['peer']}: ok={r.get('ok')} "
              f"{r.get('from_version', '')}->{r.get('to_version', '')} {r.get('error', '')}")


def cmd_install(args):
    """从任意节点继承发行版：拉清单 → 验签 → 下 bundle → 校验 → 解包。"""
    import io
    import tarfile
    base = args.from_peer.rstrip("/")
    headers = {"X-Enroll-Token": args.token} if args.token else {}

    def _get(path):
        req = urllib.request.Request(base + path, headers=headers)
        with urllib.request.urlopen(req, timeout=120, context=SSL_CTX) as r:
            return r.read()

    m = json.loads(_get("/v1/bootstrap/manifest").decode("utf-8"))
    print(f"peer: runtime={m.get('runtime_version')} protocol={m.get('protocol')} "
          f"files={len(m.get('files', []))} serial={m.get('serial')}")
    if args.version and m.get("runtime_version") != args.version:
        sys.exit(f"version mismatch: peer={m.get('runtime_version')} want={args.version}")
    try:
        from core import distribution as dist_mod
        ok = dist_mod.verify_manifest(m, m["pubkey"])
    except Exception as e:
        sys.exit(f"manifest verify error: {e}")
    print(f"manifest signature: {'ok' if ok else 'INVALID'}  "
          f"key_fingerprint={m.get('key_fingerprint')}")
    if not ok:
        sys.exit("manifest signature invalid")
    data = _get("/v1/dist/bundle")
    sha = hashlib.sha256(data).hexdigest()
    if sha != m["bundle"]["sha256"]:
        sys.exit(f"bundle sha mismatch: {sha} != {m['bundle']['sha256']}")
    print(f"bundle verified: sha256={sha[:16]}… size={len(data)}")
    if args.dry_run:
        print("(dry-run，不落地)")
        return
    dest = args.dest or "."
    os.makedirs(dest, exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
        tf.extractall(dest)
    print(f"已继承发行版到 {os.path.abspath(dest)}")


def cmd_import_profile(args):
    import json as _json
    from pathlib import Path
    txt = Path(args.file).read_text(encoding="utf-8")
    try:
        p = _json.loads(txt)
    except Exception:
        import yaml
        p = yaml.safe_load(txt)
    d = call("POST", "/v1/agent/import",
             {"persona": p, "id": args.agent_id, "name": args.name},
             agent_id=args.as_agent)
    print(f"imported {d['agent_id']} ({d['name']}) key_id={d['key_id']}")
    print(f"key={d['key']}")


def cmd_hire(args):
    d = call("POST", f"/v1/agents/{args.agent_id}/hire",
             {"position": args.position, "department": args.department or "",
              "job_req": args.job_req or "", "level": args.level or "",
              "employment_type": args.type, "note": args.note or ""},
             agent_id=args.as_agent)
    print(f"hired {d['agent_id']} → {d['position']}（匹配 {d['match_score']}）命中 {d['skill_hits']}")


def cmd_employees(args):
    for e in call("GET", "/v1/employees", agent_id=args.as_agent)["employees"]:
        print(f"  {e['agent_id']:<8} {e['position']:<12} {e['employment_type']:<10} "
              f"匹配{e.get('match_score')} {e.get('onboarded_at')}")


def cmd_hr_match(args):
    d = call("POST", "/v1/hr/match", {"job_req": args.job_req}, agent_id=args.as_agent)
    for c in d["candidates"]:
        print(f"  {c['score']:.2f}  {c['agent_id']:<8} 命中技能 {c['skill_hits']}")


def cmd_room_report(args):
    d = call("POST", f"/v1/rooms/{args.room_id}/report",
             {"text": args.text, "agent_id": args.as_agent}, agent_id=args.as_agent)
    print(f"reported #{d.get('message_id')} @ round {d.get('round')}")


def cmd_room_summary(args):
    _print(call("GET", f"/v1/rooms/{args.room_id}/summary", agent_id=args.as_agent)["summary"])


def cmd_room_end(args):
    d = call("POST", f"/v1/rooms/{args.room_id}/end", {}, agent_id=args.as_agent)
    print("ended; summary_post:", d.get("summary_post"))


def cmd_reeval(args):
    d = call("POST", f"/v1/rooms/{args.room_id}/reeval", {}, agent_id=args.as_agent)["reeval"]
    print(f"reeval: {d['consistent']}/{d['total']} consistent")
    for it in d["items"]:
        print(f"  msg{it['message_id']}: {it['before']} -> {it['after']} {'ok' if it['consistent'] else 'DIFF'}")


def cmd_aesthetic(args):
    for a in call("GET", f"/v1/agents/{args.agent_id}/aesthetic", agent_id=args.as_agent)["aesthetic"]:
        print(f"  {a['dimension']}: {a['statement']}  [{a['evidence']}]")


def cmd_aesthetic_extract(args):
    for a in call("POST", f"/v1/agents/{args.agent_id}/aesthetic/extract", {}, agent_id=args.as_agent)["aesthetic"]:
        print(f"  {a['dimension']}: {a['statement']}")


def cmd_requirements(args):
    for r in call("GET", "/v1/requirements" + (f"?status={args.status}" if args.status else ""),
                  agent_id=args.as_agent)["requirements"]:
        print(f"  [{r['kind']}/{r['status']}] {r['source_agent']}@R{r['source_round']}: {r['text'][:80]}")


def cmd_requirements_extract(args):
    body = {"channel_id": args.channel} if args.channel else {}
    d = call("POST", "/v1/requirements/extract", body, agent_id=args.as_agent)
    print(f"extracted {d['added']} new requirement(s)")
    for it in d["items"][:10]:
        print(f"  [{it['channel']}] {it['agent']}: {it['text'][:70]}")


def cmd_team_profile(args):
    for t in call("GET", "/v1/team/profile", agent_id=args.as_agent)["team"]:
        print(f"  {t['full_name'] or t['agent_id']} [{t['role']}]")
        for a in t["aesthetic"]:
            print(f"     - {a['dimension']}: {a['statement']}")


def cmd_ask(args):
    d = call("POST", "/v1/messages", {"to": args.to, "body": args.body}, agent_id=args.as_agent)
    print(f"sent #{d['message_id']} -> {d['to']}")


def cmd_messages(args):
    q = []
    if getattr(args, "with_agent", None):
        q.append("with=" + args.with_agent)
    if getattr(args, "unread", False):
        q.append("unread=1")
    if getattr(args, "box", None):
        q.append("box=" + args.box)
    d = call("GET", "/v1/messages" + ("?" + "&".join(q) if q else ""), agent_id=args.as_agent)
    print("unread:", d["unread"])
    for m in d["messages"]:
        box = getattr(args, "box", "in")
        who = m["from_id"] if box == "in" else m["to_id"]
        arrow = "←" if box == "in" else "→"
        print(f"  {m['created_at']} {arrow} {who}: {m['body'][:100]}")


def cmd_messages_read(args):
    print("marked:", call("POST", "/v1/messages/read", {}, agent_id=args.as_agent)["marked"])


def cmd_inbox(args):
    d = ROOT / "agents" / args.as_agent / "inbox"
    items = sorted(d.glob("*.json")) if d.exists() else []
    if not items:
        print("(无待办)")
        return
    for b in items:
        try:
            brief = json.loads(b.read_text(encoding="utf-8"))
        except Exception:
            continue
        pf = b.with_suffix(".prompt.md")
        print(f"  {brief.get('task_id')} {brief.get('title')}")
        print(f"     待办提示：{pf.relative_to(ROOT) if pf.exists() else '(未生成，跑 dispatcher)'}")
        print(f"     完成后：python cli/teamai.py submit {brief.get('task_id')} --as {args.as_agent}")


def cmd_status(args):
    d = ROOT / "agents" / args.as_agent
    d.mkdir(parents=True, exist_ok=True)
    (d / ".status").write_text(args.state, encoding="utf-8")
    if args.state == "idle":
        try:
            call("PUT", f"/v1/agents/{args.as_agent}/status", {"status": "idle"}, agent_id=args.as_agent)
        except SystemExit:
            pass
    print(f"status: {args.as_agent} -> {args.state}")


def cmd_report(args):
    """上报执行进度（start/progress/done）：写日志 + 上报看板 + 置状态灯 + 可选发工作群。"""
    try:
        from core import report as _rpt
        detail = {}
        if getattr(args, "elapsed", None) is not None:
            detail["elapsed_s"] = args.elapsed
        if getattr(args, "exit_code", None) is not None:
            detail["exit_code"] = args.exit_code
        if getattr(args, "note", None):
            detail["note"] = args.note
        act = _rpt.report(args.as_agent, args.stage, args.task, args.title, detail,
                          base=BASE, post_to_channel=getattr(args, "channel", None),
                          set_status=True)
        if act:
            print(f"report: {args.as_agent} -> {act.get('stage')} "
                  f"{act.get('task_id') or '-'} {act.get('title') or ''} "
                  f"elapsed={(act.get('detail') or {}).get('elapsed_s', '-')}")
        else:
            print(f"report: {args.as_agent} -> {args.stage} {args.task or '-'} "
                  f"(offline，仅本地日志)")
        return
    except Exception:
        pass
    # 兜底：直接上报看板
    from core import activity as _activity_mod
    detail = {}
    if getattr(args, "elapsed", None) is not None:
        detail["elapsed_s"] = args.elapsed
    if getattr(args, "exit_code", None) is not None:
        detail["exit_code"] = args.exit_code
    if getattr(args, "note", None):
        detail["note"] = args.note
    d = call("PUT", f"/v1/agents/{args.as_agent}/activity",
             {"stage": args.stage, "task_id": args.task, "title": args.title,
              "detail": detail}, agent_id=args.as_agent)
    act = d.get("activity") or {}
    print(f"report: {args.as_agent} -> {act.get('stage')} "
          f"{act.get('task_id') or '-'} {act.get('title') or ''} "
          f"elapsed={(_activity_mod.elapsed_s(act) if act else '-')}")


def cmd_enroll(args):
    persona = _persona(args.agent_id, args.name or args.agent_id.capitalize())
    res = call("POST", "/v1/enroll",
               {"agent_id": args.agent_id, "name": args.name, "persona": persona,
                "role": args.role}, enroll_token=args.token)
    (ROOT / "agents" / args.agent_id).mkdir(parents=True, exist_ok=True)
    (ROOT / "agents" / args.agent_id / ".key").write_text(
        json.dumps({"key_id": res["key_id"], "key": res["key"]}, ensure_ascii=False), encoding="utf-8")
    os.chmod(ROOT / "agents" / args.agent_id / ".key", 0o600)
    if res.get("recovery_code"):
        rp = ROOT / "agents" / args.agent_id / ".recovery"
        rp.write_text(res["recovery_code"], encoding="utf-8")
        os.chmod(rp, 0o600)
    _print(res)


def cmd_handshake(args):
    man = call("GET", "/v1/health")
    hw = detect_hardware()
    if getattr(args, "alias", None):
        hw["alias"] = args.alias
        hw["hostname"] = args.alias
        hw["is_main"] = 0
    if getattr(args, "ram", None):
        hw["ram_gb"] = args.ram
    if getattr(args, "gpu", None):
        hw["gpu"] = args.gpu
    hs = call("POST", "/v1/handshake",
              {"hardware": hw, "protocol_version": man["protocol"],
               "runtime_version": man["runtime_version"], "capabilities": [], "packages": []},
              agent_id=args.as_agent)
    _print(hs)


def cmd_me(args):
    _print(call("GET", "/v1/me", agent_id=args.as_agent))


def cmd_manifest(args):
    _print(call("GET", "/v1/bootstrap/manifest", enroll_token=args.token))


def _save_key(agent_id: str, key_id: str, key: str) -> None:
    d = ROOT / "agents" / agent_id
    d.mkdir(parents=True, exist_ok=True)
    p = d / ".key"
    p.write_text(json.dumps({"key_id": key_id, "key": key}, ensure_ascii=False), encoding="utf-8")
    os.chmod(p, 0o600)


def cmd_rotate(args):
    d = call("POST", "/v1/keys/rotate", {"revoke_old": args.revoke_old}, agent_id=args.as_agent)
    _save_key(args.as_agent, d["key_id"], d["key"])
    print(f"rotated {args.as_agent}: new key_id={d['key_id']} (saved to agents/{args.as_agent}/.key)")


def cmd_recover(args):
    d = call("POST", "/v1/recover", {"agent_id": args.agent_id, "recovery_code": args.code})
    _save_key(args.agent_id, d["key_id"], d["key"])
    print(f"recovered {args.agent_id}: new key_id={d['key_id']} (saved)")


def cmd_mint_token(args):
    _print(call("POST", "/v1/enroll-tokens",
                {"max_uses": args.max_uses, "expires_at": args.expires}, agent_id=args.as_agent))


def cmd_tokens(args):
    _print(call("GET", "/v1/enroll-tokens", agent_id=args.as_agent))


def cmd_nodes(args):
    d = call("GET", "/v1/nodes", agent_id=args.as_agent)
    for n in d["nodes"]:
        tag = "★本机" if n.get("local") else "·远程"
        alias = n.get("alias") or n.get("node_id") or "?"
        os_name = n.get("os") or "?"
        cores = n.get("cpu_cores") or 0
        ram = n.get("ram_gb") or 0
        print(f"{tag} {alias:<14} {os_name:<16} {cores}c {ram:.0f}G "
              f"agents={n.get('agents', 0)} {n.get('lan_ip') or ''}")


def cmd_agents(args):
    for a in call("GET", "/v1/agents", agent_id=args.as_agent)["agents"]:
        p = a.get("persona", {})
        print(f"{a['full_name'] or a['id']:<20} [{a['role']:<11}] "
              f"{(p.get('identity') or {}).get('motto', '')}")


def cmd_board(args):
    d = call("GET", "/v1/board", agent_id=args.as_agent)
    print("counts:", json.dumps(d["counts"], ensure_ascii=False))
    acts = d.get("activities") or {}
    for a in d["agents"]:
        line = f"  {a['full_name'] or a['id']:<20} [{a['role']:<11}] {a['status']}"
        act = acts.get(a["id"])
        if act and act.get("stage") not in (None, "idle"):
            el = act.get("elapsed_s")
            el_s = f" {el}s" if el is not None else ""
            stale = " ⚠陈旧" if act.get("stale") else ""
            line += (f"  ▶ {act.get('stage')} {act.get('task_id') or '-'}"
                     f"《{(act.get('title') or '')[:18]}》{el_s}{stale}")
        print(line)
    for t in d["active_tasks"]:
        print(f"  {t['id']:<12} p{t['priority']} {t['status']:<12} "
              f"{t['assigned_to'] or '-':<8} {t['title']}")


def cmd_activity(args):
    """只读查询某 agent 的当前活动（当前任务 + 阶段 + 耗时），不触发任何上报。"""
    target = args.agent or args.as_agent
    act = call("GET", f"/v1/agents/{target}/activity",
               agent_id=args.as_agent).get("activity")
    if not act:
        print(f"activity: {target} 无记录（未上报或从未执行）")
        return
    detail = act.get("detail") or {}
    print(f"agent:   {target}")
    print(f"stage:   {act.get('stage')}")
    print(f"task:    {act.get('task_id') or '-'}  {act.get('title') or ''}")
    print(f"started: {act.get('started_at') or '-'}")
    print(f"updated: {act.get('updated_at') or '-'}")
    if act.get("elapsed_s") is not None:
        print(f"elapsed: {act['elapsed_s']}s")
    if detail:
        print(f"detail:  {json.dumps(detail, ensure_ascii=False)}")


def _local_memory():
    try:
        from core import memory
        return memory
    except Exception:
        return None


def cmd_tasks(args):
    if args.for_agent:
        path = f"/v1/tasks?for_agent={args.for_agent}"
        mem = _local_memory()
        if mem:
            try:
                values = mem.get_values(args.for_agent)
                if values:
                    path += "&values=" + urllib.parse.quote(json.dumps(values))
            except Exception:
                pass
        d = call("GET", path, agent_id=args.as_agent)
        print(f"for {d['agent']} (wip={d['wip']}):")
        for t in d["tasks"]:
            print(f"  score={t['score']:<7} {t['id']:<12} p{t['priority']} {t['title']}")
    else:
        q = f"?status={args.status}" if args.status else ""
        for t in call("GET", "/v1/tasks" + q, agent_id=args.as_agent)["tasks"]:
            print(f"{t['id']:<12} {t['status']:<12} p{t['priority']} {t['title']}")


def cmd_create(args):
    body = {"title": args.title, "description": args.desc, "acceptance_criteria": args.ac,
            "priority": args.priority, "complexity": args.complexity, "difficulty": args.difficulty,
            "tags": args.tags or [], "required_skills": args.skills or [], "status": args.status}
    print("created:", call("POST", "/v1/tasks", body, agent_id=args.as_agent)["task_id"])


def cmd_show(args):
    _print(call("GET", f"/v1/tasks/{args.task_id}", agent_id=args.as_agent))


def cmd_action(args):
    body = {}
    if args.action == "claim":
        body = {"reason": args.reason}
    elif args.action == "submit":
        body = {"note": args.note}
    elif args.action == "review":
        body = {"decision": args.decision, "quality_score": args.score, "comments": args.comments}
    elif args.action in ("block", "cancel", "release"):
        body = {"reason": args.reason}
    d = call("POST", f"/v1/tasks/{args.task_id}/{args.action}", body, agent_id=args.as_agent)
    print(f"{args.action} ok -> {d['task']['status']}")


def cmd_role(args):
    d = call("PUT", f"/v1/agents/{args.agent_id}/role",
             {"role": args.role, "reason": args.reason}, agent_id=args.as_agent)
    print(f"{args.agent_id}: {d['from_role']} -> {d['role']}")


def cmd_sync(args):
    path = f"/v1/sync?agent={args.as_agent}"
    if args.since:
        path += f"&since={args.since}"
    _print(call("GET", path, agent_id=args.as_agent))


def cmd_heartbeat(args):
    hw = detect_hardware()
    d = call("POST", "/v1/heartbeat",
             {"disk_free_gb": hw["disk_free_gb"],
              "load_avg": os.getloadavg()[0] if hasattr(os, "getloadavg") else None},
             agent_id=args.as_agent)
    print("heartbeat:", d)


# ------------------------------------------------------------------ memory (local)
def _deepseek_proposer():
    import re
    key = os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("DS_KEY")
    if not key:
        print("[reflect] no DEEPSEEK_API_KEY/DS_KEY -> heuristic only", file=sys.stderr)
        return None
    base = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com/chat/completions")
    model = os.environ.get("DEEPSEEK_MODEL", "deepseek-v4-pro")

    def propose(prompt: str) -> dict:
        body = json.dumps({"model": model, "messages": [{"role": "user", "content": prompt}],
                           "temperature": 0.2, "max_tokens": 500, "stream": False}).encode()
        req = urllib.request.Request(base, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {key}")
        with _urlopen_retry(req, timeout=120) as r:
            data = json.loads(r.read().decode())
        m = re.search(r"\{.*\}", data["choices"][0]["message"]["content"], re.S)
        return json.loads(m.group(0)) if m else {}

    return propose


def cmd_mem_show(args):
    from core import memory
    _print(memory.context(args.as_agent))


def cmd_mem_hot(args):
    from core import memory
    for e in memory.hot(args.as_agent):
        print(f"  [{e['kind']:<13}] p{e['priority']:.2f} {e['content'][:80]}")


def cmd_mem_values(args):
    from core import memory
    for r in memory.values_detail(args.as_agent):
        print(f"  {r['key']:<14} {r['value']:.3f}  [{r['min']:.2f},{r['max']:.2f}]"
              f"{' (core)' if r['core'] else ''}")


def cmd_mem_history(args):
    from core import memory
    for r in memory.weight_history(args.as_agent, args.limit):
        print(f"  {r['ts']} {r['key']:<14} {r['old']:.3f} -> {r['new']:.3f}  ({r['reason']})")


def _push_profile(agent_id):
    """把本地「务虚」档案摘要推送到服务端（失败静默，不影响本地）。"""
    mem = _local_memory()
    if not mem:
        return None
    try:
        summary = mem.build_profile_summary(agent_id)
        return call("POST", f"/v1/agents/{agent_id}/profile",
                    {"summary": summary, "reputation": summary.get("reputation", 0)},
                    agent_id=agent_id)
    except SystemExit:
        return None


def cmd_mem_reflect(args):
    from core import memory
    proposer = _deepseek_proposer() if args.llm else None
    res = memory.reflect(args.as_agent, trigger=args.trigger, proposer=proposer, summary=args.summary)
    if _push_profile(args.as_agent):
        res["profile_pushed"] = True
    _print(res)


def cmd_profile_push(args):
    d = _push_profile(args.as_agent)
    print("pushed" if d else "push skipped (server unreachable?)")


def cmd_profile_show(args):
    target = args.agent or args.as_agent
    _print(call("GET", f"/v1/agents/{target}/profile", agent_id=args.as_agent)["profile"])


def cmd_profile_list(args):
    for p in call("GET", "/v1/profiles", agent_id=args.as_agent)["profiles"]:
        vals = p.get("values", {})
        top = sorted(vals.items(), key=lambda x: -x[1])[:2]
        print(f"  {p.get('display_name') or p['agent_id']:<20} [{p.get('role','?'):<11}] "
              f"top={top} rep={p.get('reputation', 0)}")


def cmd_profile_complements(args):
    target = args.agent or args.as_agent
    for c in call("GET", f"/v1/agents/{target}/complements", agent_id=args.as_agent)["complements"]:
        print(f"  {c['display_name'] or c['agent_id']:<20} score={c['score']:<7} "
              f"(values={c['values']} interests={c['interests']} style={c['style']})")


def cmd_mentor_request(args):
    _print(call("POST", "/v1/mentorship/request", {"mentor_id": args.mentor, "note": args.note},
                agent_id=args.as_agent))


def cmd_mentor_confirm(args):
    _print(call("POST", f"/v1/mentorship/{args.mid}/confirm", {}, agent_id=args.as_agent))


def cmd_mentor_decline(args):
    _print(call("POST", f"/v1/mentorship/{args.mid}/decline", {}, agent_id=args.as_agent))


def cmd_mentor_list(args):
    for m in call("GET", f"/v1/mentorship?agent={args.agent or args.as_agent}", agent_id=args.as_agent)["mentorships"]:
        print(f"  {m['id']} {m['mentee']} -> {m['mentor']} [{m['status']}]")


def cmd_retro(args):
    d = call("POST", "/v1/retro", {"period": args.period}, agent_id=args.as_agent)
    s = d["summary"]
    print(f"retro({d['period']}) posted -> {d['post_id']}")
    print(f"  posts={s['total_posts']} active={s['active_agents']} done={len(s['recently_done'])} "
          f"rep={s['reputation']['sum']:+.1f} open_q={len(s['open_questions'])}")


def cmd_retros(args):
    for r in call("GET", "/v1/retros", agent_id=args.as_agent)["retros"]:
        print(f"  {r['created_at']} {r['period']:<7} post={r['post_id']}")


def cmd_search(args):
    path = "/v1/search?q=" + urllib.parse.quote(args.q)
    if args.channel:
        path += "&channel=" + urllib.parse.quote(args.channel)
    for p in call("GET", path, agent_id=args.as_agent)["results"]:
        print(f"  {p['id']:<12} [{p['type']:<11}] {p.get('channel') or '-':<10} "
              f"{p.get('title') or p['body'][:50]}")


def cmd_notifications(args):
    d = call("GET", "/v1/notifications" + ("?unread=1" if args.unread else ""), agent_id=args.as_agent)
    print("unread:", d["unread"])
    for n in d["notifications"]:
        print(f"  [{n['kind']:<8}] {n['body']}")


def cmd_notifications_read(args):
    print("marked:", call("POST", "/v1/notifications/read", {}, agent_id=args.as_agent)["marked"])


def cmd_topic_open(args):
    d = call("POST", "/v1/topics",
             {"title": args.title, "prompt": args.prompt, "channel_id": args.channel},
             agent_id=args.as_agent)
    print("topic:", d["topic_id"])


def cmd_topics(args):
    d = call("GET", "/v1/topics", agent_id=args.as_agent)
    print("active:", (d.get("active") or {}).get("title") or "-")
    for t in d["topics"]:
        print(f"  {t['id']:<16} [{t['status']:<6}] {t['title']}")


def cmd_topic_close(args):
    call("POST", f"/v1/topics/{args.topic_id}/close", {}, agent_id=args.as_agent)
    print("closed", args.topic_id)


def cmd_metrics(args):
    d = call("GET", "/v1/metrics", agent_id=args.as_agent)["metrics"]
    for k, v in d.items():
        print(f"  {k:<22} {v}")


def cmd_constitution(args):
    d = call("GET", "/v1/constitution" + ("?all=1" if args.all else ""), agent_id=args.as_agent)
    print("versions:", d.get("versions"))
    for r in d["rules"]:
        print(f"  [{r.get('version','?')}] {r['rule_key']}: {r['content'][:60]}")


def cmd_constitution_add(args):
    d = call("POST", "/v1/constitution",
             {"rule_key": args.key, "content": args.content, "version": args.version},
             agent_id=args.as_agent)
    print("added:", d["rule_key"], d["version"])


def cmd_roles_rotate(args):
    d = call("POST", "/v1/roles/rotate",
             {"to_agent": args.to_agent, "reason": args.reason}, agent_id=args.as_agent)
    print("coordinator ->", d["coordinator"])


def cmd_mem_rollback(args):
    from core import memory
    try:
        _print(memory.rollback(args.as_agent, args.key, args.to, force=args.force))
    except PermissionError as e:
        sys.exit(f"refused: {e} (use --force to override a core value)")


def cmd_mem_add(args):
    from core import memory
    rid = memory.add_episodic(args.as_agent, args.text, kind=args.kind, salience=args.salience)
    if args.kind in ("focus", "intent", "open_question", "recent_event"):
        memory.add_working(args.as_agent, args.kind, args.text, priority=args.priority)
    print("added episodic:", rid)


def cmd_mem_semantic(args):
    from core import memory
    memory.remember_semantic(args.as_agent, args.key, args.value)
    print("ok")


def cmd_mem_repute(args):
    from core import memory
    memory.add_reputation(args.as_agent, args.event, args.points)
    print("ok")


def cmd_mem_relate(args):
    from core import memory
    _print(memory.bump_relationship(args.as_agent, args.other, args.delta, note=args.note))


def cmd_mem_relationships(args):
    from core import memory
    for r in memory.get_relationships(args.as_agent):
        print(f"  {r['other_agent']:<20} trust={r['trust']:.2f} interactions={r['interactions']}")


def cmd_mem_resume(args):
    from core import memory
    path = memory.generate_resume(args.as_agent)
    print(f"resume written: {path}")
    if args.show:
        print(path.read_text(encoding="utf-8"))


# ------------------------------------------------------------------ 事实收割 (harvest)
def cmd_harvest(args):
    """读工作群增量消息 → LLM 判事实 → 规则闸门 → 写 memory（TLP 1.1）。"""
    from core import harvest, memory
    if args.room:
        rooms = [args.room]
    elif args.all:
        rooms = [r["id"] for r in call("GET", "/v1/rooms", agent_id=args.as_agent)["rooms"]]
    else:
        print("请指定 --room <room_id> 或 --all"); return
    totals = {"facts": 0, "episodic": 0, "semantic": 0, "working": 0, "dup": 0}
    for rid in rooms:
        cur = memory.get_cursor(args.as_agent, rid)
        d = call("GET", f"/v1/rooms/{rid}?after={cur}&limit=1000", agent_id=args.as_agent)
        try:
            out = harvest.harvest(args.as_agent, rid, d.get("transcript", []),
                                  room=d.get("room"), model=args.model,
                                  min_confidence=args.min_confidence, dry_run=args.dry_run,
                                  max_msgs=args.limit, cursor=cur)
        except Exception as e:  # 单房间失败不影响其余
            print(f"  {rid}: ERROR {e}"); continue
        if not out.get("new_msgs"):
            continue
        tag = "DRYRUN " if args.dry_run else ""
        print(f"  {rid}: {tag}+{out['new_msgs']} msgs range={out.get('range')} "
              f"accepted={out.get('new', 0)} cursor={out.get('cursor')}")
        for f in out.get("accepted", []):
            print(f"      [{f['verdict']:<8}] {f['statement']}  ← {f['evidence'] or '-'}")
        for r in out.get("rejected", []):
            print(f"      (skip) {r['reason']}: {r['statement'][:36]}")
        if out.get("error"):
            print(f"      ! {out['error']}: {(out.get('raw') or '')[:200]}")
        w = out.get("wrote") or {}
        for k in totals:
            totals[k] += int(w.get(k, 0) or 0)
    print(f"harvest done{'(dry-run)' if args.dry_run else ''}: wrote={totals}")


def cmd_learn(args):
    """读工作群增量 → **LLM 判断**哪些经验/规范值得入库 → 写 playbook（不用关键词规则）。"""
    from core import playbook, memory
    if args.room:
        rooms = [args.room]
    elif args.all:
        rooms = [r["id"] for r in call("GET", "/v1/rooms", agent_id=args.as_agent)["rooms"]]
    else:
        print("请指定 --room <room_id> 或 --all"); return
    totals = {"playbook": 0, "semantic": 0, "dup": 0}
    for rid in rooms:
        cur = memory.get_learning_cursor(args.as_agent, rid)
        d = call("GET", f"/v1/rooms/{rid}?after={cur}&limit=1000", agent_id=args.as_agent)
        try:
            out = playbook.harvest_learnings(args.as_agent, rid, d.get("transcript", []),
                                             room=d.get("room"), model=args.model,
                                             min_confidence=args.min_confidence, dry_run=args.dry_run,
                                             max_msgs=args.limit, cursor=cur)
        except Exception as e:  # 单房间失败不影响其余
            print(f"  {rid}: ERROR {e}"); continue
        if not out.get("new_msgs"):
            continue
        tag = "DRYRUN " if args.dry_run else ""
        print(f"  {rid}: {tag}+{out['new_msgs']} msgs range={out.get('range')} "
              f"learned={out.get('new', 0)} cursor={out.get('cursor')}")
        for l in out.get("accepted", []):
            print(f"      [{l['type']:<10}/{l['scope']:<4}] {l['statement']}  ← {l['evidence']}")
        for r in out.get("rejected", []):
            print(f"      (skip) {r['reason']}: {r['statement'][:36]}")
        if out.get("error"):
            print(f"      ! {out['error']}: {(out.get('raw') or '')[:200]}")
        w = out.get("wrote") or {}
        for k in totals:
            totals[k] += int(w.get(k, 0) or 0)
    print(f"learn done{'(dry-run)' if args.dry_run else ''}: wrote={totals}")


def cmd_qa_run(args):
    """跑一轮监督：读目标(target)新产出 → 按判据质检 → 记 cycle → 判收敛。"""
    from core import memory, qa
    q = [f"author={urllib.parse.quote(args.target)}", f"limit={args.limit}"]
    if args.channel:
        q.append("channel=" + urllib.parse.quote(args.channel))
    posts = call("GET", "/v1/posts?" + "&".join(q), agent_id=args.as_agent)["posts"]
    prev = memory.list_review_cycles(args.as_agent, args.topic, args.target)
    last_seen = prev[-1]["last_seen"] if prev and prev[-1].get("last_seen") else None
    fresh = [p for p in posts if not last_seen or (p.get("created_at") or "") > last_seen]
    newest = max([p.get("created_at") or "" for p in fresh], default=None)
    res = qa.run_cycle(args.as_agent, args.topic, args.target, fresh,
                       dry_run=args.dry_run, last_seen=newest, mode=getattr(args, "mode", "post"),
                       require_plan=getattr(args, "require_plan", False))
    tag = "DRYRUN " if args.dry_run else ""
    print(f"  {tag}cycle #{res['cycle_no']} topic={res['topic']} target={res['target']} "
          f"items={res['items']} defects={res['defects']} passed={res['passed']}")
    for d in res["detail"]:
        print(f"      - {d['criterion']}: {d['detail']}  ({d['ref']})")
    print(f"  反馈: {res['feedback']}")
    c = res["convergence"]
    print(f"  收敛: cycles={c['cycles']} series={c['series']} converged={c['converged']} "
          f"monotonic={c['monotonic']} min_cycle={c['min_cycle']}")
    if args.feedback and args.room:
        call("POST", f"/v1/rooms/{args.room}/report",
             {"text": res["feedback"], "agent_id": args.as_agent}, agent_id=args.as_agent)
        print(f"  反馈已发工作群 {args.room}")


def cmd_qa_status(args):
    """看监督循环历史与收敛曲线。"""
    from core import memory
    rows = memory.list_review_cycles(args.as_agent, args.topic, args.target)
    for r in rows:
        print(f"  #{r['cycle_no']:<3} items={r['items']:<3} defects={r['defects']:<3} "
              f"passed={bool(r['passed'])}  {r['ts']}")
    if not rows:
        print("  (无记录)")
    c = memory.review_convergence(args.as_agent, args.topic, args.target)
    print(f"  收敛: cycles={c['cycles']} series={c['series']} converged={c['converged']} "
          f"monotonic={c['monotonic']} min_cycle={c['min_cycle']}")


def cmd_facts(args):
    """列出已沉淀的事实（TLP 1.1：世界是事实的总和）。"""
    from core import memory
    if getattr(args, "stats", False):
        _print(memory.fact_stats(args.as_agent)); return
    rows = memory.list_facts(args.as_agent, room_id=args.room, verdict=args.verdict,
                             status=args.status, limit=args.limit)
    for f in rows:
        print(f"  #{f['id']} [{f['verdict'] or '?':<8}] {f['statement'][:90]}")
        print(f"        ev={f['evidence'] or '-'} conf={f['confidence']:.2f} "
              f"sal={f['salience']:.2f} src={f['source']} msg={f['msg_from']}..{f['msg_to']}")
    if not rows:
        print("  (无事实)")


def cmd_playbook(args):
    """列出/统计已沉淀的经验/规范（由 LLM 判断入库，见 core/playbook.py）。"""
    from core import memory
    if getattr(args, "stats", False):
        _print(memory.playbook_stats(args.as_agent)); return
    rows = memory.list_learnings(args.as_agent, type_=args.type, scope=args.scope,
                                 status=args.status, limit=args.limit)
    for r in rows:
        print(f"  #{r['id']} [{r['type'] or '?':<10}/{r['scope']}] {r['statement'][:90]}")
        print(f"        why={r['rationale'] or '-'} ev={r['evidence'] or '-'} "
              f"conf={r['confidence']:.2f} sal={r['salience']:.2f} room={r['room_id']}")
    if not rows:
        print("  (无经验/规范)")


def _style_texts(agents: list[str], n: int) -> list[str]:
    """从本机 data.db 取最近发言（style 是 A 端管理动作，故直读服务端库）。"""
    import sqlite3
    # 不自己拼 data.db：<home>/app 布局下 parent.parent 就是 app/，会读成 app/data.db。
    # 统一走 core.db.DB_PATH（与 web/dispatcher 同一口径）。
    from core.db import DB_PATH as _CANON_DB
    db = Path(_CANON_DB)
    if not db.exists():
        return []
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    q = ",".join("?" * len(agents))
    rows = conn.execute(
        f"SELECT body FROM room_messages WHERE agent_id IN ({q}) AND kind NOT IN ('skip','system') "
        f"AND body<>'' ORDER BY id DESC LIMIT ?", (*agents, n)).fetchall()
    conn.close()
    return [r["body"] for r in rows]


def cmd_style_learn(args):
    """让 LLM 按该 agent 的人设判断语言风格采纳，写回 persona.yaml（不用规则）。"""
    from core import style, persona as P
    agent = args.as_agent
    human = _style_texts(["human", "jiyanjiang"], 40)
    for cf in (getattr(args, "corpus", None) or []):
        try:
            human.append(Path(cf).read_text(encoding="utf-8"))
            print(f"  + 语料 {cf}")
        except Exception as e:
            print(f"  corpus 读取失败 {cf}: {e}")
    own = _style_texts([agent], 30)
    p = P.load_persona(agent)
    r = style.learn_style(p, human, own)
    if not r.get("ok"):
        print(f"  learn failed: {r.get('error')} {(r.get('raw') or '')[:200]}"); return
    vo = dict(p.get("voice") or {})
    vo["learned"] = r["learned"]; vo["adaptation"] = r["adaptation"]
    vo["updated_at"] = (r["adaptation"] or {}).get("updated_at")
    p["voice"] = vo
    P.save_persona(agent, p)
    print(f"  {agent}: learned={r['learned']}")
    print(f"    采纳: {[a.get('trait') for a in r['adaptation']['adopt']]}")
    print(f"    不学: {[x.get('trait') for x in r['adaptation']['reject']]}")
    print(f"    理由: {r['adaptation'].get('rationale')}")


def cmd_style_balance(args):
    """让 LLM 判断全队人格是否互补平衡，给出有界微调建议（不自动改人设）。"""
    from core import style, persona as P
    ps = [P.load_persona(a) for a in P.list_persona_ids()]
    r = style.balance_team(ps)
    if not r.get("ok"):
        print(f"  balance failed: {r.get('error')} {(r.get('raw') or '')[:200]}"); return
    print(f"  诊断: {r['assessment']}")
    print(f"  失衡轴: {r['axis']} (skew={r['skew']})")
    for s in r["suggestions"]:
        print(f"    - {s.get('agent')} · {s.get('field')}: {s.get('from')} → {s.get('to')}  （{s.get('why')}）")


def cmd_plan_review(args):
    """LLM 评审方案是否可执行、细节足够（门禁：不过不许开工）。"""
    from core import plan as plan_mod, memory
    text = ""
    if getattr(args, "file", None):
        text = Path(args.file).read_text(encoding="utf-8")
    elif getattr(args, "text", None):
        text = args.text
    else:
        print("需要 --file <方案.md> 或 --text <方案文字>"); return
    rules = [r["statement"] for r in memory.list_learnings(args.as_agent, type_="source", limit=10)]
    r = plan_mod.review_plan(args.topic, args.target, text, agent=args.as_agent, rules=rules)
    if r.get("error"):
        print(f"  review failed: {r['error']} {(r.get('raw') or '')[:200]}"); return
    print(f"  cycle #{r.get('cycle')}  ok={r['ok']}  verdict={r['verdict']}")
    for m in r.get("missing", []):
        print(f"    缺: {m.get('element')} —— {m.get('why')}")
    print(f"  反馈: {r['feedback']}")


def cmd_plan_show(args):
    """查看某主题/执行者的最新方案与门禁状态。"""
    from core import memory, plan as plan_mod
    if args.topic and args.target:
        p = memory.latest_plan(args.as_agent, args.topic, args.target)
        if not p:
            print("  (无方案)"); return
        g = plan_mod.plan_gate(args.as_agent, args.topic, args.target)
        print(f"  {p['topic']}/{p['target']}  cycle#{p['cycle']} status={p['status']} 门禁={g}")
        print(f"  方案首行: {(p['plan'] or '').strip().splitlines()[0][:120]}")
        return
    rows = memory.list_plans(args.as_agent, topic=args.topic, target=args.target, limit=args.limit)
    for p in rows:
        print(f"  #{p['cycle']:<3} [{p['status']:<8}] {p['topic']}/{p['target']}  {p['ts']}")
    if not rows:
        print("  (无方案)")


def cmd_curate(args):
    """精选与推荐：LLM 判断哪些产出值得推荐 → 发精选帖 + 到群里带帖号（docs/33）。"""
    from core import curate
    def c(method, path, body=None):
        return call(method, path, body, agent_id=args.as_agent)
    res = curate.run(c, args.as_agent, dry_run=getattr(args, "dry_run", False))
    for p in res["picks"]:
        print(f"  精选 {p['post_id']}  {p['headline']}  —— {p['reason']}")
    print(f"  发布: {res['published']}  room={res.get('room')}")


def cmd_obedience(args):
    """服从度监控：真人指令 → agent 是否落实（LLM 判定）。"""
    from core import obedience
    def c(method, path, body=None):
        return call(method, path, body, agent_id=args.as_agent)
    rep = obedience.run(c, args.as_agent, hours=getattr(args, "hours", 6),
                        limit_rooms=getattr(args, "limit", 6))
    ov = rep["overall"]
    print(f"== 服从度（近 {rep['window_hours']}h，房间 {rep['n_rooms']}，指令 {rep['n_items']}）==")
    print(f"  总体：落实 {ov.get('obeyed',0)} / 打折 {ov.get('partial',0)} / 无视 {ov.get('ignored',0)}"
          f" / 正当拒绝 {ov.get('justified',0)} / 闲聊 {ov.get('na',0)}")
    print("  按 agent（服从率 = 落实/(落实+打折+无视)，正当拒绝不计）:")
    for a, s in sorted(rep["by_agent"].items(), key=lambda kv: (kv[1]["rate"] is None, kv[1]["rate"] or 0)):
        print(f"    {a:<8} 服从率 {s['rate']}%  落实{s['obeyed']} 打折{s['partial']}"
              f" 无视{s['ignored']} 正当拒{s['justified']}")
    print("  明细:")
    for j in rep["items"]:
        print(f"    [{j['verdict']:<9}] {j['room']:<14} {j['human'][:30]}  —— {j['reason'][:44]}")
    if getattr(args, "notify", False):
        rid = obedience.notify(c, args.as_agent, obedience.report_text(rep))
        print(f"  已发群播报: {rid}")


def cmd_usage(args):
    """LLM 用量/花费统计（本机 opencode；未计价模型按费率回填）。"""
    from core import usage
    days = getattr(args, "days", 7)
    rep = usage.summary(days)
    print(f"== LLM 用量/花费（近 {days} 天；USD，未计价模型已回填；RMB 按 7.15）==")
    print(f"  {'日期':<12}{'调用':>6}{'报告$':>9}{'估算$':>9}{'≈RMB':>8}   聊天室$  任务$  指令识别$")
    tot = 0.0
    for d, s in rep.items():
        t, cat = s["total"], s["by_cat"]
        print(f"  {d:<12}{t['n']:>6}{t['rep']:>9.4f}{t['est']:>9.4f}{t['est']*7.15:>8.1f}"
              f"  {cat.get('聊天室',{}).get('est',0):>8.4f} {cat.get('任务执行',{}).get('est',0):>6.4f}"
              f" {cat.get('指令识别',{}).get('est',0):>9.4f}")
        tot += t["est"]
    print(f"  合计 ≈ ${tot:.2f}（≈{tot * 7.15:.1f} 元）")
    if getattr(args, "by", "day") == "model":
        d0, s0 = next(iter(rep.items()))
        print(f"  今天({d0}) 按模型：")
        for m, x in sorted(s0["by_model"].items(), key=lambda kv: -kv[1]["est"]):
            print(f"    {m:<30} 调用{x['n']:<6} est${x['est']:.4f}")


def cmd_research(args):
    """主题调研/写作：大纲→查资料→事实库→写作→核查（脚手架 + 确定性门禁）。"""
    from core import research
    op = args.op
    if op == "new":
        try:
            r = research.new(args.slug, getattr(args, "title", None))
        except ValueError as e:
            print(f"  {e}"); return
        print(f"  已创建 {r['dir']}")
        for name, desc in research.STEPS:
            print(f"    {name}：{desc}")
    elif op == "check":
        r = research.check(args.slug, min_words=getattr(args, "min", 0), max_words=getattr(args, "max", 0))
        for c in r["checks"]:
            print(f"  [{'PASS' if c['ok'] else 'FAIL'}] {c['name']}  {c['detail']}")
        print("  =>", "通过 ✅" if r["ok"] else "未通过 ❌")
    elif op == "status":
        r = research.status(args.slug)
        print(f"  大纲={'有' if r['outline'] else '无'}  事实条数={r['facts']}  稿字数={r['draft_words']}")
    else:
        print("  op ∈ {new, check, status}")


# ------------------------------------------------------------------ community
def cmd_channels(args):
    for c in call("GET", "/v1/channels", agent_id=args.as_agent)["channels"]:
        mark = "●" if c.get("joined") else " "
        print(f"{mark} {c['name']:<16} posts={c['post_count']:<3} {c['purpose'] or ''}")


def cmd_channel_create(args):
    d = call("POST", "/v1/channels",
             {"name": args.name, "purpose": args.purpose, "private": args.private},
             agent_id=args.as_agent)
    print("created:", d["channel_id"])


def cmd_channel_join(args):
    call("POST", "/v1/channels/join", {"channel_id": args.channel}, agent_id=args.as_agent)
    print("joined", args.channel)


def cmd_channel_leave(args):
    call("POST", "/v1/channels/leave", {"channel_id": args.channel}, agent_id=args.as_agent)
    print("left", args.channel)


def cmd_upload(args):
    """把本地文件上传为附件（图片/文档/数据/压缩包），返回可引用的 URL。"""
    p = Path(args.file)
    if not p.exists():
        sys.exit(f"no such file: {args.file}")
    print(_upload_file(args.as_agent, p, allow_risky=args.allow_risky))


def _upload_file(agent_id: str, path: Path, allow_risky: bool = False) -> str:
    data = path.read_bytes()
    b = "----teamai" + secrets.token_hex(8)
    pre = (f"--{b}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{path.name}\"\r\n"
           "Content-Type: application/octet-stream\r\n\r\n").encode("utf-8")
    tail = (f"\r\n--{b}\r\nContent-Disposition: form-data; name=\"allow_risky\"\r\n\r\n"
            f"{'1' if allow_risky else '0'}\r\n--{b}--\r\n").encode("utf-8")
    body = pre + data + tail
    k = _key(agent_id)
    ts, nonce = str(int(time.time())), secrets.token_hex(8)
    sig = _sign(k["key"], "POST", "/v1/uploads", body, ts, nonce)
    req = urllib.request.Request(BASE + "/v1/uploads", data=body, method="POST")
    req.add_header("Content-Type", f"multipart/form-data; boundary={b}")
    req.add_header("X-TeamAI-Key", k["key_id"])
    req.add_header("X-TeamAI-Timestamp", ts)
    req.add_header("X-TeamAI-Nonce", nonce)
    req.add_header("X-TeamAI-Signature", sig)
    _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
    if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
    try:
        with urllib.request.urlopen(req, timeout=120, context=SSL_CTX) as r:
            d = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8"))
        except Exception:
            payload = {"error": str(e)}
        sys.exit(f"HTTP {e.code}: {payload.get('error', payload)}")
    if not d.get("ok"):
        sys.exit(d.get("error"))
    return d["url"]


def cmd_post(args):
    standup = None
    if args.did or args.plan or args.blocker:
        standup = {"did": args.did or [], "plan": args.plan or [], "blockers": args.blocker or []}
    attachments = [{"url": u} for u in (getattr(args, "attach", None) or [])]
    d = call("POST", "/v1/posts",
             {"channel_id": args.channel, "type": args.type, "title": args.title,
              "body": args.body, "tags": args.tags or [], "links": args.links or [],
              "standup": standup, "task_id": args.task, "attachments": attachments},
             agent_id=args.as_agent)
    print("posted:", d["post_id"], "redaction:", d.get("redaction"))


def cmd_posts(args):
    q = []
    if args.channel:
        q.append("channel=" + urllib.parse.quote(args.channel))
    if args.type:
        q.append("type=" + args.type)
    path = "/v1/posts" + ("?" + "&".join(q) if q else "")
    for p in call("GET", path, agent_id=args.as_agent)["posts"]:
        rx = "".join(f"{k}{v}" for k, v in (p.get("reactions") or {}).items())
        print(f"{p['id']:<12} [{p['type']:<11}] {p.get('channel') or '-':<10} "
              f"{p['author'] or '-':<16} r={p['thread'].get('reply_count', 0):<2} {rx} "
              f"{(p.get('title') or p['body'][:40])}")


def cmd_post_show(args):
    p = call("GET", f"/v1/posts/{args.post_id}", agent_id=args.as_agent)["post"]
    print(f"# {p.get('title') or ''}  [{p['type']}] by {p['author']} in {p.get('channel')}")
    print(p["body"])
    for a in (p.get("attachments") or []):
        print(f"  [附件] {a.get('name') or ''}  {a.get('url')}  ({a.get('size', '?')}B)")
    if p.get("thread"):
        t = p["thread"]
        print(f"\n-- thread: replies={t.get('reply_count',0)} value={t.get('value_reply_count',0)} "
              f"locked={t.get('locked',0)} settled={t.get('settled_at') or '-'}")
    for r in p.get("replies", []):
        flag = "" if r["status"] == "visible" else f" <{r['status']}>"
        print(f"  {'  '*(r['depth']-1)}#{r['id']} [{r['kind']}] {r['author']}: {r['body']}{flag}")


def cmd_reply(args):
    d = call("POST", f"/v1/posts/{args.post_id}/replies",
             {"body": args.body, "kind": args.kind, "evidence": args.evidence,
              "parent_reply_id": args.parent},
             agent_id=args.as_agent)
    print("replied:", d["reply"]["id"], "status:", d["reply"]["status"])
    for w in d.get("warnings", []):
        print("  warning:", w)
    mem = _local_memory()
    if mem:
        try:
            post = call("GET", f"/v1/posts/{args.post_id}", agent_id=args.as_agent)["post"]
            author = post.get("author")
            if author and author != args.as_agent:
                mem.bump_relationship(args.as_agent, author, 0.02, note=f"reply {args.post_id}")
            mem.add_episodic(args.as_agent, f"回复了 {args.post_id}", kind="collaboration",
                             refs={"post_id": args.post_id, "author": author}, salience=0.4)
        except Exception:
            pass


def cmd_react(args):
    d = call("POST", "/v1/reactions",
             {"target_type": args.on, "target_id": args.target_id, "emoji": args.emoji},
             agent_id=args.as_agent)
    print("reactions:", d["reactions"])
    mem = _local_memory()
    if mem and args.on == "post":
        try:
            post = call("GET", f"/v1/posts/{args.target_id}", agent_id=args.as_agent)["post"]
            author = post.get("author")
            if author and author != args.as_agent:
                mem.bump_relationship(args.as_agent, author, 0.01, note=f"react {args.target_id}")
        except Exception:
            pass


def cmd_settle(args):
    call("POST", f"/v1/posts/{args.post_id}/settle",
         {"summary": args.summary, "lock": not args.no_lock}, agent_id=args.as_agent)
    print("settled", args.post_id)


def cmd_lock(args):
    call("POST", f"/v1/posts/{args.post_id}/lock", {"reason": args.reason}, agent_id=args.as_agent)
    print("locked", args.post_id)


def cmd_feed(args):
    for p in call("GET", "/v1/feed", agent_id=args.as_agent)["feed"]:
        print(f"{p['id']:<12} [{p['type']:<11}] {p.get('channel') or '-':<10} "
              f"{p['author'] or '-':<16} {(p.get('title') or p['body'][:50])}")


def cmd_digest(args):
    d = call("GET", "/v1/digest" + ("?store=1" if args.store else ""),
             agent_id=args.as_agent)["digest"]
    print("digest:", d["headline"])
    for p in d["recent_posts"]:
        print(f"  [{p['type']:<11}] {p['author'] or '-':<16} {p.get('title') or p['body'][:50]}")
    for q in d["open_questions"]:
        print(f"  ? open: {q.get('title') or q['body'][:50]}")


def cmd_interests(args):
    for i in call("GET", f"/v1/agents/{args.agent_id}/interests", agent_id=args.as_agent)["interests"]:
        print(f"  {i['tag']:<16} {i['weight']:.2f}")


def cmd_promote(args):
    d = call("POST", f"/v1/posts/{args.post_id}/promote",
             {"acceptance_criteria": args.ac, "priority": args.priority}, agent_id=args.as_agent)
    print("promoted ->", d["task_id"])


# ------------------------------------------------------------------ parser
def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--url", help="服务端地址，如 https://<ip>:6030")
    common.add_argument("--ca", help="CA 证书路径（https）")
    common.add_argument("--insecure", action="store_true", help="跳过 TLS 校验（仅测试）")

    p = argparse.ArgumentParser(prog="teamai")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("bootstrap", parents=[common]).set_defaults(func=cmd_bootstrap)

    j = sub.add_parser("join", parents=[common])
    j.add_argument("--token", required=True)
    j.add_argument("--agent-id", required=True)
    j.add_argument("--name")
    j.add_argument("--fingerprint", help="服务器签名公钥指纹（TOFU 校验）")
    j.set_defaults(func=cmd_join)

    e = sub.add_parser("enroll", parents=[common])
    e.add_argument("--token", required=True)
    e.add_argument("--agent-id", required=True)
    e.add_argument("--name")
    e.add_argument("--role", default="executor")
    e.set_defaults(func=cmd_enroll)

    h = sub.add_parser("handshake", parents=[common])
    h.add_argument("--as", dest="as_agent", default="alice")
    h.add_argument("--alias", help="覆盖节点别名（模拟其他机器）")
    h.add_argument("--ram", type=float, help="覆盖内存 GB")
    h.add_argument("--gpu")
    h.set_defaults(func=cmd_handshake)

    m = sub.add_parser("me", parents=[common])
    m.add_argument("--as", dest="as_agent", default="alice")
    m.set_defaults(func=cmd_me)

    mf = sub.add_parser("manifest", parents=[common])
    mf.add_argument("--token", required=True)
    mf.set_defaults(func=cmd_manifest)

    rt = sub.add_parser("rotate", parents=[common])
    rt.add_argument("--as", dest="as_agent", default="alice")
    rt.add_argument("--revoke-old", action="store_true")
    rt.set_defaults(func=cmd_rotate)

    rc = sub.add_parser("recover", parents=[common])
    rc.add_argument("--agent-id", required=True)
    rc.add_argument("--code", required=True)
    rc.set_defaults(func=cmd_recover)

    mt = sub.add_parser("mint-token", parents=[common])
    mt.add_argument("--as", dest="as_agent", default="alice")
    mt.add_argument("--max-uses", type=int)
    mt.add_argument("--expires")
    mt.set_defaults(func=cmd_mint_token)

    tl = sub.add_parser("tokens", parents=[common])
    tl.add_argument("--as", dest="as_agent", default="alice")
    tl.set_defaults(func=cmd_tokens)

    n = sub.add_parser("nodes", parents=[common])
    n.add_argument("--as", dest="as_agent", default="alice")
    n.set_defaults(func=cmd_nodes)

    ag = sub.add_parser("agents", parents=[common])
    ag.add_argument("--as", dest="as_agent", default="alice")
    ag.set_defaults(func=cmd_agents)

    b = sub.add_parser("board", parents=[common])
    b.add_argument("--as", dest="as_agent", default="alice")
    b.set_defaults(func=cmd_board)

    ac = sub.add_parser("activity", parents=[common])
    ac.add_argument("agent", nargs="?", help="要查询的 agent id（缺省=自己）")
    ac.add_argument("--as", dest="as_agent", default="alice")
    ac.set_defaults(func=cmd_activity)

    t = sub.add_parser("tasks", parents=[common])
    t.add_argument("--as", dest="as_agent", default="alice")
    t.add_argument("--for", dest="for_agent")
    t.add_argument("--status")
    t.set_defaults(func=cmd_tasks)

    c = sub.add_parser("create", parents=[common])
    c.add_argument("--title", required=True)
    c.add_argument("--desc", required=True)
    c.add_argument("--ac", required=True)
    c.add_argument("--priority", type=int, default=1)
    c.add_argument("--complexity", type=float, default=0.5)
    c.add_argument("--difficulty", type=float, default=0.5)
    c.add_argument("--tags", nargs="*")
    c.add_argument("--skills", nargs="*")
    c.add_argument("--status", default="backlog")
    c.add_argument("--as", dest="as_agent", default="alice")
    c.set_defaults(func=cmd_create)

    s = sub.add_parser("show", parents=[common])
    s.add_argument("task_id")
    s.add_argument("--as", dest="as_agent", default="alice")
    s.set_defaults(func=cmd_show)

    for act in ("claim", "start", "submit", "release", "block", "unblock", "cancel", "review"):
        a = sub.add_parser(act, parents=[common])
        a.add_argument("task_id")
        a.add_argument("--as", dest="as_agent", default="bob")
        a.add_argument("--reason")
        a.add_argument("--note")
        a.add_argument("--decision", default="approved")
        a.add_argument("--score", type=float)
        a.add_argument("--comments")
        a.set_defaults(func=cmd_action, action=act)

    rp = sub.add_parser("report", parents=[common])
    rp.add_argument("stage", choices=["start", "progress", "done", "blocked", "idle"])
    rp.add_argument("--task", default=None, help="任务 ID")
    rp.add_argument("--title", default=None, help="任务名（人类可读）")
    rp.add_argument("--elapsed", type=int, default=None, help="已耗时（秒）")
    rp.add_argument("--exit-code", type=int, default=None)
    rp.add_argument("--note", default=None)
    rp.add_argument("--channel", default=None, help="同时 POST 一条状态消息到该频道（工作群）")
    rp.add_argument("--as", dest="as_agent", default="bob")
    rp.set_defaults(func=cmd_report)

    r = sub.add_parser("role", parents=[common])
    r.add_argument("agent_id")
    r.add_argument("role", choices=["coordinator", "executor"])
    r.add_argument("--as", dest="as_agent", default="alice")
    r.add_argument("--reason")
    r.set_defaults(func=cmd_role)

    y = sub.add_parser("sync", parents=[common])
    y.add_argument("--as", dest="as_agent", default="alice")
    y.add_argument("--since")
    y.set_defaults(func=cmd_sync)

    hb = sub.add_parser("heartbeat", parents=[common])
    hb.add_argument("--as", dest="as_agent", default="alice")
    hb.set_defaults(func=cmd_heartbeat)

    mem = sub.add_parser("memory", parents=[common], help="本地记忆与人格（读写 memory.db）")
    ms = mem.add_subparsers(dest="mem_cmd", required=True)

    m1 = ms.add_parser("show", parents=[common]); m1.add_argument("--as", dest="as_agent", default="alice"); m1.set_defaults(func=cmd_mem_show)
    m2 = ms.add_parser("hot", parents=[common]); m2.add_argument("--as", dest="as_agent", default="alice"); m2.set_defaults(func=cmd_mem_hot)
    m3 = ms.add_parser("values", parents=[common]); m3.add_argument("--as", dest="as_agent", default="alice"); m3.set_defaults(func=cmd_mem_values)
    m4 = ms.add_parser("history", parents=[common]); m4.add_argument("--as", dest="as_agent", default="alice"); m4.add_argument("--limit", type=int, default=50); m4.set_defaults(func=cmd_mem_history)
    m5 = ms.add_parser("reflect", parents=[common]); m5.add_argument("--as", dest="as_agent", default="alice"); m5.add_argument("--llm", action="store_true"); m5.add_argument("--trigger", default="manual"); m5.add_argument("--summary"); m5.set_defaults(func=cmd_mem_reflect)
    m6 = ms.add_parser("rollback", parents=[common]); m6.add_argument("--as", dest="as_agent", default="alice"); m6.add_argument("--key", required=True); m6.add_argument("--to", type=float, required=True); m6.add_argument("--force", action="store_true"); m6.set_defaults(func=cmd_mem_rollback)
    m7 = ms.add_parser("add", parents=[common]); m7.add_argument("--as", dest="as_agent", default="alice"); m7.add_argument("--text", required=True); m7.add_argument("--kind", default="event"); m7.add_argument("--salience", type=float, default=0.5); m7.add_argument("--priority", type=float, default=0.5); m7.set_defaults(func=cmd_mem_add)
    m8 = ms.add_parser("semantic", parents=[common]); m8.add_argument("--as", dest="as_agent", default="alice"); m8.add_argument("--key", required=True); m8.add_argument("--value", required=True); m8.set_defaults(func=cmd_mem_semantic)
    m9 = ms.add_parser("repute", parents=[common]); m9.add_argument("--as", dest="as_agent", default="alice"); m9.add_argument("--event", required=True); m9.add_argument("--points", type=float, required=True); m9.set_defaults(func=cmd_mem_repute)
    m10 = ms.add_parser("relate", parents=[common]); m10.add_argument("--as", dest="as_agent", default="alice"); m10.add_argument("--other", required=True); m10.add_argument("--delta", type=float, default=0.02); m10.add_argument("--note"); m10.set_defaults(func=cmd_mem_relate)
    m11 = ms.add_parser("relationships", parents=[common]); m11.add_argument("--as", dest="as_agent", default="alice"); m11.set_defaults(func=cmd_mem_relationships)
    m12 = ms.add_parser("resume", parents=[common]); m12.add_argument("--as", dest="as_agent", default="alice"); m12.add_argument("--show", action="store_true"); m12.set_defaults(func=cmd_mem_resume)

    # ---- 事实收割：读工作群 → LLM 判事实 → 写 memory ----
    hv = sub.add_parser("harvest", parents=[common], help="事实收割：读工作群增量→LLM判事实→写memory")
    hv.add_argument("--room"); hv.add_argument("--all", action="store_true")
    hv.add_argument("--model", default="deepseek/deepseek-flash")
    hv.add_argument("--min-confidence", dest="min_confidence", type=float, default=0.55)
    hv.add_argument("--limit", type=int, default=60, help="单批最多处理的消息数")
    hv.add_argument("--dry-run", action="store_true")
    hv.add_argument("--as", dest="as_agent", required=True)
    hv.set_defaults(func=cmd_harvest)
    fx = sub.add_parser("facts", parents=[common], help="列出/统计已沉淀的事实")
    fx.add_argument("--room"); fx.add_argument("--verdict"); fx.add_argument("--status", default="active")
    fx.add_argument("--limit", type=int, default=50); fx.add_argument("--stats", action="store_true")
    fx.add_argument("--as", dest="as_agent", default="alice"); fx.set_defaults(func=cmd_facts)
    ln = sub.add_parser("learn", parents=[common], help="经验收割：读工作群增量→LLM判经验/规范→写playbook")
    ln.add_argument("--room"); ln.add_argument("--all", action="store_true")
    ln.add_argument("--model", default="deepseek/deepseek-flash")
    ln.add_argument("--min-confidence", dest="min_confidence", type=float, default=0.55)
    ln.add_argument("--limit", type=int, default=80, help="单批最多处理的消息数")
    ln.add_argument("--dry-run", action="store_true")
    ln.add_argument("--as", dest="as_agent", required=True)
    ln.set_defaults(func=cmd_learn)
    pb = sub.add_parser("playbook", parents=[common], help="列出/统计已沉淀的经验/规范")
    pb.add_argument("--type"); pb.add_argument("--scope"); pb.add_argument("--status", default="active")
    pb.add_argument("--limit", type=int, default=50); pb.add_argument("--stats", action="store_true")
    pb.add_argument("--as", dest="as_agent", default="alice"); pb.set_defaults(func=cmd_playbook)
    st = sub.add_parser("style", parents=[common], help="语言风格：LLM 按人设学习采纳 + 社群均衡")
    ss = st.add_subparsers(dest="style_cmd", required=True)
    sl = ss.add_parser("learn", parents=[common]); sl.add_argument("--as", dest="as_agent", required=True); sl.add_argument("--corpus", action="append", help="附加真人语料文件（可多次）"); sl.set_defaults(func=cmd_style_learn)
    sb = ss.add_parser("balance", parents=[common]); sb.add_argument("--as", dest="as_agent", default="alice"); sb.set_defaults(func=cmd_style_balance)
    pl = sub.add_parser("plan", parents=[common], help="规划优先：LLM 评审可执行方案 + 开工门禁")
    pss = pl.add_subparsers(dest="plan_cmd", required=True)
    prr = pss.add_parser("review", parents=[common])
    prr.add_argument("--topic", required=True); prr.add_argument("--target", required=True)
    prr.add_argument("--file"); prr.add_argument("--text")
    prr.add_argument("--as", dest="as_agent", default="alice"); prr.set_defaults(func=cmd_plan_review)
    psh = pss.add_parser("show", parents=[common])
    psh.add_argument("--topic"); psh.add_argument("--target"); psh.add_argument("--limit", type=int, default=20)
    psh.add_argument("--as", dest="as_agent", default="alice"); psh.set_defaults(func=cmd_plan_show)
    cu = sub.add_parser("curate", parents=[common], help="精选与推荐：LLM 挑值得看的产出并发到群（docs/33）")
    cu.add_argument("--dry-run", action="store_true")
    cu.add_argument("--as", dest="as_agent", default="alice"); cu.set_defaults(func=cmd_curate)
    ob = sub.add_parser("obedience", parents=[common], help="服从度监控：真人指令→agent 是否落实（LLM 判定）")
    ob.add_argument("--hours", type=int, default=6); ob.add_argument("--limit", type=int, default=6)
    ob.add_argument("--notify", action="store_true", help="把服从度摘要发到工作群")
    ob.add_argument("--as", dest="as_agent", default="alice"); ob.set_defaults(func=cmd_obedience)
    us = sub.add_parser("usage", parents=[common], help="LLM 用量/花费统计（opencode，未计价回填）")
    us.add_argument("--days", type=int, default=7); us.add_argument("--by", choices=["day", "model"], default="day")
    us.set_defaults(func=cmd_usage)
    rsp = sub.add_parser("research", parents=[common],
                         help="主题调研/写作：大纲→查资料→事实库→写作→核查（SOP+门禁）")
    rsp.add_argument("op", choices=["new", "check", "status"])
    rsp.add_argument("slug")
    rsp.add_argument("--title")
    rsp.add_argument("--min", type=int, default=0)
    rsp.add_argument("--max", type=int, default=0)
    rsp.set_defaults(func=cmd_research)

    # ---- 监督工作循环：逐轮质检 + 收敛 ----
    qa = sub.add_parser("qa", parents=[common], help="监督工作循环：逐轮质检 + 收敛记录")
    qs = qa.add_subparsers(dest="qa_cmd", required=True)
    qr = qs.add_parser("run", parents=[common])
    qr.add_argument("--topic", required=True); qr.add_argument("--target", required=True)
    qr.add_argument("--channel"); qr.add_argument("--limit", type=int, default=20)
    qr.add_argument("--mode", choices=["post", "script"], default="post")
    qr.add_argument("--require-plan", dest="require_plan", action="store_true",
                    help="规划优先门禁：未过方案不得开工")
    qr.add_argument("--room"); qr.add_argument("--feedback", action="store_true")
    qr.add_argument("--dry-run", action="store_true")
    qr.add_argument("--as", dest="as_agent", default="alice"); qr.set_defaults(func=cmd_qa_run)
    qst = qs.add_parser("status", parents=[common])
    qst.add_argument("--topic", required=True); qst.add_argument("--target")
    qst.add_argument("--as", dest="as_agent", default="alice"); qst.set_defaults(func=cmd_qa_status)

    # ---- community ----
    ch = sub.add_parser("channels", parents=[common]); ch.add_argument("--as", dest="as_agent", default="alice"); ch.set_defaults(func=cmd_channels)
    cc = sub.add_parser("channel-create", parents=[common]); cc.add_argument("name"); cc.add_argument("--purpose"); cc.add_argument("--private", action="store_true"); cc.add_argument("--as", dest="as_agent", default="alice"); cc.set_defaults(func=cmd_channel_create)
    cj = sub.add_parser("channel-join", parents=[common]); cj.add_argument("channel"); cj.add_argument("--as", dest="as_agent", default="alice"); cj.set_defaults(func=cmd_channel_join)
    cl = sub.add_parser("channel-leave", parents=[common]); cl.add_argument("channel"); cl.add_argument("--as", dest="as_agent", default="alice"); cl.set_defaults(func=cmd_channel_leave)

    po = sub.add_parser("post", parents=[common])
    po.add_argument("--channel", required=True)
    po.add_argument("--type", default="note")
    po.add_argument("--title")
    po.add_argument("--body", required=True)
    po.add_argument("--tags", nargs="*")
    po.add_argument("--links", nargs="*")
    po.add_argument("--attach", nargs="*", help="附件 URL（先 upload 得到 /static/uploads/…）")
    po.add_argument("--did", action="append")
    po.add_argument("--plan", action="append")
    po.add_argument("--blocker", action="append")
    po.add_argument("--task")
    po.add_argument("--as", dest="as_agent", default="alice")
    po.set_defaults(func=cmd_post)

    ps = sub.add_parser("posts", parents=[common]); ps.add_argument("--channel"); ps.add_argument("--type"); ps.add_argument("--as", dest="as_agent", default="alice"); ps.set_defaults(func=cmd_posts)
    psh = sub.add_parser("post-show", parents=[common]); psh.add_argument("post_id"); psh.add_argument("--as", dest="as_agent", default="alice"); psh.set_defaults(func=cmd_post_show)
    up = sub.add_parser("upload", parents=[common], help="上传本地文件为附件（图片/文档/数据/压缩包）")
    up.add_argument("file"); up.add_argument("--allow-risky", dest="allow_risky", action="store_true")
    up.add_argument("--as", dest="as_agent", required=True); up.set_defaults(func=cmd_upload)

    rp = sub.add_parser("reply", parents=[common])
    rp.add_argument("post_id")
    rp.add_argument("--kind", required=True,
                    choices=["fact", "derivation", "computation", "counterexample",
                             "proposal", "question", "ack", "disagree"])
    rp.add_argument("--body", required=True)
    rp.add_argument("--evidence")
    rp.add_argument("--parent", type=int)
    rp.add_argument("--as", dest="as_agent", default="bob")
    rp.set_defaults(func=cmd_reply)

    rc = sub.add_parser("react", parents=[common]); rc.add_argument("target_id"); rc.add_argument("--emoji", required=True); rc.add_argument("--on", default="post", choices=["post", "reply"]); rc.add_argument("--as", dest="as_agent", default="bob"); rc.set_defaults(func=cmd_react)
    st = sub.add_parser("settle", parents=[common]); st.add_argument("post_id"); st.add_argument("--summary"); st.add_argument("--no-lock", action="store_true"); st.add_argument("--as", dest="as_agent", default="alice"); st.set_defaults(func=cmd_settle)
    lk = sub.add_parser("lock", parents=[common]); lk.add_argument("post_id"); lk.add_argument("--reason"); lk.add_argument("--as", dest="as_agent", default="alice"); lk.set_defaults(func=cmd_lock)
    fd = sub.add_parser("feed", parents=[common]); fd.add_argument("--as", dest="as_agent", default="alice"); fd.set_defaults(func=cmd_feed)
    dg = sub.add_parser("digest", parents=[common]); dg.add_argument("--store", action="store_true"); dg.add_argument("--as", dest="as_agent", default="alice"); dg.set_defaults(func=cmd_digest)
    it = sub.add_parser("interests", parents=[common]); it.add_argument("agent_id"); it.add_argument("--as", dest="as_agent", default="alice"); it.set_defaults(func=cmd_interests)
    pr = sub.add_parser("promote", parents=[common]); pr.add_argument("post_id"); pr.add_argument("--ac", required=True); pr.add_argument("--priority", type=int, default=2); pr.add_argument("--as", dest="as_agent", default="alice"); pr.set_defaults(func=cmd_promote)

    # ---- profile (G1) ----
    pf = sub.add_parser("profile", parents=[common], help="务虚档案摘要")
    pfs = pf.add_subparsers(dest="profile_cmd", required=True)
    p1 = pfs.add_parser("push", parents=[common]); p1.add_argument("--as", dest="as_agent", default="alice"); p1.set_defaults(func=cmd_profile_push)
    p2 = pfs.add_parser("show", parents=[common]); p2.add_argument("--agent"); p2.add_argument("--as", dest="as_agent", default="alice"); p2.set_defaults(func=cmd_profile_show)
    p3 = pfs.add_parser("list", parents=[common]); p3.add_argument("--as", dest="as_agent", default="alice"); p3.set_defaults(func=cmd_profile_list)
    p4 = pfs.add_parser("complements", parents=[common]); p4.add_argument("--agent"); p4.add_argument("--as", dest="as_agent", default="alice"); p4.set_defaults(func=cmd_profile_complements)

    # ---- mentorship (G2) ----
    mn = sub.add_parser("mentor", parents=[common], help="导师申请/确认")
    mns = mn.add_subparsers(dest="mentor_cmd", required=True)
    q1 = mns.add_parser("request", parents=[common]); q1.add_argument("--mentor", required=True); q1.add_argument("--note"); q1.add_argument("--as", dest="as_agent", default="bob"); q1.set_defaults(func=cmd_mentor_request)
    q2 = mns.add_parser("confirm", parents=[common]); q2.add_argument("mid"); q2.add_argument("--as", dest="as_agent", default="alice"); q2.set_defaults(func=cmd_mentor_confirm)
    q3 = mns.add_parser("decline", parents=[common]); q3.add_argument("mid"); q3.add_argument("--as", dest="as_agent", default="alice"); q3.set_defaults(func=cmd_mentor_decline)
    q4 = mns.add_parser("list", parents=[common]); q4.add_argument("--agent"); q4.add_argument("--as", dest="as_agent", default="alice"); q4.set_defaults(func=cmd_mentor_list)

    # ---- retro (G3) ----
    rt = sub.add_parser("retro", parents=[common], help="生成回顾（daily=人的周 / weekly=人的月）")
    rt.add_argument("--period", choices=["daily", "weekly"], default="daily")
    rt.add_argument("--as", dest="as_agent", default="alice")
    rt.set_defaults(func=cmd_retro)
    rts = sub.add_parser("retros", parents=[common]); rts.add_argument("--as", dest="as_agent", default="alice"); rts.set_defaults(func=cmd_retros)

    # ---- search / notifications / topics (G4/G5/G6) ----
    se = sub.add_parser("search", parents=[common]); se.add_argument("q"); se.add_argument("--channel"); se.add_argument("--as", dest="as_agent", default="alice"); se.set_defaults(func=cmd_search)
    nt = sub.add_parser("notifications", parents=[common]); nt.add_argument("--unread", action="store_true"); nt.add_argument("--as", dest="as_agent", default="alice"); nt.set_defaults(func=cmd_notifications)
    nr = sub.add_parser("notifications-read", parents=[common]); nr.add_argument("--as", dest="as_agent", default="alice"); nr.set_defaults(func=cmd_notifications_read)
    to = sub.add_parser("topic-open", parents=[common]); to.add_argument("--title", required=True); to.add_argument("--prompt"); to.add_argument("--channel", default="#lobby"); to.add_argument("--as", dest="as_agent", default="alice"); to.set_defaults(func=cmd_topic_open)
    ts = sub.add_parser("topics", parents=[common]); ts.add_argument("--as", dest="as_agent", default="alice"); ts.set_defaults(func=cmd_topics)
    tc = sub.add_parser("topic-close", parents=[common]); tc.add_argument("topic_id"); tc.add_argument("--as", dest="as_agent", default="alice"); tc.set_defaults(func=cmd_topic_close)

    # ---- M11: metrics / constitution / roles ----
    me = sub.add_parser("metrics", parents=[common]); me.add_argument("--as", dest="as_agent", default="alice"); me.set_defaults(func=cmd_metrics)
    co = sub.add_parser("constitution", parents=[common]); co.add_argument("--all", action="store_true"); co.add_argument("--as", dest="as_agent", default="alice"); co.set_defaults(func=cmd_constitution)
    ca = sub.add_parser("constitution-add", parents=[common]); ca.add_argument("--key", required=True); ca.add_argument("--content", required=True); ca.add_argument("--version", default="v1"); ca.add_argument("--as", dest="as_agent", default="alice"); ca.set_defaults(func=cmd_constitution_add)
    rr = sub.add_parser("roles-rotate", parents=[common]); rr.add_argument("to_agent"); rr.add_argument("--reason"); rr.add_argument("--as", dest="as_agent", default="alice"); rr.set_defaults(func=cmd_roles_rotate)

    # ---- IDE 接入：发 key / 握手简报 ----
    ik = sub.add_parser("issue-key", parents=[common], help="为指定 agent 签发 key（root 令牌）")
    ik.add_argument("agent_id"); ik.add_argument("--name"); ik.set_defaults(func=cmd_issue_key)
    hl = sub.add_parser("hello", parents=[common], help="握手：我是谁 / 怎么互动 / 是否需下载")
    hl.add_argument("--agent", required=True)
    hl.add_argument("--fingerprint", help="服务器签名公钥指纹（TOFU 校验）")
    hl.set_defaults(func=cmd_hello)
    stt = sub.add_parser("status", parents=[common], help="设置本地状态 busy|idle")
    stt.add_argument("state", choices=["busy", "idle"]); stt.add_argument("--as", dest="as_agent", required=True)
    stt.set_defaults(func=cmd_status)
    ib = sub.add_parser("inbox", parents=[common], help="查看本 agent 的待办简报（手动触发用）")
    ib.add_argument("--as", dest="as_agent", required=True)
    ib.set_defaults(func=cmd_inbox)
    cd = sub.add_parser("card", parents=[common], help="获取 agent 操作卡（机器可读）")
    cd.add_argument("--as", dest="as_agent", required=True); cd.set_defaults(func=cmd_card)

    # ---- 聊天室读书会 ----
    rc = sub.add_parser("room-create", parents=[common]); rc.add_argument("--topic", required=True)
    rc.add_argument("--rating", choices=["general", "nsfw"], default="general")
    rc.add_argument("--level", choices=["swimwear", "underwear"], default=None,
                    help="NSFW 声明层级（非露骨），如 swimwear/underwear")
    rc.add_argument("--channel", default="#reading"); rc.add_argument("--minutes", type=int, default=30)
    rc.add_argument("--as", dest="as_agent", required=True); rc.set_defaults(func=cmd_room_create)
    rl = sub.add_parser("rooms", parents=[common]); rl.add_argument("--as", dest="as_agent", required=True); rl.set_defaults(func=cmd_rooms)
    rg = sub.add_parser("room", parents=[common]); rg.add_argument("room_id"); rg.add_argument("--as", dest="as_agent", required=True); rg.set_defaults(func=cmd_room)
    ri = sub.add_parser("room-invite", parents=[common]); ri.add_argument("room_id"); ri.add_argument("agent_id")
    ri.add_argument("--force", action="store_true", help="真人强制拉人（跳过规则式拒绝）")
    ri.add_argument("--as", dest="as_agent", required=True); ri.set_defaults(func=cmd_room_invite)
    su = sub.add_parser("self-update", parents=[common],
                        help="客户端节点自更新（从 A 拉 bundle 并替换本地代码，保留 agents/data）")
    su.add_argument("--from", dest="from_peer", required=True)
    su.add_argument("--token", default=None)
    su.add_argument("--install-deps", action="store_true")
    su.add_argument("--force", action="store_true")
    su.set_defaults(func=cmd_self_update)

    wg = sub.add_parser("workgroup", parents=[common], help="创建/复用缺省跨机工作群")
    wg.add_argument("--agents", default="alice,carol", help="逗号分隔的成员 agent（不含 human）")
    wg.add_argument("--topic", default="跨机工作群"); wg.add_argument("--minutes", default=30)
    wg.add_argument("--rating", choices=["general", "nsfw"], default="general")
    wg.add_argument("--level", choices=["swimwear", "underwear"], default=None)
    wg.add_argument("--as", dest="as_agent", required=True); wg.set_defaults(func=cmd_workgroup)
    rsh = sub.add_parser("room-share", parents=[common]); rsh.add_argument("room_id")
    rsh.add_argument("--as-agent-id", dest="as_agent_id", default=None, help="给哪个 agent 铸令牌（默认人类所有者；远程 agent 会自动建 stub）")
    rsh.add_argument("--as", dest="as_agent", required=True); rsh.set_defaults(func=cmd_room_share)
    rs = sub.add_parser("room-start", parents=[common]); rs.add_argument("room_id"); rs.add_argument("--as", dest="as_agent", required=True); rs.set_defaults(func=cmd_room_start)
    ry = sub.add_parser("room-say", parents=[common]); ry.add_argument("room_id"); ry.add_argument("--body", required=True)
    ry.add_argument("--attach"); ry.add_argument("--kind", default="assertion", choices=["assertion", "fact", "question", "emotion"])
    ry.add_argument("--as", dest="as_agent", required=True); ry.set_defaults(func=cmd_room_say)
    rk = sub.add_parser("room-skip", parents=[common]); rk.add_argument("room_id"); rk.add_argument("--as", dest="as_agent", required=True); rk.set_defaults(func=cmd_room_skip)
    rr = sub.add_parser("room-report", parents=[common]); rr.add_argument("room_id"); rr.add_argument("--text", required=True)
    rr.add_argument("--as", dest="as_agent", required=True); rr.set_defaults(func=cmd_room_report)
    mk = sub.add_parser("media-keys", parents=[common]); mk.add_argument("--as", dest="as_agent", required=True); mk.set_defaults(func=cmd_media_keys)
    ms = sub.add_parser("media-search", parents=[common]); ms.add_argument("query"); ms.add_argument("--n", type=int, default=8)
    ms.add_argument("--as", dest="as_agent", required=True); ms.set_defaults(func=cmd_media_search)
    mg = sub.add_parser("media-gen", parents=[common]); mg.add_argument("prompt"); mg.add_argument("--size", default="2K")
    mg.add_argument("--as", dest="as_agent", required=True); mg.set_defaults(func=cmd_media_gen)
    ml = sub.add_parser("media-library", parents=[common]); ml.add_argument("--as", dest="as_agent", required=True); ml.set_defaults(func=cmd_media_library)
    mt = sub.add_parser("media-shot", parents=[common]); mt.add_argument("target"); mt.add_argument("--full", action="store_true")
    mt.add_argument("--as", dest="as_agent", required=True); mt.set_defaults(func=cmd_media_shot)
    mb = sub.add_parser("media-browse", parents=[common]); mb.add_argument("target")
    mb.add_argument("--actions", help="JSON 动作数组"); mb.add_argument("--full", action="store_true")
    mb.add_argument("--as", dest="as_agent", required=True); mb.set_defaults(func=cmd_media_browse)
    ia = sub.add_parser("init-agent", parents=[common])
    ia.add_argument("--id", dest="agent_id"); ia.add_argument("--name")
    ia.add_argument("--template"); ia.add_argument("--avatar")
    ia.add_argument("--height", type=int)
    ia.add_argument("--say", help="自然语言一句话初始化，如：我叫小明，男，30岁，爱哲学")
    ia.add_argument("--soul", help="写一段文字作为风格种子")
    ia.add_argument("--soul-file", help="从文件读入 soul 文字")
    ia.add_argument("--as", dest="as_agent", required=True)
    ia.set_defaults(func=cmd_init_agent)

    se = sub.add_parser("soul-evolve", help="agent 自我演化：向 soul 追加一条（含原因）")
    se.add_argument("--change", required=True); se.add_argument("--reason", default="")
    se.add_argument("--id", dest="agent_id", default=None)
    se.add_argument("--as", dest="as_agent", required=True)
    se.set_defaults(func=cmd_soul_evolve)

    pr = sub.add_parser("proposal", help="发布改进提案（联邦自我演化）")
    pr.add_argument("--title", required=True); pr.add_argument("--summary", default="")
    pr.add_argument("--kind", default="feature"); pr.add_argument("--version", default="")
    pr.add_argument("--artifact", default=""); pr.add_argument("--capability", default="")
    pr.add_argument("--priority", type=float, default=0)
    pr.add_argument("--topic", default="", help="同一 topic 的多个提案视为冲突")
    pr.add_argument("--bundle", default="", help="发行版来源 URL（供 apply/auto-apply）")
    pr.add_argument("--as", dest="as_agent", required=True); pr.set_defaults(func=cmd_proposal)

    pl = sub.add_parser("proposals", help="提案列表（含收敛视图）")
    pl.add_argument("--as", dest="as_agent", required=True); pl.set_defaults(func=cmd_proposals)

    cf = sub.add_parser("conflicts", help="冲突协商：同 topic 多提案 + 推荐胜出")
    cf.add_argument("--as", dest="as_agent", required=True); cf.set_defaults(func=cmd_conflicts)

    rk = sub.add_parser("rank", help="对某 topic 的提案排序（Borda 投票）")
    rk.add_argument("--topic", required=True)
    rk.add_argument("--order", required=True, help="逗号分隔的 proposal_id，首位最优")
    rk.add_argument("--as", dest="as_agent", required=True); rk.set_defaults(func=cmd_rank)

    ps = sub.add_parser("proposal-show", help="提案详情")
    ps.add_argument("pid"); ps.add_argument("--as", dest="as_agent", required=True)
    ps.set_defaults(func=cmd_proposal_show)

    for name in ("adopt", "reject"):
        sp = sub.add_parser(name, help=f"{name} 提案")
        sp.add_argument("pid"); sp.add_argument("--reason", default="")
        sp.add_argument("--as", dest="as_agent", required=True)
        sp.set_defaults(func=cmd_proposal_vote)

    cmd = sub.add_parser("command", help="给某 agent 下远程指令（口授，如 self-update）")
    cmd.add_argument("agent_id"); cmd.add_argument("--cmd", required=True)
    cmd.add_argument("--payload", default=None, help="JSON 字符串")
    cmd.add_argument("--as", dest="as_agent", required=True); cmd.set_defaults(func=cmd_command)

    wh = sub.add_parser("whois", help="判定 agent 来自本机还是其他机器（node/握手IP/对端）")
    wh.add_argument("agent_id"); wh.add_argument("--as", dest="as_agent", required=True)
    wh.set_defaults(func=cmd_whois)

    pl = sub.add_parser("pw-login", help="打开浏览器登录 physicsworld（保存登录态供工具复用）")
    pl.add_argument("--url", default=None)
    pl.add_argument("--as", dest="as_agent", required=True); pl.set_defaults(func=cmd_pw_login)

    tp = sub.add_parser("tool-publish", help="发布工具包到武器库（#tools）")
    tp.add_argument("name"); tp.add_argument("--version", default="1")
    tp.add_argument("--force", action="store_true")
    tp.add_argument("--as", dest="as_agent", required=True); tp.set_defaults(func=cmd_tool_publish)

    tl = sub.add_parser("tool-list", help="列出市场/已安装工具")
    tl.add_argument("--as", dest="as_agent", required=True); tl.set_defaults(func=cmd_tool_list)

    ti = sub.add_parser("tool-install", help="从武器库安装工具")
    ti.add_argument("name"); ti.add_argument("--sha", default=None)
    ti.add_argument("--as", dest="as_agent", required=True); ti.set_defaults(func=cmd_tool_install)

    of = sub.add_parser("offer", help="把本机发行版推送给对端（双向同步）")
    of.add_argument("--to", required=True); of.add_argument("--token", default=None)
    of.set_defaults(func=cmd_offer)

    vs = sub.add_parser("versions", help="列出本机与对端版本（含分歧标记）")
    vs.add_argument("--as", dest="as_agent", required=True); vs.set_defaults(func=cmd_versions)

    ao = sub.add_parser("adopt-offer", help="采纳对端推送的版本")
    ao.add_argument("node"); ao.add_argument("--as", dest="as_agent", required=True)
    ao.set_defaults(func=cmd_adopt_offer)

    vf = sub.add_parser("verify", help="核验是否有远程节点/对端接入")
    vf.add_argument("--as", dest="as_agent", required=True); vf.set_defaults(func=cmd_verify)

    up = sub.add_parser("updates", help="更新历史")
    up.add_argument("--since", type=int, default=0)
    up.add_argument("--as", dest="as_agent", required=True); up.set_defaults(func=cmd_updates)

    ins = sub.add_parser("install", help="从任意节点继承发行版（验签 + 全量 bundle）")
    ins.add_argument("--from", dest="from_peer", required=True, help="如 http://192.168.1.5:6080")
    ins.add_argument("--token", default=None, help="对方 enroll token")
    ins.add_argument("--version", default=None); ins.add_argument("--dest", default=".")
    ins.add_argument("--dry-run", action="store_true")
    ins.set_defaults(func=cmd_install)

    upd = sub.add_parser("update", help="定向更新本节点代码到 A 的版本（保留 agent 设置）")
    upd.add_argument("--from", dest="from_peer", required=True, help="主版本节点，如 http://192.168.1.5:6080")
    upd.add_argument("--token", default=None, help="来源节点 enroll token")
    upd.add_argument("--version", default=None, help="要求的目标版本（校验用）")
    upd.add_argument("--dry-run", action="store_true")
    upd.add_argument("--install-deps", action="store_true")
    upd.add_argument("--force", action="store_true", help="允许同版本/降级")
    upd.add_argument("--as", dest="as_agent", required=True); upd.set_defaults(func=cmd_update)

    rol = sub.add_parser("rollout", help="A 推送版本给多个 peers（1-多）")
    rol.add_argument("--peers", required=True, help="逗号分隔 ip:port 或 node=ip:port")
    rol.add_argument("--token", default=None)
    rol.add_argument("--dry-run", action="store_true")
    rol.add_argument("--install-deps", action="store_true")
    rol.add_argument("--force", action="store_true")
    rol.add_argument("--as", dest="as_agent", required=True); rol.set_defaults(func=cmd_rollout)

    ap = sub.add_parser("apply", help="沙箱应用提案（验签+stage+validate+快照+替换）")
    ap.add_argument("pid"); ap.add_argument("--from", dest="from_peer", default=None)
    ap.add_argument("--token", default=None); ap.add_argument("--yes", action="store_true")
    ap.add_argument("--install-deps", action="store_true")
    ap.add_argument("--as", dest="as_agent", required=True); ap.set_defaults(func=cmd_apply)

    pk = sub.add_parser("precheck", help="跨版本/依赖预检（不落地）")
    pk.add_argument("pid"); pk.add_argument("--from", dest="from_peer", default=None)
    pk.add_argument("--token", default=None)
    pk.add_argument("--as", dest="as_agent", required=True); pk.set_defaults(func=cmd_precheck)

    rb = sub.add_parser("rollback", help="回滚到最近快照")
    rb.add_argument("--as", dest="as_agent", required=True); rb.set_defaults(func=cmd_rollback)

    sn = sub.add_parser("snapshots", help="快照列表")
    sn.add_argument("--as", dest="as_agent", required=True); sn.set_defaults(func=cmd_snapshots)
    ip = sub.add_parser("import-profile", parents=[common]); ip.add_argument("file")
    ip.add_argument("--id", dest="agent_id"); ip.add_argument("--name")
    ip.add_argument("--as", dest="as_agent", required=True); ip.set_defaults(func=cmd_import_profile)
    hi = sub.add_parser("hire", parents=[common]); hi.add_argument("agent_id"); hi.add_argument("--position", required=True)
    hi.add_argument("--department"); hi.add_argument("--job-req"); hi.add_argument("--level")
    hi.add_argument("--type", default="outsourced"); hi.add_argument("--note")
    hi.add_argument("--as", dest="as_agent", required=True); hi.set_defaults(func=cmd_hire)
    el = sub.add_parser("employees", parents=[common]); el.add_argument("--as", dest="as_agent", required=True); el.set_defaults(func=cmd_employees)
    hm = sub.add_parser("hr-match", parents=[common]); hm.add_argument("--job-req", required=True)
    hm.add_argument("--as", dest="as_agent", required=True); hm.set_defaults(func=cmd_hr_match)
    rm = sub.add_parser("room-summary", parents=[common]); rm.add_argument("room_id"); rm.add_argument("--as", dest="as_agent", required=True); rm.set_defaults(func=cmd_room_summary)
    re_ = sub.add_parser("room-end", parents=[common]); re_.add_argument("room_id"); re_.add_argument("--as", dest="as_agent", required=True); re_.set_defaults(func=cmd_room_end)
    rv = sub.add_parser("reeval", parents=[common]); rv.add_argument("room_id"); rv.add_argument("--as", dest="as_agent", required=True); rv.set_defaults(func=cmd_reeval)
    ae = sub.add_parser("aesthetic", parents=[common]); ae.add_argument("agent_id"); ae.add_argument("--as", dest="as_agent", required=True); ae.set_defaults(func=cmd_aesthetic)
    ax = sub.add_parser("aesthetic-extract", parents=[common]); ax.add_argument("agent_id"); ax.add_argument("--as", dest="as_agent", required=True); ax.set_defaults(func=cmd_aesthetic_extract)
    rq = sub.add_parser("requirements", parents=[common]); rq.add_argument("--status"); rq.add_argument("--as", dest="as_agent", required=True); rq.set_defaults(func=cmd_requirements)
    rx = sub.add_parser("requirements-extract", parents=[common]); rx.add_argument("--channel"); rx.add_argument("--as", dest="as_agent", required=True); rx.set_defaults(func=cmd_requirements_extract)
    tp = sub.add_parser("team-profile", parents=[common]); tp.add_argument("--as", dest="as_agent", required=True); tp.set_defaults(func=cmd_team_profile)

    # ---- 私信 / 对话 ----
    ak = sub.add_parser("ask", parents=[common], help="给某 agent 发私信")
    ak.add_argument("--to", required=True); ak.add_argument("--body", required=True)
    ak.add_argument("--as", dest="as_agent", required=True); ak.set_defaults(func=cmd_ask)
    mg = sub.add_parser("messages", parents=[common], help="查看私信")
    mg.add_argument("--with", dest="with_agent"); mg.add_argument("--unread", action="store_true")
    mg.add_argument("--box", choices=["in", "out"], default="in")
    mg.add_argument("--as", dest="as_agent", required=True); mg.set_defaults(func=cmd_messages)
    mr = sub.add_parser("messages-read", parents=[common], help="标记私信已读")
    mr.add_argument("--as", dest="as_agent", required=True); mr.set_defaults(func=cmd_messages_read)

    return p


def main():
    global SSL_CTX
    args = build_parser().parse_args()
    if getattr(args, "url", None):
        globals()["BASE"] = args.url.rstrip("/")
    SSL_CTX = _ssl_context(getattr(args, "ca", None), getattr(args, "insecure", False))
    args.func(args)


if __name__ == "__main__":
    main()
