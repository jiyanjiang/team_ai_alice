#!/usr/bin/env python3
"""redact —— 脱敏扫描（自包含，可经目录系统分发）。

三层校验的确定性部分：正则 + 高熵字符串。
用法：
    python runtime/redact.py <file>            # 扫描并打印报告
    python runtime/redact.py --stdin < file
通过标准：high_count == 0。
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import Counter

PATTERNS = [
    ("high", "api_key_sk", re.compile(r"sk-[A-Za-z0-9]{20,}")),
    ("high", "aws_akid", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("high", "bearer", re.compile(r"Bearer\s+[A-Za-z0-9._\-]{16,}")),
    ("high", "private_key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("high", "password", re.compile(r"(?i)(password|passwd|secret|token)\s*[:=]\s*\S{6,}")),
    ("high", "abs_path_users", re.compile(r"/Users/[A-Za-z0-9._-]+/")),
    ("high", "abs_path_home", re.compile(r"/home/[A-Za-z0-9._-]+/")),
    ("high", "abs_path_win", re.compile(r"[A-Za-z]:\\\\Users\\\\[A-Za-z0-9._-]+")),
    ("medium", "email", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("medium", "private_ip", re.compile(r"\b(10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)\b")),
]


def entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    return -sum((c / len(s)) * math.log2(c / len(s)) for c in counts.values())


def scan(text: str) -> dict:
    findings = []
    for level, name, rx in PATTERNS:
        for m in rx.finditer(text):
            findings.append({"level": level, "rule": name, "match": m.group(0)[:60],
                             "start": m.start()})
    for m in re.finditer(r"[A-Za-z0-9+/=_\-]{24,}", text):
        tok = m.group(0)
        if entropy(tok) > 4.2:
            findings.append({"level": "medium", "rule": "high_entropy", "match": tok[:40],
                             "start": m.start()})
    counts = {"high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["level"]] += 1
    return {"counts": counts, "findings": findings, "pass": counts["high"] == 0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", nargs="?")
    ap.add_argument("--stdin", action="store_true")
    a = ap.parse_args()
    text = sys.stdin.read() if a.stdin or not a.file else open(a.file, encoding="utf-8").read()
    report = scan(text)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(0 if report["pass"] else 2)


if __name__ == "__main__":
    main()
