#!/usr/bin/env python3
"""harvest_agent —— 常驻「事实收割」：随时读工作群 → LLM 判事实 → 写 memory（docs/24）。

用法：
    python dist/harvest_agent.py --as alice --all --interval 90
    python dist/harvest_agent.py --as alice --room room-55e1cd08 --once
环境：TEAMAI_URL（默认 http://127.0.0.1:6030）
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))


def _key(agent: str) -> dict:
    return json.loads((ROOT / "agents" / agent / ".key").read_text(encoding="utf-8"))


def _sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    canon = f"{method.upper()}\n{path}\n{hashlib.sha256(body).hexdigest()}\n{ts}\n{nonce}"
    return hmac.new(key.encode(), canon.encode(), hashlib.sha256).hexdigest()


class Client:
    def __init__(self, base: str, agent: str):
        self.base = base.rstrip("/")
        self.agent = agent
        self.k = _key(agent)

    def call(self, method: str, path: str, body: dict | None = None) -> dict:
        data = json.dumps(body, ensure_ascii=False).encode() if body is not None else b""
        ts, nonce = str(int(time.time())), secrets.token_hex(8)
        req = urllib.request.Request(self.base + path, data=data if body is not None else None, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("X-TeamAI-Key", self.k["key_id"])
        req.add_header("X-TeamAI-Timestamp", ts)
        req.add_header("X-TeamAI-Nonce", nonce)
        req.add_header("X-TeamAI-Signature", _sign(self.k["key"], method, path, data, ts, nonce))
        _hub_tok = os.environ.get("TEAMAI_HUB_TOKEN") or os.environ.get("TEAMAI_TUNNEL_TOKEN")
        if _hub_tok and "/n/" in req.full_url: req.add_header("X-Hub-Token", _hub_tok)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            return {"_http": e.code, "_body": e.read().decode()[:200]}
        except urllib.error.URLError as e:
            return {"_err": str(e)}


def sweep(cli: Client, agent: str, rooms: list[str], *, model: str, min_conf: float, limit: int,
          learn: bool = True, learn_model: str | None = None) -> tuple[dict, dict]:
    from core import harvest, memory
    if learn:
        from core import playbook
    totals = {"facts": 0, "episodic": 0, "semantic": 0, "working": 0, "dup": 0, "msgs": 0}
    lt = {"playbook": 0, "semantic": 0, "dup": 0, "msgs": 0}
    for rid in rooms:
        # ① 事实收割（可说的事实）
        cur = memory.get_cursor(agent, rid)
        d = cli.call("GET", f"/v1/rooms/{rid}?after={cur}&limit=200")
        if "_err" not in d and "_http" not in d:
            try:
                out = harvest.harvest(agent, rid, d.get("transcript", []), room=d.get("room"),
                                      model=model, min_confidence=min_conf, max_msgs=limit, cursor=cur)
            except Exception as e:
                print(f"  {rid}: ERROR {e}", flush=True)
                out = {}
            if out.get("new_msgs"):
                w = out.get("wrote") or {}
                for k in totals:
                    totals[k] += int(w.get(k, 0) or 0)
                totals["msgs"] += int(out.get("new_msgs", 0))
                print(f"  {rid}: +{out['new_msgs']} msgs accepted={out.get('new', 0)} "
                      f"pending={out.get('pending', 0)} cursor={out.get('cursor')}", flush=True)
                for f in out.get("accepted", []):
                    print(f"      [{f['verdict']:<8}] {f['statement']}", flush=True)
                if out.get("error"):
                    print(f"      ! {out['error']}: {(out.get('raw') or '')[:200]}", flush=True)
        # ② 经验收割（LLM 判断哪些经验/规范/事实源值得入库）
        if learn:
            lcur = memory.get_learning_cursor(agent, rid)
            d2 = cli.call("GET", f"/v1/rooms/{rid}?after={lcur}&limit=1000")
            if "_err" in d2 or "_http" in d2:
                continue
            try:
                o2 = playbook.harvest_learnings(agent, rid, d2.get("transcript", []), room=d2.get("room"),
                                                model=learn_model or model, max_msgs=limit, cursor=lcur)
            except Exception as e:
                print(f"  {rid}: learn ERROR {e}", flush=True)
                o2 = {}
            if o2.get("new_msgs"):
                w2 = o2.get("wrote") or {}
                for k in lt:
                    lt[k] += int(w2.get(k, 0) or 0)
                lt["msgs"] += int(o2.get("new_msgs", 0))
                print(f"  {rid}: learn +{o2['new_msgs']} learned={o2.get('new', 0)} "
                      f"cursor={o2.get('cursor')}", flush=True)
                for l in o2.get("accepted", []):
                    print(f"      [{l['type']}/{l['scope']}] {l['statement']}", flush=True)
                if o2.get("error"):
                    print(f"      ! learn {o2['error']}: {(o2.get('raw') or '')[:200]}", flush=True)
    return totals, lt


def main() -> None:
    ap = argparse.ArgumentParser(description="事实收割常驻进程（docs/24）")
    ap.add_argument("--as", dest="as_agent", required=True)
    ap.add_argument("--url", default=os.environ.get("TEAMAI_URL", "http://127.0.0.1:6030"))
    ap.add_argument("--room", action="append", default=None)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--interval", type=int, default=300)
    ap.add_argument("--model", default=os.environ.get("TEAMAI_HARVEST_MODEL", "deepseek/deepseek-flash"))
    ap.add_argument("--min-confidence", dest="min_confidence", type=float, default=0.55)
    ap.add_argument("--limit", type=int, default=60, help="单房间单批最多消息数")
    ap.add_argument("--no-learn", dest="learn", action="store_false", default=True,
                    help="关掉经验收割（默认开启：事实+经验一起收）")
    ap.add_argument("--learn-model", dest="learn_model", default=None,
                    help="经验收割模型（默认同 --model）")
    ap.add_argument("--once", action="store_true", help="只跑一轮")
    args = ap.parse_args()

    cli = Client(args.url, args.as_agent)
    print(f"[harvest] agent={args.as_agent} url={args.url} interval={args.interval}s "
          f"model={args.model}", flush=True)
    while True:
        if args.room:
            rooms = args.room
        else:
            d = cli.call("GET", "/v1/rooms")
            rooms = [r["id"] for r in d.get("rooms", []) if r.get("status") == "running"] \
                if args.all else [r["id"] for r in d.get("rooms", []) if r.get("status") == "running"][:1]
        if rooms:
            t, lt = sweep(cli, args.as_agent, rooms, model=args.model,
                          min_conf=args.min_confidence, limit=args.limit,
                          learn=args.learn, learn_model=args.learn_model)
            if t["msgs"] or lt["msgs"]:
                print(f"[harvest] {time.strftime('%H:%M:%S')} rooms={len(rooms)} "
                      f"facts={t} learn={lt}", flush=True)
        if args.once:
            break
        time.sleep(max(10, args.interval))


if __name__ == "__main__":
    main()
