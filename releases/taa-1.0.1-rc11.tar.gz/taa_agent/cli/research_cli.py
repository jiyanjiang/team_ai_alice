#!/usr/bin/env python3
"""独立 research CLI：不依赖 hub / tunnel / 服务端网络。

既可被 `cli/teamai.py research ...` 挂载，也可直接：
    python cli/research_cli.py list --all
    python cli/research_cli.py ask --prompt "问题"
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _prompt(args) -> str:
    pf = getattr(args, "prompt_file", None)
    return open(pf, encoding="utf-8").read() if pf else (getattr(args, "prompt", None) or "")


def _print_result(r: dict) -> None:
    if r.get("rounds"):
        print(f"  已写 {r['file']}（{r['rounds']} 轮 · {r['chars']} 字 · 累计用量 {r['usage']}）")
    else:
        print(f"  已写 {r['file']}（{r['chars']} 字 · 用量 {r['usage']}）")
    print(f"  code={r.get('code') or '-'} version={r.get('version') or '-'} "
          f"provider={r.get('provider') or '-'} model={r.get('model') or '-'} "
          f"fallback={r.get('fallback_from') or '-'}")


def cmd_research(args) -> None:
    """主题调研/写作：大纲→查资料→事实库→写作→核查（脚手架 + 确定性门禁）。"""
    from core import research

    op = args.op
    if op == "code":
        prompt = _prompt(args)
        if not prompt.strip():
            print("  需要 --prompt 或 --prompt-file"); return
        ident = research.prompt_identity(prompt)
        print(f"  code: {ident['code']}")
        print(f"  normalized: {ident['normalized_prompt']}")
        print(f"  hash: {ident['normalized_prompt_hash']}")
        return
    if op == "list":
        items = research.list_research(include_legacy=bool(getattr(args, "all", False)))
        if getattr(args, "json", False):
            print(json.dumps(items, ensure_ascii=False, indent=2))
        else:
            for item in items:
                ref = item.get("code") or item.get("slug") or "-"
                versions = ",".join(item.get("versions") or []) or "-"
                latest = item.get("latest") or "-"
                title = item.get("title") or "-"
                err = f"  ERR={item['error']}" if item.get("error") else ""
                print(f"  {item['kind']:<6} {ref:<16} latest={latest:<4} "
                      f"versions={versions:<12} {title}{err}")
        return

    slug = getattr(args, "slug", None)
    version = getattr(args, "version", None)
    reuse = bool(getattr(args, "reuse", False))
    title = getattr(args, "title", None)

    if op == "new":
        prompt = _prompt(args)
        if not slug:
            if not prompt.strip():
                print("  需要 <slug>，或 --prompt 走现代 code"); return
            try:
                r = research.new_prompt(prompt, title=title, reuse=reuse)
            except (ValueError, RuntimeError) as e:
                print(f"  {e}"); return
            print(f"  code={r['code']} version={r['version']} created={r['created']}")
            print(f"  已创建 {r['dir']}")
            return
        try:
            r = research.new(slug, title)
        except ValueError as e:
            print(f"  {e}"); return
        print(f"  已创建 {r['dir']}")
        for name, desc in research.STEPS:
            print(f"    {name}：{desc}")
    elif op == "check":
        if not slug:
            print("  需要 <slug> 或 r-<code>"); return
        r = research.check(slug, min_words=getattr(args, "min", 0),
                           max_words=getattr(args, "max", 0), version=version)
        for c in r["checks"]:
            print(f"  [{'PASS' if c['ok'] else 'FAIL'}] {c['name']}  {c['detail']}")
        print("  =>", "通过 ✅" if r["ok"] else "未通过 ❌")
    elif op == "status":
        if not slug:
            print("  需要 <slug> 或 r-<code>"); return
        r = research.status(slug, version=version)
        print(f"  大纲={'有' if r['outline'] else '无'}  事实条数={r['facts']}  稿字数={r['draft_words']}")
    elif op == "ask":
        prompt = _prompt(args)
        if not prompt.strip():
            print("  需要 --prompt 或 --prompt-file"); return
        sysp = open(args.system, encoding="utf-8").read() if getattr(args, "system", None) else None
        rounds = getattr(args, "rounds", 1)
        model = getattr(args, "model", "deepseek-v4-pro")
        ali_model = getattr(args, "ali_model", None)
        try:
            if not slug:
                r = research.ask_prompt(prompt, title=title, reuse=reuse, rounds=rounds,
                                        model=model, ali_model=ali_model, system=sysp,
                                        temperature=getattr(args, "temperature", 0.3),
                                        tag=getattr(args, "tag", ""), progress=print)
            elif rounds and rounds > 1:
                r = research.ask_deep(slug, prompt, rounds=rounds, model=model,
                                      ali_model=ali_model, system=sysp,
                                      temperature=getattr(args, "temperature", 0.3),
                                      tag=getattr(args, "tag", ""), version=version,
                                      progress=print)
            else:
                r = research.ask(slug, prompt, model=model, ali_model=ali_model,
                                 system=sysp,
                                 temperature=getattr(args, "temperature", 0.3),
                                 tag=getattr(args, "tag", ""), version=version)
        except (ValueError, RuntimeError) as e:
            print(f"  {e}"); return
        _print_result(r)
    else:
        print("  op ∈ {new, check, status, ask, code, list}")


def add_research_arguments(p: argparse.ArgumentParser) -> argparse.ArgumentParser:
    p.add_argument("op", choices=["new", "check", "status", "ask", "code", "list"])
    p.add_argument("slug", nargs="?", help="legacy slug 或现代 r-<code>")
    p.add_argument("--version", default=None,
                   help="现代调研版本 v1/v2；默认 latest（仅 check/status/ask）")
    p.add_argument("--title")
    p.add_argument("--min", type=int, default=0)
    p.add_argument("--max", type=int, default=0)
    p.add_argument("--prompt")
    p.add_argument("--prompt-file", dest="prompt_file")
    p.add_argument("--system")
    p.add_argument("--model", default="deepseek-v4-pro")
    p.add_argument("--ali-model", dest="ali_model", default=None,
                   help="DeepSeek 不可用时的阿里模型（默认 qwen-plus）")
    p.add_argument("--temperature", type=float, default=0.3)
    p.add_argument("--rounds", type=int, default=1,
                   help="ask 深挖轮数（>1 走多轮：拆解→寻证→综合）")
    p.add_argument("--reuse", action="store_true",
                   help="复用现代调研最新版本（重试/补跑）；默认新建 v2/v3")
    p.add_argument("--all", action="store_true", help="list 时包含 legacy 目录")
    p.add_argument("--json", action="store_true", help="list 输出 JSON")
    p.add_argument("--tag", default="")
    return p


def add_research_parser(subparsers, common=None):
    p = subparsers.add_parser(
        "research", parents=[common] if common is not None else [],
        help="主题调研/写作：大纲→查资料→事实库→写作→核查（SOP+门禁）")
    add_research_arguments(p)
    p.set_defaults(func=cmd_research)
    return p


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="research_cli",
                                description="独立 research CLI（无 hub/tunnel 依赖）")
    add_research_arguments(p)
    args = p.parse_args(argv)
    cmd_research(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
