"""P3: map a v0.5 local identity onto the main TAA core database.

The v0.5 identity remains the center-facing identity. The main core keeps its
existing agents/keys schema; this module creates idempotent mirror rows so the
local /app can use the same agent id.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import sqlite3
from pathlib import Path
from typing import Any

from .identity import IdentityState


def _now() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_core_identity(state: IdentityState, conn: sqlite3.Connection) -> dict[str, Any]:
    """Create/update core nodes, agents and keys for the v0.5 identity.

    It never writes the v0.5 key to disk outside the existing identity store;
    the key is encrypted with the core master key in the core keys table.
    """
    from core import security  # local import: keeps standalone v0.5 usable

    node_id = state.node.node_id
    center_owner_id = state.center.owner_id
    if not center_owner_id:
        raise ValueError("node is not connected to a center Owner")
    alias = f"v05-{node_id[-10:]}"
    node_row = conn.execute("SELECT id FROM nodes WHERE id=?", (node_id,)).fetchone()
    if node_row is None:
        conn.execute(
            "INSERT INTO nodes(id, hostname, alias, node_code, os, arch, is_main, last_seen) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (node_id, state.node.alias, alias, state.node.fingerprint_hash[:16],
             "", "", 0, _now()),
        )
    else:
        conn.execute(
            "UPDATE nodes SET hostname=?, last_seen=? WHERE id=?",
            (state.node.alias, _now(), node_id),
        )

    mapped: list[dict[str, Any]] = []
    for agent in state.agents:
        full_name = f"{agent.display_name}@{alias}"
        row = conn.execute("SELECT id FROM agents WHERE id=?", (agent.agent_id,)).fetchone()
        persona = {
            "id": agent.agent_id,
            "name": agent.display_name,
            "kind": "ai",
            "identity": {"avatar": "🤖"},
            "v05": {
                "owner_id": center_owner_id,
                "node_id": node_id,
                "center_owner_id": center_owner_id,
            },
        }
        if row is None:
            conn.execute(
                "INSERT INTO agents(id, name, kind, node_id, full_name, role, persona_json, status, last_seen) "
                "VALUES (?,?, 'ai', ?,?, 'executor', ?, 'active', ?)",
                (agent.agent_id, agent.display_name, node_id, full_name,
                 json.dumps(persona, ensure_ascii=False), _now()),
            )
        else:
            conn.execute(
                "UPDATE agents SET name=?, node_id=?, full_name=?, persona_json=?, status='active', last_seen=? "
                "WHERE id=?",
                (agent.display_name, node_id, full_name,
                 json.dumps(persona, ensure_ascii=False), _now(), agent.agent_id),
            )

        key_row = conn.execute(
            "SELECT key_id, key_hash FROM keys WHERE agent_id=? AND revoked_at IS NULL",
            (agent.agent_id,),
        ).fetchone()
        key_id = None
        if key_row is None:
            key_id = security.gen_key_id()
            conn.execute(
                "INSERT INTO keys(key_id, agent_id, key_hash, key_enc, label) VALUES (?,?,?,?,?)",
                (key_id, agent.agent_id,
                 security.hash_secret(agent.agent_key),
                 security.encrypt(agent.agent_key), "v05-bridge"),
            )
            key_id_out = key_id
        else:
            key_id = str(key_row["key_id"])
            key_id_out = key_id if security.hash_secret(agent.agent_key) == key_row["key_hash"] else None

        root = Path(__file__).resolve().parents[1]
        # Keep a local persona file so chatroom_agent can read the display
        # name / role and @alice can resolve to the v0.5 agent id.
        try:
            import yaml
            pdir = root / "agents" / agent.agent_id
            pdir.mkdir(parents=True, exist_ok=True)
            yp = pdir / "persona.yaml"
            if not yp.exists():
                yp.write_text(yaml.safe_dump({
                    "id": agent.agent_id, "name": agent.display_name,
                    "kind": "ai", "role": "executor",
                    "identity": {"avatar": "\U0001F916"},
                }, allow_unicode=True, sort_keys=False), encoding="utf-8")
        except Exception:
            pass

        # Local runtime needs the same plaintext key file as a bootstrapped
        # core agent. It is written only under the local app tree and only if
        # the existing core key hash matches the v0.5 key; never sent to center.
        if key_id_out:
            key_path = root / "agents" / agent.agent_id / ".key"
            key_path.parent.mkdir(parents=True, exist_ok=True)
            key_path.write_text(json.dumps(
                {"key_id": key_id_out, "key": agent.agent_key}, ensure_ascii=False),
                encoding="utf-8")
            try:
                os.chmod(key_path, 0o600)
            except OSError:
                pass

        mapped.append({"agent_id": agent.agent_id, "display_name": agent.display_name})

    conn.commit()
    return {
        "ok": True,
        "owner_id": center_owner_id,
        "center_owner_id": center_owner_id,
        "node_id": node_id,
        "agents": mapped,
    }
