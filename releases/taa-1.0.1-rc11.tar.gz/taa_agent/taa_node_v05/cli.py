"""Minimal CLI for the v0.5 identity/data-contract slice."""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

from .bundle import export_bundle, import_bundle
from .names import random_name
from .identity import (
    add_agent,
    init_identity,
    load_state,
    public_summary,
)
from .onboarding import connect, reset_owner_password
from .messaging import inbox as message_inbox, presence as owner_presence, send as message_send
from .sync import SyncConflict, plan_sync, sync_bundle
from .claim_ui import claim_with_browser, ide_bootstrap_prompt


def _home(value: str) -> pathlib.Path:
    return pathlib.Path(value).expanduser()


def cmd_init(args: argparse.Namespace) -> int:
    result = init_identity(
        _home(args.home),
        alias=args.alias,
        username=args.username,
        password=args.password,
        email=args.email or "",
        create_agent=not args.no_agent,
        agent_name=args.agent_name or random_name(),
    )
    print(json.dumps(public_summary(result.state), ensure_ascii=False, indent=2))
    print("identity=", _home(args.home) / "identity.json")
    print("No local Owner password is created; authenticate with the center.")
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    print(json.dumps(public_summary(load_state(_home(args.home))), ensure_ascii=False, indent=2))
    return 0


def cmd_add_agent(args: argparse.Namespace) -> int:
    state, agent = add_agent(_home(args.home), args.name)
    print(json.dumps({"ok": True, "agent": {"agent_id": agent.agent_id, "name": agent.display_name,
                                             "agent_key": agent.agent_key}}, ensure_ascii=False, indent=2))
    print("agent_key is stored locally; do not publish it.")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    result = export_bundle(_home(args.home), pathlib.Path(args.out).expanduser())
    print(json.dumps({"ok": True, "path": str(result.path),
                      "files": len(result.manifest.get("files") or []),
                      "contains_secrets": result.manifest.get("contains_secrets")},
                     ensure_ascii=False, indent=2))
    return 0


def cmd_import(args: argparse.Namespace) -> int:
    result = import_bundle(
        pathlib.Path(args.bundle).expanduser(),
        _home(args.home),
        keep_node_id=args.keep_node_id,
        rotate_agent_keys=args.rotate_agent_keys,
        alias=args.alias,
    )
    print(json.dumps({"ok": True, "home": str(result.destination),
                      "source_node_id": result.manifest.get("source_node_id"),
                      "new_node_id": result.state.node.node_id,
                      "agents": len(result.state.agents)},
                     ensure_ascii=False, indent=2))
    return 0


def cmd_connect(args: argparse.Namespace) -> int:
    result = connect(
        _home(args.home),
        base=args.base,
        username=args.username,
        password=args.password,
        create_owner=args.create_owner,
        email=args.email or "",
        register_agents=not args.no_agents,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_reset_owner_password(args: argparse.Namespace) -> int:
    result = reset_owner_password(_home(args.home), base=args.base, password=args.password)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_message_send(args: argparse.Namespace) -> int:
    result = message_send(_home(args.home), to_agent_id=args.to, body=args.body,
                          from_agent_id=args.from_agent or None)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_message_inbox(args: argparse.Namespace) -> int:
    result = message_inbox(_home(args.home), agent_id=args.agent or None)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_presence(args: argparse.Namespace) -> int:
    result = owner_presence(_home(args.home), username=args.username, password=args.password)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_bundle_plan(args: argparse.Namespace) -> int:
    result = plan_sync(pathlib.Path(args.bundle).expanduser(), _home(args.home) if args.home else None,
                       free_disk_gb=args.free_disk_gb,
                       budget_bytes=args.budget_mb * 1024 * 1024 if args.budget_mb else None,
                       max_asset_mb=args.max_asset_mb)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_bundle_sync(args: argparse.Namespace) -> int:
    try:
        result = sync_bundle(pathlib.Path(args.bundle).expanduser(), _home(args.home),
                             overwrite=args.overwrite,
                             free_disk_gb=args.free_disk_gb,
                             budget_bytes=args.budget_mb * 1024 * 1024 if args.budget_mb else None,
                             max_asset_mb=args.max_asset_mb)
    except SyncConflict as exc:
        print(json.dumps({"ok": False, "error": "conflicts", "conflicts": exc.conflicts},
                         ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({"ok": True, "copied": result.copied, "skipped": result.skipped},
                     ensure_ascii=False, indent=2))
    return 0


def cmd_claim_ui(args: argparse.Namespace) -> int:
    result = claim_with_browser(_home(args.home), base=args.base, lang=args.lang,
                                timeout=args.timeout, open_browser=not args.no_browser)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 1


def cmd_ide_prompt(args: argparse.Namespace) -> int:
    print(ide_bootstrap_prompt(_home(args.home), base=args.base))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="taa-node-v05")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init")
    p.add_argument("--home", required=True)
    p.add_argument("--alias", default=None)
    p.add_argument("--username", default=None)
    p.add_argument("--password", default=None)
    p.add_argument("--email", default=None)
    p.add_argument("--no-agent", action="store_true")
    p.add_argument("--agent-name", default=None)
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("show")
    p.add_argument("--home", required=True)
    p.set_defaults(func=cmd_show)
    p = sub.add_parser("agent-add")
    p.add_argument("--home", required=True)
    p.add_argument("--name", required=True)
    p.set_defaults(func=cmd_add_agent)
    p = sub.add_parser("connect")
    p.add_argument("--home", required=True)
    p.add_argument("--base", required=True)
    p.add_argument("--username", required=True)
    p.add_argument("--password", required=True)
    p.add_argument("--create-owner", action="store_true")
    p.add_argument("--email", default="")
    p.add_argument("--no-agents", action="store_true")
    p.set_defaults(func=cmd_connect)
    p = sub.add_parser("reset-owner-password")
    p.add_argument("--home", required=True)
    p.add_argument("--base", required=True)
    p.add_argument("--password", required=True)
    p.set_defaults(func=cmd_reset_owner_password)
    p = sub.add_parser("message-send")
    p.add_argument("--home", required=True)
    p.add_argument("--to", required=True)
    p.add_argument("--body", required=True)
    p.add_argument("--from-agent", default=None)
    p.set_defaults(func=cmd_message_send)
    p = sub.add_parser("message-inbox")
    p.add_argument("--home", required=True)
    p.add_argument("--agent", default=None)
    p.set_defaults(func=cmd_message_inbox)
    p = sub.add_parser("presence")
    p.add_argument("--home", required=True)
    p.add_argument("--username", required=True)
    p.add_argument("--password", required=True)
    p.set_defaults(func=cmd_presence)
    p = sub.add_parser("claim-ui")
    p.add_argument("--home", required=True)
    p.add_argument("--base", required=True)
    p.add_argument("--lang", choices=["zh-CN", "en"], default="zh-CN")
    p.add_argument("--timeout", type=int, default=180)
    p.add_argument("--no-browser", action="store_true")
    p.set_defaults(func=cmd_claim_ui)
    p = sub.add_parser("ide-prompt")
    p.add_argument("--home", required=True)
    p.add_argument("--base", default="https://alice.loomsci.com")
    p.set_defaults(func=cmd_ide_prompt)
    p = sub.add_parser("bundle-plan")
    p.add_argument("--bundle", required=True)
    p.add_argument("--home", default=None)
    p.add_argument("--free-disk-gb", type=float, default=None)
    p.add_argument("--budget-mb", type=int, default=None)
    p.add_argument("--max-asset-mb", type=int, default=64)
    p.set_defaults(func=cmd_bundle_plan)
    p = sub.add_parser("bundle-sync")
    p.add_argument("--bundle", required=True)
    p.add_argument("--home", required=True)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--free-disk-gb", type=float, default=None)
    p.add_argument("--budget-mb", type=int, default=None)
    p.add_argument("--max-asset-mb", type=int, default=64)
    p.set_defaults(func=cmd_bundle_sync)
    p = sub.add_parser("export")
    p.add_argument("--home", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_export)
    p = sub.add_parser("import")
    p.add_argument("--bundle", required=True)
    p.add_argument("--home", required=True)
    p.add_argument("--keep-node-id", action="store_true")
    p.add_argument("--rotate-agent-keys", action="store_true")
    p.add_argument("--alias", default=None)
    p.set_defaults(func=cmd_import)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
