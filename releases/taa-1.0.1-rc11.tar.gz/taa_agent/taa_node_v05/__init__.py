"""TAA Node Identity v0.5."""

__version__ = "0.5.2"


def product_version(home=None) -> str:
    """Read the installed TAA product version, not the identity schema version."""
    import os
    from pathlib import Path as _Path
    candidates = []
    h = _Path(home or os.environ.get("TAA_HOME") or "~/.taa").expanduser()
    candidates += [h / "app" / "VERSION", h / "VERSION"]
    here = _Path(__file__).resolve()
    candidates += [here.parents[1] / "VERSION", here.parents[1] / "dist" / "VERSION"]
    for path in candidates:
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value:
                return value
        except OSError:
            pass
    return "unknown"


def runtime_version(home=None) -> str:
    import os
    from pathlib import Path as _Path
    h = _Path(home or os.environ.get("TAA_HOME") or "~/.taa").expanduser()
    for path in (h / "app" / "dist" / "VERSION", h / "dist" / "VERSION"):
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value:
                return value
        except OSError:
            pass
    return "unknown"
