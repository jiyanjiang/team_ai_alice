"""X25519 + AES-GCM message envelopes.

Private keys are local-only. The center receives ciphertext envelopes and
public keys, never plaintext.
"""
from __future__ import annotations

import base64
import json
import os
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ENVELOPE_VERSION = 1


def b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def generate_keypair() -> tuple[str, str]:
    private = X25519PrivateKey.generate()
    private_raw = private.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return b64e(private_raw), b64e(public_raw)


def public_from_private(private_b64: str) -> str:
    private = X25519PrivateKey.from_private_bytes(b64d(private_b64))
    return b64e(private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    ))


def _derive(shared: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"taa-v05-mailbox",
        info=b"x25519-aesgcm",
    ).derive(shared)


def encrypt_for(recipient_public_b64: str, plaintext: str) -> dict[str, Any]:
    recipient = X25519PublicKey.from_public_bytes(b64d(recipient_public_b64))
    ephemeral = X25519PrivateKey.generate()
    shared = ephemeral.exchange(recipient)
    key = _derive(shared)
    nonce = os.urandom(12)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext.encode("utf-8"), None)
    ephemeral_public = ephemeral.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return {
        "v": ENVELOPE_VERSION,
        "alg": "x25519-aesgcm",
        "epk": b64e(ephemeral_public),
        "nonce": b64e(nonce),
        "ct": b64e(ciphertext),
    }


def decrypt(envelope: dict[str, Any] | str, recipient_private_b64: str) -> str:
    if isinstance(envelope, str):
        envelope = json.loads(envelope)
    if int(envelope.get("v") or 0) != ENVELOPE_VERSION or envelope.get("alg") != "x25519-aesgcm":
        raise ValueError("unsupported envelope")
    recipient = X25519PrivateKey.from_private_bytes(b64d(recipient_private_b64))
    ephemeral = X25519PublicKey.from_public_bytes(b64d(str(envelope["epk"])))
    shared = recipient.exchange(ephemeral)
    key = _derive(shared)
    plaintext = AESGCM(key).decrypt(b64d(str(envelope["nonce"])), b64d(str(envelope["ct"])), None)
    return plaintext.decode("utf-8")
