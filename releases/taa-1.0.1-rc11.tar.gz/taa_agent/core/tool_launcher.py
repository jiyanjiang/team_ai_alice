"""本地工具启动器：/app/tools。

中心 /tools 是工具市场；这里是本机默认工具 + 中心入口。
"""
from __future__ import annotations

import html
import json
import os
import pathlib
import tomllib

TAA_HOME = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
TOOLS = TAA_HOME / "tools"
CENTER_FALLBACK = "https://alice.loomsci.com"

# 首包只展示 weather + research；research 是 workflow，不是独立页面。
DEFAULT_TOOLS = [
    {
        "id": "weather",
        "name": "天气与穿搭",
        "kind": "tool",
        "version": "0.1.0",
        "desc": "查地点天气，并按本人衣柜/场景给出建议。",
        "check": "python cli/teamai.py weather --as <agent> --at 成都",
        "run": "python cli/teamai.py weather --as <agent> --at 成都",
    },
    {
        "id": "research.ask",
        "name": "主题调研",
        "kind": "workflow",
        "version": "0.1.0",
        "desc": "按七步调研流程做资料收集、事实库、写作与核查。",
        "check": "python cli/teamai.py research status <slug>",
        "run": "python cli/teamai.py research new <slug> --title \"主题\"",
    },
]


def esc(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _center_base() -> str:
    try:
        cfg = tomllib.loads((TAA_HOME / "config.toml").read_text(encoding="utf-8"))
        base = str((cfg.get("center") or {}).get("base") or "").rstrip("/")
        return base or CENTER_FALLBACK
    except Exception:
        return CENTER_FALLBACK


def _name(man: dict, locale: str = "zh-CN") -> str:
    n = man.get("name")
    if isinstance(n, dict):
        if locale == "en":
            return str(n.get("en") or n.get("zh") or man.get("id") or "")
        return str(n.get("zh") or n.get("en") or man.get("id") or "")
    return str(n or man.get("id") or "")


def _installed(locale: str = "zh-CN") -> list[dict]:
    out = []
    if not TOOLS.exists():
        return out
    for d in sorted(TOOLS.iterdir()):
        if not d.is_dir():
            continue
        try:
            man = json.loads((d / "manifest.json").read_text(encoding="utf-8"))
        except Exception:
            continue
        tid = str(man.get("id") or d.name)
        out.append({"id": tid, "name": _name(man, locale), "version": str(man.get("version") or ""),
                    "desc": str(man.get("description") or ""), "dir": str(d)})
    return out


def _cmd(tid: str) -> str:
    arg = '{"city":"成都"}' if tid == "alice.weather" else "{}"
    return f"taa tool run {tid} '{arg}'"


def _lcmd(cmd: str, label: str) -> str:
    return (f'<div class="lcmd"><code>{esc(cmd)}</code>'
            f'<button class="btn lcopy" type="button" data-copy="{esc(cmd)}">{esc(label)}</button></div>')


def page_tools(shell, tr, locale: str = "zh-CN") -> str:
    center = _center_base()
    tools = DEFAULT_TOOLS
    cards = "".join(
        f'<article class="ltool card"><div class="lthead"><b>{esc(t["name"])}</b>'
        f'<span class="tag">{esc(t.get("kind", "tool"))}</span>'
        f'<span class="tag">v{esc(t["version"])}</span></div>'
        f'<p>{esc(t["desc"] or t["id"])}</p>'
        f'{_lcmd(t["check"], tr("common.copy", "复制"))}'
        f'{_lcmd(t["run"], tr("common.copy", "复制"))}'
        f'<p class="dim">{esc(t["id"])}</p></article>' for t in tools)
    body = f"""
  <section class="card lhero">
    <div class="kicker">{tr("tools.local_kicker", "本地运行台")}</div>
    <h2>{tr("tools.local_title", "本地工具启动器")}</h2>
    <p class="dim">{tr("tools.local_sub", "中心负责市场与审核；本机负责安装、执行与文件。中心 /tools 才是工具市场。")}</p>
    <div class="lacts">
      <a class="btn primary" href="{esc(center)}/tools" target="_blank" rel="noopener">{tr("tools.open_market", "打开中心工具市场")} →</a>
      <a class="btn" href="{esc(center)}/tools?surface=online" target="_blank" rel="noopener">{tr("tools.open_online", "在线工具")}</a>
    </div>
  </section>
  <section class="card lsec">
    <div class="lhead"><h2>{tr("tools.installed", "本机已安装")}</h2><span class="dim">{len(tools)}</span></div>
    {cards or f'<p class="dim">{tr("tools.installed_empty", "本机还没有安装工具。先去中心工具市场安装。")}</p>'}
  </section>
  <style>
  .lhero{{padding:20px 22px;margin-bottom:12px}}
  .lhero h2{{margin:6px 0 6px}}
  .lacts{{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}}
  .lsec{{padding:18px 20px;margin-bottom:12px}}
  .lhead{{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}}
  .lhead h2{{font-size:18px;margin:0}}
  .ltool{{padding:14px 16px;margin-top:10px;box-shadow:none}}
  .lthead{{display:flex;align-items:center;gap:8px;justify-content:space-between}}
  .ltool p{{margin:6px 0;font-size:13.5px;color:var(--ink-soft)}}
  .lcmd{{display:flex;align-items:center;gap:8px;flex-wrap:wrap;background:var(--lace);border:1px solid var(--hair);border-radius:8px;padding:7px 9px;margin-top:6px}}
  .lcmd code{{flex:1 1 160px;min-width:0;font:12px/1.5 ui-monospace,Menlo,monospace;white-space:pre-wrap;overflow-wrap:anywhere}}
  .lcmd .lcopy{{flex:0 0 auto}}
  @media(max-width:520px){{.lhero{{padding:16px}}.lacts .btn{{width:100%;justify-content:center}}.ltool{{padding:12px}}.lcmd code{{flex-basis:100%}}}}
  </style>"""
    side = f'''<div class="sidebox"><div class="shead">{tr("tools.local_title", "本地工具启动器")}</div>
      <a class="citem" href="#installed">{tr("tools.installed", "本机已安装")}</a>
      <a class="citem" href="{esc(center)}/tools" target="_blank" rel="noopener">{tr("tools.open_market", "中心工具市场")} ↗</a>
      <a class="citem" href="{esc(center)}/tools?surface=online" target="_blank" rel="noopener">{tr("tools.open_online", "在线工具")} ↗</a></div>'''
    detail = f'''<div class="card" style="padding:16px 18px"><div class="kicker">{tr("tools.center", "中心入口")}</div>
      <p class="dim" style="margin:8px 0 0">{tr("tools.center_hint", "中心工具市场负责浏览、在线运行、提交与审核；本页只负责本机安装与运行。")}</p>
      <a class="btn" style="margin-top:12px" href="{esc(center)}/tools" target="_blank" rel="noopener">{tr("tools.open_market", "打开中心工具市场")} →</a></div>'''
    return shell(tr("tools.local_title", "本地工具启动器"), body, "tools",
                 tr("tools.local_sub", "本机安装与运行"), side=side, detail=detail)
