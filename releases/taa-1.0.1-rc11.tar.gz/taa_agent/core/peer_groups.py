"""P10.5c: sync center collab groups into the local owner/group tables.

The center remains the directory/source of group membership. This module does
not create a second center: it fetches a snapshot with an Owner session token
and upserts local ``collab_groups`` / ``collab_group_members`` rows. The token is
used only for the request and is never persisted.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request

from . import peer_grants


class GroupSyncError(ValueError):
    def __init__(self, msg: str, code: int = 502):
        super().__init__(msg)
        self.code = code


def _base(base: str) -> str:
    return (base or "").strip().rstrip("/")


def _get_json(url: str, token: str, timeout: int = 15) -> dict:
    if not token:
        raise GroupSyncError("owner_session_required", 401)
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + token,
        "accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise GroupSyncError(f"center_http_{exc.code}", exc.code) from exc
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        raise GroupSyncError(f"center_unreachable:{type(exc).__name__}", 502) from exc


def snapshot_from_center(base: str, owner_token: str, *, timeout: int = 15) -> dict:
    """Fetch groups + owner members without writing local state."""
    base = _base(base)
    groups = _get_json(base + "/v05/collab/groups", owner_token, timeout=timeout).get("groups") or []
    snap_groups = []
    for g in groups:
        gid = str(g.get("group_id") or "").strip()
        if not gid:
            continue
        detail = _get_json(base + "/v05/collab/groups/" + urllib.parse.quote(gid, safe=""),
                           owner_token, timeout=timeout)
        members = []
        for m in detail.get("members") or []:
            owner = str(m.get("owner_id") or "").strip()
            agent = str(m.get("agent_id") or "").strip()
            if owner and not agent:
                members.append({"owner_id": owner, "role": str(m.get("role") or "member")})
        snap_groups.append({"group_id": gid, "name": str(g.get("name") or gid),
                            "created_by": str(g.get("created_by") or ""), "members": members})
    return {"v": 1, "groups": snap_groups}


def import_snapshot(conn, snapshot: dict) -> dict:
    """Upsert a center snapshot into local collab group tables."""
    peer_grants.ensure(conn)
    added = {"groups": 0, "members": 0}
    for g in snapshot.get("groups") or []:
        gid = str(g.get("group_id") or "").strip()
        if not gid:
            continue
        cur = conn.execute(
            "INSERT INTO collab_groups(group_id,name,created_by) VALUES(?,?,?) "
            "ON CONFLICT(group_id) DO UPDATE SET name=excluded.name",
            (gid[:80], str(g.get("name") or gid)[:120], str(g.get("created_by") or "")[:80]))
        added["groups"] += int(cur.rowcount > 0)
        creator = str(g.get("created_by") or "").strip()
        if creator:
            conn.execute("INSERT OR IGNORE INTO collab_group_members(group_id,owner_id,role,added_by) "
                         "VALUES(?,?, 'owner', ?)", (gid[:80], creator[:80], creator[:80]))
            added["members"] += 1
        for m in g.get("members") or []:
            oid = str(m.get("owner_id") or "").strip()
            if not oid:
                continue
            role = str(m.get("role") or "member")
            if role not in ("owner", "member"):
                role = "member"
            conn.execute("INSERT OR IGNORE INTO collab_group_members(group_id,owner_id,role,added_by) "
                         "VALUES(?,?,?,?)", (gid[:80], oid[:80], role, creator[:80] or oid[:80]))
            added["members"] += 1
    conn.commit()
    return {"ok": True, "added": added}


def sync_from_center(conn, base: str, owner_token: str, *, timeout: int = 15) -> dict:
    snap = snapshot_from_center(base, owner_token, timeout=timeout)
    res = import_snapshot(conn, snap)
    return {**res, "groups": len(snap.get("groups") or []), "snapshot": snap}


def sync_from_env(conn) -> dict:
    """Use TAA_CENTER_BASE + TAA_OWNER_SESSION for the local sync button.

    The session is read from the process environment, never from the browser
    form and never written into the HTML/DB.
    """
    base = (os.environ.get("TAA_CENTER_BASE") or "").strip()
    token = (os.environ.get("TAA_OWNER_SESSION") or "").strip()
    if not base or not token:
        raise GroupSyncError("center_session_not_configured", 503)
    res = sync_from_center(conn, base, token)
    return {**res, "base": base}
