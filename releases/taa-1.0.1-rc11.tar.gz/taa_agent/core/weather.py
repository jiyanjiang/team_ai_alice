"""weather —— 天气 + 穿搭建议（**地点不固定**）。

链路（Owner 指定）：**地点 → 经纬度 → 当天该地天气 → 按本人衣柜/性别给出穿搭建议**。

- 数据源（多源降级，全部免密钥）：
  1) 地名解析：Open-Meteo geocoding → Nominatim（OpenStreetMap）；
  2) 天气：Open-Meteo forecast → wttr.in → MET Norway（api.met.no）。
  任一源成功即返回，`source` 字段标明实际来源；全部失败才抛错并在 `last_errors()` 留痕。
- 衣柜：读 `agents/<id>/persona.yaml` 的 `wardrobe`（颗粒度见 docs/64；参考 soul 项目 wardrobe.json）。
- **纯函数 `recommend()`** 与网络解耦，可离线单测。
"""
from __future__ import annotations

import json
import os
import re
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GEOCODE_API = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_API = "https://api.open-meteo.com/v1/forecast"
NOMINATIM_API = "https://nominatim.openstreetmap.org/search"
WTTR_API = "https://wttr.in"
METNO_API = "https://api.met.no/weatherapi/locationforecast/2.0/compact"
UA = "teamai-weather/1.1"

# WMO 天气代码 → 文案
WMO = {
    0: "☀️ 晴朗", 1: "🌤️ 基本晴朗", 2: "⛅ 部分多云", 3: "☁️ 阴天",
    45: "🌫️ 雾", 48: "🌫️ 雾凇",
    51: "🌦️ 轻微毛毛雨", 53: "🌦️ 中等毛毛雨", 55: "🌧️ 浓密毛毛雨",
    61: "🌧️ 轻微降雨", 63: "🌧️ 中等降雨", 65: "🌧️ 强降雨",
    66: "🌧️ 冻雨", 67: "🌧️ 强冻雨",
    71: "🌨️ 轻微降雪", 73: "🌨️ 中等降雪", 75: "❄️ 强降雪", 77: "🌨️ 雪粒",
    80: "🌦️ 轻微阵雨", 81: "🌦️ 中等阵雨", 82: "⛈️ 强阵雨",
    85: "🌨️ 阵雪", 86: "❄️ 强阵雪",
    95: "⛈️ 雷暴", 96: "⛈️ 雷暴伴冰雹", 99: "⛈️ 强雷暴伴冰雹",
}


def wmo_desc(code) -> str:
    try:
        return WMO.get(int(code), f"未知({code})")
    except (TypeError, ValueError):
        return "未知"


def wmo_category(code) -> str:
    """归为 sunny / cloudy / rainy / snowy，供衣柜规则匹配。"""
    try:
        c = int(code)
    except (TypeError, ValueError):
        return "cloudy"
    if c in (0, 1):
        return "sunny"
    if c in (2, 3, 45, 48):
        return "cloudy"
    if c in (71, 73, 75, 77, 85, 86):
        return "snowy"
    if 51 <= c <= 67 or 80 <= c <= 82 or c >= 95:
        return "rainy"
    return "cloudy"


def _get(url: str, params: dict, timeout: float = 12.0, headers: dict | None = None):
    """带 UA 的 GET → JSON。`headers` 供个别源覆盖 UA（Nominatim / MET Norway 有此要求）。"""
    q = urllib.parse.urlencode(params or {})
    h = {"User-Agent": UA}
    h.update(headers or {})
    req = urllib.request.Request(f"{url}?{q}" if q else url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


#: 最近一次多源降级的失败明细（诊断用，不参与业务判断）
_LAST_ERRORS: dict[str, list[str]] = {}


def last_errors() -> dict[str, list[str]]:
    """各数据源最近一次的失败原因，便于回答「为什么降级了/为什么全失败」。"""
    return {k: list(v) for k, v in _LAST_ERRORS.items()}


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _build_forecast(cur: dict, daily: list[dict], timezone: str) -> dict:
    """把各源的解析结果统一成 `forecast()` 的返回结构（保证下游无感知）。"""
    d0 = daily[0] if daily else {}
    code = cur.get("code")
    if code is None:
        code = d0.get("code")
    return {
        "temp": cur.get("temp"),
        "feels": cur.get("feels"),
        "humidity": cur.get("humidity"),
        "wind": cur.get("wind"),
        "code": code,
        "desc": wmo_desc(code),
        "cat": wmo_category(code),
        "t_max": d0.get("t_max"),
        "t_min": d0.get("t_min"),
        "precip_prob": d0.get("precip_prob"),
        "day_code": d0.get("code"),
        "daily": daily,
        "timezone": timezone or "auto",
    }


# ------------------------------------------------------------------ 地名解析（多源）
def _geo_open_meteo(place: str) -> dict | None:
    d = _get(GEOCODE_API, {"name": place, "count": 1, "language": "zh", "format": "json"})
    rs = d.get("results") or []
    if not rs:
        return None
    r = rs[0]
    return {"name": r.get("name"), "country": r.get("country"), "admin1": r.get("admin1"),
            "lat": r.get("latitude"), "lon": r.get("longitude"), "timezone": r.get("timezone")}


def _geo_nominatim(place: str) -> dict | None:
    """备用源：OpenStreetMap Nominatim（免密钥；要求可识别 UA，禁止高频调用）。"""
    d = _get(NOMINATIM_API, {"q": place, "format": "jsonv2", "limit": 1,
                             "accept-language": "zh-CN,zh,en"},
             headers={"User-Agent": UA + " (weather geocoding fallback)"})
    rs = d if isinstance(d, list) else []
    if not rs:
        return None
    r = rs[0] or {}
    lat, lon = _num(r.get("lat")), _num(r.get("lon"))
    if lat is None or lon is None:
        return None
    addr = r.get("address") or {}
    name = str(r.get("name") or addr.get("city") or addr.get("town")
               or addr.get("county") or addr.get("state") or place).strip()
    return {"name": name, "country": addr.get("country"), "admin1": addr.get("state"),
            "lat": lat, "lon": lon, "timezone": None}


def geocode(place: str) -> dict | None:
    """地点 → 经纬度（最匹配一条）。多源降级：Open-Meteo → Nominatim/OSM。

    区分两种失败：所有源都「查无此地」→ 返回 None；所有源都请求失败 →
    抛 RuntimeError（带上各源原因），上层才能分别提示。
    """
    place = str(place or "").strip()
    if not place:
        return None
    errors: list[str] = []
    reachable = False
    for name, fn in (("open-meteo", _geo_open_meteo), ("nominatim", _geo_nominatim)):
        try:
            r = fn(place)
            reachable = True
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{name}: {type(exc).__name__} {str(exc)[:100]}")
            continue
        if r and r.get("lat") is not None and r.get("lon") is not None:
            r["source"] = name
            _LAST_ERRORS["geocode"] = errors
            return r
        errors.append(f"{name}: 无匹配结果")
    _LAST_ERRORS["geocode"] = errors
    if not reachable:
        raise RuntimeError("地点解析失败（所有数据源均不可用）：" + " | ".join(errors))
    return None


# ------------------------------------------------------------------ 天气（多源）
def _forecast_open_meteo(lat: float, lon: float, timezone: str, days: int) -> dict:
    d = _get(FORECAST_API, {
        "latitude": lat, "longitude": lon, "timezone": timezone or "auto",
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weathercode,windspeed_10m",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode",
        "forecast_days": days,
    })
    cur = d.get("current") or {}
    day = d.get("daily") or {}

    def _at(k, i=0):
        v = day.get(k) or []
        return v[i] if i < len(v) else None

    dates = day.get("time") or []
    daily = [{"date": dates[i],
              "code": _at("weathercode", i), "desc": wmo_desc(_at("weathercode", i)),
              "cat": wmo_category(_at("weathercode", i)),
              "t_max": _at("temperature_2m_max", i), "t_min": _at("temperature_2m_min", i),
              "precip_prob": _at("precipitation_probability_max", i)}
             for i in range(len(dates))]
    return {
        "temp": cur.get("temperature_2m"),
        "feels": cur.get("apparent_temperature"),
        "humidity": cur.get("relative_humidity_2m"),
        "wind": cur.get("windspeed_10m"),
        "code": cur.get("weathercode"),
        "desc": wmo_desc(cur.get("weathercode")),
        "cat": wmo_category(cur.get("weathercode")),
        "t_max": _at("temperature_2m_max"),
        "t_min": _at("temperature_2m_min"),
        "precip_prob": _at("precipitation_probability_max"),
        "day_code": _at("weathercode"),
        "daily": daily,
        "timezone": d.get("timezone"),
    }


#: wttr.in（WWO 代码）→ 本项目使用的 WMO 代码
_WWO_TO_WMO = {
    113: 0, 116: 2, 119: 3, 122: 3, 143: 45, 248: 45, 260: 48,
    176: 80, 179: 71, 182: 73, 185: 66, 200: 95,
    227: 71, 230: 75, 263: 51, 266: 51, 281: 66, 284: 67,
    293: 61, 296: 61, 299: 63, 302: 63, 305: 65, 308: 65, 311: 66, 314: 67,
    317: 71, 320: 73, 323: 71, 326: 73, 329: 75, 332: 75, 335: 75, 338: 75,
    350: 77, 353: 80, 356: 81, 359: 82, 362: 66, 365: 67, 368: 73, 371: 75,
    374: 77, 377: 77, 386: 95, 389: 95, 392: 95, 395: 75,
}


def _wttr_code(v):
    """wttr 的 WWO 代码 → WMO；本身就是 WMO（0–99）时原样保留。"""
    try:
        c = int(v)
    except (TypeError, ValueError):
        return None
    if c in _WWO_TO_WMO:
        return _WWO_TO_WMO[c]
    return c if 0 <= c <= 99 else None


def _forecast_wttr(lat: float, lon: float, timezone: str, days: int) -> dict:
    """第 2 源：wttr.in（坐标直查；免密钥，返回 WWO 代码需换算）。"""
    d = _get(f"{WTTR_API}/{lat},{lon}", {"format": "j1", "lang": "zh"})
    if not isinstance(d, dict):
        raise ValueError("wttr.in 响应格式异常")
    cur = (d.get("current_condition") or [{}])[0]
    daily = []
    for dd in (d.get("weather") or [])[:max(1, days)]:
        hourly = dd.get("hourly") or []
        biggest = next((h for h in hourly if str(h.get("time")) in ("1200", "1500")),
                       hourly[0] if hourly else {})
        code = _wttr_code(biggest.get("weatherCode"))
        probs = [p for p in (_num(h.get("chanceofrain")) for h in hourly) if p is not None]
        daily.append({"date": dd.get("date"), "code": code, "desc": wmo_desc(code),
                      "cat": wmo_category(code),
                      "t_max": _num(dd.get("maxtempC")), "t_min": _num(dd.get("mintempC")),
                      "precip_prob": max(probs) if probs else None})
    return _build_forecast({
        "temp": _num(cur.get("temp_C")), "feels": _num(cur.get("FeelsLikeC")),
        "humidity": _num(cur.get("humidity")), "wind": _num(cur.get("windspeedKmph")),
        "code": _wttr_code(cur.get("weatherCode")),
    }, daily, timezone)


#: MET Norway symbol_code → WMO（前缀匹配，忽略 _day/_night 后缀）
_SYMBOL_TO_WMO = {
    "clearsky": 0, "fair": 1, "partlycloudy": 2, "cloudy": 3, "fog": 45,
    "lightrain": 61, "rain": 63, "heavyrain": 65,
    "lightrainshowers": 80, "rainshowers": 81, "heavyrainshowers": 82,
    "lightsleet": 66, "sleet": 66, "heavysleet": 67,
    "lightsnow": 71, "snow": 73, "heavysnow": 75,
    "lightsnowshowers": 71, "snowshowers": 73, "heavysnowshowers": 75,
    "rainandthunder": 95, "sleetandthunder": 95, "snowandthunder": 95,
    "lightrainandthunder": 95, "partlycloudyandthunder": 95, "cloudyandthunder": 95,
}


def _symbol_to_wmo(sym) -> int | None:
    key = str(sym or "").lower().split("_")[0]
    if not key:
        return None
    if key in _SYMBOL_TO_WMO:
        return _SYMBOL_TO_WMO[key]
    if "thunder" in key:
        return 95
    if "snow" in key:
        return 73
    if "sleet" in key:
        return 66
    if "rain" in key:
        return 63
    if "fog" in key:
        return 45
    if "cloud" in key:
        return 3
    if "clear" in key or "fair" in key:
        return 1
    return None


def _forecast_metno(lat: float, lon: float, timezone: str, days: int) -> dict:
    """第 3 源：MET Norway（免费；要求可识别 UA；风速 m/s，统一换算为 km/h）。"""
    from datetime import datetime as _dt

    d = _get(METNO_API, {"lat": round(float(lat), 4), "lon": round(float(lon), 4)},
             headers={"User-Agent": UA + " (teamai weather fallback)"})
    series = (((d or {}).get("properties") or {}).get("timeseries")) or []
    if not series:
        raise ValueError("met.no 无 timeseries")

    tzinfo = None
    try:
        from zoneinfo import ZoneInfo
        if timezone and timezone not in ("auto", ""):
            tzinfo = ZoneInfo(timezone)
    except Exception:  # noqa: BLE001
        tzinfo = None

    rows = []
    for item in series:
        try:
            when = _dt.fromisoformat(str(item.get("time") or "").replace("Z", "+00:00"))
        except ValueError:
            continue
        data = item.get("data") or {}
        det = (data.get("instant") or {}).get("details") or {}
        sym = ((data.get("next_1_hours") or {}).get("summary") or {}).get("symbol_code")
        rows.append((when.astimezone(tzinfo) if tzinfo else when, det, str(sym or "")))
    if not rows:
        raise ValueError("met.no 时间序列不可解析")

    grouped: dict[str, list] = {}
    for when, det, sym in rows:
        grouped.setdefault(when.date().isoformat(), []).append((when.hour, det, sym))

    daily = []
    for key in sorted(grouped)[:max(1, days)]:
        rr = grouped[key]
        temps = [t for t in (_num(det.get("air_temperature")) for _, det, _ in rr) if t is not None]
        _, _, noon_sym = min(rr, key=lambda x: abs(x[0] - 12))
        code = _symbol_to_wmo(noon_sym)
        daily.append({"date": key, "code": code, "desc": wmo_desc(code), "cat": wmo_category(code),
                      "t_max": max(temps) if temps else None,
                      "t_min": min(temps) if temps else None,
                      "precip_prob": None})

    det0 = rows[0][1]
    wind = _num(det0.get("wind_speed"))
    return _build_forecast({
        "temp": _num(det0.get("air_temperature")),
        "feels": None,
        "humidity": _num(det0.get("relative_humidity")),
        "wind": round(wind * 3.6, 1) if wind is not None else None,
        "code": _symbol_to_wmo(rows[0][2]),
    }, daily, timezone)


def forecast(lat: float, lon: float, timezone: str = "auto", days: int = 1) -> dict:
    """取「当前 + 今日（可选 N 日）」天气。days>1 时附 `daily` 列表。

    多源降级：Open-Meteo → wttr.in → MET Norway。任一源返回可用数据即止，
    返回值的 `source` 标明实际来源；全部不可用才抛 RuntimeError（附各源原因）。
    """
    days = max(1, min(int(days or 1), 14))
    errors: list[str] = []
    for name, fn in (("open-meteo", _forecast_open_meteo),
                     ("wttr.in", _forecast_wttr),
                     ("met.no", _forecast_metno)):
        try:
            d = fn(lat, lon, timezone or "auto", days)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{name}: {type(exc).__name__} {str(exc)[:100]}")
            continue
        if not d or (d.get("temp") is None and d.get("t_max") is None):
            errors.append(f"{name}: 返回空数据")
            continue
        d["source"] = name
        _LAST_ERRORS["forecast"] = errors
        return d
    _LAST_ERRORS["forecast"] = errors
    raise RuntimeError("天气获取失败（所有数据源均不可用）：" + " | ".join(errors))


# ------------------------------------------------------------------ 穿搭（纯函数）
def _items(wardrobe: dict) -> dict:
    """只取**非私密**单品：`private: true` 的（如贴身衣物）**永不**出现在建议/输出里。"""
    it = wardrobe.get("items") or {}
    return {k: [x for x in (v or []) if not (isinstance(x, dict) and x.get("private"))]
            for k, v in it.items()}


def _fits(item: dict, temp: float, cat: str) -> bool:
    rng = item.get("temperature_range")
    if isinstance(rng, (list, tuple)) and len(rng) == 2:
        lo, hi = float(rng[0]), float(rng[1])
        if not (lo - 3 <= temp <= hi + 3):
            return False
    return True


#: 场景 → (中文名, 适配场合关键词, 提示)
SCENES: dict[str, tuple] = {
    "commute": ("通勤", ["办公", "正式", "评审", "外出"], "通勤：优先得体、好走的鞋；外套便于穿脱"),
    "outdoor": ("户外", ["运动", "外出", "休闲"], "户外：防晒/防风/防水、浅色耐脏，备帽"),
    "formal": ("正式", ["正式", "评审", "办公"], "正式：成套素色、无 logo"),
    "home": ("居家", ["居家", "休闲"], "居家：棉质、宽松"),
    "sport": ("运动", ["运动", "健身"], "运动：速干透气"),
}

#: 无衣柜时的通用建议（按温度带）
_GENERIC = [
    (28, ["透气浅色短袖/衬衫", "短裤或薄长裤", "帽子 / 防晒"]),
    (22, ["长袖衬衫或薄针织", "长裤或及踝长裙"]),
    (16, ["薄毛衣 + 长裤", "可备薄外套"]),
    (8, ["针织衫 + 长裤 + 外套", "围巾"]),
    (-99, ["厚毛衣 + 保暖内层 + 大衣 / 羽绒", "帽 / 围巾 / 手套"]),
]


def _generic(temp: float, cat: str) -> list[str]:
    out = list(next(v for lo, v in _GENERIC if temp >= lo))
    if cat == "rainy":
        out.append("带伞；鞋选防水")
    if cat == "snowy":
        out.append("防滑鞋")
    return out


#: 实际天气源 → 展示名（多源降级后不能把来源写死成 Open-Meteo）
_SRC_NAME = {"open-meteo": "Open-Meteo", "wttr.in": "wttr.in", "met.no": "MET Norway"}


def _src_name(weather: dict) -> str:
    return _SRC_NAME.get(str(weather.get("source") or "").lower(), "天气源")


def recommend(weather: dict, wardrobe: dict, gender: str | None = None,
              scene: str | None = None) -> dict:
    """按天气 + 本人衣柜给出穿搭建议（不调 LLM，纯规则 + 衣柜数据）。"""
    temp = weather.get("temp")
    if temp is None:
        temp = (weather.get("t_max") or 20)
    temp = float(temp)
    cat = weather.get("cat") or "cloudy"
    items = _items(wardrobe)
    gender = (gender or "").lower()
    scene = (scene or "").strip().lower() or None
    scene_meta = SCENES.get(scene) if scene else None

    if not any(items.values()):            # 衣柜未建 → 通用建议（不臆造个人风格）
        return {"outfit": [], "generic": _generic(temp, cat),
                "notes": ["本机衣柜未建：以下是**通用**建议；建好 `persona.wardrobe` 后按你的风格推荐"],
                "basis": {"temp": temp, "cat": cat, "desc": weather.get("desc"), "scene": scene},
                "source": f"{_src_name(weather)}（通用档）"}

    allow_dress = gender in ("female", "f", "woman", "女") and bool(items.get("dresses"))
    occ_pref = scene_meta[1] if scene_meta else []

    def _scene_key(x):
        occ = x.get("occasion") or []
        return 0 if any(o in occ for o in occ_pref) else 1

    def pick(kind: str, n: int = 1):
        cand = [x for x in items.get(kind, []) if _fits(x, temp, cat)]
        if occ_pref:
            cand = sorted(cand, key=_scene_key)
        return cand[:n]

    def nearest(kind: str):
        """严格过滤为空时的兜底：取温度区间离当前最近的一件。"""
        cand = items.get(kind, []) or []
        if not cand:
            return []
        def dist(x):
            rng = x.get("temperature_range")
            if isinstance(rng, (list, tuple)) and len(rng) == 2:
                lo, hi = float(rng[0]), float(rng[1])
                return 0 if lo <= temp <= hi else min(abs(temp - lo), abs(temp - hi))
            return 999
        return sorted(cand, key=dist)[:1]

    picks: list[dict] = []
    # 极热/极冷 → 连衣裙优先（女）
    if allow_dress and temp >= 22:
        picks += pick("dresses")
    if not any(p.get("type") == "连衣裙" for p in picks):
        picks += pick("tops")
        picks += pick("bottoms")
    if temp < 18:                         # 天冷才加外层
        picks += pick("outerwear", 1)
    # 兜底：确保有内搭（上装或连衣裙）+ 下装（极端温度也不至于只剩外套）
    if not any(p.get("type") in ("上装", "连衣裙") for p in picks):
        picks += nearest("tops")
    if not any(p.get("type") in ("长裤", "半身裙", "短裤", "运动裤", "连衣裙") for p in picks):
        picks += nearest("bottoms")
    # 配饰（鞋/发饰/信物）：不限温
    picks += (items.get("accessories") or [])[:2]

    # 规则兜底（wardrobe.outfit_rules.weather_based）
    rules = ((wardrobe.get("outfit_rules") or {}).get("weather_based") or {})
    rule_hit = None
    for band in (rules.get(cat) or {}).values():
        rng = band.get("range") or []
        if len(rng) == 2 and rng[0] - 3 <= temp <= rng[1] + 3:
            rule_hit = band
            break
    if not picks and rule_hit:
        idx = {x.get("id"): x for k in items for x in items[k]}
        picks = [idx[i] for i in (rule_hit.get("recommend") or []) if i in idx]

    # 去重
    seen, uniq = set(), []
    for p in picks:
        pid = p.get("id") or p.get("name")
        if pid in seen:
            continue
        seen.add(pid)
        uniq.append(p)

    rain = cat == "rainy"
    snow = cat == "snowy"
    notes = []
    if rain:
        notes.append("有降水：带伞，鞋选防水/深色，外层选易干的")
    if snow:
        notes.append("有雪：保暖优先，鞋要防滑")
    if temp >= 28:
        notes.append("偏热：选透气浅色，备防晒")
    if temp <= 8:
        notes.append("偏冷：加保暖内层与围巾/外套")
    if (weather.get("wind") or 0) and float(weather["wind"]) >= 25:
        notes.append("风大：外层要挡风")
    if scene_meta:
        notes.append(scene_meta[2])

    return {
        "outfit": [{"name": p.get("name"), "type": p.get("type"), "color": p.get("color"),
                    "style": p.get("style")} for p in uniq],
        "notes": notes,
        "basis": {"temp": temp, "feels": weather.get("feels"), "cat": cat,
                  "desc": weather.get("desc"), "scene": scene},
        "source": f"本机衣柜（persona.wardrobe）+ {_src_name(weather)}",
    }


def center_geo(base: str | None = None) -> dict | None:
    """Read the center's Cloudflare request city. Never invent a city."""
    base = (base or os.environ.get("TAA_CENTER_URL") or os.environ.get("TEAMAI_URL") or "").rstrip("/")
    if not base:
        # Installed TAA: use the user's configured center, not a hardcoded host.
        try:
            from .center_sync import _cfg
            base = _cfg()[0].rstrip("/")
        except Exception:  # noqa: BLE001
            base = ""
    if not base:
        return None
    try:
        d = _get(base + "/geo/suggest", {}, timeout=5)
    except Exception:  # noqa: BLE001
        return None
    if not d.get("ok") or not d.get("city"):
        return None
    return {
        "city": str(d.get("city") or "").strip(),
        "region": str(d.get("region") or "").strip(),
        "country": str(d.get("country") or "").strip(),
        "timezone": str(d.get("timezone") or "").strip(),
        "label": str(d.get("label") or d.get("city") or "").strip(),
    }


#: 场景 → 画面背景（给生图用，避免默认灰底影棚）
#: 刻意避开店铺/招牌/广告牌：万相会在这些载体上写中文，且大概率是乱码。
_SCENE_BG = {
    "commute": "写字楼之间的人行道，玻璃幕墙与行道树",
    "outdoor": "公园步道，两侧是树与草地，远处开阔天空",
    "formal": "办公楼外的石材广场，落地窗与绿植",
    "home": "采光良好的客厅，木地板与织物沙发",
    "sport": "河边跑道，护栏、树与远处水面",
}

#: 天气 → 光线（决定画面的时间感）
_WEATHER_LIGHT = {
    "sunny": "午后侧逆光，影子清晰，空气通透",
    "clear": "午后侧逆光，影子清晰，空气通透",
    "cloudy": "阴天柔和散射光，色调偏冷，没有硬阴影",
    "overcast": "阴天柔和散射光，色调偏冷，没有硬阴影",
    "rainy": "雨天地面湿润反光，远处有薄雾",
    "snowy": "雪后散射光，空气清冷，地面泛白",
    "foggy": "薄雾弥漫，远处景物层次递减",
}


def _resolve_agent(agent_id: str) -> str:
    """把「名字」解析成真实 agent id。

    安装实例的目录名是 agt_xxx，而工具/CLI 默认传 "alice"。直接查目录会落空，
    于是 gender 取不到、天气图生成成男性（2026-11-01 实测的根因之一）。
    这里在找不到同名目录时，按 persona.name 反查一次。
    """
    aid = str(agent_id or "").strip()
    if not aid:
        return aid
    try:
        from core import persona as P
        if (P.agent_dir(aid) / "persona.yaml").is_file():
            return aid
        want = aid.lower()
        cands: list[tuple[bool, bool, float, str]] = []
        for d in P.AGENTS_DIR.iterdir():
            f = d / "persona.yaml"
            if not f.is_file():
                continue
            try:
                import yaml
                doc = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
            except Exception:  # noqa: BLE001
                continue
            name = str(doc.get("name") or "").strip()
            if name.lower() != want and str(doc.get("id") or "") != aid:
                continue
            # 数据库对 lower(name) 有唯一约束，磁盘却可能留下注册失败的空目录
            # （2026-10-25 实测有一条 86 字节的孤儿 alice）。用「是否有工作区/守则」
            # 把完整 agent 排在前面，再比性别字段与修改时间。
            complete = (d / "AGENTS.md").is_file() or (d / "workspace").is_dir()
            has_gender = bool(str((doc.get("identity") or {}).get("gender") or "").strip())
            cands.append((complete, has_gender, f.stat().st_mtime, d.name))
        if cands:
            cands.sort(reverse=True)
            return cands[0][3]
    except Exception:  # noqa: BLE001
        pass
    return aid


def _clean_desc(s) -> str:
    """天气描述常带 emoji（如 "☁️ 阴天"）；emoji 进提示词会干扰模型，清掉。"""
    t = str(s or "").strip()
    if not t:
        return ""
    out = "".join(ch for ch in t
                  if not (0x1F000 <= ord(ch) <= 0x1FAFF
                          or 0x2600 <= ord(ch) <= 0x27BF
                          or ord(ch) in (0xFE0F, 0x20E3)))
    return out.strip(" ，,、")


#: 人像描述开头的「镜头框定语」：Close-up portrait of / headshot / selfie…
#: 这类词会把画面往特写上拽，与「街拍中景」场景提示互斥（2026-11-01 A/B 实测：
#: 去掉后走动姿态与纵深街景明显更自然），故消费端一律剥离。
_FRAMING = re.compile(
    r"^\s*(?:(?:a|an|the)\s+)?(?:close[- ]?up|headshot|portrait|selfie|face shot|"
    r"profile photo|full[- ]body (?:photo|shot|portrait))\s*(?:photo|shot|image|picture)?\s*(?:of|:)?\s*",
    re.I)


def _strip_framing(text: str) -> str:
    """去掉「特写/肖像」框定语，只保留人物描述本身。"""
    t = str(text or "").strip()
    out = _FRAMING.sub("", t).strip()
    if out and out != t:
        out = out[0].upper() + out[1:]
    return out


def _clip_face(text: str, limit: int = 260) -> str:
    """人像描述按句截到 `limit` 字符内。

    实测（2026-11-01，ark，同场景 4 臂对比）：人像描述 733 字符时构图偏摆拍、
    玻璃上还多出海报；572 字符（核心 200 字 + 体型/发型）最自然。故缺省 260。
    多出来的细节不但没用，还会把「场景/穿搭/姿态」挤出模型 prompt 上限。
    """
    t = " ".join(str(text or "").split())
    if len(t) <= limit:
        return t
    cur = ""
    for seg in re.split(r"(?<=[.;。；])\s*", t):
        if not seg:
            continue
        if len(cur) + len(seg) + 1 > limit:
            break
        cur = f"{cur} {seg}".strip()
    return cur or t[:limit]


def image_prompt(loc: dict, weather: dict, advice: dict, gender: str | None = None,
                 scene: str | None = None, body: dict | None = None,
                 scene_ctx: dict | None = None, face_limit: int | None = None) -> str:
    """构建天气穿搭图提示词。

    2026-11-01 重写。旧版只有一个泛指的 "a person"，导致：
      · 性别随机（Alice 是女性却生成男性）；
      · 没有场景，模型退回灰底影棚；
      · 只有弱约束 "no text"，阿里万相仍会自行加中文标题，且是乱码。

    新版显式给出：主体（性别/年龄段/体型）、场景与光线、抓拍姿态，
    并把「不得出现任何文字」写成强约束；同时在 negative_prompt 里再压一遍。

    人物一致性：`body.face_prompt`（稳定人像描述）优先；缺失才用 `body.appearance`。
    """
    place = loc.get("name") or loc.get("label") or "city"
    items = " / ".join(o.get("name", "") for o in (advice.get("outfit") or []) if o.get("name"))
    generic = " / ".join(advice.get("generic") or [])
    wearing = items or generic or "适合当季的日常服装"

    g = (gender or "").strip().lower()
    if g in ("female", "f", "woman", "女", "她"):
        subject = "一位女性"
    elif g in ("male", "m", "man", "男", "他"):
        subject = "一位男性"
    else:
        subject = "一位青年"

    b = body or {}
    age = b.get("age")
    build = str(b.get("build") or "").strip()
    # 人物一致性：有 body.face_prompt 就用它（同一人多次出图长相稳定），
    # 没有才退回 body.appearance 的简短外形描述（老档案不迁移也能用）。
    # 1) 剥离「特写/肖像」框定语（会把街景拽成人像特写）；
    # 2) 按句截断（模型 prompt 有上限，人像描述不能挤掉场景/穿搭）。
    raw_face = _strip_framing(str(b.get("face_prompt") or "").strip())
    face = _clip_face(raw_face, face_limit or 260).rstrip(";；。 ")
    look = face or str(b.get("appearance") or "").strip().rstrip("。")
    who = subject
    if age:
        who += f"，约 {age} 岁"
    if build:
        who += f"，{build}"
    if look:
        who += f"，{look}"

    ctx = scene_ctx or {}
    cat = str(weather.get("cat") or "").lower()
    desc = _clean_desc(weather.get("desc"))
    temp = weather.get("temp")
    temp_txt = f"{temp}摄氏度" if temp is not None else ""

    if ctx.get("indoor"):
        # 室内场景：地点不进画面（避免模型把城市名当标题写上去），
        # 用「房间 + 时刻 + 正在做什么 + 姿态」定画面。
        # 户外配件（伞/墨镜/遮阳帽）不进室内画面，否则会出现「窝在沙发上打伞」。
        for _w in ("伞", "墨镜", "遮阳帽", "雨衣", "手套"):
            wearing = " / ".join(x for x in wearing.split(" / ") if _w not in x) or wearing
        bg = str(ctx.get("room") or "干净整洁的室内，有生活痕迹")
        light = str(ctx.get("light") or "自然光，柔和")
        moment = str(ctx.get("name") or "")
        pose = str(ctx.get("pose") or "自然坐着或站着，姿态放松")
        where = f"{ctx.get('daypart') or ''}{moment + '，' if moment else ''}位于{bg}"
        scene_txt = f"{where}，{light}"
    else:
        bg = _SCENE_BG.get((scene or "").strip().lower()) or \
            "人行道，两侧是绿树、砖石墙面与玻璃立面，远处有行人虚影"
        light = _WEATHER_LIGHT.get(cat) or "自然日光，光线柔和"
        where = f"位于{place}的{bg}"
        scene_txt = f"{where}，{desc + '，' if desc else ''}{temp_txt}，{light}"
        pose = "行走中的瞬间，一只脚在前、手臂自然摆动，视线略微偏离镜头，表情放松"

    return (
        f"写实生活摄影，{who}，穿着{wearing}。"
        f"场景：{scene_txt}。"
        f"姿态：{pose}；表情自然放松、带一点轻松的笑意，不是严肃或疲惫的表情，"
        "也不是正面站立的证件照姿势，有生活感。"
        "中景或大半身，浅景深，背景有真实环境细节而不是纯色背景；"
        "背景里不出现店铺、招牌、广告牌、指示牌、门牌与海报。"
        "画面中不得出现任何文字、汉字、字母、数字、标签、水印、logo、字幕或排版元素。"
    )


#: 生图负向词：文字类 + 影棚灰底 + 呆板站姿（阿里万相支持 negative_prompt）
IMAGE_NEGATIVE = ("文字, 汉字, 中文, 字母, 英文, 数字, 字幕, 标题, 排版, 水印, logo, "
                  "印章, 乱码, 错字, 纯色背景, 灰色背景, 影棚背景, 白墙, "
                  "证件照, 正面证件照, 僵硬站姿, 双手下垂站定, 呆滞表情")


def outfit_for(agent_id: str, place: str, days: int = 1, scene: str | None = None,
               center_base: str | None = None, image: bool = False,
               image_engine: str | None = None, image_size: str | None = None) -> dict:
    """完整链路：地点 → 经纬度 → 天气（可 N 日）→ 按本人衣柜/性别建议。"""
    agent_id = _resolve_agent(agent_id)
    # 读本人衣柜（本地私有）；地点为空时尝试用 persona.residence.
    wardrobe, gender, residence = {}, None, ""
    p: dict = {}
    try:
        import sys
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from core import persona as P
        p = P.load_persona(agent_id)
        gender = (p.get("identity") or {}).get("gender")
        # 衣柜**外接**目录：persona 只存 starter，这次按目录展开，
        # 目录改了（加/换单品）立刻生效，不用回写 persona。
        wardrobe = P.expand_wardrobe(p.get("wardrobe") or {}, gender or "")
        residence = str((p.get("residence") or {}).get("city") or "").strip()
    except Exception:  # noqa: BLE001
        pass
    from . import owner_location
    place = str(place or "").strip()
    place = owner_location.normalize_city(place) or place
    residence = owner_location.normalize_city(residence) or residence
    place_source = "user" if place else ""
    if not place and residence:
        place, place_source = residence, "persona"
    if not place:
        owner_city = owner_location.load_weather_city()
        if owner_city:
            place, place_source = owner_city, "owner"
    if not place:
        geo = center_geo(center_base)
        if geo:
            place = owner_location.normalize_city(geo.get("city", "")) or str(geo.get("city") or "").strip()
            if place:
                place_source = "cloudflare"
                try:
                    owner_location.set_weather_city(place, source="cloudflare")
                except Exception:  # noqa: BLE001
                    pass
                try:
                    from core import persona as _P
                    _P.set_residence(agent_id, place, region=geo.get("region", ""),
                                     country=geo.get("country", ""),
                                     timezone=geo.get("timezone", ""), source="cloudflare")
                except Exception:  # noqa: BLE001
                    pass
    if not place:
        return {"ok": False, "error": "需要地点",
                "hint": "请提供城市名，或在 persona.residence.city 设置默认城市；也可连接中心使用 CF 城市",
                "examples": ["成都", "上海", "Boston"]}
    try:
        loc = geocode(place)
    except RuntimeError as exc:
        # 取不到就说取不到：不猜天气、不编地点，把试过的源和原因一起交出去
        return {"ok": False, "error": f"地点解析失败：{place}",
                "detail": str(exc)[:300], "sources": list(_LAST_ERRORS.get("geocode") or []),
                "hint": "所有地名源都不可用；稍后重试或换个城市写法（可带省份/国家）"}
    if not loc:
        return {"ok": False, "error": f"地点未找到：{place}",
                "hint": "请设置城市名（可带省份/国家）后重试；也可设置 persona.residence.city",
                "examples": ["成都", "上海", "Boston"]}
    try:
        w = forecast(loc["lat"], loc["lon"], loc.get("timezone") or "auto", days)
    except RuntimeError as exc:
        return {"ok": False, "error": f"天气获取失败：{loc.get('name') or place}",
                "detail": str(exc)[:300], "sources": list(_LAST_ERRORS.get("forecast") or []),
                "place": loc,
                "hint": "Open-Meteo / wttr.in / MET Norway 都不可用；不编造天气，稍后重试"}
    # 时间 → 生活场景（室内/户外、在做什么、什么光）。
    # 显式传了 scene（通勤/正式/户外…）就以用户为准，不用时间推断。
    tz = str((p.get("residence") or {}).get("tz") or "Asia/Shanghai")
    from . import scene as scene_mod
    ctx = {} if scene else scene_mod.current(tz)
    eff_scene = scene or (ctx.get("scene") if ctx else None)
    adv = recommend(w, wardrobe, gender, eff_scene)
    # N 日：逐日建议
    daily = []
    if days and int(days) > 1:
        for d in (w.get("daily") or []):
            wd = {"temp": d.get("t_max"), "t_max": d.get("t_max"), "t_min": d.get("t_min"),
                  "cat": d.get("cat"), "desc": d.get("desc"), "wind": 0}
            daily.append({"date": d.get("date"), "desc": d.get("desc"),
                          "t_min": d.get("t_min"), "t_max": d.get("t_max"),
                          "precip_prob": d.get("precip_prob"),
                          "advice": recommend(wd, wardrobe, gender, scene)})
    result = {"ok": True, "place": loc, "place_source": place_source,
              "weather": w, "gender": gender, "scene": eff_scene,
              "scene_ctx": ctx, "advice": adv, "daily": daily,
              # 多源降级留痕：主源失败时会记下原因，便于排查「为什么数据不一样」
              "data_source": {"geocode": loc.get("source"), "weather": w.get("source"),
                              "failed": list(_LAST_ERRORS.get("forecast") or [])}}
    if image:
        try:
            from . import media
            prompt = image_prompt(loc, w, adv, gender=gender, scene=scene,
                                  body=(p.get("body") or {}), scene_ctx=ctx)
            size = image_size or "2K"
            # 出图引擎：未显式指定时跟随全局配置 providers.image_engine（默认 ark 火山，
            # 可设 ali）。命令行 --image-engine ali|ark|auto 可单次覆盖。
            # 一个引擎失败就换另一个重试，单引擎故障不影响出图。
            eng = (image_engine or media.image_engine()).strip().lower()
            try:
                url, used = media.generate_image_with_engine(
                    prompt, size=size, engine=eng, negative_prompt=IMAGE_NEGATIVE)
            except Exception:
                alt = "ark" if eng != "ark" else "ali"
                url, used = media.generate_image_with_engine(
                    prompt, size=size, engine=alt, negative_prompt=IMAGE_NEGATIVE)
            result["image"] = {"ok": True, "url": url, "engine": used,
                               "engine_requested": eng}
        except Exception as exc:  # noqa: BLE001
            # Image is optional; never fail the weather/outfit response for it.
            result["image"] = {"ok": False, "error": str(exc)[:240]}
    return result
