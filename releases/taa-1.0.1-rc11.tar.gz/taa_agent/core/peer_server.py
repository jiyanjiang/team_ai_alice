"""TAA direct peer transport foundation.

The peer listener is deliberately separate from the local UI port (6080).
It advertises only reachability candidates; the center remains the directory
and relay fallback. Chat payloads will be added behind a group capability
check in the next step. This module currently exposes only a harmless
reachability probe so a direct path can be tested without sending data.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import mimetypes
import os
import socket
import threading
import time
import urllib.parse
import urllib.request
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from core.peer_network import candidate_endpoints, rank_endpoints
from core import timeutil

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PORT = int(os.environ.get("TAA_PEER_PORT", "6090") or 6090)
DEFAULT_BIND = os.environ.get("TAA_PEER_BIND", "0.0.0.0") or "0.0.0.0"
_SERVERS: list[ThreadingHTTPServer] = []
_THREADS: list[threading.Thread] = []


def _lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()


def _global_ipv6() -> list[str]:
    out: list[str] = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6):
            addr = str(info[4][0]).split("%", 1)[0]
            try:
                ip = ipaddress.ip_address(addr)
            except ValueError:
                continue
            if ip.is_global and addr not in out:
                out.append(addr)
    except OSError:
        pass
    return out


def _normalise_public(value: str) -> str:
    value = (value or "").strip().rstrip("/")
    if not value:
        return ""
    if not value.startswith(("http://", "https://")):
        value = "http://" + value
    return value


def listener_info() -> dict[str, Any]:
    return {"active": bool(_SERVERS), "ports": [int(s.server_address[1]) for s in _SERVERS],
            "hosts": [str(s.server_address[0]) for s in _SERVERS]}


def peer_endpoints(port: int | None = None) -> list[dict[str, Any]]:
    """Candidates for every active peer listener, never the 6080 UI port."""
    ports = [int(port)] if port else [int(s.server_address[1]) for s in _SERVERS]
    if not ports:
        return []
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for p in ports:
        for item in candidate_endpoints(p):
            url = str(item.get("url") or "").rstrip("/")
            if not url or url in seen:
                continue
            seen.add(url)
            out.append(item)
    return out[:8]


def _node_id() -> str:
    try:
        from taa_node_v05.identity import load_state
        home = Path(os.environ.get("TAA_V05_HOME") or os.environ.get("TAA_HOME") or "~/.taa").expanduser()
        return str(load_state(home).node.node_id or "")
    except Exception:  # noqa: BLE001
        return ""


def _version() -> str:
    for p in (ROOT / "VERSION", ROOT / "dist" / "VERSION"):
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            pass
    return ""


def _sha256_hex(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _signature(secret: str, group_id: str, timestamp: str, raw: bytes) -> str:
    message = f"{group_id}\n{timestamp}\n{_sha256_hex(raw)}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()


def _verify_signature(secret: str, group_id: str, timestamp: str, raw: bytes, sig: str) -> bool:
    try:
        if abs(int(time.time()) - int(timestamp)) > 300:
            return False
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(_signature(secret, group_id, timestamp, raw), sig or "")


def _ensure_peer_columns(c) -> None:
    cols = {str(r["name"]) for r in c.execute("pragma table_info(rooms)").fetchall()}
    for name, ddl in (
        ("center_group_id", "text"),
        ("center_transport_secret", "text"),
        ("center_peer_endpoints", "text"),
    ):
        if name not in cols:
            c.execute(f"alter table rooms add column {name} {ddl}")
    mcols = {str(r["name"]) for r in c.execute("pragma table_info(room_messages)").fetchall()}
    for name, ddl in (
        ("peer_message_id", "text"),
        ("client_message_id", "text"),
        ("direct_delivered", "integer default 0"),
    ):
        if name not in mcols:
            c.execute(f"alter table room_messages add column {name} {ddl}")
    c.execute("create unique index if not exists ux_room_messages_peer on room_messages(room_id, peer_message_id) where peer_message_id is not null")
    c.execute("create unique index if not exists ux_room_messages_client on room_messages(room_id, client_message_id) where client_message_id is not null")
    c.commit()


def _room_for_group(c, gid: str):
    return c.execute("select * from rooms where center_group_id=? limit 1", (gid,)).fetchone()


def _ensure_remote_agent(c, *, owner_id: str, agent_id: str, agent_name: str, node_id: str) -> str:
    if agent_id and c.execute("select 1 from agents where id=?", (agent_id,)).fetchone():
        return agent_id
    if agent_id:
        from .agent_names import next_available_name
        name, _renamed = next_available_name(c, agent_name or agent_id,
                                             exclude_agent_id=agent_id)
        full = f"{name}@center"
        c.execute("insert or ignore into agents(id,name,kind,node_id,full_name,role,persona_json,status) "
                  "values(?,?, 'ai', NULL, ?, 'executor', '{}', 'idle')",
                  (agent_id, name[:80], full))
        c.execute("update agents set name=?, status='idle' where id=?", (name[:80], agent_id))
        return agent_id
    local = "remote-human-" + owner_id
    if not c.execute("select 1 from agents where id=?", (local,)).fetchone():
        c.execute("insert or ignore into agents(id,name,kind,node_id,full_name,role,persona_json,status) "
                  "values(?,?, 'human', NULL, NULL, 'executor', '{}', 'active')",
                  (local, (owner_id or "remote")[:80]))
    return local


def _log_error(where: str, exc: BaseException) -> None:
    """本地留痕，**绝不回给对端**：抹掉本机绝对路径，只留类型与短描述。

    脱敏红线（docs/16 §3.3）：对端可见的响应里不允许出现本机路径/异常原文；
    排障信息只写本机 stderr，且先把 ROOT 前缀替换掉。
    """
    try:
        msg = str(exc).replace(str(ROOT), "<root>")
    except Exception:  # noqa: BLE001
        msg = ""
    print(f"[peer] {where} 失败：{type(exc).__name__}: {msg[:300]}")


def _local_upload(url: str) -> Path | None:
    """`/static/uploads/<name>` → 本机文件；绝不接受目录穿越或其它来源。"""
    raw = str(url or "").strip()
    if not raw.startswith("/static/uploads/"):
        return None
    name = raw.split("?", 1)[0].split("#", 1)[0].rsplit("/", 1)[-1]
    if not name or name in {".", ".."} or "/" in name or "\\" in name:
        return None
    p = ROOT / "static" / "uploads" / name
    return p if p.is_file() else None


def _decode_attachments(raw: Any) -> list[dict[str, Any]]:
    """把对端 payload 里的附件解成本机可访问的 manifest。

    三种历史形状都要认（否则中心兜底/旧节点发来的图会被静默丢弃）：
      1. `{"sha256": ...}` —— S3 直投：字节已先落到 `peer-<sha32>.<ext>`，按内容寻址反查；
      2. `{"url": "/static/uploads/..."}` —— 旧节点直投/本机回放；
      3. 裸字符串 URL —— 中心兜底与更早的 payload。
    解不出来的一律跳过，不伪造、不落死链。
    """
    out: list[dict[str, Any]] = []
    if not isinstance(raw, list):
        return out
    base = ROOT / "static" / "uploads"
    base.mkdir(parents=True, exist_ok=True)
    for item in raw[:9]:
        if isinstance(item, str):
            item = {"url": item}
        if not isinstance(item, dict):
            continue
        digest = str(item.get("sha256") or "").strip().lower()
        if len(digest) == 64 and all(ch in "0123456789abcdef" for ch in digest):
            matches = list((ROOT / "static" / "uploads").glob("peer-" + digest[:32] + ".*"))
            if matches:
                name = str(item.get("name") or matches[0].name)[:120]
                mime = str(item.get("mime") or mimetypes.guess_type(matches[0].name)[0]
                           or "application/octet-stream")
                out.append({"url": "/static/uploads/" + matches[0].name, "name": name,
                            "sha256": digest, "mime": mime,
                            "size": int(item.get("size") or matches[0].stat().st_size)})
            continue
        url_item = str(item.get("url") or "")
        local = _local_upload(url_item)
        if local is not None:
            out.append({"url": url_item, "name": str(item.get("name") or local.name)[:120]})
            continue
        try:
            data = base64.b64decode(str(item.get("data") or ""), validate=True)
        except Exception:
            continue
        if not data or len(data) > 6 * 1024 * 1024:
            continue
        ext = mimetypes.guess_extension(str(item.get("mime") or "")) or Path(str(item.get("name") or "")).suffix or ".bin"
        if ext.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bin"}:
            ext = ".bin"
        name = f"peer-{uuid.uuid4().hex}{ext}"
        (base / name).write_bytes(data)
        out.append({"url": "/static/uploads/" + name, "name": str(item.get("name") or name)[:120]})
    return out


def _read_json(handler: BaseHTTPRequestHandler, limit: int = 10 * 1024 * 1024) -> tuple[bytes, dict[str, Any]]:
    try:
        size = int(handler.headers.get("content-length") or "0")
    except ValueError:
        size = 0
    if size <= 0 or size > limit:
        raise ValueError("bad_content_length")
    raw = handler.rfile.read(size)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("bad_json")
    return raw, data


# ---------------------------------------------------------------------------
# 直投端点健康度（2026-10-31 事故根因）
#
# 一个房间的 `center_peer_endpoints` 是**所有其他成员**公布的可达地址合集：
# 同一个对端会同时给出 LAN / VPN / IPv6 多个地址，其中常年有死地址。
# 旧实现要求「每个地址都成功」才判定送达，于是只要有一条死地址（IPv6 在
# utun6 上不通），本机发出去的每条消息都会判失败 → 积压只增不减 → 每轮还
# 要把死地址的 2s 超时全付一遍（2026-10-31：4 个端点里 2 个死，每条消息
# 白烧 4s，id 2049 之后直投成功率恒为 0）。
#
# 正确口径：
#   1. 按 transport 节点分组，**每个对端节点有一个地址成功即算该对端送达**
#      （同一对端的多个地址是冗余候选，不是多个必须分别送达的目的地）；
#   2. 失败地址进短时黑名单（默认 300s），期间直接跳过、不再付超时；
#      到期自动复活重试，不写死、不删除地址。
# ---------------------------------------------------------------------------
_ENDPOINT_DEAD_UNTIL: dict[str, float] = {}
_ENDPOINT_FAILS: dict[str, int] = {}
_ENDPOINT_DEAD_LOCK = threading.Lock()
ENDPOINT_DEAD_TTL_S = float(os.environ.get("TAA_PEER_DEAD_TTL", "300") or 300)
# 偶发一次超时不足以判死（对端在忙/瞬时丢包都会超时）。连续失败到这个次数
# 才拉黑，避免"一次抖动把整轮 20 条全部打成 endpoint_dead"。
ENDPOINT_DEAD_AFTER = max(1, int(os.environ.get("TAA_PEER_DEAD_AFTER", "3") or 3))


def _endpoint_is_dead(url: str) -> bool:
    with _ENDPOINT_DEAD_LOCK:
        until = _ENDPOINT_DEAD_UNTIL.get(url) or 0.0
        if until and until <= time.time():
            _ENDPOINT_DEAD_UNTIL.pop(url, None)
            _ENDPOINT_FAILS.pop(url, None)
            return False
        return bool(until)


def _endpoint_mark(url: str, alive: bool) -> None:
    with _ENDPOINT_DEAD_LOCK:
        if alive:
            _ENDPOINT_DEAD_UNTIL.pop(url, None)
            _ENDPOINT_FAILS.pop(url, None)
            return
        n = _ENDPOINT_FAILS.get(url, 0) + 1
        _ENDPOINT_FAILS[url] = n
        if n >= ENDPOINT_DEAD_AFTER:
            _ENDPOINT_DEAD_UNTIL[url] = time.time() + ENDPOINT_DEAD_TTL_S


def endpoint_health() -> dict[str, Any]:
    """当前被短时拉黑的地址（排障用；不含敏感信息）。"""
    with _ENDPOINT_DEAD_LOCK:
        now = time.time()
        return {"dead": {u: round(t - now) for u, t in _ENDPOINT_DEAD_UNTIL.items() if t > now},
                "ttl_s": ENDPOINT_DEAD_TTL_S}


def _peer_groups(endpoints: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    """把地址按对端节点分组；旧数据没有 node 字段时视为同一个对端。

    `_store_group_transport` 新写入的地址带 `node`（transport_node_id）；
    历史行没有这个字段，只能退化成一个分组——对「一个房间只有一个对端」
    的既有数据（当前线上即是）语义仍然正确。
    """
    groups: dict[str, list[dict[str, Any]]] = {}
    for ep in rank_endpoints(endpoints or []):
        if isinstance(ep, str):
            ep = {"kind": "peer", "url": ep}
        if not isinstance(ep, dict):
            continue
        url = str(ep.get("url") or "").rstrip("/")
        if not url or str(ep.get("kind") or "") == "peer-loopback":
            continue
        key = str(ep.get("node") or ep.get("node_id") or "")
        groups.setdefault(key, []).append({**ep, "url": url})
    return list(groups.values())


def _post_one(url: str, path: str, body: bytes, headers: dict[str, str],
              timeout: float) -> tuple[bool, str]:
    req = urllib.request.Request(url + path, data=body, method="POST", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if 200 <= resp.status < 300:
                return True, ""
            return False, f"{url}: HTTP {resp.status}"
    except Exception as exc:  # noqa: BLE001
        return False, f"{url}: {type(exc).__name__}"


def _post_per_peer(*, group_id: str, secret: str, endpoints: list[dict[str, Any]],
                   body: bytes, suffix: str, extra_headers: dict[str, str],
                   timeout: float) -> dict[str, Any]:
    """向每个对端节点投一次；节点内任一地址成功即该节点成功。"""
    ts = str(int(time.time()))
    sig = _signature(secret, group_id, ts, body)
    path = "/peer/v1/groups/" + urllib.parse.quote(group_id, safe="") + suffix
    base_headers = {
        "x-taa-group": group_id,
        "x-taa-timestamp": ts,
        "x-taa-signature": sig,
        "user-agent": "TAA-Peer/1",
        **extra_headers,
    }
    peers = _peer_groups(endpoints)
    ok_peers = 0
    tried = 0
    skipped_dead: list[str] = []
    errors: list[str] = []
    for addrs in peers:
        live = [a for a in addrs if not _endpoint_is_dead(a["url"])]
        skipped_dead.extend(a["url"] for a in addrs if _endpoint_is_dead(a["url"]))
        if not live:
            # 全部在短时黑名单里：算这次未送达（等 TTL 到期再试），但零耗时。
            errors.append(f"{addrs[0]['url']}: endpoint_dead")
            continue
        delivered = False
        for ep in live:
            tried += 1
            ok, err = _post_one(ep["url"], path, body, base_headers, timeout)
            _endpoint_mark(ep["url"], ok)
            if ok:
                delivered = True
                break
            errors.append(err)
        if delivered:
            ok_peers += 1
    return {
        "peers": len(peers),
        "ok_peers": ok_peers,
        "attempted": tried,
        "ok": ok_peers,
        "skipped_dead": skipped_dead,
        "errors": errors,
        # 所有对端节点都送达才叫 ok_all；只要有一个对端收不到就继续重试，
        # 这样多成员房间里「送到 A 没送到 B」不会被记成已送达。
        "ok_all": bool(peers) and ok_peers == len(peers),
        "delivered": ok_peers > 0,
    }


def post_direct_group_message(*, group_id: str, secret: str, endpoints: list[dict[str, str]],
                              payload: dict[str, Any], timeout: float = 2.0) -> dict[str, Any]:
    """Push one already-created local message to peer endpoints.

    判定口径见 `_post_per_peer`：按对端节点计成功，死地址短时拉黑。
    """
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return _post_per_peer(group_id=group_id, secret=secret, endpoints=endpoints or [],
                          body=raw, suffix="/messages",
                          extra_headers={"content-type": "application/json"},
                          timeout=timeout)


def post_direct_file(*, group_id: str, secret: str, endpoints: list[dict[str, str]],
                     name: str, data: bytes, content_type: str = "application/octet-stream",
                     timeout: float = 2.0) -> dict[str, Any]:
    """Upload one compressed attachment as raw bytes; never base64."""
    return _post_per_peer(group_id=group_id, secret=secret, endpoints=endpoints or [],
                          body=data, suffix="/files",
                          extra_headers={"content-type": content_type or "application/octet-stream",
                                         "x-taa-filename": name[:120]},
                          timeout=timeout)


class _Handler(BaseHTTPRequestHandler):
    server_version = "TAA-Peer/1"

    def _json(self, status: int, obj: dict[str, Any]) -> None:
        raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(raw)))
        self.send_header("cache-control", "no-store")
        self.send_header("x-taa-peer", "1")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(raw)

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def do_GET(self) -> None:  # noqa: N802
        if self.path.split("?", 1)[0] in ("/peer/v1/ping", "/peer/v1/health"):
            self._json(200, {
                "ok": True, "service": "taa-peer", "proto": 1,
                "node_id": _node_id(), "version": _version(),
                "time": int(time.time()),
            })
            return
        self._json(404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        path = self.path.split("?", 1)[0]
        is_file = path.startswith("/peer/v1/groups/") and path.endswith("/files")
        is_message = path.startswith("/peer/v1/groups/") and path.endswith("/messages")
        if not (is_file or is_message):
            self._json(404, {"ok": False, "error": "not_found"})
            return
        suffix = "/files" if is_file else "/messages"
        gid = urllib.parse.unquote(path[len("/peer/v1/groups/"):-len(suffix)].strip("/"))
        if not gid or len(gid) > 80:
            self._json(400, {"ok": False, "error": "bad_group"})
            return
        if is_file:
            try:
                size = int(self.headers.get("content-length") or "0")
            except ValueError:
                size = 0
            if size <= 0 or size > 2 * 1024 * 1024:
                # 先把声明长度读掉再回 413：客户端可能还在写 body，直接回包会
                # BrokenPipeError，发送端就看不到 413 这个明确原因。上限 8MB——
                # 再大的一律不读完，宁可让对端连接失败也不在本机吞流量。
                if 0 < size <= 8 * 1024 * 1024:
                    try:
                        self.rfile.read(size)
                    except Exception:  # noqa: BLE001
                        pass
                self._json(413, {"ok": False, "error": "file_too_large", "limit": 2 * 1024 * 1024})
                return
            raw = self.rfile.read(size)
            from core import db as db_mod
            c = db_mod.connect()
            try:
                _ensure_peer_columns(c)
                room = _room_for_group(c, gid)
                if not room:
                    self._json(404, {"ok": False, "error": "group_not_local"})
                    return
                secret = str(room["center_transport_secret"] or "")
                ts = str(self.headers.get("x-taa-timestamp") or "")
                sig = str(self.headers.get("x-taa-signature") or "")
                if not secret or not _verify_signature(secret, gid, ts, raw, sig):
                    self._json(403, {"ok": False, "error": "bad_signature"})
                    return
                name = str(self.headers.get("x-taa-filename") or "attachment")[:120]
                ctype = str(self.headers.get("content-type") or "application/octet-stream")[:80]
                digest = hashlib.sha256(raw).hexdigest()
                ext = mimetypes.guess_extension(ctype.split(";", 1)[0]) or Path(name).suffix or ".bin"
                if ext.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bin"}:
                    ext = ".bin"
                filename = "peer-" + digest[:32] + ext
                base = ROOT / "static" / "uploads"
                base.mkdir(parents=True, exist_ok=True)
                (base / filename).write_bytes(raw)
                # 内容库登记（docs/16 §4.3）：文件已按 sha 寻址落盘，这里只补索引，
                # 失败不阻断"对端已可访问"——但会在本机留一行日志。
                try:
                    from core import attachments as att_mod
                    att_mod.register_blob(c, {"url": "/static/uploads/" + filename,
                                              "name": name, "mime": ctype,
                                              "size": len(raw)})
                except Exception as exc:  # noqa: BLE001
                    _log_error("blob_register", exc)
                c.commit()
                self._json(200, {"ok": True, "url": "/static/uploads/" + filename,
                                 "name": name, "sha256": digest, "size": len(raw),
                                 "mime": ctype})
            except Exception as exc:  # noqa: BLE001
                _log_error("files", exc)
                self._json(500, {"ok": False, "error": "internal_error"})
            finally:
                c.close()
            return
        try:
            raw, data = _read_json(self)
        except Exception:  # noqa: BLE001 —— 解析异常原文可能带请求体片段，不回给对端
            self._json(400, {"ok": False, "error": "bad_request"})
            return
        from core import db as db_mod
        c = db_mod.connect()
        try:
            _ensure_peer_columns(c)
            room = _room_for_group(c, gid)
            if not room:
                self._json(404, {"ok": False, "error": "group_not_local"})
                return
            secret = str(room["center_transport_secret"] or "")
            ts = str(self.headers.get("x-taa-timestamp") or "")
            sig = str(self.headers.get("x-taa-signature") or "")
            if not secret or not _verify_signature(secret, gid, ts, raw, sig):
                self._json(403, {"ok": False, "error": "bad_signature"})
                return
            body = str(data.get("body") or "").strip()
            # 纯图片消息（无文字）是合法消息：旧实现无条件要求 body，
            # 导致"只发图"的直投永远 400 body_required，并留在本地重试队列里。
            attachments_in = _decode_attachments(data.get("attachments"))
            if not body and not attachments_in:
                self._json(400, {"ok": False, "error": "body_required"})
                return
            if len(body) > 4000:
                self._json(413, {"ok": False, "error": "body_too_long"})
                return
            owner_id = str(data.get("owner_id") or "")[:80]
            node_id = str(data.get("node_id") or "")[:80]
            agent_id = str(data.get("agent_id") or "")[:80]
            agent_name = str(data.get("agent_name") or "")[:80]
            client_id = str(data.get("client_message_id") or "")[:120]
            if not owner_id or not node_id:
                self._json(400, {"ok": False, "error": "identity_required"})
                return
            local_agent = _ensure_remote_agent(c, owner_id=owner_id, agent_id=agent_id,
                                               agent_name=agent_name, node_id=node_id)
            created_utc = timeutil.to_utc_iso(data.get("created_at"), assume="utc") or timeutil.now_utc_iso()
            created = timeutil.to_local_text(created_utc, assume="utc")
            reply_center = str(data.get("reply_to") or "")[:100]
            reply_local = None
            if reply_center:
                rr = c.execute("select id from room_messages where center_message_id=?", (reply_center,)).fetchone()
                reply_local = int(rr["id"]) if rr else None
            rnd = int(room["current_round"] or 1)
            attachments = attachments_in
            att_json = json.dumps(attachments, ensure_ascii=False) if attachments else None
            sender_kind = "ai" if agent_id else "human"
            cur = c.execute(
                "insert or ignore into room_messages(room_id,round,agent_id,body,kind,source,created_at,"
                "created_at_utc,attachment,peer_message_id,client_message_id,reply_to_id,reply_to_center_id,"
                "sender_owner_id,sender_kind) "
                "values(?,?,?,?, 'assertion','peer',?,?,?,?,?,?,?,?,?)",
                (room["id"], rnd, local_agent, body[:4000], created, created_utc, att_json,
                 client_id or ("peer-" + uuid.uuid4().hex), client_id or None,
                 reply_local, reply_center or None, owner_id or None, sender_kind),
            )
            c.commit()
            local_mid = int(cur.lastrowid or 0)
            if local_mid:
                # 附件 manifest 落库（docs/16 §4.2/§4.3）：字节已随 /files 到达本机，
                # 这里补"消息 ↔ 附件"关系并置 synced；失败不影响消息本身。
                if attachments:
                    try:
                        from core import attachments as att_mod
                        att_mod.register_message(c, local_mid, room["id"], attachments)
                        for a in attachments:
                            sha = str(a.get("sha256") or "")
                            if sha:
                                att_mod.set_status(c, local_mid, sha, "synced", a.get("url"))
                    except Exception as exc:  # noqa: BLE001
                        _log_error("attachments", exc)
                try:
                    from core.app_ui import _maybe_dispatch_remote, _ws_broadcast, _ws_payload
                    payload = _ws_payload(c, room["id"], local_mid)
                    if payload:
                        _ws_broadcast(room["id"], {"type": "message", "message": payload})
                    _maybe_dispatch_remote(c, rid=room["id"], mid=local_mid,
                                           body=body, source="peer", owner_id=owner_id)
                except Exception:  # noqa: BLE001
                    pass
            self._json(200, {"ok": True, "room_id": room["id"], "inserted": bool(cur.rowcount),
                             "message_id": cur.lastrowid})
        except Exception as exc:  # noqa: BLE001
            try:
                c.rollback()
            except Exception:
                pass
            _log_error("messages", exc)
            self._json(500, {"ok": False, "error": "internal_error"})
        finally:
            c.close()

    def log_message(self, fmt: str, *args: Any) -> None:
        # Keep the local log quiet unless probing fails.
        return


def start_peer_server(*, port: int | None = None, bind: str | None = None) -> dict[str, Any]:
    global _SERVERS, _THREADS
    if os.environ.get("TAA_PEER_DISABLE") == "1":
        return {"ok": False, "disabled": True}
    if _SERVERS:
        return {"ok": True, **listener_info()}
    host = (bind or DEFAULT_BIND).strip() or "0.0.0.0"
    if port:
        ports = [int(port)]
    elif os.environ.get("TAA_PEER_PORT"):
        ports = [int(os.environ["TAA_PEER_PORT"])]
    else:
        ports = [6090, 6091]
        extra = os.environ.get("TAA_PEER_PORTS", "")
        if extra:
            ports = [int(x) for x in extra.split(",") if x.strip().isdigit()]
    errors: list[str] = []
    for p in ports:
        try:
            srv = ThreadingHTTPServer((host, p), _Handler)
            srv.daemon_threads = True
            th = threading.Thread(target=srv.serve_forever, name=f"taa-peer-server-{p}", daemon=True)
            th.start()
            _SERVERS.append(srv)
            _THREADS.append(th)
        except OSError as exc:
            errors.append(f"{p}: {type(exc).__name__}: {exc}")
    if not _SERVERS:
        return {"ok": False, "host": host, "ports": ports, "errors": errors}
    return {"ok": True, "host": host, **listener_info(), "errors": errors}


def stop_peer_server() -> None:
    global _SERVERS, _THREADS
    servers, _SERVERS = _SERVERS, []
    _THREADS = []
    for srv in servers:
        try:
            srv.shutdown()
        except Exception:  # noqa: BLE001
            pass
        try:
            srv.server_close()
        except Exception:  # noqa: BLE001
            pass
