"""图像生成 provider 契约（默认 OpenAI 兼容，可注册第三方）。

与 `core/llm_http.py` 同一套思路（见 `docs/533`）：

  · 端点 / 模型 / 密钥 / 顺序全部来自配置，业务代码不判断服务商；
  · 内置 provider 只有 "ark"（火山）与 "ali"（阿里万相），实现在 `core/media.py`；
  · 任何**OpenAI 兼容**的 images/generations 端点，只要配三个环境变量即可接入：

        TEAMAI_IMAGE_URL    https://your-host/v1/images/generations
        TEAMAI_IMAGE_MODEL  模型名
        TEAMAI_IMAGE_KEY    密钥（缺失时视为不可用）

  · 顺序：`TEAMAI_IMAGE_PROVIDER_ORDER="ark,ali,openai"`（缺省 ark,ali，再自动补 openai）；
  · provider 只负责"拿到图片 URL"，下载落盘由 `media` 层统一做（保持存储语义不变）。

未做（明确不承诺）：各家异步任务协议（如万相的提交+轮询）不在这里抽象——
那是 `media.ali_generate` 的实现细节，新增同类厂商请照它的样子写一个函数并注册。
"""
from __future__ import annotations

import json
import os
import urllib.request

DEFAULT_SIZE = "1024x1024"
_SIZE_MAP = {"2k": "2048x2048", "4k": "4096x4096", "1k": "1024x1024"}

#: 第三方注册表：name -> callable(prompt, size=..., negative_prompt=...) -> 远端图片 URL
_REGISTRY: dict[str, object] = {}


def endpoint() -> str:
    return (os.environ.get("TEAMAI_IMAGE_URL") or "").strip()


def model_name() -> str:
    return (os.environ.get("TEAMAI_IMAGE_MODEL") or "").strip()


def api_key() -> str:
    return (os.environ.get("TEAMAI_IMAGE_KEY") or "").strip()


def _size(value: str | None) -> str:
    s = str(value or "").strip().lower()
    if not s:
        return DEFAULT_SIZE
    return _SIZE_MAP.get(s, s if "x" in s or "*" in s else DEFAULT_SIZE)


def available(name: str = "openai") -> bool:
    if name == "openai":
        return bool(endpoint() and api_key())
    return name in _REGISTRY


def register(name: str, fn) -> None:
    """注册一个 provider。fn(prompt, size=..., negative_prompt=...) 返回远端图片 URL。"""
    _REGISTRY[str(name).strip().lower()] = fn


def get(name: str):
    n = str(name or "").strip().lower()
    if n == "openai":
        return openai_generate if available("openai") else None
    return _REGISTRY.get(n)


def openai_generate(prompt: str, *, size: str = "", negative_prompt: str = "",
                    timeout: int = 180) -> str:
    """OpenAI 兼容的图像生成：POST {url}，返回 data[0].url（或 b64 落盘后的本地 URL）。"""
    url = endpoint()
    key = api_key()
    if not (url and key):
        raise RuntimeError("未配置 OpenAI 兼容出图端点：需要 TEAMAI_IMAGE_URL / TEAMAI_IMAGE_KEY")
    body = json.dumps({
        "model": model_name(),
        "prompt": prompt,
        "n": 1,
        "size": _size(size),
        "response_format": "url",
    }).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
    })
    with urllib.request.urlopen(req, timeout=max(10, min(int(timeout), 300))) as r:
        d = json.loads(r.read().decode("utf-8", "replace"))
    items = d.get("data") or []
    if not items:
        raise RuntimeError(f"出图端点未返回图片：{str(d)[:160]}")
    item = items[0]
    if item.get("url"):
        return str(item["url"])
    if item.get("b64_json"):
        import base64
        from . import media  # 延迟导入，避免与 media 循环依赖
        return media._save_bytes(base64.b64decode(item["b64_json"]), ".png")
    raise RuntimeError(f"出图端点返回既无 url 也无 b64_json：{str(item)[:120]}")
