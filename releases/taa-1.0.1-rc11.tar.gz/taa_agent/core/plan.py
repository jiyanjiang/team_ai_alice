"""规划优先（plan-first）——执行前，先把「可执行、涉及细节的方案」评审通过。

背景（导师反复强调，见工作群 room-55e1cd08 / playbook）：
- 执行者常常方案没定就动手，导致跑偏、撞车、返工。
- 纪律：**先磋商出不自相矛盾、不撞车的可执行方案，再执行**；主 agent 出方案+定判据+验收，从 agent 执行。

本模块让 **LLM 判断**方案是否"可执行、细节足够"（不用关键词凑数），并逐项指出缺口；
方案与每轮评审落 `memory.plans`，可多轮迭代直到 approved，供 qa/loop 做"未过方案不得开工"的门禁。
自检友好：`review_plan(..., llm=...)` 可注入假 LLM，不触网。
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from . import memory as mem

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = os.environ.get("TEAMAI_PLAN_MODEL", "deepseek/deepseek-flash")

# 需要覆盖的方案要素（评审时给 LLM 参考，具体是否"够"由 LLM 判断）
REQUIRED_ELEMENTS = [
    "目标与交付物（产出什么/给谁/格式）",
    "步骤或大纲（拆到可逐条执行）",
    "事实源清单（硬源优先、≥2 独立来源、一手/二手分列）",
    "事实库/schema（每条含 URL+原文摘录+用途）",
    "验收判据（可量化：找什么、几份算够、配不上砍哪条）",
    "分工与轮次（谁做什么、几轮收敛、卡点如何上报）",
    "风险与不做项（边界）",
]


def build_review_prompt(topic: str, target: str, plan_text: str,
                        rules: list[str] | None = None) -> str:
    rules_txt = "\n".join(f"- {r}" for r in (rules or [])[:20]) or "（无）"
    elems = "\n".join(f"{i+1}) {e}" for i, e in enumerate(REQUIRED_ELEMENTS))
    return (
        "你是团队的「方案评审器」。团队纪律：**先确认可执行、涉及细节的方案，再让执行者动手**。\n"
        f"被审对象：主题《{topic}》／执行者 {target}。\n\n"
        "团队已沉淀的相关经验（来源纪律等，评审时应据此判断方案是否达标）：\n"
        f"{rules_txt}\n\n"
        "请判断：这份方案是否**可执行、细节足够**，足以让执行者不再反复、不撞车地开工？\n"
        "逐项检查（缺哪项就指出，并说明为什么这与执行相关）：\n"
        f"{elems}\n\n"
        "判断权在你：是否\"足够\"由你实事求是判断，**不要**用固定关键词凑数；方案没写清就判不过。\n\n"
        f"----- 方案全文 -----\n{plan_text[:6000]}\n---------------------\n\n"
        "只输出一个 JSON（不要多余文字）：\n"
        '{"ok":true,"missing":[{"element":"…","why":"…"}],"verdict":"一句话结论",'
        '"feedback":"给执行者/主agent的具体修改要求"}'
    )


def _extract_json(text: str) -> dict | None:
    if not text:
        return None
    s = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", s, re.S)
    if m:
        s = m.group(1).strip()
    i, j = s.find("{"), s.rfind("}")
    if i < 0 or j <= i:
        return None
    try:
        d = json.loads(s[i:j + 1], strict=False)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


def review_plan(topic: str, target: str, plan_text: str, *, agent: str = "alice",
                rules: list[str] | None = None, llm=None, model: str = DEFAULT_MODEL,
                store: bool = True) -> dict:
    """LLM 评审方案 → {ok, missing, verdict, feedback, cycle}；可选落库（memory.plans）。"""
    if not (plan_text or "").strip():
        return {"ok": False, "missing": [{"element": "方案正文", "why": "空方案"}],
                "verdict": "未提交方案", "feedback": "请先出可执行方案。"}
    prompt = build_review_prompt(topic, target, plan_text, rules)
    if llm is None:
        from core.llm import get as llm_get
        backend_file = ROOT / "agents" / agent / "backend"
        backend = (backend_file.read_text(encoding="utf-8").strip()
                   if backend_file.exists() else "opencode")
        llm = llm_get(backend)
        res = llm.run(prompt, model=model, cwd=str(ROOT),
                      title=f"plan-review:{topic}:{target}", timeout=240)
        text = res.text if res.ok else ""
        if not res.ok:
            return {"ok": False, "error": "llm_failed", "raw": text[-300:]}
    else:
        text = llm(prompt)
    d = _extract_json(text) or {}
    ok = bool(d.get("ok"))
    missing = [{"element": x.get("element"), "why": x.get("why")}
               for x in (d.get("missing") or []) if isinstance(x, dict)]
    verdict = (d.get("verdict") or "").strip()
    feedback = (d.get("feedback") or "").strip()
    out = {"ok": ok, "missing": missing, "verdict": verdict, "feedback": feedback}
    if store:
        cycle = mem.record_plan(agent, topic, target, plan_text,
                                status="approved" if ok else "draft",
                                review={"ok": ok, "missing": missing, "verdict": verdict,
                                        "feedback": feedback})
        out["cycle"] = cycle
    return out


def plan_gate(agent: str, topic: str, target: str) -> dict:
    """开工门禁：是否已有 approved 方案。返回 {ok, reason, cycle}。"""
    p = mem.latest_plan(agent, topic, target)
    if not p:
        return {"ok": False, "reason": "尚无方案：请先出可执行方案并过评审"}
    if p.get("status") != "approved":
        return {"ok": False, "reason": f"方案未通过（{p.get('status')}）：先按反馈改到过审", "cycle": p.get("cycle")}
    return {"ok": True, "cycle": p.get("cycle"), "reason": "方案已过审"}
