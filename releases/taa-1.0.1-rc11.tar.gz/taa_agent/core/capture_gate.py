"""采集完整性硬门禁（Owner 2026-10-14 口径：**解析不完整 ＝ 失败，不入库**）。

为什么要有它：知识库的**信噪比**靠这一道闸——只收"解析完整的好文"，
失败也**不入库正文**（只留 `status=failed` + 原因），并把它当作**该源质量/我们解析能力**的度量。

判据（全部可判定、可回归；阈值可在 config 覆盖）
  · title 非空且 ≥4 字
  · published_at 非空（格式宽松：含 4 位年即可）
  · byline ≥1 个作者
  · **body_chars ≥ MIN_BODY（默认 800）** ← 付费墙/截断通常远低于此
  · 段落数 ≥ 3
  · **无付费墙/登录墙文案**（中英标记）

用法：
    from core.capture_gate import judge
    ok, reasons, metrics = judge({"title":…, "published_at":…, "byline":[…], "body":…, "html":…})
    if not ok:  # → status=failed，原因入日志/统计；**不得入库正文**
        ...
"""
from __future__ import annotations

import re

from .access_check import judge_access

MIN_TITLE = 4
MIN_BODY = 800
MIN_PARAS = 3

# 付费墙/登录墙标记（命中即判"不完整"——这正是"用户会关掉"的那类页面）
PAYWALL_MARKERS = [
    "subscribe to continue", "subscribe to read", "sign in to read", "sign in to continue",
    "become a member to", "already a subscriber", "register to continue",
    "订阅后继续", "登录后继续", "开通会员", "付费阅读", "仅限订阅用户",
]

_YEAR = re.compile(r"(19|20)\d{2}")


def _paras(body: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n{2,}", body or "") if p.strip()]


def judge(art: dict, *, min_body: int = MIN_BODY, min_title: int = MIN_TITLE,
          min_paras: int = MIN_PARAS) -> tuple[bool, list[str], dict]:
    """返回 (ok, reasons, metrics)。ok=False ⇒ 调用方**不得入库正文**。"""
    title = str(art.get("title") or "").strip()
    date = str(art.get("published_at") or "").strip()
    byline = art.get("byline") or []
    if isinstance(byline, str):
        byline = [b for b in re.split(r"[,，;；]", byline) if b.strip()]
    body = str(art.get("body") or "")
    html = str(art.get("html") or "")

    body_chars = len(re.sub(r"\s+", "", body))
    paras = _paras(body)
    low = (body + "\n" + html).lower()
    paywall = [m for m in PAYWALL_MARKERS if m in low]
    # 登录态 / 付费墙 → **内容不全**（Owner：未登录时详情页很可能只有前几段，须做判断、不许入库）
    accessible, access_reasons, access_sig = judge_access(html, body)

    metrics = {
        "title_chars": len(title),
        "has_date": bool(_YEAR.search(date)),
        "byline_n": len([b for b in byline if str(b).strip()]),
        "body_chars": body_chars,
        "paras": len(paras),
        "paywall_hits": paywall,
        "access": access_sig,
    }

    reasons: list[str] = []
    if len(title) < min_title:
        reasons.append(f"title_too_short({len(title)})")
    if not metrics["has_date"]:
        reasons.append("no_date")
    if metrics["byline_n"] < 1:
        reasons.append("no_byline")
    if body_chars < min_body:
        reasons.append(f"body_too_short({body_chars}<{min_body})")
    if len(paras) < min_paras:
        reasons.append(f"too_few_paras({len(paras)}<{min_paras})")
    if not accessible:
        reasons += access_reasons          # login_required / maybe_truncated
    if paywall:
        reasons.append("paywall_text")
    return (not reasons), reasons, metrics


def status_of(ok: bool) -> str:
    """入库状态：只有完整解析才允许 `raw/queued`，否则 `failed`（**正文不入库**）。"""
    return "queued" if ok else "failed"


def judge_loaded(body: str, html: str = "", reference_chars: int = 0) -> tuple[bool, list[str], dict]:
    """Owner 口径（2026-10-14 定稿）：**完整性 = 页面是否加载完整**。

    判据（**不看停留时长、不看段落数、不看日期作者**）：
      ① 正文容器抽到了内容（非空）；
      ② 页面里**没有**"没加载完 / 要登录订阅才能继续"的迹象（墙文案/墙元素/被截断）；
      ③ 若拿到**源站公布的全文字数**（RSS `<content:encoded>`，独立参照）→ 我的正文不得明显短于它
         （<85% 判不完整：说明这页被墙/没加载完）。这条是硬标尺，替换我先前那些软判据。
    """
    from .access_check import judge_access
    body_chars = len(re.sub(r"\s+", "", body or ""))
    ok_access, a_reasons, sig = judge_access(html or "", body or "")
    reasons: list[str] = []
    if body_chars < 1:
        reasons.append("no_body")
    if not ok_access:
        reasons += a_reasons
    ratio = 0.0
    if reference_chars:
        ratio = body_chars / reference_chars
        if ratio < 0.85:
            reasons.append(f"shorter_than_source({body_chars}<{int(reference_chars * 0.85)})")
    return (not reasons), reasons, {"body_chars": body_chars, "reference_chars": reference_chars,
                                    "ratio": round(ratio, 2), "access": sig, "judge": "loaded"}
