"""通用抓取 web.capture —— 正文级抽取 + 登录态探针（t-6c302f69）。

把专用工具 `tools/physicsworld` 通用化，而不是重写它：

1) **优先直传**：调用方（浏览器插件/已登录的有头浏览器）把渲染好的 `html` 或纯 `text`
   直接 POST 上来 → 就地抽取，**不落盘、不联网**（隐私：受限全文默认不长期保存）。
2) **兜底抓取**：无直传时才用 Playwright + 该 agent 的 `.pwprofile`（登录态复用）打开 URL。
3) **正文级抽取**：Readability 风格算法（主文/标题/作者/日期/主图），替换原来
   `body.inner_text()[:5000]`（带导航/图注噪音的截断）。**纯标准库、零依赖、确定性**，
   因此可离线单测（scripts/test_capture.py）。
4) **登录有效性探针**：不再用「页面文本匹配 Sign out」这种不可靠口径；改为访问一个
   已知需登录的账户页，**断言登录后特征**（有登出/账户菜单）**或反向断言未登录特征**
   （有 `type=password` 登录表单 / 被重定向到 sign-in），并返回**证据**（决定性标记 + 命中片段）。

红线（与 docs/83 一致）：
  · **默认不落盘**：`capture()` 返回正文但不写文件（`persisted=False`）；受限全文不入库。
  · **不绕付费墙**：抓不到就停，不模拟登录、不破解；登录态只来自使用者自己的 `.pwprofile`。
  · **零依赖**：只用 Python 标准库（html.parser / re / json / urllib），不进任何第三方包。

数据源优先级：本队自建资产 > 官方一手源 > 第三方/API。本任务的"数据"是**网页正文本身**
（一手页面），由调用方浏览器直传或本机 profile 兜底抓取，属"一手源"，无需外部 API。
"""
from __future__ import annotations

import html as _html
import json
import re
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124 Safari/537.36")
MAX_TEXT = 40000            # 抽取正文上限（字符），防超大页
MIN_ARTICLE = 400           # 低于此长度视为抽取失败 → 回退（与旧 extract_main 语义一致）
MIN_PARA = 25               # 计入候选的段落最小长度

# ---------------------------------------------------------------- 不可见/噪声标签
_SKIP_TAGS = {"script", "style", "noscript", "template", "svg", "iframe", "canvas",
              "nav", "header", "footer", "aside", "form", "figure", "figcaption"}
_VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
         "param", "source", "track", "wbr"}
_BLOCK = {"p", "div", "section", "article", "main", "ul", "ol", "li", "h1", "h2", "h3",
          "h4", "h5", "h6", "blockquote", "pre", "table", "tr", "td", "br", "header",
          "footer", "nav", "aside", "figure", "figcaption", "hr"}

_UNLIKELY = re.compile(
    r"(?i)(combx|comment|com-|contact|foot|footer|footnote|masthead|media|meta|outbrain|"
    r"promo|related|scroll|shoutbox|sidebar|sponsor|shopping|tags|tool|widget|share|social|"
    r"newsletter|subscribe|subscription|cookie|banner|breadcrumb|nav|menu|advert|ad-|-ad|"
    r"byline|author-box|recirc|most-popular|recommend|pagination|paywall|gdpr|consent|"
    r"site-header|site-footer|top-bar|utility)")
_MAYBE = re.compile(
    r"(?i)(\barticle\b|\bbody\b|\bcontent\b|entry|hentry|h-entry|\bmain\b|\bpage\b|"
    r"post|text|blog|story|article-body|entry-content|post-content)")
_NEGATIVE = _UNLIKELY


# ---------------------------------------------------------------- 极简 DOM
class _Node:
    __slots__ = ("tag", "attrs", "children", "parent", "parts")

    def __init__(self, tag: str, attrs: dict, parent):
        self.tag = tag
        self.attrs = attrs
        self.children: list[_Node] = []
        self.parent = parent
        self.parts: list[str] = []

    # 自身（含后代）的可见文本
    def text(self) -> str:
        out = []
        for p in self.parts:
            out.append(p)
        for c in self.children:
            out.append(c.text())
        return "".join(out)

    def cls_id(self) -> str:
        return " ".join(str(self.attrs.get(k, "")) for k in ("class", "id", "role"))


class _Parser:
    """极简容错 HTML → DOM。只关心结构/文本，不追求完整 HTML5 规则。"""

    def __init__(self) -> None:
        self.root = _Node("__root__", {}, None)
        self.stack = [self.root]

    def feed(self, html: str) -> _Node:
        # 1) 先去注释 / CDATA，避免误判标签
        html = re.sub(r"<!--[\s\S]*?-->", " ", html)
        html = re.sub(r"<!\[CDATA\[[\s\S]*?\]\]>", " ", html)
        token = re.compile(r"<(/?)([a-zA-Z][a-zA-Z0-9:-]*)((?:\s+[^<>]*?)?)(/?)>")
        pos = 0
        for m in token.finditer(html):
            data = html[pos:m.start()]
            if data:
                self._data(data)
            pos = m.end()
            closing, tag, attrs_s, selfclose = m.group(1), m.group(2).lower(), m.group(3), m.group(4)
            if tag in ("!doctype", "br") and closing == "!":
                continue
            if closing:
                self._end(tag)
            else:
                node = _Node(tag, _attrs(attrs_s), self.stack[-1])
                self.stack[-1].children.append(node)
                if not selfclose and tag not in _VOID:
                    self.stack.append(node)
        if html[pos:]:
            self._data(html[pos:])
        return self.root

    def _data(self, data: str) -> None:
        # 折叠空白；保留单空格
        t = data.replace("\u00a0", " ")
        if t.strip():
            self.stack[-1].parts.append(t)

    def _end(self, tag: str) -> None:
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return


def _attrs(s: str) -> dict:
    d: dict[str, str] = {}
    for m in re.finditer(r"([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s\"'>]+)", s or ""):
        k = m.group(1).lower()
        v = m.group(2).strip("\"'")
        d[k] = _html.unescape(v)
    return d


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", _html.unescape(s or "")).strip()


# ---------------------------------------------------------------- meta 抽取
def _meta(html: str, *names: str) -> str:
    for n in names:
        for pat in (rf'<meta[^>]+(?:property|name)=["\']{re.escape(n)}["\'][^>]*?content=["\']([^"\']*)["\']',
                    rf'<meta[^>]+content=["\']([^"\']*)["\'][^>]*?(?:property|name)=["\']{re.escape(n)}["\']'):
            m = re.search(pat, html, re.I)
            if m and _norm(m.group(1)):
                return _norm(m.group(1))
    return ""


def _title_from_html(html: str) -> str:
    m = re.search(r"<title[^>]*>([\s\S]*?)</title>", html, re.I)
    if not m:
        return ""
    t = _norm(m.group(1))
    # 去掉尾部站名（"… – Physics World" / "… | Site"）
    return re.sub(r"\s*[–—|·\-]\s*[^–—|·\-]{0,40}$", "", t).strip() or t


def _first_h1(root: _Node) -> str:
    for n in _iter(root):
        if n.tag == "h1":
            t = _norm(n.text())
            if len(t) >= 8:
                return t
    return ""


def _iter(node: _Node):
    for c in node.children:
        yield c
        yield from _iter(c)


def _find(root: _Node, tag: str):
    for n in _iter(root):
        if n.tag == tag:
            return n
    return None


def _make_abs(base_url: str, src: str) -> str:
    if not src:
        return ""
    if src.startswith(("http://", "https://")):
        return src
    if src.startswith("//"):
        return "https:" + src
    p = urlsplit(base_url)
    if src.startswith("/"):
        return f"{p.scheme}://{p.netloc}{src}"
    return f"{p.scheme}://{p.netloc}/{src.lstrip('./')}"


# ---------------------------------------------------------------- 链接密度
def _link_density(node: _Node) -> float:
    total = len(_norm(node.text()))
    if total == 0:
        return 0.0
    link_len = sum(len(_norm(a.text())) for a in _iter(node) if a.tag == "a")
    return link_len / total


# ---------------------------------------------------------------- 打分抽取（Readability 风格）
def _score_blocks(root: _Node) -> dict:
    scores: dict[int, float] = {}
    blocks = [n for n in _iter(root) if n.tag in ("p", "pre", "td", "blockquote", "li")]
    for b in blocks:
        txt = _norm(b.text())
        if len(txt) < MIN_PARA:
            continue
        if _has_unlikely_ancestor(b):
            continue
        base = 1.0 + txt.count(",") + min(len(txt) / 100.0, 3.0)
        parent = b.parent
        if parent is None:
            continue
        scores[id(parent)] = scores.get(id(parent), 0.0) + base
        gp = parent.parent
        if gp is not None:
            scores[id(gp)] = scores.get(id(gp), 0.0) + base / 2.0
    return scores


def _is_unlikely(node: _Node) -> bool:
    """Readability 官方口径：命中 unlikely **且未**命中 maybe 才算可疑。

    例：`the-content equalize-sidebar` 同时含 sidebar（负面）与 content（正面）→ **不算**可疑；
    否则整篇正文的祖先链会被误杀（实测：该容器下所有 <p> 被排除，抽取退化到登录提示框）。
    """
    s = node.cls_id()
    return bool(s) and bool(_UNLIKELY.search(s)) and not bool(_MAYBE.search(s))


def _has_unlikely_ancestor(node: _Node) -> bool:
    p = node.parent
    depth = 0
    while p is not None and depth < 6:
        if p.tag in _SKIP_TAGS or _is_unlikely(p):
            return True
        p = p.parent
        depth += 1
    return False


def _class_weight(node: _Node) -> float:
    w = 0.0
    s = node.cls_id()
    if not s:
        return w
    if _NEGATIVE.search(s):
        w -= 25.0
    if _MAYBE.search(s):
        w += 25.0
    return w


def _candidate_score(node: _Node, scores: dict) -> float:
    return scores.get(id(node), 0.0) + _class_weight(node) - _link_density(node) * 10.0


def _collect_paragraphs(node: _Node) -> list[str]:
    """从候选容器收集段落文本（p/h2/h3/blockquote/pre/li），跳过短块与噪声子块。"""
    out: list[str] = []
    seen: set[str] = set()
    for n in _tree_order(node):
        if n.tag in _SKIP_TAGS:
            continue
        if _is_unlikely(n):
            continue
        if n.tag in ("p", "h2", "h3", "h4", "blockquote", "pre"):
            t = _norm(n.text())
            if len(t) < 15:
                continue
            # 段内有链接且链接密度极高 → 判为导航/相关阅读
            if n.tag == "p" and _link_density(n) > 0.6 and len(t) < 80:
                continue
            key = t[:80]
            if key in seen:
                continue
            seen.add(key)
            out.append(t)
    return out


def _tree_order(node: _Node):
    yield node
    for c in node.children:
        yield from _tree_order(c)


def extract_main(html: str, url: str = "") -> dict:
    """Readability 风格正文抽取；失败时回退到 article/main/body 最长段落集（零回归）。"""
    html = html or ""
    title = (_meta(html, "og:title", "twitter:title") or _title_from_html(html))
    byline = _meta(html, "article:author", "author", "og:article:author", "twitter:creator")
    date = _meta(html, "article:published_time", "datePublished", "og:article:published_time",
                 "pubdate", "date", "dc.date", "sailthru.date")
    site = _meta(html, "og:site_name") or (urlsplit(url).netloc if url else "")
    images: list[str] = []
    og_img = _meta(html, "og:image", "twitter:image")
    if og_img:
        images.append(_make_abs(url, og_img))

    root = _Parser().feed(html)
    for t in ("script", "style", "noscript", "template", "svg", "iframe"):
        for n in list(_iter(root)):
            if n.tag == t:
                n.parts = []
                n.children = []

    scores = _score_blocks(root)
    candidates = [n for n in _iter(root) if id(n) in scores]
    best, best_score, method = None, -1e9, "score"
    for c in candidates:
        s = _candidate_score(c, scores)
        if s > best_score:
            best, best_score = c, s
    # 向上找更合适的父容器（父分更高则上移）
    if best is not None:
        node, guard = best, 0
        while node.parent is not None and guard < 3:
            if _candidate_score(node.parent, scores) > best_score:
                node = node.parent
                best_score = _candidate_score(node, scores)
                guard += 1
            else:
                break
        best = node

    paras = _collect_paragraphs(best) if best is not None else []
    text = "\n\n".join(paras).strip()

    # h1 只用于补标题
    if not title:
        title = _first_h1(root) or ""
    title = _strip_site_suffix(title, site)

    # 正文内图片（去重，绝对 URL）
    if best is not None:
        for n in _tree_order(best):
            if n.tag == "img":
                src = n.attrs.get("src") or n.attrs.get("data-src") or ""
                src = _make_abs(url, src)
                if src and src not in images:
                    images.append(src)

    # 回退：article / main / body 里最长 <p> 集（与旧 extract_main 同口径，保底不更差）
    if len(text) < MIN_ARTICLE:
        alt = _fallback_longest(html)
        if len(alt) > len(text):
            text, method = alt, "fallback"

    footer = _footer_note(html)
    if footer and not byline:
        byline = footer

    return {
        "title": title,
        "byline": byline,
        "date": date,
        "site": site,
        "text": text[:MAX_TEXT],
        "images": images[:8],
        "source_url": url,
        "method": method,
        "text_len": len(text[:MAX_TEXT]),
    }


def _strip_site_suffix(title: str, site: str) -> str:
    """去掉标题尾部的站名（"… – Physics World"）。"""
    t = _norm(title)
    if not t:
        return t
    for tail in {site, site.replace(" ", ""), site.replace(" ", "-")}:
        if tail:
            t = re.sub(rf"\s*[–—|\-·]\s*{re.escape(tail)}\s*$", "", t, flags=re.I).strip()
    return t


def _footer_note(html: str) -> str:
    m = re.search(r'(?i)<meta[^>]+name=["\'](?:sailthru\.author|parsely-author|author)["\'][^>]+content=["\']([^"\']+)', html)
    if m and re.search(r"(?i)(wogan|editor|correspondent|reporter|staff)", m.group(1)):
        return _norm(m.group(1))
    return ""


def _fallback_longest(html: str) -> str:
    """旧 extract_main 的兜底：<article> > <main> > <body> 里 <p> 文本长度最大的一组。"""
    best = ""
    for pat in (r"<article[\s\S]*?</article>", r"<main[\s\S]*?</main>", r"<body[\s\S]*?</body>"):
        for m in re.finditer(pat, html, re.I):
            ps = re.findall(r"<p[\s>][\s\S]*?</p>", m.group(0), re.I)
            paras = []
            for p in ps:
                t = _norm(re.sub(r"<[^>]+>", " ", p))
                if len(t) >= 40:
                    paras.append(t)
            joined = "\n\n".join(paras)
            if len(joined) > len(best):
                best = joined
    return best


def body_inner_text(html: str) -> str:
    """近似浏览器 `document.body.innerText`：body 内按文档序取可见文本，块级换行。

    仅用于**对照证据**（证明 Readability 抽取的噪音更少），不作为产出。
    注意：这里**只**去掉脚本/样式等不可见标签，**保留** nav/header/footer/aside 文本
    ——因为浏览器 innerText 本来就会把这些导航/页脚噪音一并吐出来。
    """
    invis = {"script", "style", "noscript", "template", "svg", "iframe", "canvas"}
    root = _Parser().feed(html or "")
    body = _find(root, "body") or root
    lines: list[str] = []

    def walk(n: _Node) -> None:
        if n.tag in invis:
            return
        if n.tag in _BLOCK and lines and lines[-1] != "":
            lines.append("")
        if n.tag not in _VOID:
            for p in n.parts:
                t = _norm(p)
                if t:
                    lines.append(t)
        for c in n.children:
            walk(c)
        if n.tag in _BLOCK:
            lines.append("")

    for c in body.children:
        walk(c)
    out = []
    for ln in lines:
        if ln == "" and (not out or out[-1] == ""):
            continue
        out.append(ln)
    return "\n".join(out).strip()


# ---------------------------------------------------------------- 登录态探针
# 已知需登录的「账户页」：未登录会带 password 登录表单；已登录会有登出/账户菜单。
ACCOUNT_URL = "https://physicsworld.com/account/"
SIGNIN_HINT = re.compile(r"(?i)(sign[-_ ]?in|log[-_ ]?in|login)")
SIGNOUT_LINK = re.compile(r"(?i)(sign[-_ ]?out|log[-_ ]?out)")


def _probe_from_html(html: str, final_url: str, status: int = 200) -> dict:
    has_password = bool(re.search(r"type=[\"']password", html or "", re.I))
    has_signin_form = bool(re.search(r"(?i)<form[^>]+(log|sign)[-_]?in", html or ""))
    has_signout = bool(SIGNOUT_LINK.search(html or ""))
    redirected_to_signin = bool(SIGNIN_HINT.search(urlsplit(final_url).path))
    account_kitchen = bool(re.search(r"(?i)(my\s+account|account\s+dashboard|signed\s+in\s+as)", html or ""))

    if has_signout and not has_password:
        verdict = "valid"
        reason = "账户页出现登出/账户菜单且无密码登录表单"
    elif has_password or has_signin_form or redirected_to_signin:
        verdict = "invalid"
        reason = "账户页出现密码登录表单 / 被重定向到登录页（未登录）"
    elif account_kitchen:
        verdict = "valid"
        reason = "账户页出现已登录特征（my account / signed in as）且无密码表单"
    else:
        verdict = "unknown"
        reason = "页面既无登录表单也无登录后特征，无法判定"

    evidence = {
        "probe_url": ACCOUNT_URL, "final_url": final_url, "http_status": status,
        "has_password_input": has_password, "has_signin_form": has_signin_form,
        "has_signout_link": has_signout, "redirected_to_signin_path": redirected_to_signin,
        "has_account_marker": account_kitchen, "matched": reason,
        "snippet": _snippet_for(html or "", has_password, has_signout),
    }
    return {"logged_in": verdict == "valid", "verdict": verdict, "reason": reason, "evidence": evidence}


def _snippet_for(html: str, has_password: bool, has_signout: bool) -> str:
    pat = (r'type=["\']password[\s\S]{0,120}' if has_password
           else (r'(?i)(sign|log)[-_ ]?out[\s\S]{0,80}' if has_signout else r".{0,0}"))
    if not pat:
        return ""
    m = re.search(pat, html)
    return _norm(re.sub(r"<[^>]+>", " ", m.group(0)))[:120] if m else ""


def probe_login(agent: str = "bob", url: str = ACCOUNT_URL, headed: bool = False,
                html: str | None = None, timeout: int = 25) -> dict:
    """登录态探针：返回 {logged_in, verdict, reason, evidence}。

    html 直传时只做离线判定（不联网）；否则用该 agent 的 .pwprofile 打开账户页实采。
    """
    if html is not None:
        d = _probe_from_html(html, url or ACCOUNT_URL)
        d["evidence"]["source"] = "upload"
        return d
    try:
        got = fetch_url(url, agent=agent, headed=headed, timeout=timeout)
        d = _probe_from_html(got["html"], got["final_url"], got.get("status", 200))
        d["evidence"]["source"] = got.get("source", "playwright")
        return d
    except Exception as e:  # noqa: BLE001
        return {"logged_in": False, "verdict": "unknown", "reason": f"抓取失败：{type(e).__name__}",
                "evidence": {"probe_url": url, "error": str(e)[:200], "source": "playwright"}}


# ---------------------------------------------------------------- 抓取（直传优先，profile 兜底）
def _profile(agent: str) -> Path:
    p = ROOT / "agents" / agent / ".pwprofile"
    p.mkdir(parents=True, exist_ok=True)
    return p


def fetch_url(url: str, agent: str = "bob", headed: bool = False, timeout: int = 30) -> dict:
    """无直传时的兜底：用该 agent 的 .pwprofile 打开 URL，取渲染后的 DOM。

    返回 {html, final_url, status, source}；Playwright 不可用时退到 urllib（无 JS、无登录态）。
    """
    try:
        return _fetch_playwright(url, agent, headed, timeout)
    except Exception:  # noqa: BLE001
        return _fetch_urllib(url, timeout)


def _fetch_playwright(url: str, agent: str, headed: bool, timeout: int) -> dict:
    # 默认绝不弹可见窗口；只有显式 TEAMAI_ALLOW_HEADED=1 才允许（排障/登录）。
    headed = bool(headed and os.environ.get("TEAMAI_ALLOW_HEADED") == "1")
    from playwright.sync_api import sync_playwright  # 延迟导入：无 playwright 也能用直传路径
    with sync_playwright() as pw:
        ctx = pw.chromium.launch_persistent_context(str(_profile(agent)), headless=not headed,
                                                    viewport={"width": 1440, "height": 1000})
        try:
            pg = ctx.new_page()
            resp = pg.goto(url, wait_until="domcontentloaded", timeout=max(timeout, 15) * 1000)
            pg.wait_for_timeout(1200)
            html = pg.content()
            return {"html": html, "final_url": pg.url,
                    "status": (resp.status if resp else 200), "source": "playwright:profile"}
        finally:
            ctx.close()


def _fetch_urllib(url: str, timeout: int = 30) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return {"html": r.read().decode("utf-8", "ignore"), "final_url": r.url,
                "status": getattr(r, "status", 200), "source": "urllib"}


# ---------------------------------------------------------------- 顶层：capture
def capture(url: str | None = None, html: str | None = None, text: str | None = None,
            mode: str = "text", agent: str = "bob", headed: bool = False,
            allow_network: bool = True, timeout: int = 30) -> dict:
    """抓取/抽取一页。**优先用调用方直传的 html/text**；无直传才联网（profile 兜底）。

    mode: "text"（默认）| "html"。返回 {title, byline, date, text, images[], source_url, ...}。
    **默认不落盘**（persisted=False）——受限全文不长期保存（docs/83 红线）。
    """
    src = "upload:text" if (text and not html) else ("upload:html" if html else "fetch")
    meta_html = html or ""
    not_fetched = html is not None or text is not None

    if html:
        art = extract_main(html, url or "")
    elif text:
        art = {"title": "", "byline": "", "date": "", "site": (urlsplit(url).netloc if url else ""),
               "images": [], "method": "upload", "source_url": url or "",
               "text": text, "text_len": len(text)}
    elif url and allow_network:
        got = fetch_url(url, agent=agent, headed=headed, timeout=timeout)
        meta_html = got["html"]
        art = extract_main(got["html"], got.get("final_url") or url)
        src = got.get("source", "fetch")
    else:
        raise ValueError("需要 url，或直传 html/text 之一")

    # 直传 text 时补标题/日期（从 url 或首行），不联网
    if text and not html:
        first = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
        art["title"] = art.get("title") or first[:120]
    if not art.get("source_url"):
        art["source_url"] = url or ""

    out = {
        "title": art.get("title", ""),
        "byline": art.get("byline", ""),
        "date": art.get("date", ""),
        "text": art.get("text", ""),
        "images": art.get("images", []),
        "source_url": art.get("source_url", "") or (url or ""),
        "site": art.get("site", ""),
        "text_len": len(art.get("text", "") or ""),
        "mode": mode,
        "method": art.get("method", ""),
        "source": src,
        "persisted": False,          # 默认不落盘（受限全文不入库）
        "fetched": not not_fetched,  # False = 用了直传（未联网）
    }
    return out


def to_json(d: dict) -> str:
    return json.dumps(d, ensure_ascii=False, indent=2)
