"""采集查重（信源台 M1 的最小可交付）：**canonical_url + 正文内容哈希** 双键。

Owner 口径（docs/83 §3）：命中即**只更新 last_seen**，不重复入库、不重复加工。
- canonical_url：剥 utm_*/fbclid/gclid/ref、去锚点、host 小写、去尾部斜杠、剥常见 index 尾。
- content_key：正文归一（去空白/大小写）后 sha1 —— 防"同一篇换 URL 再采一遍"。
"""
from __future__ import annotations

import hashlib
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

DROP_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
               "fbclid", "gclid", "ref", "referrer", "spm", "from", "share_token"}


def canonical_url(url: str) -> str:
    if not url:
        return ""
    try:
        s = urlsplit(url.strip())
    except Exception:  # noqa: BLE001
        return url.strip()
    q = [(k, v) for k, v in parse_qsl(s.query, keep_blank_values=True) if k.lower() not in DROP_PARAMS]
    path = re.sub(r"/index\.(html?|php)/*$", "/", s.path, flags=re.I)   # 先脱 index 尾（允许尾斜杠）
    path = re.sub(r"/+$", "", path) or "/"                              # 再统一去尾斜杠
    return urlunsplit((s.scheme.lower() or "https", s.netloc.lower(), path, urlencode(q), ""))


def content_key(text: str) -> str:
    norm = re.sub(r"\s+", "", (text or "").lower())
    return hashlib.sha1(norm.encode("utf-8", "ignore")).hexdigest()


def judge(existing_urls: set[str] | list[str], existing_hashes: set[str] | list[str],
          url: str, text: str) -> dict:
    """返回 {duplicate, reason, canonical_url, content_hash}。"""
    cu, ch = canonical_url(url), content_key(text)
    eu = set(existing_urls or [])
    eh = set(existing_hashes or [])
    if cu and cu in eu:
        return {"duplicate": True, "reason": "canonical_url", "canonical_url": cu, "content_hash": ch}
    if ch and ch in eh:
        return {"duplicate": True, "reason": "content_hash", "canonical_url": cu, "content_hash": ch}
    return {"duplicate": False, "reason": "new", "canonical_url": cu, "content_hash": ch}
