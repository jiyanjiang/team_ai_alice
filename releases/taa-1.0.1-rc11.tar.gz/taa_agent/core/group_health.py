"""Phase 5 group-chat health: command -> task -> inbox visibility."""
from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from . import chatwork, group_command, outbox, presence


def _age_seconds(value: str | None) -> int | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if not dt.tzinfo:
            dt = dt.replace(tzinfo=timezone.utc)
        return max(0, int((datetime.now(timezone.utc) - dt).total_seconds()))
    except ValueError:
        return None


def _inbox_path(agent: str, task_id: str) -> Path:
    # P1.5：与写入端 / brief_gc 同源（core.db.AGENTS_DIR），不再各算各的
    from .db import brief_inbox
    return brief_inbox(agent) / f"{task_id}.json"


def snapshot(conn, room_id: str = "") -> dict:
    group_command.ensure(conn)
    presence.ensure(conn)
    where = " WHERE room_id=?" if room_id else ""
    args = (room_id,) if room_id else ()
    commands = [dict(r) for r in conn.execute(
        "SELECT * FROM group_command" + where + " ORDER BY created_at DESC LIMIT 20", args)]
    states = Counter(str(r["state"] or "") for r in commands)
    task_rows = conn.execute(
        "SELECT status,COUNT(*) n FROM tasks GROUP BY status").fetchall()
    tasks = {str(r["status"]): int(r["n"]) for r in task_rows}
    missing_inbox = []
    for r in commands:
        if r.get("task_id") and r.get("state") in ("queued", "running"):
            target = str(r.get("target_agent_id") or "")
            tr = conn.execute("SELECT status FROM tasks WHERE id=?", (r["task_id"],)).fetchone()
            if tr and str(tr["status"] or "") not in ("claimed", "in_progress"):
                continue
            if target and not _inbox_path(target, str(r["task_id"])).is_file():
                missing_inbox.append({"command_id": r["id"], "task_id": r["task_id"],
                                      "target_agent_id": target})
    pres_rows = conn.execute("SELECT online,COUNT(*) n FROM presence GROUP BY online").fetchall()
    pres = {str(r["online"]): int(r["n"]) for r in pres_rows}
    rooms = [dict(r) for r in conn.execute(
        "SELECT id,status,title FROM rooms WHERE center_group_id IS NOT NULL "
        "AND center_group_id!='' ORDER BY id").fetchall()]
    room = conn.execute("SELECT id,status,title FROM rooms WHERE id=?", (room_id,)).fetchone() if room_id else None
    transport = None
    transport_warning = ""
    if room_id:
        try:
            tr = conn.execute("SELECT center_group_id,center_peer_endpoints FROM rooms WHERE id=?",
                              (room_id,)).fetchone()
            if tr:
                eps = json.loads(str(tr["center_peer_endpoints"] or "[]"))
                eps = eps if isinstance(eps, list) else []
                transport = {"center_group_id": str(tr["center_group_id"] or ""),
                             "endpoints": len(eps)}
                if tr["center_group_id"] and not eps:
                    transport_warning = "center_peer_endpoints_empty"
        except Exception:
            transport = None
    pending = [r for r in commands if r.get("state") == "pending_consent"]
    overdue = [r for r in pending if r.get("consent_deadline") and
               str(r["consent_deadline"]) < group_command._now()]
    outbox_rows = outbox.pending(conn, room_id, limit=50)
    stale_outbox = [r for r in outbox_rows
                    if (_age_seconds(r.get("created_at_utc")) or 0) > 30]
    ok = not missing_inbox and not overdue and not stale_outbox
    return {
        "ok": ok,
        "room": dict(room) if room else None,
        "rooms": rooms,
        "commands": commands,
        "command_states": dict(states),
        "pending_consent": len(pending),
        "overdue_consent": len(overdue),
        "tasks": tasks,
        "missing_inbox": missing_inbox,
        "unsynced": len(outbox_rows),
        "outbox_pending": outbox_rows,
        "outbox_stale": len(stale_outbox),
        "presence": pres,
        "transport": transport,
        "transport_warning": transport_warning,
        "source": "local",
    }
