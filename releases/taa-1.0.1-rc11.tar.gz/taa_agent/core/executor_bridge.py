"""本地会话 → opencode 执行器桥。

设计边界：
- 只有本地 Flask 的「执行」按钮（或 /exec 前缀）才会触发；普通聊天不触发。
- 同一房间同一 agent 同时只跑一个任务。
- 执行发生在项目根目录，使用本机 opencode + 本机模型 Key；不经过中心。
"""
from __future__ import annotations

import os
import pathlib
import re
import sqlite3
import subprocess
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from . import executor_jobs
from .db import DB_PATH as _CANON_DB

ROOT = pathlib.Path(__file__).resolve().parent.parent
# P1A/A1：统一 canonical 库，不再 fallback 到 cwd/data.db
DB = pathlib.Path(os.environ.get("TEAMAI_UI_DB") or _CANON_DB)
LOG = ROOT / "runtime" / "executor.log"
RUNNING: set[tuple[str, str, str]] = set()
WORKERS: set[str] = set()
WORKERS_LOCK = threading.Lock()
LOCK = threading.Lock()
# 单机并发工位：父体与子体都算一个槽；默认 4，按机器/额度调（见 docs/332）。
POOL = ThreadPoolExecutor(max_workers=int(os.environ.get("TEAMAI_EXEC_WORKERS", "4")),
                          thread_name_prefix="taa-exec")
_WARM = {"at": 0.0, "ok": False, "ms": 0, "busy": False}


def _log(line: str) -> None:
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
    except OSError:
        pass


FEED_MIN_SECONDS = int(os.environ.get("TEAMAI_FEED_MIN_SECONDS", "300"))


def write_task_feed(room: str, agent: str, agent_name: str, task: str, text: str,
                    log_path: str = "", elapsed: float = 0.0, ok: bool = True) -> str | None:
    """长任务成功后落一条结构化 Feed；使用已有摘要，不额外调用 LLM。

    幂等键 = room + agent + 原始任务；重复执行只保留一条。
    """
    if not ok or elapsed < FEED_MIN_SECONDS:
        return None
    import hashlib
    import re as _re
    from core import community, redaction
    key = hashlib.sha256(f"{room}:{agent}:{task}".encode("utf-8")).hexdigest()[:16]
    mark = f"<!-- taa-exec-feed:{key} -->"
    task_line = " ".join((task or "").split())[:180]
    summary = (text or "").strip()[:1800]
    feed_body = (
        f"{mark}\n"
        f"## 长任务复盘\n"
        f"**任务**：{task_line or '（未记录任务描述）'}\n\n"
        f"**结论/验证**\n{summary or '执行完成，但没有可读摘要。'}\n"
        + (f"\n**完整输出**：`{log_path}`\n" if log_path else "")
    )
    try:
        if not redaction.scan(feed_body)["pass"]:
            # Keep the long-task recap useful: remove only high-risk tokens
            # (absolute paths/keys), then re-check the redacted body.
            feed_body = redaction.redact(feed_body)
            if not redaction.scan(feed_body)["pass"]:
                _log(f"feed skipped room={room} agent={agent} reason=redaction")
                return None
    except Exception:
        pass
    c = _conn()
    try:
        if c.execute("SELECT 1 FROM posts WHERE body LIKE ? LIMIT 1", (mark + "%",)).fetchone():
            return None
        task_id = next(iter(_re.findall(r"\bt-[0-9a-f]{8}\b", task or "")), None)
        title = "长任务复盘 · " + (task_line[:72] or "执行完成")
        try:
            from core import community as _community
            # P1.6：统一走 create_post_and_emit —— 复盘帖也必须发 post.created，
            # 否则 B 机拉不到这条帖，链接在 B 机就是 404。
            pid = _community.create_post_and_emit(
                c, agent, "#projects/team-ai", "note", feed_body,
                title=title[:160], tags=["长任务", "复盘"], task_id=task_id,
                kind="public_channel", visibility="public")
        except Exception:
            # 频道/额度异常时直接落一条最小 Feed，不让复盘丢失。
            import uuid
            pid = "p-" + uuid.uuid4().hex[:8]
            c.execute("INSERT INTO posts(id,channel_id,author_id,type,title,body,tags,status,"
                      "kind,visibility,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,"
                      "datetime('now','localtime'),datetime('now','localtime'))",
                      (pid, "#general", agent, "note", title[:160], feed_body,
                       '["长任务", "复盘"]', "published", "public_channel", "public"))
            c.commit()
            # P1.6：兜底直插也必须补事件，否则这条帖子在对端就是死链
            try:
                from core import community as _cm
                from core.net.events import emit as _emit_evt
                _emit_evt("post.created", _cm.post_event_payload(
                    pid, agent, "#general", "note", feed_body,
                    title=title[:160], tags=["长任务", "复盘"]))
            except Exception:  # noqa: BLE001
                pass
        _log(f"feed written room={room} agent={agent} post={pid} elapsed={int(elapsed)}s")
        return pid
    except Exception as e:  # noqa: BLE001
        _log(f"feed failed room={room} agent={agent}: {e}")
        return None
    finally:
        c.close()


def publish_result(room: str, agent: str, agent_name: str, task: str, text: str,
                   log_path: str = "", ok: bool = True) -> str | None:
    """Write the executor result to the forum, for one chat link back.

    The chat line is only a pointer; the full result lives in a post so it can
    be read, quoted, searched and linked without flooding the room.
    """
    import hashlib
    import re as _re
    from core import community, redaction
    task_line = " ".join((task or "").split())[:180]
    marker = "<!-- taa-exec-result:" + hashlib.sha256(
        f"{room}:{agent}:{task_line}".encode("utf-8")).hexdigest()[:16] + " -->"
    body = (
        f"{marker}\n"
        f"## 执行结果\n"
        f"**任务**：{task_line or '（未记录）'}  \n"
        f"**执行者**：{agent_name}（{agent}）  \n"
        f"**状态**：{'成功' if ok else '失败'}\n\n"
        f"{text.strip()[:12000] or '（无输出）'}"
        # P1.6：绝不把本机绝对路径写进跨机可见的正文——那在对端就是一个打不开的死链。
        + (f"\n\n**完整输出**：`{os.path.basename(str(log_path))}`"
           "（本机日志，跨机不可读；以正文摘要为准）" if log_path else "")
    )
    try:
        if not redaction.scan(body)["pass"]:
            body = redaction.redact(body)
    except Exception:
        pass
    c = _conn()
    try:
        old = c.execute("SELECT id FROM posts WHERE body LIKE ? LIMIT 1",
                        (marker + "%",)).fetchone()
        if old:
            return str(old["id"])
        title = ("执行结果 · " + (task_line[:70] or "已完成"))
        task_id = next(iter(_re.findall(r"\bt-[0-9a-f]{8}\b", task or "")), None)
        try:
            # P1.6：结果帖统一入口（必发 post.created；附件走 manifest）
            pid = community.create_post_and_emit(
                c, agent, "#projects/team-ai", "artifact", body,
                title=title[:160], tags=["执行结果", "executor"], task_id=task_id,
                kind="public_channel", visibility="public")
        except Exception:
            import uuid
            pid = "p-" + uuid.uuid4().hex[:8]
            c.execute("INSERT INTO posts(id,channel_id,author_id,type,title,body,tags,status,"
                      "kind,visibility,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,"
                      "datetime('now','localtime'),datetime('now','localtime'))",
                      (pid, "#projects/team-ai", agent, "artifact", title[:160], body,
                       '["执行结果", "executor"]', "published", "public_channel", "public"))
            # P1.6：兜底直插也必须补事件（结果帖是对端最常点的那条）
            try:
                from core.net.events import emit as _emit_evt
                _emit_evt("post.created", community.post_event_payload(
                    pid, agent, "#projects/team-ai", "artifact", body,
                    title=title[:160], tags=["执行结果", "executor"]))
            except Exception:  # noqa: BLE001
                pass
        c.commit()
        return str(pid)
    except Exception as exc:  # noqa: BLE001
        _log(f"result post failed room={room} agent={agent}: {exc}")
        return None
    finally:
        c.close()


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout = 30000")
    return c


def _say(room: str, agent: str, body: str, source: str = "executor",
         kind: str = "assertion") -> None:
    # D7：默认值曾是 "opencode"，于是没显式传 source 的回聊会被记成 opencode——
    # codebuddy/claude 跑完也顶着 opencode 的徽标（"谁说的"失真）。默认改成中性的
    # `executor`，调用点能拿到真实后端名时一律显式传 `source=bname`。
    c = _conn()
    try:
        row = c.execute("SELECT current_round FROM rooms WHERE id=?", (room,)).fetchone()
        rnd = int(row["current_round"] or 1) if row else 1
        ident = c.execute("SELECT owner_id,kind FROM agents WHERE id=?", (agent,)).fetchone()
        cur = c.execute(
            "INSERT INTO room_messages(room_id,round,agent_id,body,kind,created_at,source,"
            "sender_owner_id,sender_kind) "
            "VALUES(?,?,?,?, ?, datetime('now','localtime'), ?,?,?)",
            (room, rnd, agent, body[:4000], kind, source,
             str(ident["owner_id"]) if ident and ident["owner_id"] else None,
             str(ident["kind"]) if ident and ident["kind"] else None))
        mid = int(cur.lastrowid or 0)
        c.commit()
        if mid:
            try:
                from core import app_ui
                payload = app_ui._ws_payload(c, room, mid)
                if payload:
                    app_ui._ws_broadcast(room, {"type": "message", "message": payload})
            except Exception:  # noqa: BLE001
                pass
    finally:
        c.close()


def notice(room: str, agent: str, body: str) -> None:
    """规则提示只进系统事件，不进聊天正文。

    聊天正文只允许真实 agent 回复；规则的“未找到本机执行器”不应伪装成 agent 回执。
    """
    _say(room, agent, body, source="system", kind="system")


def _clean(text: str) -> str:
    try:
        from core.dm_runtime import clean_llm_text
        out = clean_llm_text(text or "")
    except Exception:  # noqa: BLE001
        out = (text or "").strip()
    return out.strip()


def _save_raw(room: str, agent: str, body: str, raw: str, backend: str = "opencode") -> str:
    try:
        d = ROOT / "runtime" / "executor"
        d.mkdir(parents=True, exist_ok=True)
        name = f"{time.strftime('%Y%m%d-%H%M%S')}-{room}-{agent}.md"
        p = d / name
        p.write_text(f"# {backend or 'executor'} raw output\n\n- room: {room}\n- agent: {agent}\n"
                     f"- instruction: {body}\n\n```\n{raw[:200_000]}\n```\n", encoding="utf-8")
        return str(p.relative_to(ROOT))
    except OSError:
        return ""


def classify_failure(text: str, returncode: int | None = None) -> tuple[str, str]:
    """把执行失败归一成可行动类型，而不是把整段 CLI 输出丢给人。"""
    low = (text or "").lower()
    # DNS/network must be checked before `returncode is None`, because a resolver
    # failure often exits with no numeric code and would otherwise be mislabeled
    # as a task timeout.
    if ("enotfound" in low or "getaddrinfo" in low or "name or service not known" in low
            or "nodename nor servname" in low or "temporary failure in name resolution" in low
            or "econnreset" in low or "etimedout" in low or "fetch failed" in low
            or "network is unreachable" in low or "no route to host" in low):
        return "network_dns", "DNS/网络暂时不可用；已自动重试（2/5/60 秒，约 1 分钟）仍失败。请检查 Wi-Fi/DNS/VPN，并运行 scripts/net_diagnose.py。"
    if "startup_hang" in low:
        # 与"任务太大跑不完"分开：这类是执行器**没启动起来**，重试只会重复卡死。
        return "startup_hang", ("执行器启动后长时间无任何输出（守护进程/DNS 僵死）。"
                                "已终止；请重启本地 opencode 服务后重试，不用把任务拆小。")
    if returncode is None or "timed out" in low or "timeout" in low:
        return "timeout", "执行超时；检查任务是否过大或网络/模型是否卡住。"
    if "no such file" in low or "not found" in low or "未找到命令" in low:
        return "missing_cli", "找不到执行器命令；检查 opencode 安装与 PATH。"
    if "401" in low or "403" in low or "unauthorized" in low or "api key" in low or "invalid key" in low:
        return "auth", "模型 Key 无效或权限不足；到设置检查团队 Key。"
    if "permission denied" in low or "eacces" in low:
        return "permission", "当前用户没有执行权限；检查文件/目录权限。"
    if "usage:" in low or "positional arguments" in low:
        return "bad_command", "执行器只拿到命令帮助；检查任务参数。"
    return "executor_error", "执行器返回非零状态；详见归档输出。"


def verify_success(text: str, returncode: int | None = None) -> tuple[bool, str]:
    """Do not trust rc=0 alone; reject empty output and error traces."""
    raw = (text or "").strip()
    if returncode not in (None, 0):
        return False, f"returncode={returncode}"
    if not raw:
        return False, "empty output"
    low = raw.lower()
    # A successful run may contain a transient DNS error from one tool call
    # while a later retry produced the artifact.  Do not mark the whole task
    # failed just because the string appears somewhere in the transcript.
    success_evidence = bool(re.search(
        r"(?im)(exit(?: code)?\s*[:=]?\s*0\b|✅|通过|已验证|ok\s+engine|"
        r"\bPNG\b|\bbytes\b|产出|产物路径)", raw))
    if re.search(r"(?im)^\s*(?:error|traceback|exception)\s*:", low) and not success_evidence:
        return False, "error trace in output"
    for marker in ("enotfound", "getaddrinfo", "permission denied", "unauthorized",
                   "invalid api key", "command not found"):
        if marker in low:
            if marker in ("enotfound", "getaddrinfo") and success_evidence:
                continue
            return False, marker
    if re.search(r"(?im)^\s*usage:\s", low) and len(raw) < 1200:
        return False, "tool help only"
    return True, "ok"


def warm() -> dict:
    """只预热 CLI 进程解析，不调用模型、不消耗 token。"""
    if _WARM["ok"] and time.time() - _WARM["at"] < 600:
        return dict(_WARM)
    if _WARM["busy"]:
        return dict(_WARM)
    _WARM["busy"] = True
    t0 = time.time()
    # P1.8：把"首条"要付的固定成本提前付掉——重模块导入 + SQLite 首次打开。
    try:
        import core.app_ui  # noqa: F401
        from core import db as _db
        _c = _db.connect()
        try:
            _c.execute("select 1").fetchone()
        finally:
            _c.close()
    except Exception:                                            # noqa: BLE001
        pass
    try:
        from core.llm import available as llm_available, get as llm_get
        # D7：不再写死 opencode —— 谁装了预热谁，装多个时取第一个可用的。
        names = [n for n, ok in llm_available().items() if ok] or ["opencode"]
        name = names[0]
        adapter = llm_get(name)
        cmd = adapter.build("", model=None, cwd=str(ROOT))
        # 只跑 --version，不把空 prompt 交给模型。
        exe = cmd[0] if cmd else name
        subprocess.run([exe, "--version"], cwd=str(ROOT), stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=5)
        _WARM.update({"at": time.time(), "ok": True, "backend": name,
                      "ms": int((time.time() - t0) * 1000), "busy": False})
        _log(f"warm ok backend={name} ms={_WARM['ms']}")
    except Exception as e:  # noqa: BLE001
        _WARM.update({"at": time.time(), "ok": False, "ms": int((time.time() - t0) * 1000), "busy": False})
        _log(f"warm failed: {e}")
    return dict(_WARM)


def warm_async() -> None:
    if _WARM["ok"] or _WARM["busy"]:
        return
    threading.Thread(target=warm, name="taa-exec-warm", daemon=True).start()


def health() -> dict:
    """轻量预检：不调用模型，不消耗 token。"""
    # D7：报告**所有**后端，而不是只看 opencode。`cli` 字段保持旧语义（首个同步后端）。
    backends: dict[str, bool] = {}
    try:
        from core.llm import available as llm_available
        backends = llm_available()
    except Exception:  # noqa: BLE001
        backends = {}
    sync_names = [n for n, ok in backends.items() if ok and n != "codebuddy"]
    cli = bool(sync_names)
    supervisors = []
    try:
        for lock in (ROOT / "runtime").glob(".supervisor.*.lock"):
            try:
                pid = int(lock.read_text(encoding="utf-8").strip() or "0")
                if pid and os.kill(pid, 0) is None:
                    supervisors.append({"agent": lock.name[len(".supervisor."):-len(".lock")],
                                        "pid": pid})
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        pass
    return {"ok": bool(cli), "cli": (sync_names[0] if sync_names else "未找到"),
            "backends": backends, "warm_backend": str(_WARM.get("backend") or ""),
            "supervisor": bool(supervisors), "supervisor_pids": supervisors,
            "dispatcher_expected": bool(supervisors),
            "running": len(RUNNING), "workers": 2,
            "warm": bool(_WARM.get("ok")), "warm_ms": int(_WARM.get("ms") or 0)}


def _elapsed_text(seconds: float) -> str:
    return f"{int(seconds)}s" if seconds < 60 else f"{int(seconds // 60)}m{int(seconds % 60):02d}s"


_HELP_LINE = re.compile(r"^\s*(usage|options|positional arguments)\s*:", re.I)
_REPORT_LINE = re.compile(
    r"^\s*(?:#|##|###|[-*]\s|\d+[.)、）]\s*)?"
    r"(?:结论|验证|产物|风险|未完成|完成|做了什么|下一步|摘要|summary|done|result)",
    re.I)


def _looks_like_help(text: str) -> bool:
    """只有“开头就是命令帮助”才算 help；不能因为尾部工具轨迹出现 usage 就误判。"""
    lines = [ln.strip() for ln in (text or "").replace("\r", "").splitlines() if ln.strip()]
    if not lines:
        return False
    head = "\n".join(lines[:12])
    if not any(_HELP_LINE.match(ln) for ln in lines[:12]):
        return False
    # 有真实报告结构时，帮助行只是过程中的工具输出。
    if _REPORT_LINE.search(head) or _REPORT_LINE.search((text or "")[:5000]):
        return False
    return True


def _strip_tool_trace(text: str) -> str:
    """截掉 opencode 末尾的 shell / 文件浏览轨迹，避免混进摘要。"""
    # 只截行首的 shell 命令/工具输出，不碰报告正文里的 inline code。
    m = re.search(r"(?m)^\s*\$\s+(?:cat|ls|cd|echo|git|python|shasum|file|stat|du|find|grep)\b", text or "")
    if m:
        text = text[:m.start()]
    m2 = re.search(r"(?m)^\s*---\s*(?:WORKING|files|ignored)\s*---", text or "")
    if m2:
        text = text[:m2.start()]
    return text.strip()


def summarize_output(text: str, instruction: str = "") -> str:
    """把 opencode 的原始输出压成人类可读摘要；完整输出留在 executor.log。"""
    raw = _clean(text or "")
    if not raw:
        return "执行完成，但没有返回可读输出。"
    body = _strip_tool_trace(raw)
    if _looks_like_help(body):
        return ("执行结束，但这次只拿到工具帮助/环境输出，没有形成可读结果。"
                "请确认指令是否缺参数；完整输出已写入 runtime/executor.log。")
    # 去掉围栏代码的正文，保留标题/结论/验证等可读行。
    text = re.sub(r"```[\s\S]*?```", "\n[代码块已折叠，完整内容见 executor.log]\n", body)
    lines = [ln.strip() for ln in text.replace("\r", "").splitlines()]
    keep = []
    for ln in lines:
        if not ln:
            continue
        if len(ln) > 420:                 # 长命令行/JSON/日志行不刷屏
            continue
        # 同时接受 1) / 2、/ 3） / 4. 等真实报告编号
        if re.match(r"^(#|##|###|[-*] |\d+[.)、）]\s*|结论|完成|验证|产物|风险|未完成|已|修复|新增|改动|测试)", ln, re.I):
            keep.append(ln)
        elif not keep and len(ln) >= 12:
            keep.append(ln)
        if len("\n".join(keep)) >= 1500:
            break
    out = "\n".join(keep).strip()
    if not out:
        out = text.strip()[:900]
    if len(out) > 1800:
        out = out[:1800].rstrip() + "…"
    return out + ("\n\n（完整过程与代码：runtime/executor.log）" if len(raw) > 1800 or "```" in raw else "")


def should_execute(body: str) -> bool:
    """群聊 @agent 的意图门：状态/解释类问题走 chatwork 快速回复，动作类才开 opencode。"""
    text = (body or "").strip()
    if re.match(r"^\s*/(?:exec|run)\b", text, re.I):
        return True
    # Do not use a narrow command-verb whitelist: users naturally say
    # “推荐/调研/发布/写/总结/分析/搜索/画”.  These are execution intents too.
    action = re.search(
        r"执行|修复|实现|改成|跑一下|测试|生成|部署|提交|写|做|安装|构建|调试|"
        r"抓取|读取|整理|优化|新增|删除|更新|迁移|运行|验证|检查|推荐|调研|研究|"
        r"发布|创建|设计|画|绘制|搜索|搜一下|查找|查询|总结|分析|解释|翻译|"
        r"列出|上传|下载|排查|诊断|补|改造|替换|清理|同步|对比|统计|计算|提取|"
        r"解析|归档|保存|打开|截图|发到|发送|回帖|回复|报告|写一份|做一份",
        text)
    return bool(action)


def _finish_route(room: str, message_id: int, ok: bool, note: str = "") -> None:
    """把触发这条执行的群消息推进到路由终态（done/failed）。

    P1A 的承诺是"路由表有终态"；此前全库只有 claim 没有 finish，
    所有行永远停在 claimed，只能等租约过期被 GC 成 failed。
    """
    if not room or not message_id:
        return
    try:
        from core import message_route as _mr
        c = _conn()
        try:
            who = _mr.owner(c, room, int(message_id))
            if who:
                _mr.finish(c, room_id=room, message_id=int(message_id), owner=who,
                           state="done" if ok else "failed",
                           note=note or ("executor done" if ok else "executor failed"))
        finally:
            c.close()
    except Exception:  # noqa: BLE001
        pass


_REAPER = {"started": False}
_REAPER_LOCK = threading.Lock()

#: 长任务心跳间隔（秒）。0 = 关闭。默认 180s：15 分钟的任务约 5 条，不刷屏又能证明"还活着"。
HB_SECONDS = int(os.environ.get("TEAMAI_EXEC_HEARTBEAT", "180"))


def _start_heartbeat(room: str, agent: str, task: str, started: float,
                     stop: threading.Event) -> None:
    """执行期间按间隔回报"仍在执行"。

    事故背景：执行器卡住/重试时群里一个字都没有，人只能判断成"死了"。
    """
    if HB_SECONDS <= 0 or not room:
        return

    def _beat() -> None:
        while not stop.wait(HB_SECONDS):
            el = int(time.time() - started)
            try:
                _say(room, agent,
                     f"⏱ 仍在执行 · 已 {el // 60} 分 {el % 60} 秒：{task[:50]}…",
                     source="executor")
            except Exception:  # noqa: BLE001
                pass

    threading.Thread(target=_beat, name="taa-exec-heartbeat", daemon=True).start()


def reap_stale_jobs() -> int:
    """回收"状态 running 但无人 finish"的僵尸作业，并把路由推进终态。

    事故背景（2026-11-01）：子进程到点被杀/线程被杀/服务重启时，finish() 不执行，
    作业永久 running、message_route 永久 claimed（租约过期后被判 failed，与真实结果相反）。
    """
    try:
        c = _conn()
        try:
            rows = executor_jobs.reap_stale(c)
        finally:
            c.close()
    except Exception as e:  # noqa: BLE001
        _log(f"reap failed {type(e).__name__}: {e}")
        return 0
    for job in rows:
        room = str(job.get("room_id") or "")
        try:
            _finish_route(room, int(job.get("message_id") or 0), False,
                          note="executor stale: 超时未回收")
        except Exception:  # noqa: BLE001
            pass
        if room:
            try:
                _say(room, str(job.get("agent_id") or ""),
                     f"⚠ 上一次执行（{(str(job.get('body') or ''))[:40]}…）超时未回收，已判失败；"
                     f"可重新发指令。", source="executor")
            except Exception:  # noqa: BLE001
                pass
    if rows:
        _log(f"reaped stale jobs={len(rows)} ids={[r.get('id') for r in rows]}")
    return len(rows)


def start_reaper(interval: int = 60) -> None:
    """后台定时回收（幂等，只启一次）。"""
    with _REAPER_LOCK:
        if _REAPER["started"]:
            return
        _REAPER["started"] = True

    def _loop() -> None:
        while True:
            try:
                reap_stale_jobs()
            except Exception:  # noqa: BLE001
                pass
            time.sleep(max(15, int(interval)))

    threading.Thread(target=_loop, name="taa-exec-reaper", daemon=True).start()


def _run(room: str, agent: str, agent_name: str, body: str, sub: str = "",
         backend: str = "", message_id: int = 0) -> bool:
    key = (room, agent, sub)
    ok = False
    # 失败分支也要能说清"是谁失败了"，所以在 try 之前先给默认值。
    bname = backend or "executor"
    # P0-6 审计（docs/534 §8.4）：只留痕不拦截。计时/退出码先占位，
    # 这样异常路径在 finally 里也能记上一条（拿不到退出码就记 null，不猜 0）。
    _audit_t0 = time.time()
    _audit_rc: int | None = None
    try:
        task = " ".join((body or "").split())
        try:
            from core import nodeinfo
            where = nodeinfo.saved_alias() or "本机"
        except Exception:
            where = "本机"
        role_tag = f" ·子体 {agent}.{sub}" if sub else ""
        from core.llm import get as llm_get
        adapter = llm_get(backend or "opencode")
        bname = str(getattr(adapter, "name", "") or backend or "opencode")
        _say(room, agent,
             f"⏳ 收到：{task[:120]}\n"
             f"{where}{role_tag} · {bname} 已启动；完成后只回结论/验证/产物摘要，完整输出归档到 runtime/executor/。",
             source=bname)
        started = time.time()
        persona = ""
        if sub:
            from core import subagents as _sa
            try:
                entry = _sa.get_entry(f"{agent}.{sub}")
                persona = _sa.charter(entry) + "\n"
            except Exception as _e:  # noqa: BLE001
                _log(f"subagent charter failed {agent}.{sub}: {_e}")
        prompt = (
            f"{persona}"
            f"你是 Team AI 的 agent「{agent_name}」。人类在本地 TAA 会话里给你下达了执行指令：\n"
            f"{body}\n\n"
            "请在当前项目目录直接执行（可以读写文件、运行命令、测试）。完成后用中文简短汇报：\n"
            "1) 做了什么；2) 验证结果（命令/退出码/测试）；3) 产物路径；4) 未完成项或风险。\n"
            "不要泄露 API Key；不要执行与指令无关的破坏性操作。最终回复只给：1) 结论 2) 验证命令/结果 3) 产物路径 4) 风险；"
            "不要粘贴大段代码、命令帮助、工具轨迹或过程日志。若失败，只用一句说明原因和下一步。"
            "不要启动可见 Chrome/浏览器窗口，除非用户明确要求；需要抓网页时用无头工具。"
        )
        from core.llm import models as _models
        model = os.environ.get("TEAMAI_EXEC_MODEL") or _models.provider("deepseek-flash")
        timeout = int(os.environ.get("TEAMAI_EXEC_TIMEOUT", "900"))
        # 日志写规范名（D8）：以前这里写的是 provider 形态，和实际后端对不上。
        _log(f"start room={room} agent={agent} sub={sub or '-'} backend={bname} "
             f"model={_models.canonical(model)}")
        _stop_beat = threading.Event()
        _start_heartbeat(room, agent, task, started, _stop_beat)
        try:
            res = adapter.run(
                prompt, model=model, cwd=str(ROOT),
                title=f"taa-exec:{agent}:{room[-8:]}", timeout=timeout)
            _audit_rc = getattr(res, "returncode", None)
        finally:
            _stop_beat.set()
        # 启动器型执行器（如 CodeBuddy GUI）：只能打开窗口，拿不到 stdout。
        # 这里**不核验、不发结果帖**，只如实说"已启动"——伪造"执行完成"会让人
        # 以为活干完了，正是 2026-10-30 "ACK + 结果帖"那类噪音的同一个病根。
        # 启动器型（只能开窗口、拿不到 stdout）：如实说"已启动"，不伪造"完成"。
        _interactive = (adapter.interactive() if callable(getattr(adapter, "interactive", None))
                        else bool(getattr(adapter, "INTERACTIVE", False)))
        if _interactive:
            ok = bool(res.ok)
            _say(room, agent,
                 f"🖥 {bname} 已在窗口启动" + ("；结果请在该窗口查看。" if ok
                                          else f"；启动失败：{_clean(res.text)[:200]}"),
                 source=bname)
            _log(f"launched room={room} agent={agent} backend={bname} ok={ok}")
            return ok
        raw = _clean(res.text or "")
        text = summarize_output(raw, body)
        log_path = _save_raw(room, agent, body, raw, backend=bname)
        elapsed = _elapsed_text(time.time() - started)
        verified, verify_reason = verify_success(raw, res.returncode)
        ok = bool(res.ok and verified)
        if not res.ok:
            kind, hint = classify_failure(raw, res.returncode)
            text = f"❌ 执行失败 · {kind} · {elapsed}\n{hint}\n{text}"[:2400]
        elif not verified:
            text = f"❌ 执行未通过核验 · {verify_reason} · {elapsed}\n{text}"[:2400]
        else:
            text = f"✅ 执行完成 · {elapsed}\n{text}"
        if log_path:
            text += f"\n完整输出：{log_path}"
        post_id = publish_result(room, agent, agent_name, task, text, log_path, ok=ok)
        if post_id:
            first = " ".join(text.splitlines()[1:3]).strip()[:220]
            _say(room, agent, f"📌 执行结果已发帖：/app/p/{post_id}\n{first}".strip(), source=bname)
        else:
            _say(room, agent, text[:3800], source=bname)
        _log(f"done room={room} agent={agent} ok={ok} rc={res.returncode} "
             f"verified={verified} reason={verify_reason} elapsed={elapsed} post={post_id}")
        return ok
    except Exception as e:  # noqa: BLE001
        kind, hint = classify_failure(str(e))
        _log(f"error room={room} agent={agent} kind={kind}: {e}\n{traceback.format_exc()[:1200]}")
        try:
            _say(room, agent, f"❌ 执行失败 · {kind}\n{hint}\n（详情见 runtime/executor.log）",
                 source=bname)
        except Exception:  # noqa: BLE001
            pass
        return False
    finally:
        with LOCK:
            RUNNING.discard(key)
        _finish_route(room, message_id, ok)
        # P0-6：一条执行 = 一行审计。record() 内部吞掉所有异常，绝不拖垮执行。
        try:
            from core import audit as _audit
            _audit.record(actor=f"{agent}.{sub}" if sub else agent, tool=bname,
                          args=body or "", exit_code=_audit_rc,
                          duration_ms=int((time.time() - _audit_t0) * 1000),
                          ok=ok, source="executor", extra={"room": room})
        except Exception:  # noqa: BLE001
            pass


def _single_local_agent(room: str) -> str:
    """房间里唯一的本机 AI（answer 兜底用；多 AI 房返回空，避免替别人说话）。"""
    try:
        ais = _local_ais(room)
    except Exception:  # noqa: BLE001
        return ""
    return ais[0][0] if len(ais) == 1 else ""


def route_saved_message(room: str, text: str, *, message_id: int,
                        client_message_id: str = "", prefixed: bool = False) -> str:
    """消息**落库之后**的唯一裁决入口（由后台线程调用，不阻塞 HTTP）。

    顺序：抢所有权 → LLM 裁决 → answer 单句 / execute 派给执行器 / ignore。
    抢不到所有权（别的消费者已认领）直接返回，绝不重复动作。

    返回 "execute" | "answer" | "ignore" | "skipped"，便于自检与日志。
    """
    from core import intent_router
    from core import message_route as _mr

    if not room or not message_id:
        return "skipped"

    c = _conn()
    try:
        got = _mr.claim(c, room_id=room, message_id=int(message_id),
                        client_message_id=client_message_id, owner="direct_executor")
    finally:
        c.close()
    if not got:
        _log(f"route skip room={room} msg={message_id}: 已被其他 owner 认领")
        return "skipped"

    targets = resolve(room, text) if text else []
    agent_name = targets[0].name if targets else ""
    agent_id = targets[0].agent if targets else ""
    d = intent_router.decide(text, agent=agent_name, agent_id=agent_id,
                             room=room, mention=bool(targets))
    _log(f"route room={room} msg={message_id} action={d.action} "
         f"backend={d.backend or '-'} source={d.source} reason={d.reason}")

    if d.action == "answer":
        who = agent_id or _single_local_agent(room)
        if not who or not d.reply:
            _finish_route(room, message_id, False, "answer without target")
            return "ignore"
        _say(room, who, d.reply[:2000], source="chatwork")
        _finish_route(room, message_id, True, "answered")
        return "answer"

    if d.action == "execute":
        if not targets:
            notice(room, "system",
                   "⚠ 没有本机可执行对象：请 @ 本机 agent；远程 agent 要在它自己的电脑上执行。")
            _finish_route(room, message_id, False, "no local target")
            return "ignore"
        for t in targets:
            ok, msg = submit(room, t.agent, t.name, text, sub=t.sub,
                             dedupe_key=client_message_id, backend=d.backend,
                             message_id=message_id)
            if not ok:
                notice(room, t.agent, f"⚠ {msg}")
        return "execute"

    _finish_route(room, message_id, True, "ignored")
    return "ignore"


def _worker(agent: str) -> None:
    try:
        while True:
            c = _conn()
            try:
                job = executor_jobs.claim_next(c, agent)
            finally:
                c.close()
            if not job:
                break
            key = (job["room_id"], agent, str(job.get("sub_agent") or ""))
            with LOCK:
                RUNNING.add(key)
            ok = False
            err = ""
            try:
                ok = bool(_run(job["room_id"], agent, agent, job["body"],
                               sub=str(job.get("sub_agent") or ""),
                               backend=str(job.get("backend") or ""),
                               message_id=int(job.get("message_id") or 0)))
            except Exception as exc:  # noqa: BLE001
                err = f"{type(exc).__name__}: {exc}"
            finally:
                with LOCK:
                    RUNNING.discard(key)
                c = _conn()
                try:
                    executor_jobs.finish(c, str(job["id"]), ok, err)
                finally:
                    c.close()
    finally:
        with WORKERS_LOCK:
            WORKERS.discard(agent)


def _start_worker(agent: str) -> None:
    with WORKERS_LOCK:
        if agent in WORKERS:
            return
        WORKERS.add(agent)
    POOL.submit(_worker, agent)


def resume_workers() -> None:
    # 启动即回收：服务重启后，上一轮挂在 running 的作业不会自己出来。
    reap_stale_jobs()
    start_reaper()
    c = _conn()
    try:
        agents = executor_jobs.queued_agents(c)
    finally:
        c.close()
    for agent in agents:
        _start_worker(agent)


def submit(room: str, agent: str, agent_name: str, body: str, sub: str = "",
           dedupe_key: str = "", backend: str = "",
           message_id: int = 0) -> tuple[bool, str]:
    """提交一次执行；返回 (accepted, message)。sub 非空表示子 agent 角色。

    backend 为空 = 由执行器侧按 `agents/<id>/backend` / 注册表默认值决定；
    message_id 用于执行结束把 `message_route` 推进到终态（done/failed）。
    """
    if os.environ.get("TEAMAI_EXEC_DISABLED") == "1":
        return False, "执行器已被 TEAMAI_EXEC_DISABLED=1 关闭"
    body = (body or "").strip()
    if not body:
        return False, "空指令"
    warm_async()
    c = _conn()
    try:
        jid, status = executor_jobs.enqueue(
            c, agent=agent, room=room, body=body, sub=sub, dedupe_key=dedupe_key,
            backend=backend, message_id=message_id)
    finally:
        c.close()
    if not jid:
        return False, "执行队列写入失败"
    if status in ("queued", "running"):
        _start_worker(agent)
        return True, "已排队" if status == "queued" else "执行中"
    return True, "已完成"


def is_group(room: str) -> bool:
    """群聊：成员 >2，或包含多个 AI。"""
    c = _conn()
    try:
        row = c.execute("select count(*) n, sum(a.kind='ai') ai from room_members m "
                        "join agents a on a.id=m.agent_id where m.room_id=?", (room,)).fetchone()
        return bool(row and (int(row["n"] or 0) > 2 or int(row["ai"] or 0) > 1))
    finally:
        c.close()


@dataclass(frozen=True)
class Target:
    """一次执行目标：父 agent + 可选子角色（sub 为空 = 父本体）。"""
    agent: str
    name: str
    sub: str = ""


def _local_ais(room: str, *, owner_id: str | None = None,
               node_id: str | None = None, alias: str | None = None
               ) -> list[tuple[str, str, str]]:
    """Room AIs that belong to this owner/node (explicit args are test hooks)."""
    c = _conn()
    try:
        from core import nodeinfo
        local = (nodeinfo.saved_alias() or "") if alias is None else alias
        local_owner = ""
        local_node = ""
        if owner_id is None or node_id is None:
            try:
                from taa_node_v05.identity import load_state
                home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
                st = load_state(home)
                if owner_id is None:
                    local_owner = str(getattr(st.center, "owner_id", "") or "")
                if node_id is None:
                    local_node = str(getattr(st.node, "node_id", "") or "")
            except Exception:  # noqa: BLE001
                pass
        if owner_id is not None:
            local_owner = owner_id
        if node_id is not None:
            local_node = node_id
        sql = ("SELECT a.id,a.name,a.owner_name FROM room_members m JOIN agents a ON a.id=m.agent_id "
               "WHERE m.room_id=? AND a.kind='ai' AND coalesce(a.full_name,'') NOT LIKE '%@center' ")
        args: list = [room]
        if local_owner:
            # A remote agent must never become local merely because it has a
            # nice display name or a missing node_id.
            sql += "AND (a.owner_id IS NULL OR a.owner_id='' OR a.owner_id=?) "
            args.append(local_owner)
        # Older installs store the node alias here, newer ones store nod_*.
        node_ids = [x for x in (local, local_node) if x]
        if node_ids:
            sql += "AND (a.node_id IS NULL OR a.node_id='' OR a.node_id IN (%s)) " % ",".join("?" * len(node_ids))
            args.extend(node_ids)
        sql += "ORDER BY m.rowid"
        rows = c.execute(sql, args).fetchall()
    finally:
        c.close()
    return [(r["id"], r["name"] or r["id"], r["owner_name"] or "") for r in rows]


def resolve(room: str, body: str, *, owner_id: str | None = None,
            node_id: str | None = None) -> list[Target]:
    """把群聊 @ 解析成本机执行目标（含子 agent 角色）。

    - DM 只有一个 AI：直接返回父本体；
    - `@bob.dev`：父 bob + 角色 dev（编制里存在才生效）；
    - `@Bob`：精确匹配唯一显示名或 agent_id（不做跨 owner 模糊匹配）；
    - 远程/未知：不作为本机目标。

    `owner_id` / `node_id` 是本机身份显式覆盖（沿用 `_local_ais` 的测试钩子）：
    跨机拉取时调用方已知本次同步属于哪个 owner，显式传入可避免依赖 `~/.taa`
    的全局 identity——测试环境与多身份实例下，全局 identity 会把本机 AI 过滤掉。
    """
    ais = _local_ais(room, owner_id=owner_id, node_id=node_id)
    c2 = _conn()
    try:
        kr = c2.execute("SELECT kind FROM rooms WHERE id=?", (room,)).fetchone()
        room_kind = (kr["kind"] if kr else "") or ""
    finally:
        c2.close()
    if len(ais) == 1 and room_kind == "dm":
        return [Target(ais[0][0], ais[0][1])]
    mentions = [m.lower() for m in re.findall(r"@([\w.\-+]{1,80})", body or "")]
    if not mentions:
        return []
    ids = [aid for aid, _, _ in ais]
    names = {aid: name for aid, name, _ in ais}
    owners = {aid: owner for aid, _, owner in ais}
    out: list[Target] = []
    seen: set[tuple[str, str]] = set()
    for raw in mentions:
        token, owner_token = (raw.split("+", 1) + [""])[:2]
        hit = None
        try:
            from core import subagents as _sa
            hit = _sa.resolve_mention(token, ids)
        except Exception:  # noqa: BLE001
            hit = None
        if hit:
            aid, role = hit
            if owner_token and owners.get(aid, "").lower() != owner_token:
                continue
            t = Target(aid, names[aid], role)
            if (t.agent, t.sub) not in seen:
                seen.add((t.agent, t.sub))
                out.append(t)
            continue
        for aid, name, owner in ais:
            al = aid.lower()
            # Exact canonical name/ID only.  Fuzzy substring matching could
            # route "@Alice" to a completely different owner's agent.
            if token == al or token == name.lower():
                if owner_token and owner.lower() != owner_token:
                    continue
                t = Target(aid, name)
                if (t.agent, t.sub) not in seen:
                    seen.add((t.agent, t.sub))
                    out.append(t)
                break
    return out


def targets(room: str, body: str) -> list[tuple[str, str]]:
    """兼容旧调用：只返回 (agent_id, name)，丢弃子角色。"""
    return [(t.agent, t.name) for t in resolve(room, body)]


def strip_prefix(body: str) -> tuple[str, bool]:
    """显式 /exec、/run 前缀视为执行指令。"""
    m = re.match(r"^\s*/(?:exec|run)\s+(.+)$", body or "", re.S | re.I)
    if m:
        return m.group(1).strip(), True
    return (body or "").strip(), False
