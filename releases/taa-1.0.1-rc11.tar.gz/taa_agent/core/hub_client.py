"""跨局域网协作 · 节点侧客户端（只出站，过 NAT）。

设计要点（`docs/405`）：
- **只主动连中心**：节点不需要公网 IP / 端口映射 / 入站规则，家庭网、公司网都一样；
- **push 自己的事件、pull 别人的事件**：中心按 `hub_seq` 递增，节点用本地游标增量拉取，
  不会因为某个时刻中心不可达而丢事件（游标只在成功写入后才推进）；
- **失败绝不阻塞本地**：所有异常只记状态 + 退避重试，本机继续用本地事件日志干活；
- **不回声**：只推 `node_id == 自己` 的事件，从中心拉回的事件不会被再次推回去。

配置（`config.yaml` 或环境变量）：
    hub:
      enabled: true
      url: "https://hub.example.com"   # 环境变量 TEAMAI_HUB_URL
      token: "<强随机串>"               # 环境变量 TEAMAI_HUB_TOKEN
      group: "team-a"                  # 可选；中心按 token 决定组，这里仅用于展示
      interval: 10                     # 秒
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request

UA = "taa-hub-client/1"
PUSH_CURSOR = "hub_push_rowid"
PULL_CURSOR = "hub_pull_seq"


class HubClient:
    def __init__(self, log, url: str, token: str, node_id: str | None = None,
                 group: str = "default", addr: str = "", interval: float = 10.0,
                 batch: int = 200, timeout: float = 8.0, register_every: float = 30.0):
        self.log = log
        self.url = (url or "").rstrip("/")
        self.token = (token or "").strip()
        self.node_id = node_id or getattr(log, "node_id", "node")
        self.group = group or "default"
        self.addr = addr or ""
        self.interval = max(1.0, float(interval or 10))
        self.batch = max(1, int(batch or 200))
        self.timeout = max(1.0, float(timeout or 8))
        self.register_every = max(5.0, float(register_every or 30))

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._last_ok = 0.0
        self._last_error = ""
        self._last_register = 0.0
        self._peers: list[dict] = []
        self._pushed = 0
        self._pulled = 0
        self._ticks = 0
        self._fail_streak = 0

    # ---------------- 生命周期 ----------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="hub-client", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=3)

    def _loop(self) -> None:
        while not self._stop.is_set():
            ok = self.tick()
            self._fail_streak = 0 if ok else min(self._fail_streak + 1, 4)
            delay = self.interval * (2 ** self._fail_streak if self._fail_streak else 1)
            self._stop.wait(min(delay, self.interval * 16))

    # ---------------- 一轮同步 ----------------
    def tick(self) -> bool:
        """执行一轮 register/push/pull；返回本轮是否全部成功（异常不外抛）。"""
        with self._lock:
            self._ticks += 1
        try:
            if time.time() - self._last_register >= self.register_every:
                self._register()
            self._push()
            self._pull()
        except Exception as e:  # noqa: BLE001 —— 任何失败都不得影响本机
            self._mark_error(e)
            return False
        with self._lock:
            self._last_ok = time.time()
            self._last_error = ""
        return True

    def _register(self) -> None:
        body = {"node_id": self.node_id, "addr": self.addr,
                "meta": {"group": self.group, "client": UA}}
        d = self._post("/v1/hub/register", body)
        peers = d.get("peers")
        with self._lock:
            if isinstance(peers, list):
                self._peers = peers[:100]
            # 以中心判定的组为准（token → group 在中心侧），本地 group 仅作展示默认值
            if d.get("group"):
                self.group = str(d["group"])
        self._last_register = time.time()

    def _push(self) -> None:
        cursor = int(self.log.meta_get(PUSH_CURSOR, 0) or 0)
        # 单轮最多 5 批，避免离线积压时一次性把本地卡住
        for _ in range(5):
            events, new_cursor = self.log.own_since(cursor, self.batch)
            if not events:
                return
            d = self._post("/v1/hub/events", {"events": events})
            # 中心去重按 id；accepted+skipped 即「已被中心收下」
            with self._lock:
                self._pushed += int(d.get("accepted") or 0)
            self.log.meta_set(PUSH_CURSOR, new_cursor)
            cursor = new_cursor
            if len(events) < self.batch:
                return

    def _pull(self) -> None:
        cursor = int(self.log.meta_get(PULL_CURSOR, 0) or 0)
        for _ in range(5):
            d = self._get(f"/v1/hub/events?since={cursor}&limit={self.batch}")
            events = d.get("events") or []
            if events:
                added = self.log.merge(events)
                with self._lock:
                    self._pulled += added
            nxt = int(d.get("next_since") or cursor)
            # 即使 next_since 未前进也要落盘（幂等），避免重复拉同一批
            self.log.meta_set(PULL_CURSOR, nxt)
            cursor = nxt
            if not d.get("more"):
                return

    # ---------------- HTTP ----------------
    def _headers(self) -> dict:
        return {"content-type": "application/json", "user-agent": UA,
                "x-hub-token": self.token}

    def _post(self, path: str, body: dict) -> dict:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.url + path, data=data, method="POST",
                                     headers=self._headers())
        return self._open(req)

    def _get(self, path: str) -> dict:
        req = urllib.request.Request(self.url + path, headers=self._headers())
        return self._open(req)

    def _open(self, req) -> dict:
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = (e.read().decode("utf-8", "ignore") or "")[:200]
            except Exception:
                pass
            raise RuntimeError(f"hub HTTP {e.code}: {detail}") from e

    def _mark_error(self, e: Exception) -> None:
        with self._lock:
            self._last_error = f"{type(e).__name__}: {str(e)[:200]}"

    # ---------------- 状态（给 /v1/hub/status；绝不含 token） ----------------
    def status(self) -> dict:
        with self._lock:
            now = time.time()
            return {
                "enabled": True,
                "url": self.url,
                "group": self.group,
                "node_id": self.node_id,
                "connected": bool(self._last_ok and now - self._last_ok < self.interval * 3),
                "last_ok_at": self._last_ok or None,
                "last_error": self._last_error,
                "push_cursor": int(self.log.meta_get(PUSH_CURSOR, 0) or 0),
                "pull_cursor": int(self.log.meta_get(PULL_CURSOR, 0) or 0),
                "pushed": self._pushed,
                "pulled": self._pulled,
                "ticks": self._ticks,
                "peers": list(self._peers),
            }
