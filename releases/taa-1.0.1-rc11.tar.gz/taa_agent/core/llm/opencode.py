"""opencode 适配器：`opencode run --dir <cwd> --model <m> --title <t> "<prompt>" [-f file]`。"""
from __future__ import annotations

from core.binpath import resolve as _resolve

import json
import os
import shutil
import sys
import time
from pathlib import Path

from .base import LLMAdapter

ROOT = Path(__file__).resolve().parent.parent.parent

# 随包声明的可用模型（缺哪个补哪个，不覆盖本地已有）
# deepseek-flash = DeepSeek-V4.1-Flash，input_modalities 含 image → **视觉模型**
DEEPSEEK_MODELS = {
    "deepseek-chat": {"name": "DeepSeek Chat (flash)"},
    "deepseek-reasoner": {"name": "DeepSeek Reasoner"},
    "deepseek-v4-pro": {"name": "DeepSeek V4 Pro"},
    "deepseek-flash": {"name": "DeepSeek V4.1 Flash (vision)"},
    "deepseek-v4-flash-vision-exp": {"name": "DeepSeek V4 Flash Vision Exp"},
}


def _attempt_log(title: str | None, n: int, total: int, elapsed: float, res) -> None:
    """把每一次尝试写进 runtime/executor.log。

    事故教训：旧实现只在 `_run` 开头和结尾各写一行，重试全程不落日志，
    于是"卡住"和"在跑"在日志上长得一模一样。这里补可 grep 的逐次流水。
    """
    try:
        text = getattr(res, "text", "") or ""
        rc = getattr(res, "returncode", None)
        if rc is None:
            status = "startup_hang" if "startup_hang" in text else "timeout"
            # 首行是看门狗写的说明，不算 CLI 的真实输出
            payload = text.split("\n", 1)[1] if "\n" in text else ""
        else:
            status = "ok" if getattr(res, "ok", False) else f"failed rc={rc}"
            payload = text
        t = " ".join(str(title or "-").split())[:60]
        line = (f"{time.strftime('%Y-%m-%d %H:%M:%S')} attempt title={t} "
                f"n={n}/{total} elapsed={elapsed:.1f}s out_bytes={len(payload)} status={status}\n")
        log = ROOT / "runtime" / "executor.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8") as f:
            f.write(line)
    except Exception:  # noqa: BLE001
        pass


def _candidates(name: str) -> list[str]:
    """服务进程 PATH 被收窄（launchd 下只有 /usr/bin:/bin）→ 必须解析**绝对路径**。
    自查：终端里能找到、服务里找不到，就是这个坑（与 ffmpeg 那次同型）。"""
    import os as _os, shutil as _sh
    out = [_os.environ.get("OPENCODE_BIN") or "",
           _sh.which(name) or "",
           f"/opt/homebrew/bin/{name}", f"/usr/local/bin/{name}",
           _os.path.expanduser(f"~/.opencode/bin/{name}"),
           _os.path.expanduser(f"~/.local/bin/{name}"),
           _os.path.expanduser(f"~/.bun/bin/{name}")]
    return [c for c in out if c]


def _bin(name: str = "opencode") -> str:
    return _resolve(name)             # 统一解析（见 core/binpath.py）


def _deepseek_key(root: Path) -> str | None:
    try:
        from .. import config
        k = config.deepseek_key()
        if k:
            return k
    except Exception:
        pass
    for p in (root / "bootstrap" / "deepseek.key",):
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            pass
    return os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("DS_KEY")


def ensure_config(root: Path = ROOT) -> Path | None:
    """确保 `runtime/opencode.deepseek.json` 存在且包含随包声明的模型（合并式）。

    保留本地已有 provider/模型/自定义项；只补缺的模型，并更新 key（若有稳定来源）。
    """
    key = _deepseek_key(root)
    cfg = root / "runtime" / "opencode.deepseek.json"
    try:
        cur = json.loads(cfg.read_text(encoding="utf-8"))
    except Exception:
        cur = {}
    if not key and not cur:
        return None
    cfg.parent.mkdir(parents=True, exist_ok=True)
    prov = cur.setdefault("provider", {}).setdefault("deepseek", {})
    prov.setdefault("npm", "@ai-sdk/openai-compatible")
    prov.setdefault("name", "DeepSeek (self key)")
    opts = prov.setdefault("options", {})
    opts.setdefault("baseURL", "https://api.deepseek.com/v1")
    if key:
        opts["apiKey"] = key
    models = prov.setdefault("models", {})
    for mid, spec in DEEPSEEK_MODELS.items():
        if mid not in models:
            models[mid] = dict(spec)
    cur.setdefault("model", "deepseek/deepseek-flash")
    cfg.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


class OpencodeAdapter(LLMAdapter):
    name = "opencode"

    def available(self) -> bool:
        return _bin() != "opencode" or shutil.which("opencode") is not None

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        # 注意：opencode V2 取消了 `run --dir`；工作目录由 subprocess 的 cwd 决定（base.run 已设）。
        cmd = [_bin(), "run"]
        if model:
            cmd += ["--model", model]
        if title:
            cmd += ["--title", title]
        cmd.append(prompt)
        for f in (files or []):
            cmd += ["-f", f]
        return cmd

    def env(self, extra: dict | None = None) -> dict:
        e = super().env(extra)
        cfg = ROOT / "runtime" / "opencode.deepseek.json"
        if cfg.exists():
            e.setdefault("OPENCODE_CONFIG", str(cfg))
        # Node's getaddrinfo can be blocked by macOS mDNSResponder's partial/
        # negative cache while `dig` still resolves.  The preload falls back to
        # dig only after a normal lookup fails, preserving TLS/SNI.
        guard = ROOT / "core" / "opencode_dns_guard.js"
        if guard.exists():
            old = str(e.get("NODE_OPTIONS") or "").strip()
            e["NODE_OPTIONS"] = ((old + " ") if old else "") + "--require=" + str(guard)
        return e

    @staticmethod
    def _transient(text: str) -> bool:
        low = (text or "").lower()
        return any(x in low for x in (
            "enotfound", "getaddrinfo", "name or service not known",
            "nodename nor servname", "temporary failure in name resolution",
            "econnreset", "socket hang up", "fetch failed", "connection reset",
            "network is unreachable", "no route to host",
            " 429", " 502", " 503", " 504", "rate limit",
        ))

    def run(self, prompt, *, model=None, cwd=".", files=None, title=None,
            timeout: int = 180, env_extra=None, stdin_text=None):
        """Retry transient DNS/network failures without hiding auth failures.

        DNS flakiness on macOS can make Node's resolver fail for one process
        while the next process succeeds.  Retry the whole CLI call with a
        bounded backoff (2/5/60s, ~67s total; the last wait is long enough for macOS negative-cache expiry), then let
        executor_bridge classify it as `network_dns` if it still fails.
        """
        last = None
        backoff = (2, 5, 60)
        attempts = len(backoff) + 1
        for attempt in range(attempts):
            t0 = time.time()
            last = super().run(prompt, model=model, cwd=cwd, files=files, title=title,
                               timeout=timeout, env_extra=env_extra, stdin_text=stdin_text)
            _attempt_log(title, attempt + 1, attempts, time.time() - t0, last)
            # 超时 / 启动卡死（rc=None）一律不重试：重试只会把静默时间放大成 N×timeout
            # （2026-11-01 实测 900s×4 ≈ 1 小时无回音）。
            if last.returncode is None:
                return last
            if not self._transient(last.text):
                return last
            if attempt + 1 < attempts:
                wait = backoff[attempt]
                print(f"[llm] opencode transient network failure; "
                      f"retry {attempt + 2}/{attempts} in {wait}s", file=sys.stderr, flush=True)
                time.sleep(wait)
        return last
