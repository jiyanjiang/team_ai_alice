"""WorkBuddy 适配器（占位 + 完全配置驱动，2026-10-30）。

为什么不写死 CLI 形态：
  执行器会不断换（opencode → qoder → workbuddy → …），把某个厂商的参数写进代码就等于
  把系统钉死在那一版。这里只约定**一条命令模板**，其余交给配置：

  | 变量 | 作用 | 默认 |
  |---|---|---|
  | `TEAM_WORKBUDDY_CMD` | 完整命令模板，支持 `{prompt}` `{cwd}` `{model}` `{title}` | 空 |
  | `TEAM_WORKBUDDY_BIN` | 可执行名/路径（配合默认参数时才用） | `workbuddy` |
  | `TEAM_WORKBUDDY_ARGS` | 追加参数（空格分隔） | 空 |
  | `TEAM_WORKBUDDY_STDIN` | `1` = 提示词走 stdin，不放进 argv | `0` |

未配置 `TEAM_WORKBUDDY_CMD` 且本机找不到 `workbuddy` 时，`available()` 返回 False，
`intent_router.resolve_backend()` 会自动跳过它——**装了就用，没装不报错**。
"""
from __future__ import annotations

import os
import shlex
import shutil

from .base import LLMAdapter


class WorkBuddyAdapter(LLMAdapter):
    name = "workbuddy"

    def _bin(self) -> str:
        return (os.environ.get("TEAM_WORKBUDDY_BIN") or "workbuddy").strip()

    def prompt_via_stdin(self) -> bool:
        return os.environ.get("TEAM_WORKBUDDY_STDIN", "0") == "1"

    def available(self) -> bool:
        if os.environ.get("TEAM_WORKBUDDY_CMD"):
            return True
        return bool(shutil.which(self._bin()))

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        tpl = os.environ.get("TEAM_WORKBUDDY_CMD") or ""
        if tpl:
            s = (tpl.replace("{prompt}", "" if self.prompt_via_stdin() else str(prompt))
                    .replace("{cwd}", str(cwd))
                    .replace("{model}", str(model or ""))
                    .replace("{title}", str(title or "")))
            return [c for c in shlex.split(s) if c != ""]
        cmd = [self._bin()]
        if not self.prompt_via_stdin():
            cmd += ["-p", str(prompt)]
        if cwd:
            cmd += ["--cwd", str(cwd)]
        if model:
            cmd += ["-m", str(model)]
        extra = os.environ.get("TEAM_WORKBUDDY_ARGS", "")
        if extra:
            cmd += shlex.split(extra.replace("{cwd}", str(cwd)))
        for f in (files or []):
            cmd += ["--attachment", str(f)]
        return cmd

    def run(self, prompt, *, model=None, cwd=".", files=None, title=None, timeout=180,
            env_extra=None, stdin_text=None):
        stdin_text = prompt if (self.prompt_via_stdin() and stdin_text is None) else stdin_text
        return super().run(prompt, model=model, cwd=cwd, files=files, title=title,
                           timeout=timeout, env_extra=env_extra, stdin_text=stdin_text)
