"""模型 ID 的单一规范（D8）。

同一个模型在两个命名空间里出现，**不是两个模型**：

| 命名空间 | 形式 | 谁用 |
|---|---|---|
| provider | `deepseek/deepseek-flash` | opencode / qoder / omp 这类 CLI |
| bare | `deepseek-flash` | 直连 HTTP API（research / persona_gen） |

这里只做**等价映射**，不猜新模型、不做能力推断；遇到未知名字原样返回（宁可报错，不可猜错）。
"""
from __future__ import annotations

#: 别名 → 规范名（裸名形态）。左右两边互为同一个模型。
_ALIAS: dict[str, str] = {
    "deepseek/deepseek-flash": "deepseek-flash",
    "deepseek/deepseek-chat": "deepseek-chat",       # 旧别名，指向 flash
    "deepseek/deepseek-v4-pro": "deepseek-v4-pro",
    "deepseek/deepseek-v4-flash-vision-exp": "deepseek-v4-flash-vision-exp",
    "deepseek-v4.1-flash": "deepseek-flash",         # 文档/报告里出现过的小数点写法
    "deepseek-v4.1-pro": "deepseek-v4-pro",
    "deepseek/flash": "deepseek-flash",
    "flash": "deepseek-flash",
    "pro": "deepseek-v4-pro",
}


def canonical(name: str | None) -> str:
    """去命名空间后的规范名；未知名字原样返回。"""
    raw = (name or "").strip()
    if not raw:
        return ""
    return _ALIAS.get(raw, _ALIAS.get(raw.lower(), raw))


def provider(name: str | None) -> str:
    """转成 provider 前缀形态（CLI 用）。非 deepseek 家族原样返回。"""
    bare = canonical(name)
    if not bare:
        return ""
    if "/" in bare:
        return bare
    return f"deepseek/{bare}" if bare.startswith("deepseek") else bare


def for_namespace(name: str | None, namespace: str) -> str:
    """按适配器声明的命名空间输出。不明命名空间一律保留原样，避免误伤。"""
    ns = (namespace or "").strip().lower()
    if ns == "provider":
        return provider(name)
    if ns == "bare":
        return canonical(name)
    return (name or "").strip()
