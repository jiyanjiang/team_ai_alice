"""Qoder 适配器 —— 非交互驱动 Qoder（Win16G / Darwin 实测 v1.1.68）。

实测（Darwin@Win16G，2026-10-13）：
  · 真 CLI 名 = **`qoderclicn`**（`qoder` 只是 IDE 启动 shim，无 CLI 能力）
  · 非交互：`-p/--print "prompt"`；`--no-session-persistence`；`-o/--output-format text|json|stream-json`
  · 上下文：`-w/--cwd`、`--attachment <file>`、`--system-prompt`、`--append-system-prompt`
  · 模型：`-m/--model`、`--reasoning-effort`、`--thinking …`
  · 权限：`--permission-mode default|accept_edits|bypass_permissions|dont_ask|auto`
  · 子命令：login / status / update / mcp / plugins / hooks / skills / commit / **remote-control**
  · **前提**：需先 `qoderclicn login`（OAuth；须人类本机同意）——未登录时 `-p` 会报 "Not logged in"。

可配置环境变量：
| 变量 | 作用 | 默认 |
|---|---|---|
| `TEAM_QODER_BIN` | 可执行名/路径 | `qoderclicn` |
| `TEAM_QODER_CMD` | **完整命令模板**（含 `{prompt}/{cwd}/{model}`；给定时优先，信任配置） | 空 |
| `TEAM_QODER_STDIN` | `1`=提示词走 stdin | `0` |
| `TEAM_QODER_ARGS` | 追加参数（空格分隔） | 空 |
| `TEAM_QODER_OUTPUT` | 输出格式 | `json` |
| `TEAM_QODER_PERMISSION_MODE` | 权限模式 | `bypass_permissions` |
"""
from __future__ import annotations

import os
import shlex
import shutil

from .base import LLMAdapter

#: 候选可执行名（真 CLI 在前；`qoder` 仅作兜底，且会被 available() 的真假校验挡住）
_CANDIDATES = ("qoderclicn", "qoder")


class QoderAdapter(LLMAdapter):
    name = "qoder"

    def _bin(self) -> str:
        env = os.environ.get("TEAM_QODER_BIN")
        if env:
            return env
        for c in _CANDIDATES:
            if shutil.which(c):
                return c
        return "qoderclicn"

    def prompt_via_stdin(self) -> bool:
        return os.environ.get("TEAM_QODER_STDIN", "0") == "1"

    def available(self) -> bool:
        """**不得假阳**：`qoder` 可能是 IDE 启动 shim（`--version` → "CLI is not installed"）。

        以 `--version` 实测（rc==0 且不含 "not installed"）为准；显式给了完整命令模板则信任。
        """
        if os.environ.get("TEAM_QODER_CMD"):
            return True
        b = shutil.which(self._bin())
        if not b:
            return False
        try:
            import subprocess
            r = subprocess.run([b, "--version"], capture_output=True, text=True, timeout=8)
            txt = ((r.stdout or "") + (r.stderr or "")).lower()
            if "not installed" in txt:
                return False
            return r.returncode == 0
        except Exception:  # noqa: BLE001
            return False

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        tpl = os.environ.get("TEAM_QODER_CMD") or ""
        if tpl:
            s = (tpl.replace("{prompt}", "" if self.prompt_via_stdin() else str(prompt))
                    .replace("{cwd}", str(cwd)).replace("{model}", str(model or ""))
                    .replace("{title}", str(title or "")))
            return [c for c in shlex.split(s) if c != ""]
        cmd = [self._bin()]
        if not self.prompt_via_stdin():
            cmd += ["-p", str(prompt)]
        cmd += ["--no-session-persistence",
                "--permission-mode", os.environ.get("TEAM_QODER_PERMISSION_MODE", "bypass_permissions"),
                "--output-format", os.environ.get("TEAM_QODER_OUTPUT", "json")]
        if cwd:
            cmd += ["--cwd", str(cwd)]
        if model:
            cmd += ["-m", model]
        extra = os.environ.get("TEAM_QODER_ARGS", "")
        if extra:
            cmd += shlex.split(extra.replace("{cwd}", str(cwd)))
        for f in (files or []):
            cmd += ["--attachment", str(f)]
        return cmd

    def run(self, prompt, *, model=None, cwd=".", files=None, title=None, timeout=180,
            env_extra=None, stdin_text=None):
        stdin_text = prompt if (self.prompt_via_stdin() and stdin_text is None) else stdin_text
        return super().run(prompt, model=model, cwd=cwd, files=files, title=title,
                           timeout=timeout, env_extra=env_extra, stdin_text=stdin_text)
