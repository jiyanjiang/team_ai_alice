"""CodeBuddy CN 适配器 —— **启动器型**（interactive），不是同步执行器。

实测（2026-10-30，CodeBuddy CN **1.106.1**，本机）：
  · 真 CLI = `buddycn`（`~/.codebuddy/bin/buddycn` → `CodeBuddy CN.app/…/bin/code`）
  · `buddycn --version` → 1.106.1（可用）
  · `buddycn chat [-m agent|ask|edit] [-n|--new-window] <prompt>` → **打开 GUI 窗口**跑 agent
  · `buddycn chat --help` 的选项只有 mode / add-file / maximize / new-window / profile，
    **没有** `-p/--print`、`--output-format`：拿不到 stdout，也拿不到退出码语义

因此本适配器只承诺"**能启动**"，不承诺"能拿结果"：
  `INTERACTIVE = True`，`executor_bridge` 见到这个标记就不做"执行完成/核验"，
  只如实告诉群里"已在窗口启动，结果请在该窗口查看/由 agent 自己回帖"。

为什么不硬造一个 stdout：
  伪造"✅ 执行完成"会让人以为活干完了，而实际结果还在窗口里没提交——
  这正是 2026-10-30 "ACK + 结果帖"那类噪音的同一个病根。

配置（都不需要改代码）：
| 变量 | 作用 | 默认 |
|---|---|---|
| `TEAM_CODEBUDDY_BIN` | 可执行名/路径 | `buddycn`（再回落 `~/.codebuddy/bin/buddycn`） |
| `TEAM_CODEBUDDY_MODE` | chat 模式 | `agent` |
| `TEAM_CODEBUDDY_ARGS` | 追加参数（空格分隔） | 空 |
| `TEAM_CODEBUDDY_CMD` | 完整命令模板（`{prompt}/{cwd}/{model}/{title}`） | 空 |
"""
from __future__ import annotations

import os
import pathlib
import re
import shlex
import shutil
import subprocess

from .base import LLMAdapter, LLMResult

#: 二进制能力探测缓存（进程内）：只缓存 `--help` 的结论，不缓存模型输出。
_CAP_CACHE: dict[str, bool] = {}


class CodebuddyAdapter(LLMAdapter):
    name = "codebuddy"
    #: 类级默认：GUI 启动器。实际是否同步由 `interactive()` 判定（D9）。
    INTERACTIVE = True
    #: 模型名走裸名（codebuddy/codebuddy CLI 不吃 provider 前缀）
    MODEL_NAMESPACE = "bare"

    #: 候选二进制：新版叫 `codebuddy`，老版叫 `buddycn`（本机 1.106.1 只有后者）。
    _CANDIDATES = ("codebuddy", "buddycn")
    _HOME_CANDIDATES = (".codebuddy/bin/codebuddy", ".codebuddy/bin/buddycn")

    def _bin(self) -> str:
        env = (os.environ.get("TEAM_CODEBUDDY_BIN") or "").strip()
        if env:
            return env
        found: list[str] = []
        for name in self._CANDIDATES:
            hit = shutil.which(name)
            if hit:
                found.append(hit)
        for rel in self._HOME_CANDIDATES:
            p = pathlib.Path.home() / rel
            if p.exists():
                found.append(str(p))
        if not found:
            return "buddycn"
        # 优先选支持非交互 `-p` 的那个：能拿 stdout 就不必开 GUI。
        for cand in found:
            if self._supports_print(cand):
                return cand
        return found[0]

    def _supports_print(self, binpath: str) -> bool:
        """只读 `--help` 判断是否支持非交互输出；不调用模型。"""
        key = f"print:{binpath}"
        if key in _CAP_CACHE:
            return _CAP_CACHE[key]
        ok = False
        try:
            r = subprocess.run([binpath, "--help"], capture_output=True, text=True, timeout=6)
            txt = (r.stdout or "") + (r.stderr or "")
            ok = bool(re.search(r"(?m)^\s*(-p|--print)\b", txt))
        except Exception:  # noqa: BLE001
            ok = False
        _CAP_CACHE[key] = ok
        return ok

    def print_mode(self) -> bool:
        return self._supports_print(self._bin())

    def interactive(self) -> bool:
        """同步执行器返回 False；只能开窗口的返回 True。"""
        return not self.print_mode()

    def available(self) -> bool:
        if os.environ.get("TEAM_CODEBUDDY_CMD"):
            return True
        b = self._bin()
        if not (shutil.which(b) or pathlib.Path(b).exists()):
            return False
        try:
            r = subprocess.run([b, "--version"], capture_output=True, text=True, timeout=8)
            return r.returncode == 0
        except Exception:  # noqa: BLE001
            return False

    def build(self, prompt, *, model=None, cwd=".", files=None, title=None):
        tpl = os.environ.get("TEAM_CODEBUDDY_CMD") or ""
        if tpl:
            s = (tpl.replace("{prompt}", str(prompt)).replace("{cwd}", str(cwd))
                    .replace("{model}", str(model or "")).replace("{title}", str(title or "")))
            return [c for c in shlex.split(s) if c != ""]
        if self.print_mode():
            # 非交互：能拿 stdout，按普通同步执行器处理（D9）
            return [self._bin(), "-p", str(prompt)]
        cmd = [self._bin(), "chat",
               "-m", os.environ.get("TEAM_CODEBUDDY_MODE", "agent"),
               "--new-window"]
        for f in (files or []):
            cmd += ["-a", str(f)]
        extra = os.environ.get("TEAM_CODEBUDDY_ARGS", "")
        if extra:
            cmd += shlex.split(extra)
        cmd.append(str(prompt))
        return cmd

    def run(self, prompt, *, model=None, cwd=".", files=None, title=None, timeout=180,
            env_extra=None, stdin_text=None):
        """非交互（有 `-p`）走同步执行；只能开 GUI 时 detached 启动并如实说明。"""
        if self.print_mode():
            return super().run(prompt, model=model, cwd=cwd, files=files, title=title,
                               timeout=timeout, env_extra=env_extra, stdin_text=stdin_text)
        cmd = self.build(prompt, model=model, cwd=cwd, files=files, title=title)
        try:
            subprocess.Popen(cmd, cwd=str(cwd or "."), env=self.env(env_extra),
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        except FileNotFoundError:
            return LLMResult(False, f"[codebuddy] 未找到命令：{cmd[0]}", None)
        except Exception as e:  # noqa: BLE001
            return LLMResult(False, f"[codebuddy] 启动失败：{type(e).__name__}: {e}", None)
        return LLMResult(True,
                         "已在 CodeBuddy 窗口启动（该执行器无终端输出）。\n"
                         "结果请在该窗口查看；需要入库时让 agent 用 `teamai submit` 回帖。",
                         0)
