"""LLM 适配层基类：把"调用某个 coding agent CLI"统一成一个接口。

- 我们**直接调用** LLM/agent CLI（opencode / omp / qoder），不把它当业务状态。
- 统一接口：build()（拼命令，便于单测）+ run()（执行，含超时/杀进程组）。
"""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import threading
import time
from dataclasses import dataclass


@dataclass
class LLMResult:
    ok: bool
    text: str
    returncode: int | None = None


def _kill_group(proc) -> None:
    """杀整个进程组：CLI 会派生孙进程，只杀父会让管道一直被占。"""
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:  # noqa: BLE001
        try:
            proc.kill()
        except Exception:  # noqa: BLE001
            pass


# ---- 成本策略：全队默认模型（Owner 2026-10-14：「所有生成统一用 ds flash，更便宜更快」）----
DEFAULT_MODEL = "deepseek/deepseek-flash"     # DeepSeek V4.1 Flash


def effective_model(model: str | None) -> str:
    """决定"这次到底用哪个模型"——**单一覆盖点**，不必逐个调用点改。

    优先级：config `llm.model` / 环境变量 `TEAMAI_MODEL`（**一律覆盖调用点传参**，便于全局降本）
            > 调用点显式传入 > DEFAULT_MODEL。
    需要临时用贵模型（如 ds v4 pro）：设 `TEAMAI_MODEL=deepseek/deepseek-v4-pro`；
    需要让调用点的显式选择重新生效：设 `TEAMAI_MODEL_ALLOW_OVERRIDE=1`。
    """
    from .. import config as _cfg
    forced = (_cfg.get("llm.model", env="TEAMAI_MODEL") or "").strip()
    if forced and os.environ.get("TEAMAI_MODEL_ALLOW_OVERRIDE") != "1":
        return forced
    return model or forced or DEFAULT_MODEL


class LLMAdapter:
    name = "base"
    #: 模型 ID 命名空间：provider=`deepseek/deepseek-flash`，bare=`deepseek-flash`。
    #: 由 `core.llm.models.for_namespace()` 在 run() 里统一换算（D8）。
    MODEL_NAMESPACE = "provider"

    def available(self) -> bool:
        return True

    def build(self, prompt: str, *, model: str | None = None, cwd: str = ".",
              files: list[str] | None = None, title: str | None = None) -> list[str]:
        raise NotImplementedError
    def env(self, extra: dict | None = None) -> dict:
        e = dict(os.environ)
        if extra:
            e.update(extra)
        return e

    def run(self, prompt: str, *, model: str | None = None, cwd: str = ".",
            files: list[str] | None = None, title: str | None = None, timeout: int = 180,
            env_extra: dict | None = None, stdin_text: str | None = None) -> LLMResult:
        """跑一次 CLI，带**启动看门狗**。

        2026-11-01 实机事故：`opencode run` 连上本地守护进程后 15 分钟零输出
        （日志只有一行 `cli starting`），旧实现要等满 `timeout` 才杀，外层再重试 4 次
        → 一条群消息静默近 1 小时。
        现在：**任何输出都没有**且超过 `TEAMAI_LLM_STARTUP_TIMEOUT`（默认 90s）即判定
        `startup_hang` 并杀进程组，把「启动卡死」与「任务跑太久」区分开。
        """
        from . import models as _models
        _model = _models.for_namespace(effective_model(model), self.MODEL_NAMESPACE)
        cmd = self.build(prompt, model=_model, cwd=cwd, files=files, title=title)
        try:
            proc = subprocess.Popen(cmd, cwd=str(cwd), env=self.env(env_extra),
                                    stdin=(subprocess.PIPE if stdin_text is not None else subprocess.DEVNULL),
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                    start_new_session=True)
        except FileNotFoundError:
            return LLMResult(False, f"[llm] 未找到命令：{cmd[0]}", None)

        startup = int(os.environ.get("TEAMAI_LLM_STARTUP_TIMEOUT", "90") or 90)
        chunks: list[str] = []
        lock = threading.Lock()

        def _pump(stream) -> None:
            """用 os.read 抢字节：read(n) 会等满 n 才返回，判断"有没有输出"不能用它。"""
            try:
                fd = stream.fileno()
                while True:
                    b = os.read(fd, 4096)
                    if not b:
                        break
                    with lock:
                        chunks.append(b.decode("utf-8", "replace"))
            except Exception:  # noqa: BLE001
                pass

        pumps = [threading.Thread(target=_pump, args=(s,), daemon=True)
                 for s in (proc.stdout, proc.stderr)]
        for t in pumps:
            t.start()
        if stdin_text is not None:
            try:
                proc.stdin.write(stdin_text)
                proc.stdin.close()
            except Exception:  # noqa: BLE001
                pass

        started = time.time()
        killed = ""
        while True:
            if proc.poll() is not None:
                break
            elapsed = time.time() - started
            with lock:
                produced = bool(chunks)
            if not produced and startup > 0 and elapsed > startup:
                killed = (f"[llm] startup_hang: 启动 {int(elapsed)}s 无任何输出，"
                          f"判定执行器/守护进程卡死，已终止。")
                break
            if timeout and elapsed > timeout:
                killed = f"[llm] timeout: 超过 {timeout}s，已终止。"
                break
            time.sleep(0.2)

        if killed:
            _kill_group(proc)
        try:
            proc.wait(timeout=10)
        except Exception:  # noqa: BLE001
            _kill_group(proc)
        for t in pumps:
            t.join(2)
        with lock:
            text = "".join(chunks)
        if killed:
            return LLMResult(False, (killed + "\n" + text).strip(), None)
        return LLMResult(proc.returncode == 0, text, proc.returncode)
