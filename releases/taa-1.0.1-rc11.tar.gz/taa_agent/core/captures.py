"""信源台采集索引（M1 剩余件）：`sources` / `captures` / FTS。

Owner 口径（docs/83 §3、docs/84 §0.2）：
  · 采集触发＝**详情页**；**解析不完整＝失败**（`status=failed`，**正文不入库**）；
  · **查重双键**命中 → **只更新 `last_seen`**，不重复入库、不重复加工；
  · 每台机**单写者**（由上层保证），每次写入留痕。

本模块自带建表（不依赖 schema.sql，避免与他人改动冲突）。
"""
from __future__ import annotations

import json
import sqlite3
import time

from .capture_dedupe import canonical_url, content_key, judge as dedupe_judge
from .capture_gate import judge as gate_judge
from .capture_gate import judge_loaded as gate_loaded

DDL = """
CREATE TABLE IF NOT EXISTS sources (
  id TEXT PRIMARY KEY, name TEXT, domain TEXT, notes TEXT,
  style_profile TEXT, channel TEXT, created_at TEXT,
  url_patterns TEXT DEFAULT '[]',   -- ★ 该源「文章详情页」URL 形态（正则数组；fail-closed 用）
  exclude_patterns TEXT DEFAULT '[]', -- ★ 该源「非采集页」形态（栏目/列表/专题；显式拒绝且理由清楚）
  discover_url TEXT DEFAULT ''      -- 仅供**发现**文章链接的入口（首页/栏目页）——**不采集**
);
CREATE TABLE IF NOT EXISTS feed_polls (
  source_id TEXT PRIMARY KEY, at TEXT, items INTEGER, kept INTEGER
);
CREATE TABLE IF NOT EXISTS script_state (
  session_id TEXT PRIMARY KEY, version TEXT, host TEXT, last_seen TEXT
);
CREATE TABLE IF NOT EXISTS capture_links (
  url TEXT PRIMARY KEY,             -- 文章详情页 URL（**唯一标识**）
  source_id TEXT, canonical_url TEXT, title TEXT,
  found_at TEXT, last_seen TEXT,
  status TEXT DEFAULT 'pending',    -- pending / captured
  capture_id INTEGER, clicked_at TEXT, published_at TEXT
);
CREATE TABLE IF NOT EXISTS captures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT, url TEXT, canonical_url TEXT UNIQUE,
  title TEXT, byline TEXT, published_at TEXT,
  captured_at TEXT, last_seen TEXT,
  content_hash TEXT, body_chars INTEGER, images TEXT DEFAULT '[]',
  path TEXT, status TEXT, reasons TEXT, extractor_version TEXT
);
CREATE INDEX IF NOT EXISTS idx_captures_source ON captures(source_id);
CREATE INDEX IF NOT EXISTS idx_captures_hash ON captures(content_hash);
"""

FTS_DDL = """
CREATE VIRTUAL TABLE IF NOT EXISTS capture_fts USING fts5(
  capture_id UNINDEXED, title, body
);
"""


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(DDL)
    conn.execute("DROP TABLE IF EXISTS capture_rejects")   # 2026-10-14 Owner：库里只留"看过的全文"，拒收不留痕
    # 迁移：老库补列（幂等）
    for table, cols in (
        ("sources", (("url_patterns", "TEXT DEFAULT '[]'"), ("exclude_patterns", "TEXT DEFAULT '[]'"),
                     ("discover_url", "TEXT DEFAULT ''"))),
        ("capture_links", (("clicked_at", "TEXT"), ("published_at", "TEXT"))),
    ):
        have = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        for col, ddl in cols:
            if col not in have:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
    try:
        conn.executescript(FTS_DDL)
    except sqlite3.OperationalError:
        pass          # 该 sqlite 无 FTS5 → 仍可用普通检索
    conn.commit()


def upsert_source(conn, source_id: str, name: str = "", domain: str = "",
                  style_profile: str = "", channel: str = "", notes: str = "",
                  url_patterns=None, discover_url: str = "", exclude_patterns=None) -> None:
    pats = source_patterns(url_patterns) if url_patterns is not None else None
    exc = source_patterns(exclude_patterns) if exclude_patterns is not None else None
    conn.execute("INSERT OR REPLACE INTO sources"
                 "(id,name,domain,notes,style_profile,channel,created_at,url_patterns,discover_url,"
                 " exclude_patterns) VALUES(?,?,?,?,?,?,datetime('now','localtime'),?,?,?)",
                 (source_id, name, domain, notes, style_profile, channel,
                  json.dumps(pats or [], ensure_ascii=False),
                  discover_url or "", json.dumps(exc or [], ensure_ascii=False)))
    conn.commit()


def source_patterns(v) -> list[str]:
    """归一化源的文章 URL 形态：接受 list 或 JSON 字符串。"""
    if isinstance(v, str):
        try:
            v = json.loads(v or "[]")
        except json.JSONDecodeError:
            v = []
    return [str(p) for p in (v or []) if str(p).strip()]


def get_source(conn, source_id: str) -> dict | None:
    r = conn.execute("SELECT * FROM sources WHERE id=?", (source_id,)).fetchone()
    return dict(r) if r else None


def source_by_domain(conn, domain: str) -> dict | None:
    """按域名匹配**最长**后缀（避免同类域互相抢）。"""
    rows = [dict(r) for r in conn.execute("SELECT * FROM sources")]
    dom = (domain or "").lower()
    hit = [r for r in rows if r["domain"] and (dom == r["domain"] or dom.endswith("." + r["domain"]))]
    return max(hit, key=lambda r: len(r["domain"])) if hit else None


# -------- 文章详情页链接清单（**只存 URL，不采集**）：供信息收集页逐条点开 --------
def upsert_link(conn, url: str, source_id: str = "", title: str = "",
                now: str | None = None, published_at: str = "") -> None:
    ts = now or time.strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("INSERT INTO capture_links(url,source_id,canonical_url,title,found_at,last_seen,status,published_at) "
                 "VALUES(?,?,?,?,?,?,COALESCE((SELECT status FROM capture_links WHERE url=?),'pending'),?) "
                 "ON CONFLICT(url) DO UPDATE SET last_seen=excluded.last_seen, "
                 "title=CASE WHEN excluded.title<>'' THEN excluded.title ELSE capture_links.title END, "
                 "published_at=CASE WHEN excluded.published_at<>'' THEN excluded.published_at ELSE capture_links.published_at END",
                 (url, source_id, canonical_url(url), title, ts, ts, url, published_at or ""))
    # 链接与采集状态**双向同步**（先采后登记也要对上）
    cu = canonical_url(url)
    conn.execute(
        "UPDATE capture_links SET status = CASE "
        "  WHEN EXISTS(SELECT 1 FROM captures c WHERE c.canonical_url=? AND c.status<>'failed') THEN 'captured' "
        "  WHEN EXISTS(SELECT 1 FROM captures c WHERE c.canonical_url=?) THEN 'failed' "
        "  ELSE 'pending' END, "
        "  capture_id = COALESCE((SELECT c.id FROM captures c WHERE c.canonical_url=? AND c.status<>'failed' "
        "                         ORDER BY c.id DESC LIMIT 1), capture_id) WHERE url=?",
        (cu, cu, cu, url))


def link_rows(conn, source_id: str = "", limit: int = 500) -> list[dict]:
    sql = ("SELECT l.rowid AS id, l.*, c.status AS cap_status, c.body_chars, c.path "
           "FROM capture_links l LEFT JOIN captures c ON c.canonical_url=l.canonical_url ")
    args: tuple = ()
    if source_id:
        sql += "WHERE l.source_id=? "
        args = (source_id,)
    sql += "ORDER BY COALESCE(NULLIF(l.published_at,''), l.found_at) DESC, l.found_at DESC LIMIT ?"
    args = args + (limit,)
    return [dict(r) for r in conn.execute(sql, args)]


def save_capture(conn, *, source_id: str, url: str, body: str, title: str = "",
                 byline=None, published_at: str = "", path: str = "",
                 images=None, html: str = "", extractor_version: str = "",
                 now: str | None = None, dwell_s: int = 0, strict: bool = True,
                 reference_chars: int = 0, hero: dict | None = None) -> dict:
    """入库：先过**完整性门禁**，再过**查重**；返回处置结果。"""
    ts = now or time.strftime("%Y-%m-%d %H:%M:%S")
    if strict:
        ok, reasons, metrics = gate_judge({"title": title, "published_at": published_at,
                                          "byline": byline, "body": body, "html": html})
    else:
        # Owner 定稿判据：只看"页面是否加载完整"
        ok, reasons, metrics = gate_loaded(body, html, reference_chars)
    cu, ch = canonical_url(url), content_key(body)

    if not ok:
        # ★ Owner 口径（2026-10-14）：不完整（含未登录/付费墙）→ **什么都不存**。
        #   "当前的数据库跟整齐，就是我浏览过的文章全文" —— 库里不留拒收痕迹，只在**当场**告诉浏览器。
        return {"status": "failed", "reasons": reasons, "metrics": metrics, "saved": False}

    rows = [dict(r) for r in conn.execute(
        "SELECT id, canonical_url, content_hash FROM captures WHERE status<>'failed'")]
    # ★ 去重口径（Owner 2026-10-14）：**文章详情页以 URL 为唯一标识**
    ex = next((r for r in rows if r["canonical_url"] == cu), None)
    if ex:
        conn.execute("UPDATE captures SET last_seen=? WHERE id=?", (ts, ex["id"]))
        conn.execute("UPDATE capture_links SET status='captured', capture_id=?, last_seen=? "
                     "WHERE canonical_url=?", (ex["id"], ts, cu))
        conn.commit()
        return {"status": "duplicate", "reason": "same_url", "canonical_url": cu, "id": ex["id"],
                "saved": True, "path": (conn.execute("SELECT path FROM captures WHERE id=?",
                                                     (ex["id"],)).fetchone() or [""])[0]}
    # content_hash 只作**参考信号**（不同 URL 同一篇），**不阻塞入库**
    same = next((r for r in rows if r["content_hash"] == ch), None)

    cur = conn.execute("INSERT INTO captures"
                       "(source_id,url,canonical_url,title,byline,published_at,captured_at,last_seen,"
                       " content_hash,body_chars,images,path,status,reasons,extractor_version)"
                       " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (source_id, url, cu, title, json.dumps(byline or [], ensure_ascii=False),
                        published_at, ts, ts, ch, metrics["body_chars"],
                        json.dumps(images or [], ensure_ascii=False), path, "raw",
                        json.dumps({"same_content_as": same["id"]} if same else {}, ensure_ascii=False),
                        extractor_version))
    cid = cur.lastrowid
    # ★ 完整文章**自动保存为 md**（Owner：按时间降序浏览）
    md_path = ""
    try:
        from .article_md import write_article_md
        md_path = write_article_md(source_id=source_id, url=url, title=title, byline=byline or [],
                                   published_at=published_at, body=body, captured_at=ts,
                                   dwell_s=(dwell_s or 0), content_hash=ch,
                                   extractor_version=extractor_version, hero=hero)
        conn.execute("UPDATE captures SET path=? WHERE id=?", (md_path, cid))
    except Exception:  # noqa: BLE001  （落盘失败不影响索引；path 留空）
        pass
    conn.execute("UPDATE capture_links SET status='captured', capture_id=?, last_seen=? WHERE canonical_url=?",
                 (cid, ts, cu))
    try:
        conn.execute("INSERT INTO capture_fts(capture_id,title,body) VALUES(?,?,?)", (cid, title, body))
    except sqlite3.OperationalError:
        pass
    conn.commit()
    return {"status": "raw", "id": cid, "canonical_url": cu, "content_hash": ch,
            "saved": True, "path": md_path, "metrics": metrics}


def article_rows(conn, source_id: str = "", limit: int = 200, since: str = "") -> list[dict]:
    """**干净数据**清单（只有完整文章）：时间降序；带 md 路径。"""
    sql = ("SELECT id, source_id, url, canonical_url, title, byline, published_at, captured_at, "
           "last_seen, body_chars, path, reasons FROM captures WHERE 1=1 ")
    args: list = []
    if source_id:
        sql += "AND source_id=? "; args.append(source_id)
    if since:
        sql += "AND captured_at>=? "; args.append(since)
    sql += "ORDER BY captured_at DESC, id DESC LIMIT ?"
    args.append(limit)
    return [dict(r) for r in conn.execute(sql, tuple(args))]


def touch_click(conn, link_id, now: str | None = None) -> None:
    """记录「从清单点进来了」（点击来源留痕在**链接**上，不在文章表里）。"""
    if not link_id:
        return
    try:
        conn.execute("UPDATE capture_links SET clicked_at=? WHERE rowid=?",
                     (now or time.strftime("%Y-%m-%d %H:%M:%S"), int(link_id)))
        conn.commit()
    except (ValueError, sqlite3.Error):
        pass


def script_seen(conn, session_id: str = "", version: str = "", host: str = "",
                now: str | None = None) -> None:
    """脚本心跳：证明**你的浏览器**已经带着脚本在线（清单页据此显示「脚本在线」）。"""
    ts = now or time.strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("INSERT INTO script_state(session_id,version,host,last_seen) VALUES(?,?,?,?) "
                 "ON CONFLICT(session_id) DO UPDATE SET last_seen=excluded.last_seen, "
                 "version=excluded.version, host=excluded.host",
                 (session_id or "default", version, host, ts))
    conn.commit()


def script_online(conn, within_s: int = 300) -> dict:
    """脚本是否**当前在线**：心跳须在 within_s 秒内（此前只要有过一次就永远显示在线）。"""
    row = conn.execute("SELECT MAX(last_seen) AS t FROM script_state").fetchone()
    t = (row["t"] if row else "") or ""
    online = False
    if t:
        try:
            online = (time.mktime(time.strptime(t, "%Y-%m-%d %H:%M:%S")) + within_s) >= time.time()
        except ValueError:
            online = False
    return {"last_seen": t, "online": online, "within_s": within_s}
