"""单机多子 agent（一体多役）注册表与运行时。

设计（详见 `docs/332_单机多agent_一体多役_20261023.md`）：

- 子 agent **不是新的服务端身份**，而是「父身份 + 角色」：`bob.dev`、`alice.review`。
- 不复制 `.key` / `memory.db` / `persona.yaml`；共享父身份鉴权，产出归属父 agent。
- 每个角色声明：天职、可写范围、并发上限、工作区模式（shared / worktree）。
- 每个角色独立的**工作区 + 锁 + 审计**，避免 10 个 worker 同时写同一棵树。

命名规则：`<parent>.<role>`，parent/role 均为小写字母开头的 `[a-z0-9_-]`。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AGENTS = ROOT / "agents"
LOCK_DIR = ROOT / "runtime" / "subagents" / "locks"
WORKSPACE_ROOT = ROOT / "runtime" / "workspaces"

# 角色库：跨 agent 复用；各 agent 的 roster 只挑选需要的角色并覆盖参数。
DEFAULT_ROLES: dict[str, dict] = {
    "dev": dict(
        duty="实现与修复：按验收标准改代码、补测试、跑最小验证。",
        scope=["scripts", "core", "runtime", "cli", "apps-src", "tools"],
        max_parallel=1, workspace="worktree",
    ),
    "qa": dict(
        duty="独立复现与回归：只读代码，跑测试与验收脚本，出可复核证据。",
        scope=["reports", "runtime", "evidence"], max_parallel=2, workspace="shared",
    ),
    "ops": dict(
        duty="日常运维：服务健康、日志巡检、备份/清理、定时任务。",
        scope=["runtime", "scripts", "backups", "reports"], max_parallel=1, workspace="shared",
    ),
    "docs": dict(
        duty="文档与发布说明：docs/、README、SOP 的结构化写作与校对。",
        scope=["docs", "README.md", "SOP.md"], max_parallel=1, workspace="shared",
    ),
    "research": dict(
        duty="调研与资料整理：来源分级、每条点评、落 research/ 与 reading/。",
        scope=["research", "reading", "sources", "reports"], max_parallel=2, workspace="shared",
    ),
    "data": dict(
        duty="数据治理：只按脚本做可回滚的清理/迁移，先备份再执行。",
        scope=["data", "reports", "runtime"], max_parallel=1, workspace="shared",
    ),
    "review": dict(
        duty="代码与方案评审：只读，指出问题与风险，不替作者改。",
        scope=["reports"], max_parallel=2, workspace="shared",
    ),
    "triage": dict(
        duty="任务分诊：认领/归档 backlog，补齐归属与验收标准。",
        scope=["runtime", "reports"], max_parallel=1, workspace="shared",
    ),
    "release": dict(
        duty="发布门禁：版本号/说明/回滚点/自检四件套。",
        scope=["scripts", "docs", "dist"], max_parallel=1, workspace="shared",
    ),
}

# A 机默认编制：2 个主体 + 9 个角色 = 11 个可并行工位。
DEFAULT_ROSTER: dict[str, list[str]] = {
    "alice": ["review", "triage", "release"],
    "bob": ["dev", "qa", "ops", "docs", "research", "data"],
}

NAME_RE = re.compile(r"^([a-z][a-z0-9_-]{1,30})\.([a-z][a-z0-9_-]{1,30})$")
ROLE_RE = re.compile(r"^[a-z][a-z0-9_-]{1,30}$")


class SubagentError(RuntimeError):
    pass


def parse_name(name: str) -> tuple[str, str]:
    """`bob.dev` → ("bob", "dev")；非法名直接报错（不做模糊匹配）。"""
    m = NAME_RE.match((name or "").strip())
    if not m:
        raise SubagentError(f"非法子 agent 名：{name!r}（应为 <parent>.<role>）")
    return m.group(1), m.group(2)


def display_name(entry: dict) -> str:
    """给人看的名字：Bob·dev（服务端归属仍是父 agent Bob）。"""
    return f"{entry['parent'].capitalize()}·{entry['role']}"


def roster_file(parent: str) -> Path:
    return AGENTS / parent / "subagents.yaml"


def default_roster(parent: str) -> dict:
    roles = DEFAULT_ROSTER.get(parent, [])
    return {
        "parent": parent,
        "max_parallel": int(os.environ.get("TEAMAI_SUBAGENT_MAX", "6")),
        "roles": {
            r: {**DEFAULT_ROLES[r], "enabled": True}
            for r in roles if r in DEFAULT_ROLES
        },
    }


def load_roster(parent: str) -> dict:
    p = roster_file(parent)
    if not p.exists():
        return default_roster(parent)
    try:
        import yaml
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception as e:  # noqa: BLE001
        raise SubagentError(f"读取 {p} 失败：{e}") from e
    data.setdefault("parent", parent)
    data.setdefault("max_parallel", int(os.environ.get("TEAMAI_SUBAGENT_MAX", "6")))
    data.setdefault("roles", {})
    return data


def save_roster(parent: str, data: dict) -> Path:
    import yaml
    p = roster_file(parent)
    p.parent.mkdir(parents=True, exist_ok=True)
    header = ("# 子 agent 编制（一体多役）\n"
              "# 名字规则 <parent>.<role>；不是服务端身份，共享父 agent 的 key。\n"
              "# 编辑后可用 `../venv/bin/python scripts/subagents.py list` 校验。\n")
    p.write_text(header + yaml.safe_dump(data, allow_unicode=True, sort_keys=False),
                 encoding="utf-8")
    return p


def init_roster(parent: str, force: bool = False) -> dict:
    """创建默认编制；已存在且 !force 时只补齐缺失角色，不覆盖手工修改。"""
    cur = load_roster(parent) if roster_file(parent).exists() else {"parent": parent,
                                                                    "max_parallel": int(
                                                                        os.environ.get(
                                                                            "TEAMAI_SUBAGENT_MAX",
                                                                            "6")),
                                                                    "roles": {}}
    if force:
        cur = default_roster(parent)
    else:
        for role in DEFAULT_ROSTER.get(parent, []):
            cur["roles"].setdefault(role, {**DEFAULT_ROLES[role], "enabled": True})
    save_roster(parent, cur)
    return cur


def parents() -> list[str]:
    if not AGENTS.exists():
        return []
    return sorted(p.name for p in AGENTS.iterdir()
                  if p.is_dir() and (p / ".key").exists() and not p.name.startswith("_"))


def entries(parent: str | None = None) -> list[dict]:
    """展开所有编制，返回扁平的子 agent 列表（含天职/范围/并发）。"""
    out: list[dict] = []
    for p in ([parent] if parent else parents()):
        if not (AGENTS / p / ".key").exists():
            continue
        try:
            data = load_roster(p)
        except SubagentError:
            continue
        for role, cfg in (data.get("roles") or {}).items():
            if not ROLE_RE.match(str(role)):
                continue
            base = DEFAULT_ROLES.get(role, {})
            out.append({
                "name": f"{p}.{role}",
                "parent": p,
                "role": role,
                "duty": cfg.get("duty") or base.get("duty") or "（待定义）",
                "scope": list(cfg.get("scope") or base.get("scope") or []),
                "max_parallel": int(cfg.get("max_parallel", base.get("max_parallel", 1)) or 1),
                "workspace": cfg.get("workspace") or base.get("workspace") or "shared",
                "enabled": bool(cfg.get("enabled", True)),
            })
    return out


def get_entry(name: str) -> dict:
    parent, role = parse_name(name)
    for e in entries(parent):
        if e["role"] == role:
            return e
    raise SubagentError(f"编制里没有 {name}（先 `subagents.py init --agent {parent}`）")


# ------------------------------------------------------------------ 文本 → 目标
def resolve_mention(mention: str, local_ids: list[str]) -> tuple[str, str] | None:
    """把群聊里的 @ 解析成 (父 agent_id, 角色)。

    - `@bob.dev` 且 bob 是本机 agent、role 在编制内 → ("bob", "dev")
    - `@bob` / `@Bob` → ("bob", "")（父本体）
    - 远程 agent / 未知角色 → None（调用方继续按原有 @ 规则处理）
    """
    m = (mention or "").strip().lstrip("@").lower()
    if not m:
        return None
    local = {x.lower(): x for x in local_ids}
    if "." in m:
        prefix, role = m.split(".", 1)
        if prefix in local:
            try:
                e = get_entry(f"{prefix}.{role}")
                if e["enabled"]:
                    return local[prefix], e["role"]
            except SubagentError:
                return None
    if m in local:
        return local[m], ""
    return None


# ------------------------------------------------------------------ 提示词
def charter(entry: dict) -> str:
    scope = "、".join(entry["scope"]) or "（未声明：默认只读，产出写 reports/）"
    return (
        f"你是 Team AI 的 agent「{entry['parent'].capitalize()}」的子 agent "
        f"「{display_name(entry)}」（{entry['name']}）。\n"
        f"你的天职：{entry['duty']}\n"
        f"可写范围（相对项目根）：{scope}。范围外只读；需要越界先在上报里说明，不要直接改。\n"
        "硬约束：\n"
        "1) 不新建服务端身份/密钥；一切产出归属父 agent，不另行代表团队对外发言。\n"
        "2) 不改父 agent 的人格与记忆（persona.yaml / memory.db / AGENTS.md 个人段）。\n"
        "3) 不并发改同一文件；拿到锁再干活，超出并发上限就排队。\n"
        "4) 不可逆操作（删除/迁移/发布）先给方案与回滚点，等父 agent 或人类批准。\n"
    )


# ------------------------------------------------------------------ 工作区
def workspace_for(entry: dict, task_id: str, mode: str | None = None) -> Path:
    """分配独立工作区；同名任务复用同一目录（可断点续跑）。"""
    from runtime import workspace as ws
    safe = "".join(ch if (ch.isalnum() or ch in "-_.") else "_" for ch in str(task_id))[:60]
    return ws.allocate(ROOT, f"{entry['parent']}-{entry['role']}-{safe}", lane="sub")


def prepare_workspace(entry: dict, task_id: str, mode: str | None = None) -> tuple[Path, str]:
    """按角色声明准备 workspace，返回 (路径, 实际模式)。

    worktree：`git worktree add` 到 runtime/worktrees/<name>-<task>，用于并行改代码；
    shared：主仓根目录下的独立产物目录（默认，适合运维/文档/调研）。
    """
    mode = mode or entry.get("workspace") or "shared"
    if mode != "worktree":
        p = workspace_for(entry, task_id)
        return p, "shared"
    safe = "".join(ch if (ch.isalnum() or ch in "-_.") else "_" for ch in str(task_id))[:40]
    path = WORKSPACE_ROOT / "worktrees" / f"{entry['parent']}-{entry['role']}-{safe}"
    branch = f"sub/{entry['parent']}-{entry['role']}-{safe}"
    if path.exists():
        return path, "worktree"
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        r = subprocess.run(["git", "-C", str(ROOT), "worktree", "add", "-B", branch, str(path)],
                           capture_output=True, text=True, timeout=120)
    except Exception as e:  # noqa: BLE001
        raise SubagentError(f"git worktree 失败：{e}") from e
    if r.returncode != 0:
        # 失败就退回 shared，不把并行任务卡死；由审计记录实际模式。
        p = workspace_for(entry, task_id)
        return p, "shared(git失败)"
    return path, "worktree"


def within_scope(entry: dict, relpath: str) -> bool:
    """提示词级范围校验（不是内核沙箱）：越界返回 False，供审计/评审用。"""
    p = str(relpath or "").replace("\\", "/").lstrip("./")
    if not p or p.startswith("/") or ".." in Path(p).parts:
        return False
    return any(p == s or p.startswith(s.rstrip("/") + "/") for s in entry["scope"])


# ------------------------------------------------------------------ 锁 / 审计
def _alive(pid: int) -> bool:
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:  # noqa: BLE001
        return False


def lock_path(name: str) -> Path:
    return LOCK_DIR / f"{name}.lock"


def acquire(entry: dict, task: str = "") -> Path:
    """原子占位；同角色已有活进程则拒绝（返回 SubagentError 供 CLI 排队）。"""
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    p = lock_path(entry["name"])
    payload = json.dumps({"name": entry["name"], "pid": os.getpid(), "task": (task or "")[:200],
                          "started": time.strftime("%Y-%m-%d %H:%M:%S")}, ensure_ascii=False)
    try:
        fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, payload.encode())
        os.close(fd)
        return p
    except FileExistsError:
        old = {}
        try:
            old = json.loads(p.read_text(encoding="utf-8") or "{}")
        except Exception:  # noqa: BLE001
            pass
        if old and _alive(old.get("pid", 0)):
            raise SubagentError(
                f"{entry['name']} 正在跑（pid={old.get('pid')}，{old.get('started')}）："
                f"{old.get('task', '')[:60]}") from None
        p.write_text(payload, encoding="utf-8")          # 过期锁直接接管
        return p


def release(entry: dict) -> None:
    try:
        lock_path(entry["name"]).unlink()
    except FileNotFoundError:
        pass


def running() -> list[dict]:
    out: list[dict] = []
    if not LOCK_DIR.exists():
        return out
    for p in sorted(LOCK_DIR.glob("*.lock")):
        try:
            d = json.loads(p.read_text(encoding="utf-8") or "{}")
        except Exception:  # noqa: BLE001
            continue
        if d.get("pid") and _alive(d["pid"]):
            out.append(d)
    return out


def audit(entry: dict, event: str, task: str = "", **kw) -> Path:
    p = AGENTS / entry["parent"] / "subagents.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    rec = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "name": entry["name"],
           "event": event, "task": (task or "")[:300], "pid": os.getpid(), **kw}
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return p


def summary() -> dict:
    es = entries()
    return {
        "parents": sorted({e["parent"] for e in es}),
        "enabled": len([e for e in es if e["enabled"]]),
        "total": len(es),
        "running": len(running()),
        "roles": [e["name"] for e in es if e["enabled"]],
    }
