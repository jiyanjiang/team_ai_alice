"""帖子「分享到朋友圈」（docs/531·B 案）。

设计要点（与立项文档一一对应）：
  * 分享 = `posts` 里的一条**引用型帖子**：`kind='moment'`、`tags='朋友圈,lobby'`、
    `share_of=<原帖 id>`、`visibility` 默认 `friends`。不新建表、不复制正文。
  * 去重靠部分唯一索引 `uq_posts_share_alive`：同一人同一原帖只有一条存活分享。
  * 「移除」= `status='archived'`（软删留痕），对外不说"撤回"。
  * **可见性 ≤ 原帖**：分享的可见面取 `min(分享, 原帖)`，不放大原帖。

这里只放数据与权限判定，HTML 渲染留在 `core/app_ui.py`（避免循环 import）。
"""

from __future__ import annotations

import json
import sqlite3
import time

MOMENT_TAGS = "朋友圈,lobby"
MOMENT_TAG_LIST = ["朋友圈", "lobby"]


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _row_get(row, key, default=None):
    """兼容 sqlite3.Row 与 dict。"""
    try:
        return row[key]
    except (IndexError, KeyError, TypeError):
        return default


def friend_set(conn, viewer: str) -> set[str] | None:
    """好友集合；判定不可用（库异常/只读连接）返回 None。

    返回 None 时调用方必须**保持原行为**（不做收紧）：这些行在补 visibility
    之前本来就是可见的，不能让一次查询失败把整页内容藏掉。
    """
    base = _local_friend_ids(conn, viewer)
    if base is None:
        # 本机派生判定不可用 → 不放宽也不收紧（docs/532：宁可少给，不给错）。
        return None
    try:
        from . import friend_sync
        base = set(base) | friend_sync.friend_agents(conn, viewer)
    except Exception:                                            # noqa: BLE001
        pass
    return base


def _local_friend_ids(conn, viewer: str) -> set[str] | None:
    """本机 friendships（project/team 派生 + 显式请求）里的好友集合。"""
    try:
        from .moments import friend_ids
        return friend_ids(conn, viewer)
    except Exception:                                            # noqa: BLE001
        pass
    # app_ui 的 db() 是 mode=ro：friend_ids 内部的派生同步（INSERT）写不进去会整段抛错。
    # 此时退回一个写连接再算一次，否则「好友可见」在真机上等于没接（静默放行）。
    try:
        from .db import connect
        from .moments import friend_ids
        c2 = connect()
        try:
            return friend_ids(c2, viewer)
        finally:
            c2.close()
    except Exception:                                            # noqa: BLE001
        return None


def can_view(viewer: str, row, friends: set[str] | None = None,
             conn=None) -> bool:
    """本条帖子对 viewer 是否可见。

    规则：public → 是；friends → 作者本人或好友；其它未知值 → 按 public（向后兼容）。
    `friends` 可预计算以批量判定；不给则用 conn 现取；判定不可用 → 放行（不回归）。
    """
    if row is None:
        return False
    if viewer and _row_get(row, "author_id") == viewer:
        return True
    vis = str(_row_get(row, "visibility") or "public").lower()
    if vis != "friends":
        return True
    if friends is None:
        if conn is None:
            return False
        friends = friend_set(conn, viewer)
    if friends is None:
        return True
    # friends = **viewer 的好友集合**；要判的是「作者是不是我的好友」，
    # 不是「我在自己的好友集合里」（那样恒 False，好友可见等于没接）。
    return bool(viewer) and _row_get(row, "author_id") in friends


def visible_rows(conn, viewer: str, rows) -> list:
    """批量过滤（feed / moments 用）。好友集合只算一次；判定不可用则原样返回。"""
    rows = list(rows or [])
    if not rows:
        return []
    friends = friend_set(conn, viewer)
    if friends is None:
        return rows
    return [r for r in rows if can_view(viewer, r, friends)]


def share_of_row(conn, post_id: str):
    """取原帖（含 share_of 列）；不存在/已归档 → None（分享侧据此降级）。"""
    if not post_id:
        return None
    try:
        return conn.execute(
            "select * from posts where id=? and coalesce(status,'') "
            "not in ('duplicate','archived')", (post_id,)).fetchone()
    except sqlite3.Error:
        return None


def share_of_any(conn, post_id: str):
    """原帖行，**不过滤 status**。

    用途：区分两种"原帖不可见"——
      * 本机根本没有这条帖（跨机收到好友的分享）→ 该用快照渲染，否则分享卡永远是空的；
      * 本机有这条帖但已归档/无权看 → 维持 docs/531 的"不展示缓存正文"（不泄露已删内容）。
    返回 None 表示"本机从来没有过这条帖"。
    """
    if not post_id:
        return None
    try:
        return conn.execute("select * from posts where id=?", (post_id,)).fetchone()
    except sqlite3.Error:
        return None


def my_share(conn, viewer: str, post_id: str):
    """viewer 对该帖的存活分享（没有则 None）。"""
    try:
        return conn.execute(
            "select * from posts where share_of=? and author_id=? "
            "and coalesce(status,'') NOT IN ('archived','duplicate') limit 1",
            (post_id, viewer)).fetchone()
    except sqlite3.Error:
        return None


def snapshot_of(row) -> dict:
    """分享当时的原帖自包含摘要（跨机渲染用）。

    对端机器没有原帖（或原帖在对方不可见的频道）时，靠这份快照渲染分享卡，
    避免"点开 404"。**绝不写本机绝对路径**：只放正文与标识。
    """
    return {
        "id": str(_row_get(row, "id") or ""),
        "author": str(_row_get(row, "author_id") or ""),
        "title": str(_row_get(row, "title") or "")[:200],
        "body": str(_row_get(row, "body") or "")[:2000],
        "channel": str(_row_get(row, "channel_id") or "")[:80],
        "created_at": str(_row_get(row, "created_at") or ""),
    }


def _source_attachments(row, limit: int = 9) -> list:
    """原帖的图片附件（≤9，create_post 的九宫格上限）；非图片不收。"""
    raw = _row_get(row, "attachments")
    try:
        items = json.loads(raw) if raw else []
    except (TypeError, ValueError):
        return []
    if not isinstance(items, list):
        return []
    out = []
    for it in items:
        if isinstance(it, dict):
            mime = str(it.get("mime") or "")
            if mime and not mime.startswith("image/"):
                continue
            if not (it.get("url") or it.get("sha256")):
                continue
        out.append(it)
    return out[:limit]


def share_post(conn, actor: str, post_id: str, note: str = "",
               visibility: str = "friends") -> dict:
    """分享一条帖子到自己的朋友圈（幂等：已有存活分享则更新转发语）。

    返回 {ok, share_id, post_id, created} 或 {ok: False, error}。
    """
    src = share_of_row(conn, post_id)
    if src is None:
        return {"ok": False, "error": "not_found"}
    if _row_get(src, "share_of"):
        # 不允许分享"分享帖"，否则引用会套娃；请直接分享原帖。
        return {"ok": False, "error": "share_of_share"}
    if not can_view(actor, src, conn=conn):
        return {"ok": False, "error": "forbidden"}

    # 可见性不放大原帖：friends 分享只能更严
    vis = str(visibility or "friends").lower()
    if vis not in ("friends", "public"):
        vis = "friends"
    src_vis = str(_row_get(src, "visibility") or "public").lower()
    if src_vis == "friends":
        vis = "friends"

    note = (note or "").strip()[:2000]
    row = my_share(conn, actor, post_id)
    if row is not None:
        conn.execute("update posts set body=?, updated_at=? where id=?",
                     (note, _now(), _row_get(row, "id")))
        conn.commit()
        return {"ok": True, "share_id": _row_get(row, "id"), "post_id": post_id,
                "created": False}

    # 必须走 community 的唯一发帖入口：它**必发** `post.created`，对端才拿得到这条分享。
    # 裸 INSERT 是 P0-5 的复发版——内部发帖绕过事件 → 好友机器上这条分享根本不存在。
    # 快照随事件走，对端没有原帖时也能渲染，不留死链。
    try:
        from . import community
        from .quota import QuotaExceeded
        if not community.get_channel(conn, "#lobby"):
            community.create_channel(conn, actor, "#lobby",
                                     purpose="茶水间：见闻、思考、兴趣")
        sid = community.create_post_and_emit(
            conn, actor, "#lobby", "share", note,
            tags=list(MOMENT_TAG_LIST), kind="moment", visibility=vis,
            share_of=post_id, share_snapshot=snapshot_of(src),
            attachments=_source_attachments(src))
    except QuotaExceeded:
        return {"ok": False, "error": "quota"}
    except sqlite3.IntegrityError:
        # 唯一索引 uq_posts_share_alive 兜底：并发重复分享 → 返回已有那条。
        again = my_share(conn, actor, post_id)
        if again is not None:
            return {"ok": True, "share_id": _row_get(again, "id"),
                    "post_id": post_id, "created": False}
        raise
    return {"ok": True, "share_id": sid, "post_id": post_id, "created": True}


def unshare_post(conn, actor: str, share_id: str) -> dict:
    """移除自己的分享（软删：status='archived'）。"""
    try:
        row = conn.execute("select * from posts where id=?", (share_id,)).fetchone()
    except sqlite3.Error:
        row = None
    if row is None:
        return {"ok": False, "error": "not_found"}
    if _row_get(row, "author_id") != actor:
        return {"ok": False, "error": "forbidden"}
    conn.execute("update posts set status='archived', updated_at=? where id=?",
                 (_now(), share_id))
    conn.commit()
    return {"ok": True, "share_id": share_id}
