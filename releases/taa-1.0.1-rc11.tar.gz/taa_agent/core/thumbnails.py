"""本地图片缩略图：列表/聊天气泡用 480px 预览，灯箱仍取原图。

设计约束：
- 只处理本机 `static/uploads/` 下的图片，拒绝路径穿越和外部 URL。
- 原图不可变（上传名是内容 hash）；若原图 mtime 更新则自动重建。
- Pillow 不可用时尝试 macOS `sips`；两者都没有则返回 None，调用方回退原图。
- 缩略图放 `runtime/thumbs/`，不进入 static 发布目录，也不写入数据库。
"""
from __future__ import annotations

import hashlib
import os
import subprocess
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit

ROOT = Path(__file__).resolve().parent.parent
UPLOAD_DIR = ROOT / "static" / "uploads"
THUMB_DIR = ROOT / "runtime" / "thumbs"
IMG_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
MAX_WIDTH = 960


def _path_of(url: str) -> str:
    try:
        p = urlsplit(str(url or ""))
    except Exception:
        return ""
    if p.scheme or p.netloc:
        return ""
    return unquote(p.path)


def is_thumbable(url: str) -> bool:
    path = _path_of(url)
    return bool(path.startswith("/static/uploads/")
                and Path(path).suffix.lower() in IMG_EXTS)


def thumb_url(url: str, width: int = 480) -> str:
    """给 HTML/JS 用的缩略图地址；不可缩略时原样返回。"""
    if not is_thumbable(url):
        return url
    try:
        w = max(160, min(MAX_WIDTH, int(width)))
    except (TypeError, ValueError):
        w = 480
    return f"/thumb?u={quote(str(url), safe='')}&w={w}"


def source_path(url: str) -> Path | None:
    if not is_thumbable(url):
        return None
    path = _path_of(url)
    f = (ROOT / path.lstrip("/")).resolve()
    # 安装版 static/uploads 常是指向 ~/.taa/static/uploads 的软链；
    # 只按 ROOT.resolve() 做前缀会误判为越界，导致缩略图 404。
    allowed = (ROOT.resolve(), UPLOAD_DIR.resolve())
    if not any(_is_under(f, base) for base in allowed):
        return None
    return f if f.is_file() else None


def _is_under(path: Path, base: Path) -> bool:
    try:
        path.relative_to(base)
        return True
    except ValueError:
        return False


def _thumb_path(src: Path, width: int) -> Path:
    key = hashlib.sha256(f"{src.resolve()}:{width}".encode("utf-8")).hexdigest()[:24]
    return THUMB_DIR / f"{key}-{width}.jpg"


def _save_pillow(src: Path, dest: Path, width: int) -> bool:
    try:
        from PIL import Image, ImageOps
    except Exception:
        return False
    try:
        im = Image.open(src)
        im = ImageOps.exif_transpose(im)
        if getattr(im, "is_animated", False):
            im.seek(0)
        # 预览允许长图；但把高度封在 2 倍宽度，避免一张 480x8000 的截图仍很大。
        im.thumbnail((width, width * 2), Image.Resampling.LANCZOS)
        if im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGBA")
            bg = Image.new("RGB", im.size, "white")
            bg.paste(im, mask=im.getchannel("A"))
            im = bg
        else:
            im = im.convert("RGB")
        tmp = dest.with_name(dest.name + f".{os.getpid()}.tmp")
        im.save(tmp, "JPEG", quality=82, optimize=True, progressive=True)
        os.replace(tmp, dest)
        return dest.is_file() and dest.stat().st_size > 0
    except Exception:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def _save_sips(src: Path, dest: Path, width: int) -> bool:
    try:
        tmp = dest.with_name(dest.name + f".{os.getpid()}.tmp.jpg")
        r = subprocess.run(
            ["sips", "-Z", str(width), "-s", "format", "jpeg",
             str(src), "--out", str(tmp)],
            capture_output=True, timeout=30)
        if r.returncode == 0 and tmp.is_file() and tmp.stat().st_size:
            os.replace(tmp, dest)
            return True
        tmp.unlink(missing_ok=True)
    except Exception:
        pass
    return False


def ensure_thumb(url: str, width: int = 480) -> Path | None:
    try:
        w = max(160, min(MAX_WIDTH, int(width)))
    except (TypeError, ValueError):
        w = 480
    src = source_path(url)
    if not src:
        return None
    dest = _thumb_path(src, w)
    try:
        if dest.is_file() and dest.stat().st_mtime >= src.stat().st_mtime:
            return dest
    except OSError:
        pass
    dest.parent.mkdir(parents=True, exist_ok=True)
    if _save_pillow(src, dest, w) or _save_sips(src, dest, w):
        return dest if dest.is_file() else None
    return None
