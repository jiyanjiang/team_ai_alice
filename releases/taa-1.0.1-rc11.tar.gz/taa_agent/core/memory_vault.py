"""记忆备份 / 软删 / 回滚 / 定期物理删除（docs/323）。

导师口径（2026-10-22，本地 TAA 会话）：
  * **日常必须备份**：数据库（`memory.db`）+ md（`resume.md` / 人格说明书等）；
  * **软删 = 先备份，再挪到软删路径**，并**记录路径**，随时可调用（restore）；
  * **很久用不上才真删**：软删满冷静期（默认 90 天）后 `purge` 物理删除；
  * **新备份进来 → 旧备份退出 → 循环滚动**，系统自然瘦身；期间始终可回滚。

设计（与 `core/storage.py` / `core/sleep.py` 的分工）：
  * `storage` 管媒体/交付物的分级删除；`sleep` 管过程文件；本模块**只管记忆**；
  * 三级状态机：`live`（在 `backups/memory/`）→ `deleted`（挪进 `.trash/memory/`，可 restore）
    → `purged`（物理删除，不可恢复）；**不可跳级**，每级都留台账；
  * 每次备份都用 SQLite backup API 取**一致性快照**（含 WAL 中未落盘的数据），
    并逐文件记 `sha256` / 字节数 / 原路径 / 存储路径；
  * 台账 `data/memory_vault.db`（本机状态，不入库）；另有每份备份的 `manifest.json`；
  * 行级整理（`prune`）**先整库备份**，再把待删行导出为 JSONL + Markdown 放进软删区，
    确认备份与导出都成功后才 `DELETE`；`values/facts/playbook/persona/关系/技能` 等
    **人格与事实核心永不参与自动清理**；
  * 默认 DRY-RUN，只有 `apply=True` 才动盘/动库。

用法：
    from core.memory_vault import MemoryVault
    v = MemoryVault()
    v.snapshot(apply=True)                  # 备份全部 agent（并滚动旧备份→软删）
    v.status()                              # 台账：live / deleted / purged + 到期可 purge
    v.prune("alice", apply=True)            # 导出旧行→软删；先自动整库备份
    v.restore(run_id, apply=True)           # 从软删区取回备份（不覆盖线上记忆）
    v.restore(run_id, apply=True, to_live=True)   # 真正回灌线上（先自动备份当前状态）
    v.purge(apply=True)                     # 冷静期满的软删项物理删除
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

from . import config

ROOT = Path(__file__).resolve().parent.parent

DEFAULT_KEEP = 7                 # 每个 agent 保留最近 N 份 live 备份
DEFAULT_GRACE_DAYS = 90          # 软删后多久可物理删除（"很久用不上"）
DEFAULT_LIVE_DAYS = 180          # 没新备份进来时，live 备份的最长保留天数
DEFAULT_PRUNE_DAYS = 180         # 行级整理：默认只动 N 天前的旧行
DEFAULT_MIN_SALIENCE = 0.6       # 情景记忆：只清低显著度的旧行
DEFAULT_WORKING_DAYS = 7         # 热记忆本就短命；默认清 7 天前的低优先级行

AGENT_FILES = ("working.json", "persona.yaml")
PRUNE_TABLES = {
    "working": ("ts", DEFAULT_WORKING_DAYS, "coalesce(priority,0.5) < 0.8"),
    "episodic": ("ts", DEFAULT_PRUNE_DAYS, "coalesce(salience,0.5) < {min_salience}"),
    "reflections": ("ts", DEFAULT_PRUNE_DAYS, "1=1"),
}
# 永不参与自动清理的表（人格 / 事实 / 关系 / 审计）
PROTECTED_TABLES = (
    "values_t", "weight_history", "semantic", "facts", "playbook", "plans",
    "relationships", "skills", "interests", "reputation_local", "decisions",
    "fact_cursor", "learning_cursor", "review_cycles",
)

DDL = """
CREATE TABLE IF NOT EXISTS items (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id       TEXT NOT NULL UNIQUE,
  agent        TEXT NOT NULL,
  kind         TEXT NOT NULL DEFAULT 'snapshot',   -- snapshot | prune
  state        TEXT NOT NULL DEFAULT 'live',       -- live | deleted | purged
  dir_rel      TEXT NOT NULL,                      -- 当前所在目录（相对 ROOT）
  source_rel   TEXT,                               -- 原始位置（agent 目录 / memory.db）
  files        INTEGER NOT NULL DEFAULT 0,
  bytes        INTEGER NOT NULL DEFAULT 0,
  manifest_sha TEXT,
  created_at   TEXT NOT NULL,
  trashed_at   TEXT,
  purge_after  TEXT,
  restored_at  TEXT,
  purged_at    TEXT,
  note         TEXT
);
CREATE INDEX IF NOT EXISTS idx_items_agent_state ON items(agent, state, created_at);

CREATE TABLE IF NOT EXISTS item_files (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id     TEXT NOT NULL,
  source_rel TEXT NOT NULL,
  stored_rel TEXT NOT NULL,
  kind       TEXT,
  bytes      INTEGER NOT NULL DEFAULT 0,
  sha256     TEXT,
  UNIQUE(run_id, source_rel)
);
"""


# --------------------------------------------------------------------- 基础工具
def _now_str(dt: datetime | None = None) -> str:
    return (dt or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")


def _parse(ts: str | None) -> datetime | None:
    if not ts:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(ts)[:19], fmt)
        except ValueError:
            continue
    return None


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _human(n: int | float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{int(n)}B" if unit == "B" else f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def _inside(path: Path, base: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(base.resolve(strict=False))
        return True
    except (ValueError, OSError):
        return False


def _copy_sqlite(src: Path, dst: Path) -> None:
    """SQLite 一致性快照（含 WAL）；源库只读打开，不阻塞服务端读。"""
    dst.parent.mkdir(parents=True, exist_ok=True)
    # 目标已存在时**不要 unlink**：直接 backup 覆盖（保留原 -wal/-shm 的一致性）
    source = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True, timeout=30)
    target = sqlite3.connect(dst, timeout=30)
    try:
        source.backup(target)
    finally:
        target.close()
        source.close()
    try:
        os.chmod(dst, 0o600)
    except OSError:
        pass


def _write_json(path: Path, payload: dict) -> str:
    body = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    path.write_text(body + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


class MemoryVault:
    """一个工作区的记忆保险库（默认 ROOT 下，可用 root/dir 注入做沙箱自检）。"""

    def __init__(self, root=None, backup_dir=None, trash_dir=None, ledger_path=None):
        self.root = Path(root or ROOT).resolve()
        self.backup_dir = Path(backup_dir or (self.root / "backups" / "memory")).resolve()
        self.trash_dir = Path(trash_dir or (self.root / ".trash" / "memory")).resolve()
        self.ledger_path = Path(ledger_path or (self.root / "data" / "memory_vault.db")).resolve()

    # ----------------------------------------------------------------- 配置
    def policy(self, over: dict | None = None) -> dict:
        try:
            min_sal = float(config.get("memory.vault.min_salience", DEFAULT_MIN_SALIENCE,
                                       env="TEAMAI_MEM_MIN_SALIENCE"))
        except (TypeError, ValueError):
            min_sal = DEFAULT_MIN_SALIENCE
        p = {
            "keep": config.get_int("memory.vault.keep", DEFAULT_KEEP, env="TEAMAI_MEM_KEEP"),
            "grace_days": config.get_int("memory.vault.grace_days", DEFAULT_GRACE_DAYS,
                                         env="TEAMAI_MEM_GRACE_DAYS"),
            "live_days": config.get_int("memory.vault.live_days", DEFAULT_LIVE_DAYS,
                                        env="TEAMAI_MEM_LIVE_DAYS"),
            "prune_days": config.get_int("memory.vault.prune_days", DEFAULT_PRUNE_DAYS,
                                         env="TEAMAI_MEM_PRUNE_DAYS"),
            "min_salience": min_sal,
        }
        p["keep"] = max(1, int(p["keep"]))
        p["grace_days"] = max(0, int(p["grace_days"]))
        p["live_days"] = max(1, int(p["live_days"]))
        p["prune_days"] = max(1, int(p["prune_days"]))
        p["min_salience"] = min(1.0, max(0.0, float(p["min_salience"])))
        if over:
            p.update({k: v for k, v in over.items() if v is not None})
        return p

    # ----------------------------------------------------------------- 台账
    def _conn(self) -> sqlite3.Connection:
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.ledger_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 30000")
        conn.executescript(DDL)
        return conn

    def _record(self, conn, *, run_id: str, agent: str, kind: str, state: str,
                dir_rel: str, source_rel: str | None, files: int, bytes_: int,
                manifest_sha: str | None, created_at: str, trashed_at: str | None = None,
                purge_after: str | None = None, note: str = "") -> None:
        conn.execute(
            "INSERT INTO items(run_id,agent,kind,state,dir_rel,source_rel,files,bytes,"
            "manifest_sha,created_at,trashed_at,purge_after,note) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (run_id, agent, kind, state, dir_rel, source_rel, files, bytes_,
             manifest_sha, created_at, trashed_at, purge_after, note))
        conn.commit()

    # ----------------------------------------------------------------- agent 发现
    def agents(self) -> list[str]:
        base = self.root / "agents"
        if not base.exists():
            return []
        out = []
        for p in sorted(base.iterdir()):
            if not p.is_dir() or p.name.startswith("_") or p.name.startswith("."):
                continue
            if (p / "memory.db").is_file():
                out.append(p.name)
        return out

    def _agent_dir(self, agent: str) -> Path:
        if not agent or "/" in agent or ".." in Path(agent).parts:
            raise ValueError(f"非法 agent id: {agent!r}")
        d = self.root / "agents" / agent
        if not (d / "memory.db").is_file():
            raise FileNotFoundError(f"agent {agent} 没有 memory.db：{d}")
        return d

    def _collect(self, agent: str) -> list[dict]:
        d = self._agent_dir(agent)
        files: list[dict] = [{"src": d / "memory.db", "kind": "db", "name": "memory.db"}]
        names = set(AGENT_FILES)
        for p in sorted(d.glob("*.md")):
            if p.is_file() and not p.is_symlink():
                names.add(p.name)
        for name in sorted(names):
            p = d / name
            if p.is_file() and not p.is_symlink() and p.stat().st_size > 0:
                files.append({"src": p, "kind": "json" if name.endswith(".json") else "text",
                              "name": name})
        return files

    def _rel(self, path: Path) -> str:
        try:
            return path.resolve(strict=False).relative_to(self.root).as_posix()
        except ValueError:
            return path.as_posix()

    # ----------------------------------------------------------------- 备份
    def snapshot(self, agents=None, apply: bool = True, keep: int | None = None,
                 now: datetime | None = None, actor: str = "memory_gc",
                 note: str = "") -> dict:
        """备份 `memory.db` + agent 目录下的 md/json；新备份进来后滚动旧备份。

        apply=False 只报告将要备份哪些文件（不写盘、不写台账）。
        """
        pol = self.policy({"keep": keep})
        now = now or datetime.now()
        if isinstance(agents, str):
            agents = [agents]
        agents = list(agents or self.agents())
        out = {"apply": bool(apply), "created_at": _now_str(now), "keep": pol["keep"],
               "agents": [], "missing": [], "rolled": [], "policy": pol}
        for agent in agents:
            try:
                files = self._collect(agent)
            except FileNotFoundError as e:
                out["missing"].append({"agent": agent, "why": str(e)})
                continue
            plan = [{"source": self._rel(f["src"]), "name": f["name"],
                     "kind": f["kind"], "bytes": f["src"].stat().st_size} for f in files]
            total = sum(x["bytes"] for x in plan)
            if not apply:
                out["agents"].append({"agent": agent, "run_id": None,
                                      "dir": self._rel(self.backup_dir / agent),
                                      "files": len(plan), "bytes": total, "plan": plan})
                continue

            run_id = f"{now:%Y%m%d-%H%M%S}-{secrets.token_hex(3)}"
            dest = self.backup_dir / agent / run_id
            dest.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(dest, 0o700)
            except OSError:
                pass
            recorded: list[dict] = []
            for f in files:
                stored = dest / f["name"]
                if f["kind"] == "db":
                    _copy_sqlite(f["src"], stored)
                else:
                    shutil.copy2(f["src"], stored)
                    try:
                        os.chmod(stored, 0o600)
                    except OSError:
                        pass
                recorded.append({"source_rel": self._rel(f["src"]),
                                 "stored_rel": self._rel(stored),
                                 "kind": f["kind"], "bytes": stored.stat().st_size,
                                 "sha256": _sha256(stored)})
            payload = {"run_id": run_id, "agent": agent, "kind": "snapshot",
                       "created_at": _now_str(now), "actor": actor, "note": note,
                       "source_dir": self._rel(self.root / "agents" / agent),
                       "files": recorded,
                       "bytes": sum(x["bytes"] for x in recorded)}
            manifest_sha = _write_json(dest / "manifest.json", payload)
            conn = self._conn()
            try:
                self._record(conn, run_id=run_id, agent=agent, kind="snapshot", state="live",
                             dir_rel=self._rel(dest),
                             source_rel=self._rel(self.root / "agents" / agent),
                             files=len(recorded), bytes_=payload["bytes"],
                             manifest_sha=manifest_sha, created_at=_now_str(now),
                             note=note or f"actor={actor}")
                for r in recorded:
                    conn.execute(
                        "INSERT OR REPLACE INTO item_files(run_id,source_rel,stored_rel,kind,"
                        "bytes,sha256) VALUES (?,?,?,?,?,?)",
                        (run_id, r["source_rel"], r["stored_rel"], r["kind"],
                         r["bytes"], r["sha256"]))
                conn.commit()
                out["agents"].append({"agent": agent, "run_id": run_id,
                                      "dir": self._rel(dest), "files": len(recorded),
                                      "bytes": payload["bytes"],
                                      "manifest_sha": manifest_sha})
                out["rolled"] += self._roll(conn, agent, pol["keep"], now, pol["grace_days"],
                                            pol["live_days"])
            finally:
                conn.close()
        return out

    def _soft_delete(self, conn, row, now: datetime, grace_days: int) -> dict:
        src = self.root / row["dir_rel"]
        dst = self.trash_dir / row["agent"] / row["run_id"]
        if dst.exists():
            dst = dst.with_name(dst.name + "-" + secrets.token_hex(2))
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not src.exists():
            conn.execute("UPDATE items SET state='deleted', trashed_at=?, purge_after=?, "
                         "note=coalesce(note,'')||' 源目录缺失' WHERE run_id=?",
                         (_now_str(now), _now_str(now + timedelta(days=grace_days)),
                          row["run_id"]))
            conn.commit()
            return {"run_id": row["run_id"], "agent": row["agent"], "moved": False,
                    "why": "source_missing", "dir": self._rel(dst)}
        shutil.move(str(src), str(dst))
        try:
            os.chmod(dst, 0o700)
        except OSError:
            pass
        purge_after = _now_str(now + timedelta(days=grace_days))
        conn.execute("UPDATE items SET state='deleted', dir_rel=?, trashed_at=?, purge_after=?, "
                     "note=coalesce(note,'')||? WHERE run_id=?",
                     (self._rel(dst), _now_str(now), purge_after,
                      f" | 软删于 {_now_str(now)}（{grace_days} 天后可物理删除）",
                      row["run_id"]))
        conn.commit()
        return {"run_id": row["run_id"], "agent": row["agent"], "moved": True,
                "from": row["dir_rel"], "dir": self._rel(dst),
                "purge_after": purge_after, "bytes": row["bytes"]}

    def _roll(self, conn, agent: str, keep: int, now: datetime, grace_days: int,
              live_days: int | None = None) -> list[dict]:
        rows = conn.execute(
            "SELECT * FROM items WHERE agent=? AND kind='snapshot' AND state='live' "
            "ORDER BY created_at DESC, id DESC", (agent,)).fetchall()
        # ① 超出 keep；② 没有新备份进来时，超过 live_days 的旧备份也退出（永远保留最新 1 份）
        stale = {r["run_id"] for r in rows[1:]
                 if live_days and _parse(r["created_at"])
                 and (_parse(r["created_at"]) < now - timedelta(days=int(live_days)))}
        drop = {r["run_id"] for r in rows[keep:]} | stale
        rolled = []
        for row in rows:
            if row["run_id"] in drop:
                rolled.append(self._soft_delete(conn, row, now, grace_days))
        return rolled

    def roll(self, keep: int | None = None, grace_days: int | None = None,
             apply: bool = True, now: datetime | None = None) -> dict:
        """只做滚动：把超出 keep 的 live 备份挪进软删区（不新建备份）。"""
        pol = self.policy({"keep": keep, "grace_days": grace_days})
        now = now or datetime.now()
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT agent, count(*) n FROM items WHERE kind='snapshot' AND state='live' "
                "GROUP BY agent").fetchall()
            out = {"apply": bool(apply), "keep": pol["keep"], "agents": {}, "rolled": []}
            for r in rows:
                out["agents"][r["agent"]] = {"live": r["n"]}
                if apply:
                    out["rolled"] += self._roll(conn, r["agent"], pol["keep"], now,
                                                pol["grace_days"], pol["live_days"])
            return out
        finally:
            conn.close()

    # ----------------------------------------------------------------- 查询
    def status(self, agent: str | None = None, state: str | None = None,
               limit: int = 200) -> dict:
        conn = self._conn()
        try:
            where, params = [], []
            if agent:
                where.append("agent=?")
                params.append(agent)
            if state:
                where.append("state=?")
                params.append(state)
            sql = "SELECT * FROM items"
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
            rows = [dict(r) for r in conn.execute(sql, (*params, int(limit)))]
            totals = {}
            for r in conn.execute("SELECT state, count(*) n, coalesce(sum(bytes),0) b "
                                  "FROM items GROUP BY state"):
                totals[r["state"]] = {"items": r["n"], "bytes": r["b"]}
            due = conn.execute(
                "SELECT count(*) n, coalesce(sum(bytes),0) b FROM items "
                "WHERE state='deleted' AND purge_after IS NOT NULL AND purge_after <= ?",
                (_now_str(),)).fetchone()
            return {"root": str(self.root), "backup_dir": self._rel(self.backup_dir),
                    "trash_dir": self._rel(self.trash_dir),
                    "ledger": self._rel(self.ledger_path), "policy": self.policy(),
                    "totals": totals,
                    "purge_due": {"items": due["n"], "bytes": due["b"]},
                    "items": rows}
        finally:
            conn.close()

    def get(self, run_id: str) -> dict | None:
        conn = self._conn()
        try:
            row = conn.execute("SELECT * FROM items WHERE run_id=?", (run_id,)).fetchone()
            if not row:
                return None
            item = dict(row)
            item["file_list"] = [dict(r) for r in conn.execute(
                "SELECT source_rel,stored_rel,kind,bytes,sha256 FROM item_files "
                "WHERE run_id=? ORDER BY id", (run_id,))]
            return item
        finally:
            conn.close()

    # ----------------------------------------------------------------- 行级整理
    def _prune_rows(self, agent: str, tables: list[str], days: int | None,
                    min_salience: float, now: datetime) -> dict:
        d = self._agent_dir(agent)
        conn = sqlite3.connect(d / "memory.db", timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 30000")
        out = {"tables": {}, "rows": 0, "bytes": 0}
        try:
            existing = {r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            for table in tables:
                if table not in PRUNE_TABLES:
                    continue
                if table not in existing:
                    continue
                col, default_days, where = PRUNE_TABLES[table]
                cutoff = _now_str(now - timedelta(days=int(days or default_days)))
                clause = f"{col} < ? AND ({where.format(min_salience=float(min_salience))})"
                rows = [dict(r) for r in conn.execute(
                    f"SELECT rowid AS __rowid, * FROM {table} WHERE {clause} "
                    f"ORDER BY {col}", (cutoff,))]
                if not rows:
                    continue
                out["tables"][table] = {
                    "rows": len(rows), "cutoff": cutoff,
                    "bytes": sum(len(json.dumps(r, ensure_ascii=False, default=str))
                                 for r in rows),
                }
                out["rows"] += len(rows)
                out["bytes"] += out["tables"][table]["bytes"]
        finally:
            conn.close()
        return out

    def prune(self, agent: str, apply: bool = True, days: int | None = None,
              min_salience: float | None = None, tables=None, vacuum: bool = False,
              keep: int | None = None, now: datetime | None = None,
              actor: str = "memory_gc") -> dict:
        """旧记忆整理：先整库备份 → 导出待删行到软删区 → 再删行。

        默认只动 `working`（7 天前、低优先级）、`episodic`（180 天前、显著度 < 0.6）、
        `reflections`（180 天前）；人格/事实/经验/关系等**永不参与**。
        """
        self._agent_dir(agent)
        pol = self.policy({"keep": keep, "min_salience": min_salience})
        now = now or datetime.now()
        tables = [t for t in (tables or list(PRUNE_TABLES)) if t in PRUNE_TABLES]
        if not tables:
            raise ValueError(f"没有可整理的表；允许：{', '.join(PRUNE_TABLES)}")
        report = self._prune_rows(agent, tables, days, pol["min_salience"], now)
        report.update({"apply": bool(apply), "agent": agent, "days": days,
                       "min_salience": pol["min_salience"], "vacuum": bool(vacuum),
                       "backup": None, "dir": None, "deleted": 0})
        if not report["rows"]:
            return report
        if not apply:
            return report

        # ① 先整库备份（失败即中止）
        snap = self.snapshot(agents=[agent], apply=True, keep=pol["keep"], now=now,
                             actor=actor, note="pre-prune 行级整理前整库备份")
        if not snap["agents"]:
            raise RuntimeError(f"pre-prune 备份失败：{snap.get('missing')}")
        report["backup"] = snap["agents"][0]["run_id"]

        # ② 导出待删行到软删区（JSONL 可回灌 + Markdown 可人读）
        d = self._agent_dir(agent)
        run_id = f"{now:%Y%m%d-%H%M%S}-prune-{secrets.token_hex(3)}"
        dest = self.trash_dir / agent / run_id
        dest.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(dest, 0o700)
        except OSError:
            pass
        db = sqlite3.connect(d / "memory.db", timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout = 30000")
        recorded, lines_md = [], []
        try:
            for table in tables:
                if table not in report["tables"]:
                    continue
                col, default_days, where = PRUNE_TABLES[table]
                cutoff = _now_str(now - timedelta(days=int(days or default_days)))
                clause = f"{col} < ? AND ({where.format(min_salience=pol['min_salience'])})"
                rows = [dict(r) for r in db.execute(
                    f"SELECT rowid AS __rowid, * FROM {table} WHERE {clause} "
                    f"ORDER BY {col}", (cutoff,))]
                lines_md.append(f"## {table} · {len(rows)} 行 · cutoff={cutoff}\n")
                for r in rows:
                    lines_md.append(
                        f"- [{r.get('id') or r.get('__rowid')}] {r.get('ts', '')} "
                        f"{str(r.get('summary') or r.get('content') or r.get('decision') or '')[:300]}")
                lines_md.append("")
            jsonl = dest / "pruned-rows.jsonl"
            with jsonl.open("w", encoding="utf-8") as f:
                for table in tables:
                    if table not in report["tables"]:
                        continue
                    col, default_days, where = PRUNE_TABLES[table]
                    cutoff = _now_str(now - timedelta(days=int(days or default_days)))
                    clause = f"{col} < ? AND ({where.format(min_salience=pol['min_salience'])})"
                    for row in db.execute(f"SELECT rowid AS __rowid, * FROM {table} "
                                          f"WHERE {clause} ORDER BY {col}", (cutoff,)):
                        f.write(json.dumps({"__table": table, **dict(row)},
                                           ensure_ascii=False, default=str) + "\n")
            md = dest / "pruned-rows.md"
            md.write_text(f"# 记忆整理导出 · {agent} · {_now_str(now)}\n\n"
                          + "\n".join(lines_md), encoding="utf-8")
            for p in (jsonl, md):
                try:
                    os.chmod(p, 0o600)
                except OSError:
                    pass
                recorded.append({"source_rel": self._rel(d / "memory.db") + "::" + p.name,
                                 "stored_rel": self._rel(p), "kind": "export",
                                 "bytes": p.stat().st_size, "sha256": _sha256(p)})

            # ③ 导出成功后才真正 DELETE（逐表按 rowid）
            deleted = 0
            db.execute("BEGIN")
            for table in report["tables"]:
                col, default_days, where = PRUNE_TABLES[table]
                cutoff = _now_str(now - timedelta(days=int(days or default_days)))
                clause = f"{col} < ? AND ({where.format(min_salience=pol['min_salience'])})"
                cur = db.execute(f"DELETE FROM {table} WHERE rowid IN "
                                 f"(SELECT rowid FROM {table} WHERE {clause})", (cutoff,))
                deleted += cur.rowcount
            db.commit()
            report["deleted"] = deleted
            if vacuum:
                try:
                    db.execute("VACUUM")
                except sqlite3.Error as e:
                    report["vacuum_error"] = str(e)
        finally:
            db.close()

        payload = {"run_id": run_id, "agent": agent, "kind": "prune",
                   "created_at": _now_str(now), "actor": actor,
                   "source_dir": self._rel(d), "tables": report["tables"],
                   "deleted": report["deleted"], "files": recorded,
                   "bytes": sum(x["bytes"] for x in recorded)}
        manifest_sha = _write_json(dest / "manifest.json", payload)
        conn = self._conn()
        try:
            self._record(conn, run_id=run_id, agent=agent, kind="prune", state="deleted",
                         dir_rel=self._rel(dest), source_rel=self._rel(d / "memory.db"),
                         files=len(recorded), bytes_=payload["bytes"],
                         manifest_sha=manifest_sha, created_at=_now_str(now),
                         trashed_at=_now_str(now),
                         purge_after=_now_str(now + timedelta(days=pol["grace_days"])),
                         note=f"行级整理：{report['deleted']} 行；备份 {report['backup']}")
            for r in recorded:
                conn.execute(
                    "INSERT OR REPLACE INTO item_files(run_id,source_rel,stored_rel,kind,"
                    "bytes,sha256) VALUES (?,?,?,?,?,?)",
                    (run_id, r["source_rel"], r["stored_rel"], r["kind"],
                     r["bytes"], r["sha256"]))
            conn.commit()
        finally:
            conn.close()
        report["dir"] = self._rel(dest)
        report["run_id"] = run_id
        return report

    # ----------------------------------------------------------------- 回滚
    def restore(self, run_id: str, apply: bool = True, to_live: bool = False,
                now: datetime | None = None) -> dict:
        """从软删区取回备份；`to_live=True` 才覆盖线上记忆（先自动备份当前状态）。

        - `snapshot`：默认把目录搬回 `backups/memory/`（state=live）；
          `to_live=True` 时再把 `memory.db`/md/json 写回 agent 目录；
        - `prune`：只能 `to_live=True`，把导出的行重新插回 `memory.db`。
        """
        now = now or datetime.now()
        item = self.get(run_id)
        if not item:
            return {"ok": False, "why": "not_found", "run_id": run_id}
        if item["state"] == "purged":
            return {"ok": False, "why": "already_purged", "run_id": run_id}
        src = self.root / item["dir_rel"]
        if not src.exists():
            return {"ok": False, "why": "dir_missing", "dir": item["dir_rel"]}
        out = {"ok": True, "apply": bool(apply), "run_id": run_id, "agent": item["agent"],
               "kind": item["kind"], "from": item["dir_rel"], "to_live": bool(to_live),
               "moved": False, "restored_files": [], "rows": 0}
        if not apply:
            return out

        # prune：直接回灌行，不搬目录
        if item["kind"] == "prune":
            if not to_live:
                out.update(ok=False, why="prune_needs_to_live")
                return out
            d = self._agent_dir(item["agent"])
            rows = []
            path = src / "pruned-rows.jsonl"
            if not path.exists():
                out.update(ok=False, why="export_missing")
                return out
            with path.open(encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        rows.append(json.loads(line))
            db = sqlite3.connect(d / "memory.db", timeout=30)
            try:
                db.execute("PRAGMA busy_timeout = 30000")
                inserted = 0
                for r in rows:
                    table = r.pop("__table", None)
                    r.pop("__rowid", None)
                    if table not in PRUNE_TABLES:
                        continue
                    cols = list(r)
                    ph = ",".join("?" * len(cols))
                    cur = db.execute(
                        f"INSERT OR IGNORE INTO {table} ({','.join(cols)}) VALUES ({ph})",
                        [r[c] for c in cols])
                    inserted += cur.rowcount
                db.commit()
                out["rows"] = inserted
            finally:
                db.close()
            conn = self._conn()
            try:
                conn.execute("UPDATE items SET restored_at=?, note=coalesce(note,'')||? "
                             "WHERE run_id=?", (_now_str(now),
                                                 f" | 回灌 {out['rows']} 行于 {_now_str(now)}",
                                                 run_id))
                conn.commit()
            finally:
                conn.close()
            return out

        # snapshot：to_live 时先**从当前目录**（备份区或软删区）复制并逐文件校验；
        # 校验通过后才把软删项搬回备份区，避免"先搬走→回滚中途失败→文件丢失"。
        if to_live:
            # 回灌线上：先备份当前状态（可回滚），再逐文件校验后覆盖
            pre = self.snapshot(agents=[item["agent"]], apply=True, now=now,
                                actor="memory_restore", note=f"pre-restore {run_id}")
            out["pre_restore"] = pre["agents"][0]["run_id"] if pre["agents"] else None
            manifest = json.loads((src / "manifest.json").read_text(encoding="utf-8"))
            for f in manifest.get("files", []):
                stored = self.root / f["stored_rel"]
                target = self.root / f["source_rel"]
                if not stored.exists():
                    out["restored_files"].append({"file": f["source_rel"], "ok": False,
                                                  "why": "stored_missing"})
                    continue
                if _sha256(stored) != f["sha256"]:
                    out["restored_files"].append({"file": f["source_rel"], "ok": False,
                                                  "why": "sha256_mismatch"})
                    continue
                if f.get("kind") == "db":
                    _copy_sqlite(stored, target)
                    chk = sqlite3.connect(target, timeout=30)
                    try:
                        integrity = chk.execute("PRAGMA integrity_check").fetchone()[0]
                    finally:
                        chk.close()
                    out["restored_files"].append({"file": f["source_rel"],
                                                  "ok": integrity == "ok",
                                                  "integrity": integrity})
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(stored, target)
                    out["restored_files"].append({"file": f["source_rel"],
                                                  "ok": _sha256(target) == f["sha256"]})
            out["ok"] = (all(x.get("ok") for x in out["restored_files"])
                         if out["restored_files"] else False)

        # 只有回灌成功（或本来就只取回备份）才把软删项搬回备份区
        if item["state"] == "deleted" and (not to_live or out["ok"]):
            conn = self._conn()
            try:
                dst = self.backup_dir / item["agent"] / item["run_id"]
                dst.parent.mkdir(parents=True, exist_ok=True)
                if dst.exists():
                    dst = dst.with_name(dst.name + "-restored-" + secrets.token_hex(2))
                shutil.move(str(src), str(dst))
                conn.execute(
                    "UPDATE items SET state='live', dir_rel=?, restored_at=?, "
                    "trashed_at=NULL, purge_after=NULL, created_at=?, note=coalesce(note,'')||? "
                    "WHERE run_id=?",
                    (self._rel(dst), _now_str(now), _now_str(now),
                     f" | 于 {_now_str(now)} 从软删区取回（原始创建时间见 manifest）", run_id))
                conn.commit()
                out["moved"] = True
                out["to"] = self._rel(dst)
            finally:
                conn.close()
        elif item["state"] == "live":
            out["to"] = item["dir_rel"]
        return out

    # ----------------------------------------------------------------- 物理删除
    def purge(self, apply: bool = True, grace_days: int | None = None,
              now: datetime | None = None, actor: str = "memory_gc") -> dict:
        """把冷静期满的软删项物理删除（只从 `.trash/memory/` 发起，绝不删 live）。"""
        pol = self.policy({"grace_days": grace_days})
        now = now or datetime.now()
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT * FROM items WHERE state='deleted' ORDER BY trashed_at, id").fetchall()
            out = {"apply": bool(apply), "grace_days": pol["grace_days"], "purged": [],
                   "waiting": 0, "skipped": []}
            for row in rows:
                if grace_days is not None:
                    due_at = _parse(row["trashed_at"] or row["created_at"])
                    due = due_at + timedelta(days=pol["grace_days"]) if due_at else None
                else:
                    due = _parse(row["purge_after"] or row["trashed_at"])
                if not due or due > now:
                    out["waiting"] += 1
                    continue
                path = self.root / row["dir_rel"]
                if not _inside(path, self.trash_dir):
                    out["skipped"].append({"run_id": row["run_id"],
                                           "why": "not_in_trash", "dir": row["dir_rel"]})
                    continue
                if not path.exists():
                    if apply:
                        conn.execute("UPDATE items SET state='purged', purged_at=?, "
                                     "note=coalesce(note,'')||' | 目录已不存在' WHERE run_id=?",
                                     (_now_str(now), row["run_id"]))
                        conn.commit()
                    out["purged"].append({"run_id": row["run_id"], "agent": row["agent"],
                                          "bytes": 0, "dir": row["dir_rel"],
                                          "note": "already_missing",
                                          "dry_run": not apply})
                    continue
                if not apply:
                    out["purged"].append({"run_id": row["run_id"], "agent": row["agent"],
                                          "bytes": row["bytes"], "dir": row["dir_rel"],
                                          "dry_run": True})
                    continue
                shutil.rmtree(path)
                conn.execute("UPDATE items SET state='purged', purged_at=? WHERE run_id=?",
                             (_now_str(now), row["run_id"]))
                conn.commit()
                out["purged"].append({"run_id": row["run_id"], "agent": row["agent"],
                                      "bytes": row["bytes"], "dir": row["dir_rel"]})
            out["freed_bytes"] = sum(x.get("bytes", 0) for x in out["purged"])
            out["actor"] = actor
            return out
        finally:
            conn.close()
