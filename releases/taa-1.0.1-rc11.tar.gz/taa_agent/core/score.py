"""首席竞选积分：把 `reputation_events`（原始事实）折算成周期积分。

两本账的分工（**不可混淆**，2026-11-03 定）：
  - `reputation_events` = 原始事实，谁做了什么，永久保留，供 agent 能力画像使用；
  - `score_events`      = 按**裁决口径**折算过的周期积分，可重算、可换版、可封顶。

折算必须**幂等**：`idem_key = 'rep:<事件id>'` 唯一，同一源事件 settle 多少次只入账一次
（`insert or ignore` + UNIQUE 兜底，不是靠"记得别重复跑"）。

口径 v1（可改，改口径只需重算，不改裁决逻辑）：

| 源事件 | 权重 | 理由 |
|---|---:|---|
| `task_approved` | 1.0 | 真实承接，最硬信号 |
| `contribution:author` | 1.0 | 署名作者 |
| `contribution:reproducer` | 1.2 | 复现比署名更难，权重最高 |
| `contribution:reviewer` | 0.8 | 评审 |
| `contribution:data` / `:tool` | 0.6 / 0.4 | 辅助 |
| `bookmarked` | 0.5 | 一次点击，信号弱，不能与交付同价 |
| `request_changes` / `task_blocked` | 1.0 | 负分原样传递（源事件本身已是负值） |
| 其它 | 1.0 | 未知类型不吞掉，保持可解释 |
"""
from __future__ import annotations

SCORE_WINDOW_DAYS = 7
WEIGHTS_VERSION = "v1"

WEIGHTS: dict[str, float] = {
    "task_approved": 1.0,
    "contribution:author": 1.0,
    "contribution:reproducer": 1.2,
    "contribution:reviewer": 0.8,
    "contribution:data": 0.6,
    "contribution:tool": 0.4,
    "bookmarked": 0.5,
    "request_changes": 1.0,
    "task_blocked": 1.0,
}
DEFAULT_WEIGHT = 1.0


def weight_of(event_type: str) -> float:
    return WEIGHTS.get(event_type, DEFAULT_WEIGHT)


def settle(conn, owner_id: str | None = None, *, days: int = SCORE_WINDOW_DAYS) -> dict:
    """把窗口内**尚未折算**的 reputation_events 折进 score_events。

    `owner_id=None` 表示全部 owner。返回 {"scanned": n, "written": m}。
    """
    sql = (
        "select r.id, r.agent_id, r.event_type, r.points, a.owner_id "
        "from reputation_events r join agents a on a.id=r.agent_id "
        "left join score_events s on s.idem_key='rep:'||r.id "
        "where s.id is null and r.created_at>=datetime('now','localtime',?)"
    )
    args: list = [f"-{int(days)} days"]
    if owner_id is not None:
        sql += " and coalesce(a.owner_id,'')=?"
        args.append(owner_id)
    rows = conn.execute(sql, args).fetchall()

    written = 0
    for r in rows:
        eid, aid, etype, pts, oid = r[0], r[1], r[2], r[3], r[4]
        w = weight_of(str(etype))
        cur = conn.execute(
            "insert or ignore into score_events(agent_id, owner_id, event_type, points,"
            " weight, idem_key, meta) values(?,?,?,?,?,?,?)",
            (aid, oid, etype, float(pts or 0) * w, w, f"rep:{eid}",
             f'{{"source":"reputation_events","id":{int(eid)},"weights":"{WEIGHTS_VERSION}"}}'))
        written += int(cur.rowcount or 0)
    if written:
        conn.commit()
    return {"scanned": len(rows), "written": written}


def total(conn, agent_id: str, *, days: int = SCORE_WINDOW_DAYS) -> float:
    row = conn.execute(
        "select coalesce(sum(points),0) s from score_events "
        "where agent_id=? and at>=datetime('now','localtime',?)",
        (agent_id, f"-{int(days)} days")).fetchone()
    return float(row[0] or 0)


def totals(conn, agent_ids: list[str], *, days: int = SCORE_WINDOW_DAYS) -> dict[str, float]:
    if not agent_ids:
        return {}
    marks = ",".join("?" * len(agent_ids))
    rows = conn.execute(
        "select agent_id, coalesce(sum(points),0) s from score_events "
        f"where agent_id in ({marks}) and at>=datetime('now','localtime',?) "
        "group by agent_id",
        (*agent_ids, f"-{int(days)} days")).fetchall()
    return {str(r[0]): float(r[1] or 0) for r in rows}


def explain(conn, agent_id: str, *, days: int = SCORE_WINDOW_DAYS) -> list[dict]:
    """按事件类型汇总本周期积分（供"为什么他当首席"的解释，只读）。"""
    rows = conn.execute(
        "select event_type, count(*) n, round(sum(points),3) s from score_events "
        "where agent_id=? and at>=datetime('now','localtime',?) "
        "group by event_type order by s desc",
        (agent_id, f"-{int(days)} days")).fetchall()
    return [{"event_type": str(r[0]), "count": int(r[1]), "points": float(r[2] or 0)}
            for r in rows]


__all__ = ["settle", "total", "totals", "explain", "weight_of",
           "WEIGHTS", "WEIGHTS_VERSION", "SCORE_WINDOW_DAYS"]
