'use strict';
/*
 * TAA DNS guard for the OpenCode Node child.
 *
 * macOS mDNSResponder can hold a partial/negative cache for a host while
 * `dig` still resolves it.  OpenCode's Node fetch then fails with:
 *     Error: getaddrinfo ENOTFOUND api.deepseek.com
 *
 * This preload keeps Node's normal resolver as the fast path and only falls
 * back to `dig +short` when getaddrinfo fails.  It does not bypass TLS: the
 * HTTPS client still uses the original hostname for SNI/certificate checks.
 */
const dns = require('dns');
const { execFileSync } = require('child_process');

const originalLookup = dns.lookup;
const originalPromiseLookup = dns.promises && dns.promises.lookup;
const forceFallback = process.env.TAA_DNS_GUARD_TEST === '1';
const debug = process.env.TAA_DNS_GUARD_DEBUG === '1';

function digAddress(host) {
  if (!host || /^[0-9.]+$/.test(host) || host.includes(':')) return null;
  try {
    const out = execFileSync('dig', ['+short', '+time=2', '+tries=1', host, 'A'], {
      encoding: 'utf8', timeout: 4000, stdio: ['ignore', 'pipe', 'ignore'],
    });
    const ips = out.split(/\r?\n/)
      .map((s) => s.trim())
      .filter((s) => /^(?:\d{1,3}\.){3}\d{1,3}$/.test(s));
    if (debug && ips.length) console.error('[dns-guard] dig fallback', host, ips[0]);
    return ips[0] || null;
  } catch (_) {
    return null;
  }
}

function normalize(options) {
  if (typeof options === 'number') return { family: options };
  return options && typeof options === 'object' ? options : {};
}

dns.lookup = function lookup(host, options, callback) {
  let opts = options;
  let cb = callback;
  if (typeof opts === 'function') {
    cb = opts;
    opts = {};
  }
  if (typeof cb !== 'function') {
    // Preserve Node's TypeError for misuse.
    return originalLookup.apply(this, arguments);
  }
  const o = normalize(opts);
  const done = (err, address, family) => {
    if (!err && !forceFallback) return cb(null, address, family);
    const ip = digAddress(String(host));
    if (!ip) return cb(err || new Error('dns fallback failed'));
    if (o.all) return cb(null, [{ address: ip, family: 4 }]);
    return cb(null, ip, 4);
  };
  return originalLookup.call(this, host, o, done);
};

if (originalPromiseLookup) {
  dns.promises.lookup = async function lookup(host, options) {
    try {
      const r = await originalPromiseLookup.call(dns.promises, host, options);
      if (!forceFallback) return r;
    } catch (err) {
      if (!forceFallback) {
        const ip = digAddress(String(host));
        if (!ip) throw err;
        const o = normalize(options);
        return o.all ? [{ address: ip, family: 4 }] : { address: ip, family: 4 };
      }
    }
    const ip = digAddress(String(host));
    if (!ip) throw new Error('dns fallback failed');
    const o = normalize(options);
    return o.all ? [{ address: ip, family: 4 }] : { address: ip, family: 4 };
  };
}
