"""Owner location helpers.

`home_location` is the public, user-editable label (it may intentionally be
coarse, wrong, or include a district).  `weather_city` is a separate canonical
city used only for weather geocoding, so "成都·武侯" is displayed as entered
but weather asks for "成都".
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

HOME = Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")).expanduser()
STATE = HOME / "weather_location.json"
MUNICIPALITIES = ("北京", "上海", "天津", "重庆", "香港", "澳门")


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip(" \t\r\n，,、·/|")


def normalize_city(value: str) -> str:
    """Best-effort city-level extraction for weather queries.

    This is intentionally only used at the weather boundary.  It never edits
    the public display value.
    """
    raw = _clean(value)
    if not raw:
        return ""
    parts = [p.strip() for p in re.split(r"[·，,、/|]+", raw) if p.strip()]
    first = parts[0] if parts else raw

    # Municipality names are city-level even when followed by a district.
    for m in MUNICIPALITIES:
        if first.startswith(m):
            return m

    # "四川省成都市武侯区" / "成都市武侯区" / "上海市浦东新区"
    for part in parts:
        p = re.sub(r"^.*?(?:省|自治区)", "", part).strip()
        found = re.search(r"([\u4e00-\u9fff]{2,10})市", p)
        if found:
            city = found.group(1).strip()
            if city.endswith(("省", "区", "县")):
                city = city[:-1]
            if city:
                return city

    # "成都·武侯" / "Chengdu, Sichuan" 的第一段
    if first != raw:
        if first.endswith(("区", "县", "镇", "街道")):
            return ""
        return first

    # A bare district/county is not a weather city.
    if re.search(r"(区|县|镇|街道)$", first):
        return ""
    return first


def load_weather_city() -> str:
    try:
        data = json.loads(STATE.read_text(encoding="utf-8"))
        return str(data.get("city") or "").strip()
    except Exception:
        return ""


def load_info() -> dict:
    try:
        data = json.loads(STATE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def set_weather_city(city: str, *, source: str = "manual") -> str:
    city = normalize_city(city) or _clean(city)
    if not city:
        return ""
    HOME.mkdir(parents=True, exist_ok=True)
    data = {
        "city": city,
        "source": str(source or "manual"),
        "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    os.replace(tmp, STATE)
    return city


def city_for_display(display: str) -> str:
    return normalize_city(display)
