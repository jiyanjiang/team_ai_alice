"""一键诊断包（docs/532 · P-E）。

P3 门禁要求"出问题能查"：用户点一下导出一个 zip，里面只有**结构化事实**，
不含 key、不含绝对路径、不含数据库文件本身。

包含：
  diag.json      版本（发行号 + 运行时号）、python/平台、表计数、
                 `PRAGMA integrity_check`、`message_route` 状态汇总、环境变量**名字**
  routes.json    最近 100 条 message_route（房间/消息/owner/状态，用于查"卡在 claimed"）
  log_tail.txt   最新一个 runtime/*.log 的最后 200 行（脱敏后）
  README.txt     说明与用法

安全：
  * 全程只读（`mode=ro` 连接），不写业务库；
  * 绝对路径一律换成 `~` / `<repo>`；key/secret/token 一类值一律换成 `<redacted>`；
  * 不打包任何 `*.db` / `*.key` / `.env`；打包后由 `_assert_clean()` 再自检一遍。
"""

from __future__ import annotations

import datetime
import io
import json
import os
import platform
import re
import sqlite3
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_LOG_LINES = 200
MAX_ROUTES = 100

_SECRET_PATTERNS = [
    (re.compile(r"sk-[A-Za-z0-9_\-]{8,}"), "<redacted>"),
    (re.compile(r"(?i)\b(api[_-]?key|secret|token|passwd|password)\b(\s*[:=]\s*)(\S+)"), r"\1\2<redacted>"),
    (re.compile(r"\b[a-f0-9]{48,}\b"), "<hex-redacted>"),
]
_PATH_PATTERNS = [
    (re.compile(r"/(?:Users|home)/[^/\s:\"']+"), "~"),
]


def scrub(text: str) -> str:
    """去掉绝对路径与凭据（日志、JSON 文本统一走这里）。"""
    out = str(text or "")
    for pat, rep in _SECRET_PATTERNS:
        out = pat.sub(rep, out)
    for pat, rep in _PATH_PATTERNS:
        out = pat.sub(rep, out)
    out = out.replace(str(ROOT), "<repo>")
    return out


def _ro_conn():
    """只读连接；拿不到就返回 None（诊断包不该因为库被锁而失败）。"""
    try:
        from core import db as dbmod
        db = getattr(dbmod, "DB_PATH", "") or ""
        if not db:
            return None
        uri = Path(db).as_uri() + "?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=2.0)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception:                                            # noqa: BLE001
        return None


def _version() -> dict:
    out: dict = {"python": sys.version.split()[0], "platform": f"{platform.system()} {platform.release()}"}
    for name, path in (("dist", ROOT / "dist" / "VERSION"), ("repo", ROOT / "VERSION")):
        try:
            out[name] = path.read_text(encoding="utf-8").strip()[:40]
        except Exception:                                        # noqa: BLE001
            continue
    try:
        from core.distribution import runtime_version
        out["runtime"] = str(runtime_version())
    except Exception:                                            # noqa: BLE001
        pass
    return out


def _counts(conn) -> dict:
    if conn is None:
        return {}
    out: dict = {}
    for tbl in ("agents", "rooms", "room_messages", "posts", "replies", "message_route",
                "group_commands", "peer_nodes", "center_friends", "enroll_tokens"):
        try:
            out[tbl] = int(conn.execute(f"select count(*) n from {tbl}").fetchone()["n"])
        except sqlite3.Error:
            continue
    return out


def _route_summary(conn) -> dict:
    if conn is None:
        return {}
    try:
        rows = conn.execute("select coalesce(state,'') s, count(*) n from message_route group by s").fetchall()
        return {str(r["s"] or "?"): int(r["n"]) for r in rows}
    except sqlite3.Error:
        return {}


def _routes(conn) -> list[dict]:
    if conn is None:
        return []
    try:
        rows = conn.execute(
            "select room_id,message_id,client_message_id,owner,coalesce(state,'') state,"
            "claimed_at,finished_at from message_route order by rowid desc limit ?",
            (MAX_ROUTES,)).fetchall()
        return [{k: ("" if r[k] is None else r[k]) for k in r.keys()} for r in rows]
    except sqlite3.Error:
        return []


def _integrity(conn) -> str:
    if conn is None:
        return "unavailable"
    try:
        return str(conn.execute("PRAGMA integrity_check").fetchone()[0])
    except sqlite3.Error as exc:
        return f"error: {type(exc).__name__}"


def _env_names() -> list[str]:
    """只给变量名与是否非空，绝不给值。"""
    return sorted(k for k in os.environ if k.upper().startswith(("TAA_", "TEAMAI_")))


def _log_tail() -> str:
    try:
        logs = sorted((ROOT / "runtime").glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not logs:
            return "(no runtime log)"
        lines = logs[0].read_text(encoding="utf-8", errors="replace").splitlines()[-MAX_LOG_LINES:]
        return f"# {logs[0].name} (last {len(lines)} lines)\n" + "\n".join(lines)
    except Exception as exc:                                     # noqa: BLE001
        return f"(log unavailable: {type(exc).__name__})"


def build_zip() -> bytes:
    conn = _ro_conn()
    try:
        diag = {
            "generated_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "versions": _version(),
            "counts": _counts(conn),
            "integrity": _integrity(conn),
            "message_route": _route_summary(conn),
            "env_names": _env_names(),
            "note": "no keys, no absolute paths, no db files",
        }
        routes = _routes(conn)
    finally:
        if conn is not None:
            conn.close()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("diag.json", scrub(json.dumps(diag, ensure_ascii=False, indent=2)))
        z.writestr("routes.json", scrub(json.dumps(routes, ensure_ascii=False, indent=2)))
        z.writestr("log_tail.txt", scrub(_log_tail()))
        z.writestr("README.txt", scrub(
            "TAA 诊断包\n"
            "  diag.json    版本/计数/完整性/message_route 汇总（无 key、无绝对路径）\n"
            "  routes.json  最近 100 条指令路由记录（查卡住的 claimed）\n"
            "  log_tail.txt 最新运行时日志尾部（已脱敏）\n"
            "用法：发回给维护者即可定位；不含任何数据库文件。\n"))
    data = buf.getvalue()
    _assert_clean(data)
    return data


def _assert_clean(data: bytes) -> None:
    """打包自检：一旦带上库文件/明文 key/绝对路径就拒绝导出（宁可不出）。"""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = z.namelist()
        for n in names:
            low = n.lower()
            if low.endswith((".db", ".sqlite", ".key", ".env")) or ".db-" in low:
                raise ValueError(f"diag bundle must not contain {n}")
        blob = "\n".join(z.read(n).decode("utf-8", "replace") for n in names)
    if re.search(r"sk-[A-Za-z0-9_\-]{8,}", blob):
        raise ValueError("diag bundle contains a key-like string")
    if re.search(r"/(?:Users|home)/[^/\s:\"']+", blob):
        raise ValueError("diag bundle contains an absolute home path")


def export(out: str | Path = "") -> Path:
    data = build_zip()
    if not out:
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        out = Path.cwd() / f"taa-diag-{stamp}.zip"
    path = Path(out).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path
