"""自动 apply（R34 落地）：沙箱 stage/validate + 快照/回滚。

流程：fetch（拉清单+bundle 并验签）→ stage（解到 .staging）→ validate（编译+导入）
     → snapshot（备份当前代码到 .snapshots）→ promote（替换代码目录）。
rollback 从最近快照恢复。改代码后需重启服务生效。
"""
from __future__ import annotations

import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
from pathlib import Path

from . import distribution

ROOT = distribution.ROOT
STAGING = ROOT / ".staging"
SNAPDIR = ROOT / ".snapshots"
KEEP_SNAPSHOTS = 5

# 更新代码时**绝不触碰**的数据（agent 设置/密钥/配置等）
PRESERVED = ["agents/", "data.db", "bootstrap/", "config.yaml", "rooms/",
             "runtime/", "events.db", ".snapshots/", "certs/", "static/uploads/"]


def version_tuple(v: str) -> tuple:
    parts = re.findall(r"\d+", v or "")
    return tuple(int(x) for x in parts[:3]) if parts else (0,)


def version_gt(a: str, b: str) -> bool:
    return version_tuple(a) > version_tuple(b)


def agent_fingerprint(conn) -> dict:
    """agent 设置指纹（id/name/persona），用于验证更新后未被改动。"""
    import hashlib
    rows = conn.execute(
        "SELECT id, name, full_name, persona_json FROM agents ORDER BY id").fetchall()
    h = hashlib.sha256()
    for r in rows:
        h.update(f"{r['id']}|{r['name']}|{r['persona_json']}".encode("utf-8"))
    return {"count": len(rows), "ids": [r["id"] for r in rows], "hash": h.hexdigest()[:16]}


def _clean(ti: tarfile.TarInfo):
    if "__pycache__" in ti.name:
        return None
    # uploads 是运行时数据（PRESERVED），不进代码快照（避免撑爆快照 / 回滚覆盖用户数据）
    if ti.name == "static/uploads" or ti.name.startswith("static/uploads/"):
        return None
    return ti


def fetch_bundle(base: str, token: str | None = None,
                 agent: str | None = None, ctx=None) -> tuple[dict, bytes]:
    """从 peer 拉取并校验（签名 + bundle sha256）。返回 (manifest, bundle_bytes)。

    · `token`：enroll 发放令牌（客户端通常没有服务器的 `bootstrap/enroll.key`）。
    · `agent`：**用本机 agent 身份签名**（读 `agents/<id>/.key`）——`/v1/bootstrap/manifest`
      本就接受 agent 签名；这样**异机免 enroll token 也能自更新**（修"客户端无 token → 401 → 静默失败"）。
    · `ctx`：客户端已配置的 CA/SSL context；缺省时退回系统默认（会拒绝自签名证书）。
    """
    headers = {"X-Enroll-Token": token} if token else {}
    _akey = None
    if agent and not token:
        try:
            _akey = json.loads((ROOT / "agents" / agent / ".key").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            _akey = None

    def _get(path: str) -> bytes:
        req = urllib.request.Request(base.rstrip("/") + path, headers=dict(headers))
        if _akey:
            import hashlib
            import hmac
            import secrets as _secrets
            from . import security
            ts, nonce = str(int(time.time())), _secrets.token_hex(8)
            req.add_header("X-TeamAI-Key", _akey["key_id"])
            req.add_header("X-TeamAI-Timestamp", ts)
            req.add_header("X-TeamAI-Nonce", nonce)
            req.add_header("X-TeamAI-Signature",
                           security.sign(_akey["key"], "GET", path, b"", ts, nonce))
        with urllib.request.urlopen(req, timeout=120, context=ctx) as r:
            return r.read()

    m = json.loads(_get("/v1/bootstrap/manifest").decode("utf-8"))
    if not distribution.verify_manifest(m, m.get("pubkey", "")):
        raise ValueError("manifest signature invalid")
    data = _get("/v1/dist/bundle")
    import hashlib
    sha = hashlib.sha256(data).hexdigest()
    if sha != (m.get("bundle") or {}).get("sha256"):
        raise ValueError(f"bundle sha mismatch: {sha} != {(m.get('bundle') or {}).get('sha256')}")
    return m, data


def stage(bundle_bytes: bytes, dest: Path | None = None) -> Path:
    dest = Path(dest) if dest else STAGING
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(bundle_bytes), mode="r:gz") as tf:
        tf.extractall(dest)
    return dest


def _staged_protocol_major(staged: Path) -> int:
    try:
        txt = (staged / "core" / "protocol.py").read_text(encoding="utf-8")
        m = re.search(r"PROTOCOL_MAJOR\s*=\s*(\d+)", txt)
        return int(m.group(1)) if m else -1
    except OSError:
        return -1


def _staged_version(staged: Path) -> str:
    try:
        return (staged / "dist" / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def parse_requirements(path: Path) -> set:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return set()
    out = set()
    for ln in text.splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#"):
            out.add(re.split(r"[<>=!~\[]", ln)[0].strip())
    return {x for x in out if x}


def precheck(staged: Path, cur_version: str = "", cur_major: int = 1) -> dict:
    """跨版本/依赖预检：协议 major、版本、requirements 差异。"""
    errors: list[str] = []
    warnings: list[str] = []
    sp = _staged_protocol_major(staged)
    if sp != -1 and sp != cur_major:
        errors.append(f"protocol major mismatch: staged={sp} current={cur_major}")
    sv = _staged_version(staged)
    added = parse_requirements(staged / "requirements.txt") - parse_requirements(ROOT / "requirements.txt")
    removed = parse_requirements(ROOT / "requirements.txt") - parse_requirements(staged / "requirements.txt")
    if added:
        warnings.append("新增依赖：" + ", ".join(sorted(added)))
    if removed:
        warnings.append("移除依赖：" + ", ".join(sorted(removed)))
    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "staged_version": sv, "current_version": cur_version,
            "protocol_major": sp, "deps_added": sorted(added), "deps_removed": sorted(removed)}


def validate(dest: Path) -> tuple[bool, str]:
    """沙箱校验：编译所有 .py + 导入核心模块。"""
    dest = Path(dest)
    py = sys.executable
    bad: list[str] = []
    targets: list[Path] = []
    for d in ("core", "dist", "cli"):
        targets += sorted((dest / d).rglob("*.py"))
    for f in targets:
        r = subprocess.run([py, "-m", "py_compile", str(f)], capture_output=True, text=True)
        if r.returncode != 0:
            bad.append(f"{f.relative_to(dest)}: {r.stderr.strip().splitlines()[-1][:120]}")
    if bad:
        return False, "compile fail:\n" + "\n".join(bad[:10])
    r = subprocess.run(
        [py, "-c", "import sys; sys.path.insert(0,'.'); import core.protocol, core.federation, core.persona"],
        cwd=str(dest), capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        return False, "import smoke failed: " + r.stderr.strip()[-300:]
    return True, "ok"


def snapshot(paths: list[str] | None = None) -> Path:
    """备份代码目录到快照；`paths` 给定时**只备份这些相对路径**（S6 分享条目回滚用）。

    默认（paths=None）行为不变。`static/uploads` 属运行时数据（PRESERVED），不进快照——
    否则快照被上传目录撑爆、且回滚会覆盖用户数据。
    """
    SNAPDIR.mkdir(parents=True, exist_ok=True)
    p = SNAPDIR / f"{time.strftime('%Y%m%d-%H%M%S')}.tar.gz"
    with tarfile.open(p, "w:gz") as tf:
        if paths:
            for rel in paths:
                src = ROOT / rel
                if src.exists():
                    tf.add(src, arcname=rel, filter=_clean)
        else:
            for d in distribution.CODE_DIRS:
                src = ROOT / d
                if src.exists():
                    tf.add(src, arcname=d, filter=_clean)
            for name in distribution.CODE_FILES:
                src = ROOT / name
                if src.exists():
                    tf.add(src, arcname=name)
    for old in sorted(SNAPDIR.glob("*.tar.gz"))[:-KEEP_SNAPSHOTS]:
        old.unlink()
    return p


def promote(dest: Path) -> None:
    dest = Path(dest)
    for d in distribution.CODE_DIRS:
        src, dst = dest / d, ROOT / d
        if src.exists():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__"))
    for name in distribution.CODE_FILES:
        src = dest / name
        if src.exists():
            shutil.copy2(src, ROOT / name)
    distribution._BUNDLE_CACHE.update(key=None, bytes=None)


def list_snapshots() -> list[dict]:
    SNAPDIR.mkdir(parents=True, exist_ok=True)
    out = []
    for p in sorted(SNAPDIR.glob("*.tar.gz")):
        out.append({"name": p.name, "size": p.stat().st_size,
                    "at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(p.stat().st_mtime))})
    return out


def rollback() -> Path | None:
    snaps = sorted(SNAPDIR.glob("*.tar.gz"))
    if not snaps:
        return None
    latest = snaps[-1]
    with tarfile.open(latest, "r:gz") as tf:
        tf.extractall(ROOT)
    latest.unlink()
    distribution._BUNDLE_CACHE.update(key=None, bytes=None)
    return latest


def _refresh_runtime_shims() -> list[str]:
    """把 `dist/` 的执行入口刷到 `runtime/`（**仅**当 runtime 下已有同名文件时）。

    `runtime/` 属 PRESERVED（保护日志/状态），但这些是**代码 shim**；若不刷新，
    凡"跑 runtime/ 旧副本"的机器**永远升不上去**（Darwin 实测踩到：dispatcher 一直跑旧码）。
    """
    done: list[str] = []
    for name in ("supervisor.py", "dispatcher.py", "loop.py", "chatroom_agent.py",
                 "harvest_agent.py", "qa_agent.py", "redact.py", "sync.py"):
        src, dst = ROOT / "dist" / name, ROOT / "runtime" / name
        if src.exists() and dst.exists():
            try:
                shutil.copy2(src, dst)
                done.append(f"dist/{name} -> runtime/{name}")
            except OSError:
                pass
    s2, d2 = ROOT / "cli" / "teamai.py", ROOT / "runtime" / "teamai.py"
    if s2.exists() and d2.exists():
        try:
            shutil.copy2(s2, d2)
            done.append("cli/teamai.py -> runtime/teamai.py")
        except OSError:
            pass
    return done


def apply_bundle(bundle_bytes: bytes, dest: Path | None = None, cur_version: str = "",
                 cur_major: int = 1, install_deps: bool = False) -> dict:
    """stage → precheck → validate → (装依赖) → snapshot → promote。"""
    staged = stage(bundle_bytes, dest)
    pc = precheck(staged, cur_version, cur_major)
    if not pc["ok"]:
        return {"ok": False, "stage": "precheck", "precheck": pc, "staged": str(staged)}
    ok, log = validate(staged)
    if not ok:
        return {"ok": False, "stage": "validate", "log": log, "precheck": pc,
                "staged": str(staged)}
    dep_log = ""
    if install_deps and pc["deps_added"]:
        from .deps import pip_install          # 官方→镜像降级 + timeout/retries
        res = pip_install(list(pc["deps_added"]), timeout=900, quiet=True)
        dep_log = (f"deps installed via {res['index']}" if res["ok"]
                   else "deps install failed（网络受限，可手动 pip install）")
    snap = snapshot()
    promote(staged)
    shims = _refresh_runtime_shims()          # ★ 刷新 runtime/ 执行 shim（否则跑旧副本的机器升不上去）
    return {"ok": True, "staged": str(staged), "snapshot": snap.name, "precheck": pc,
            "log": ("applied " + dep_log).strip() + " (重启服务后生效)",
            "runtime_shims": shims}
