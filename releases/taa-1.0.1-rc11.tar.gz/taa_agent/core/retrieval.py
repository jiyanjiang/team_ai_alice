"""检索层：给 `research.ask` 提供**可核验的来源**（而不是让模型凭空给 URL）。

设计目标（与 docs/37 七步对齐）：
  · 只做**取回**，四条通道（2026-11-01 Owner 定）：
      1) **DeepSeek Search API** —— 通用网页检索，中文/英文都认，返回标题/URL/摘要/正文；
      2) **PMC 免费全文** —— 学术主力，**只认英文**；
      3) **PubMed 摘要** —— 学术兜底，同样只认英文；
      4) **万方/知网题录**（经 DeepSeek 的 site: 限定）—— 只给中文字段题录+摘要，
         正文在付费墙后，grade 恒 secondary + paywalled=True，**只作线索**。
    Bing / OpenAlex / Wikipedia / 百度学术 **检索**已停用（无效、欠费、或链接不可引用）；
    Wikipedia 仅保留「按条目直取」（curated()），供专著工作区作底料。
  · **语言分流**：NCBI 没有中文索引（中文串等于无意义 token），故中文问题先用
    DeepSeek Chat 译成 2 条英文检索式，再喂 PubMed/PMC；
  · 每条结果保留 URL、标题、摘要、正文摘录（优先用通道自带的正文，避免二次抓页）；
  · 来源分级保守：官方/一手 > 权威二手 > 弱二手；拿不准就降级；
  · 全部落盘缓存，便于复核与离线重跑。

用法：
    from core.retrieval import gather
    docs = gather("扬中 太平洲 圩 历史", limit=8)
    # -> [{"id":"S1","title":...,"url":...,"text":...,"grade":"official",...}]

注意：本模块**唯一**的 LLM 调用是「中文→英文检索式」的语言转换（不生成事实）；
密钥一律从 config 读取，本模块不写任何密钥。
"""
from __future__ import annotations

import hashlib
import html
import os
import json
import re
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FuturesTimeout
from contextvars import ContextVar, copy_context
from dataclasses import dataclass, asdict, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "research" / "_retrieval_cache"

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"}

# 来源分级（保守）
OFFICIAL_HOSTS = (
    ".gov.cn", "gov.cn", ".edu.cn", "edu.cn", "archives.", "da.gov.cn",
    "loc.gov", "archives.gov", "nationalarchives.gov", "europa.eu",
)
PRIMARY_HOSTS = ("doi.org", "nature.com", "science.org", "aps.org", "arxiv.org",
                 "jstor.org", "tandfonline.com", "sagepub.com", "springer.com",
                 "cambridge.org", "oxford.com", "ac.cn",
                 # 维基文库：古籍原文转录，按一手史料处理（版本需在出处注明）
                 "wikisource.org")
SECONDARY_HOSTS = ("wikipedia.org", "baike.baidu.com", "britannica.com",
                   "openalex.org", "crossref.org", "zhihu.com", "cnki.net")
WEAK_HOSTS = ("sohu.com", "163.com", "sina.com.cn", "qq.com", "toutiao.com",
              "baijiahao.baidu.com", "weixin.qq.com", "douban.com")


def grade_for(url: str) -> str:
    host = (urllib.parse.urlparse(url or "").hostname or "").lower()
    if any(host == h or host.endswith("." + h.lstrip(".")) or h in host for h in OFFICIAL_HOSTS):
        return "official"
    if any(h in host for h in PRIMARY_HOSTS):
        return "primary"
    if any(h in host for h in WEAK_HOSTS):
        return "weak"
    if any(h in host for h in SECONDARY_HOSTS):
        return "secondary"
    return "weak"


_HTTP_TIMEOUT = 20               # 单请求读超时；P0-a 定的“请求级”预算
_HTTP_ATTEMPTS = 2               # 只对 429/5xx 重试 1 次，别把预算烧在重试上


def _get(url: str, timeout: int = _HTTP_TIMEOUT,
         max_bytes: int = 2_500_000) -> tuple[str, str]:
    last = None
    for attempt in range(_HTTP_ATTEMPTS):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                ctype = r.headers.get("Content-Type", "")
                raw = r.read(max_bytes)
            return ctype, raw.decode("utf-8", "ignore")
        except Exception as e:  # noqa: BLE001
            last = e
            code = getattr(e, "code", 0)
            if code not in (429, 500, 502, 503, 504) or attempt == _HTTP_ATTEMPTS - 1:
                raise
            time.sleep(1.0)
    raise last  # type: ignore[misc]


def _left(deadline: float | None) -> bool:
    """还没到该通道的预算终点吗？（deadline 用 time.monotonic()）"""
    return deadline is None or time.monotonic() < deadline


class _RateLimiter:
    """最小间隔限速器。**限速睡眠在锁内、网络请求在锁外**——这样既守住 QPS，
    又不会把并发退化成串行（P0-a 的核心点）。"""

    def __init__(self, min_gap: float) -> None:
        self.gap = float(min_gap)
        self._lock = threading.Lock()
        self._last = 0.0

    def wait(self) -> None:
        with self._lock:
            delta = self.gap - (time.time() - self._last)
            if delta > 0:
                time.sleep(delta)
            self._last = time.time()


def _clean(s: str) -> str:
    s = re.sub(r"<(script|style|noscript|svg)[^>]*>.*?</\1>", " ", s or "", flags=re.S | re.I)
    s = re.sub(r"<br\s*/?>|</p>|</div>|</h[1-6]>|</li>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t\u00a0]+", " ", s)
    s = re.sub(r"\n\s*\n\s*\n+", "\n\n", s)
    return s.strip()


_HOST_CONC = 2                                  # 同域并发上限，别把一家站打挂
_HOST_SEMS: dict[str, threading.Semaphore] = {}
_HOST_SEMS_LOCK = threading.Lock()


def _host_sem(url: str) -> threading.Semaphore:
    host = (urllib.parse.urlparse(url).hostname or "?").lower()
    with _HOST_SEMS_LOCK:
        sem = _HOST_SEMS.get(host)
        if sem is None:
            sem = _HOST_SEMS[host] = threading.Semaphore(_HOST_CONC)
        return sem


def fetch_text(url: str, timeout: int = 15) -> str:
    """抓原页并抽正文；失败返回空串（不抛异常，便于批量）。"""
    try:
        with _host_sem(url):
            ctype, body = _get(url, timeout=timeout)
    except Exception:
        return ""
    if "pdf" in ctype.lower() or url.lower().endswith(".pdf"):
        return ""
    if "html" not in ctype.lower() and "text" not in ctype.lower():
        return ""
    # 优先 article/main，退化到整页
    m = re.search(r"<(article|main)[^>]*>(.*?)</\1>", body, re.S | re.I)
    core = m.group(2) if m else body
    txt = _clean(core)
    # 去掉导航/页脚常见的短行
    lines = [ln.strip() for ln in txt.splitlines() if len(ln.strip()) >= 20]
    return "\n".join(lines)[:20000]


# ---------------------------------------------------------------- DeepSeek Search
# 2026-11-01 Owner 定：Bing / OpenAlex / Wikipedia 检索全部停用，
# 通用网页检索改用 DeepSeek Search API（POST /v1/tools/search，5 QPS）。
# 它**认中文**，是中文题目（史学/地方史等）唯一能出结果的通道。
DS_SEARCH = os.environ.get("TEAMAI_DS_SEARCH_URL") or "https://api.deepseek.com/v1/tools/search"
_DS_CONTENT_MAX = 12000          # 单页正文喂给模型的字符上限
# 官方口径 rerank_score >= 1.5 算「高质量」，但实测中文冷门题（地方史/圩田）
# 全组只有 0.85~1.31 —— 按 1.5 硬砍会把唯一能出结果的通道砍空。
# 故 1.5 只作「可越过词面门槛」的信用分，不作删除线；是否入选仍交给 _keep()。
_DS_RERANK_TRUST = 1.5
_DS_LIMITER = _RateLimiter(0.34)     # 账号级 5 QPS，我们限 ~3 QPS 留余量


def _ds_key() -> str:
    try:
        from . import config as _cfg
        return _cfg.deepseek_key()
    except Exception:  # noqa: BLE001
        return ""


def deepseek_search(q: str, limit: int = 6, *, need_content: bool = True,
                    ori_question: str = "", timeout: int = 30,
                    deadline: float | None = None) -> list[dict]:
    """DeepSeek Search：通用网页检索（中文友好）。失败返回 []，错误进 last_errors()。"""
    q = (q or "").strip()[:128]
    if not q:
        return []
    if not _left(deadline):
        _LAST_ERR.setdefault("deepseek-search", []).append("通道预算用尽，未发起")
        return []
    key = _ds_key()
    if not key:
        _LAST_ERR.setdefault("deepseek-search", []).append("缺少 DeepSeek key")
        return []
    payload = {"query": q, "count": max(1, min(50, limit)), "need_content": bool(need_content)}
    ori = (ori_question or "").strip()[:128]
    if ori and ori != q:
        payload["ori_question"] = ori
    body = json.dumps(payload, ensure_ascii=False).encode()
    data = None
    for attempt in range(2):
        if not _left(deadline):
            _LAST_ERR.setdefault("deepseek-search", []).append("通道预算用尽（重试前）")
            return []
        _DS_LIMITER.wait()
        req = urllib.request.Request(DS_SEARCH, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {key}")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
            break
        except Exception as e:  # noqa: BLE001
            code = getattr(e, "code", 0)
            _LAST_ERR.setdefault("deepseek-search", []).append(f"{type(e).__name__}:{code}")
            # code==0 是传输层错误（连接重置/读超时），同样是瞬时的，值得重试一次
            if (code == 0 or code in (429, 500, 502, 503, 504)) and attempt == 0:
                time.sleep(1.0)
                continue
            return []
    out = []
    for it in (data or {}).get("results") or []:  # type: ignore[union-attr]
        url = (it.get("url") or "").strip().split("#")[0]   # 去掉 #1#11 之类的定位片段
        title = (it.get("title") or "").strip()
        if not url or not title:
            continue
        try:
            score = float(it.get("rerank_score") or 0)
        except (TypeError, ValueError):
            score = 0.0
        try:
            authority = int(it.get("authority") or 0)
        except (TypeError, ValueError):
            authority = 0
        grade = grade_for(url)
        # 权威度 4 但不属白名单站点：只提到 secondary，绝不冒充 official/primary
        if grade == "weak" and authority >= 4:
            grade = "secondary"
        body_text = (it.get("content") or "").strip()
        summary = (it.get("summary") or it.get("snippet") or "").strip()
        out.append({"provider": "deepseek-search", "title": title[:200], "url": url,
                    "snippet": summary[:800],
                    "text": (body_text or summary)[:_DS_CONTENT_MAX],
                    "grade": grade, "date": it.get("date") or "",
                    "authority": authority, "rerank_score": round(score, 3),
                    "site": it.get("site_name") or "", "fulltext": bool(body_text)})
    return out


# ---------------------------------------------------------------- 中文文献题录
# 百度学术实测最差（rerank 0.20~0.27、混学者主页、URL 是多重跳转链，引用出去点不开），
# 故不接；改用 DeepSeek Search 的 site: 限定取万方/知网的**题录**。
# 铁律：正文在付费墙后，这里只有题录+摘要 → grade 恒 secondary + paywalled=True，
# 只作线索，**不参与 fact_gate 的 official/primary 计数**。
_CN_SCHOLAR_SITES = (("万方", "site:wanfangdata.com.cn"), ("知网", "site:cnki.net"))


# 站内检索页 / 检索结果列表不是文献，别当线索交上去
_CN_JUNK_URL = ("s.wanfangdata.com.cn/paper", "xueshu.baidu.com/usercenter",
                "cnki.net/search", "kns.cnki.net")
_CN_JUNK_TITLE = ("万方数据知识服务平台 - 摘要", "检索结果", "搜索结果")


def cn_scholar(q: str, limit: int = 3, timeout: int = 30,
               deadline: float | None = None) -> list[dict]:
    """中文文献题录（万方/知网）。只给题录与摘要，不冒充正文。"""
    out: list[dict] = []
    for name, site in _CN_SCHOLAR_SITES:
        if not _left(deadline):
            _LAST_ERR.setdefault("cn-scholar", []).append(f"{name}：通道预算用尽")
            break
        # 站点限定必须留在 query 里，故先砍正文长度再拼算符（总长 <= 128）
        query = f"{(q or '').strip()[:100]} {site}"
        for it in deepseek_search(query, limit=limit, need_content=False,
                                  timeout=timeout, deadline=deadline):
            url = it.get("url") or ""
            title = it.get("title") or ""
            if any(x in url for x in _CN_JUNK_URL) or any(x in title for x in _CN_JUNK_TITLE):
                continue
            it.update({"provider": "cn-scholar", "grade": "secondary",
                       "paywalled": True, "fulltext": False,
                       "scholar_site": name, "text": it.get("snippet") or ""})
            out.append(it)
    return out


# ---------------------------------------------------------------- 中文 → 英文检索式
# PubMed/PMC 没有中文索引：实测「阿尔茨海默病」这种标准词也返回 0 条。
# 因此在喂 NCBI 之前，先把中文问题译成英文检索式（只做语言转换，不生成事实）。
_TRANS_PROMPT = (
    "你是学术检索助手。把下面的中文问题改写成 {n} 条英文检索式，供 PubMed 使用。\n"
    "要求：\n"
    "1) 每行一条，只输出检索式本身：不要编号、不要引号、不要解释、不要中文；\n"
    "2) 用核心术语（名词短语），不要整句翻译；2-5 个词，必要时用 AND 连接；\n"
    "3) 保留专有名词原样（地名、人名、病名）。\n\n"
    "中文问题：{q}\n"
)


def _is_cjk(s: str) -> bool:
    return bool(re.search(r"[\u4e00-\u9fff]", s or ""))


def _has_latin(s: str) -> bool:
    return bool(re.search(r"[A-Za-z]{2,}", s or ""))


def translate_queries(q: str, n: int = 2, timeout: int = 20) -> list[str]:
    """中文问题 → 英文检索式（最多 n 条）。失败返回 []（错误进 last_errors()）。"""
    q = (q or "").strip()
    if not q:
        return []
    cp = CACHE / f"trans_v1_{hashlib.sha1(f'{n}|{q}'.encode()).hexdigest()[:16]}.json"
    if cp.exists():
        try:
            cached = json.loads(cp.read_text(encoding="utf-8"))
            if isinstance(cached, list) and cached:
                return [str(x) for x in cached][:n]
        except Exception:
            pass
    try:
        from . import llm_http
        raw = llm_http.ask(_TRANS_PROMPT.format(n=n, q=q), max_tokens=160,
                           temperature=0.0, timeout=timeout)
    except Exception as e:  # noqa: BLE001
        raw = ""
        _LAST_ERR.setdefault("translate", []).append(f"{type(e).__name__}")
    out: list[str] = []
    for line in (raw or "").splitlines():
        s = line.strip().strip("-*•· \t\"'`")
        s = re.sub(r"^\d+[.、)]\s*", "", s).strip()
        if not s or _is_cjk(s) or not _has_latin(s) or len(s) > 120:
            continue
        if s.lower().startswith(("english", "query", "here")):
            continue
        if s not in out:
            out.append(s)
    out = out[:n]
    if not out:
        _LAST_ERR.setdefault("translate", []).append("未得到英文检索式")
        return []
    try:
        CACHE.mkdir(parents=True, exist_ok=True)
        cp.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- 检索计划（facet 分解）
# P0-b：不再“把原问题直接扔给搜索引擎”，先让 LLM 把问题拆成 2-3 个检索角度，
# 每个角度给中英各一条检索式。检索质量从“搜索引擎心情”回到我们手里。
_PLAN_MAX_FACETS = 3
_PLAN_PROMPT = (
    "你是检索规划助手。把下面的研究问题拆成 2-{n} 个**互不重复**的检索角度（facet），\n"
    "每个角度给一条中文检索式和一条英文检索式。\n"
    "只输出 JSON，不要解释、不要代码块标记：\n"
    '{{"facets":[{{"name":"角度名","zh":"中文检索式","en":"english query"}}]}}\n'
    "要求：\n"
    "1) 每条检索式 2-6 个词，用核心术语（名词短语），不要整句；\n"
    "2) 英文检索式供 PubMed 用，专有名词（地名/人名/病名）保持原样；\n"
    "3) 角度可以是：核心概念、时间/地域限定、方法或对照；没有合适的就给 2 个；\n"
    "4) 不要输出与问题无关的角度。\n\n"
    "研究问题：{q}\n"
)


def _parse_plan(raw: str) -> list[dict]:
    """从模型输出里抠出 facets；任何不合法一律丢弃，绝不因为规划失败就检索不到东西。"""
    s = raw or ""
    i, j = s.find("{"), s.rfind("}")
    if i < 0 or j <= i:
        return []
    try:
        d = json.loads(s[i:j + 1])
    except Exception:
        return []
    out: list[dict] = []
    for it in (d.get("facets") or [])[:_PLAN_MAX_FACETS]:
        if not isinstance(it, dict):
            continue
        zh = str(it.get("zh") or "").strip()[:120]
        en = str(it.get("en") or "").strip()[:120]
        if en and (_is_cjk(en) or not _has_latin(en)):
            en = ""                      # 英文槽里塞中文 → 直接作废，交给后面的翻译兜底
        if not zh and not en:
            continue
        out.append({"name": str(it.get("name") or "")[:40], "zh": zh, "en": en})
    return out


def plan_queries(q: str, timeout: int = 25) -> dict:
    """问题 → 检索计划 {"facets":[{name,zh,en}], "source":"llm"|"fallback"}。

    规划失败一律回落成“原问题 + 一条译英”，检索照常进行，只是少几个角度。
    """
    q = (q or "").strip()
    if not q:
        return {"facets": [], "source": "empty"}
    cp = CACHE / f"plan_v1_{hashlib.sha1(f'{_PLAN_MAX_FACETS}|{q}'.encode()).hexdigest()[:16]}.json"
    if cp.exists():
        try:
            d = json.loads(cp.read_text(encoding="utf-8"))
            if isinstance(d, dict) and d.get("facets"):
                return d
        except Exception:
            pass
    try:
        from . import llm_http
        raw = llm_http.ask(_PLAN_PROMPT.format(n=_PLAN_MAX_FACETS, q=q),
                           max_tokens=420, temperature=0.0, timeout=timeout)
    except Exception as e:  # noqa: BLE001
        raw = ""
        _LAST_ERR.setdefault("plan", []).append(f"{type(e).__name__}")
    facets = _parse_plan(raw)
    if not facets:
        _LAST_ERR.setdefault("plan", []).append("未得到检索计划，回落为原问题+译英")
        return {"facets": [], "source": "fallback"}
    out = {"facets": facets, "source": "llm"}
    try:
        CACHE.mkdir(parents=True, exist_ok=True)
        cp.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- PubMed / PMC
# 学术通道只认英文；中文问题必须先经 translate_queries()。
EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
NCBI_TOOL = "teamai"
NCBI_EMAIL = os.environ.get("NCBI_EMAIL", "teamai@example.org")
NCBI_API_KEY = os.environ.get("NCBI_API_KEY", "")     # 有 key 可到 10 req/s，无 key 3 req/s
_PMC_FULLTEXT_MAX = 14000        # 单篇全文喂给模型的字符上限
# 全局节流：线程并发也不得超限。无 key 时 NCBI 限 3 req/s，取 0.40s（≈2.5/s）留边界余量
# —— 实测 0.36s 会在并发突发时踩到 429。
_NCBI_MIN_GAP = 0.12 if NCBI_API_KEY else 0.40
# 错误留痕的当前 sink；由 _ErrSink（见下）按上下文分流，默认落全局那份。
_ERR_SINK: ContextVar[dict | None] = ContextVar("retrieval_errs", default=None)

_NCBI_LIMITER = _RateLimiter(_NCBI_MIN_GAP)
_PMC_MAX_WORKERS = 3             # 同一检索式下的全文并行度（外层还会 × 3 检索式）


class _ErrSink:
    """按上下文分流的错误留痕。

    为什么要分流（2026-11-02 后台作业上线后）：原来 `_LAST_ERR` 是进程级 dict，
    三个调研作业并发时 A 的报错会记到 B 头上，排查直接失真。
    现在 gather() 在进入时把 sink 绑到 ContextVar；worker 线程用 copy_context() 继承，
    于是每个作业各记各的。单线程/CLI 场景 sink 就是全局那份，`last_errors()` 照旧可用。
    """

    def __init__(self) -> None:
        self._global: dict[str, list[str]] = {}

    def bind(self, out: dict | None):
        """选定本轮的 sink：调用方自带的 dict 优先，否则用全局那份。

        返回 ContextVar 的 token，调用方**必须**在 finally 里 `_ERR_SINK.reset(token)`：
        否则这条线程下一次没绑 sink 的写入会继续记进上一轮的 dict（隐性串台）。
        """
        sink = out if out is not None else self._global
        sink.clear()
        return _ERR_SINK.set(sink)

    def _t(self) -> dict[str, list[str]]:
        # 注意不能用 `or`：刚绑定的 sink 是空 dict（falsy），会被误判成“没绑”而回退到全局。
        sink = _ERR_SINK.get()
        return self._global if sink is None else sink

    def setdefault(self, key, default):
        return self._t().setdefault(key, default)

    def items(self):
        return self._t().items()

    def clear(self) -> None:
        self._t().clear()


_LAST_ERR = _ErrSink()


def _submit(ex: ThreadPoolExecutor, fn, *args):
    """提交任务时**带上当前 context**，好让 ContextVar（错误 sink）传进 worker 线程。"""
    ctx = copy_context()
    return ex.submit(ctx.run, fn, *args)


def last_errors() -> dict[str, list[str]]:
    """最近一轮检索的失败留痕（源 -> 错误列表），供排查"为什么没有来源"。"""
    return {k: list(v[-5:]) for k, v in _LAST_ERR.items()}


def note_error(source: str, message: str) -> None:
    """调用方也能往同一份留痕里记账（如 gather 抛错），保证失败可见。"""
    _LAST_ERR.setdefault(source, []).append(str(message)[:200])


def _ncbi_throttle() -> None:
    """NCBI 限速是**账号级**的，多个线程同时发也会 429；故在调用内部串行节流。"""
    _NCBI_LIMITER.wait()


def _ncbi(endpoint: str, params: dict, *, timeout: int = 20,
          max_bytes: int = 6_000_000) -> str:
    """E-utilities 调用；失败返回空串（调用方按"无来源"处理）。"""
    p = dict(params)
    p.setdefault("tool", NCBI_TOOL)
    p.setdefault("email", NCBI_EMAIL)
    if NCBI_API_KEY:
        p.setdefault("api_key", NCBI_API_KEY)
    url = f"{EUTILS}/{endpoint}?" + urllib.parse.urlencode(p)
    _ncbi_throttle()
    try:
        _, text = _get(url, timeout=timeout, max_bytes=max_bytes)
        return text
    except Exception as e:  # noqa: BLE001
        code = getattr(e, "code", "")
        _LAST_ERR.setdefault("ncbi", []).append(
            f"{endpoint}: {type(e).__name__}{(':' + str(code)) if code else ''}")
        return ""


def _ncbi_ids(db: str, term: str, limit: int, timeout: int = 30) -> list[str]:
    raw = _ncbi("esearch.fcgi", {"db": db, "term": term, "retmax": max(1, limit),
                                 "retmode": "json", "sort": "relevance"}, timeout=timeout)
    if not raw:
        return []
    try:
        d = json.loads(raw)
        return [str(x) for x in (d.get("esearchresult") or {}).get("idlist") or []]
    except Exception:
        return []


def _xml_text(node) -> str:
    if node is None:
        return ""
    return re.sub(r"\s+", " ", "".join(node.itertext())).strip()


def pubmed(q: str, limit: int = 5, timeout: int = 25,
           deadline: float | None = None) -> list[dict]:
    """PubMed：按相关性检索，取**摘要**（不是全文）。"""
    if not _left(deadline):
        _LAST_ERR.setdefault("pubmed", []).append("通道预算用尽，未发起")
        return []
    ids = _ncbi_ids("pubmed", q, limit, timeout=timeout)
    if not ids:
        return []
    if not _left(deadline):
        _LAST_ERR.setdefault("pubmed", []).append("通道预算用尽（efetch 前）")
        return []
    raw = _ncbi("efetch.fcgi", {"db": "pubmed", "id": ",".join(ids), "retmode": "xml"},
                timeout=timeout, max_bytes=8_000_000)
    if not raw:
        return []
    try:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(raw)
    except Exception:
        return []
    out = []
    for art in root.iter("PubmedArticle"):
        pmid = _xml_text(art.find(".//PMID"))
        title = _xml_text(art.find(".//Article/ArticleTitle"))
        if not title:
            continue
        year = (_xml_text(art.find(".//JournalIssue/PubDate/Year"))
                or _xml_text(art.find(".//JournalIssue/PubDate/MedlineDate"))[:4])
        journal = _xml_text(art.find(".//Journal/Title"))
        doi, pmcid = "", ""
        for aid in art.iter("ArticleId"):
            t = (aid.get("IdType") or "").lower()
            if t == "doi":
                doi = _xml_text(aid)
            elif t == "pmc":
                pmcid = _xml_text(aid)
        abstract = " ".join(_xml_text(x) for x in art.iter("AbstractText") if _xml_text(x))
        if doi:
            link = f"https://doi.org/{doi}"
        elif pmcid:
            link = f"https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/"
        else:
            link = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
        out.append({"provider": "pubmed", "title": title[:200], "url": link,
                    "snippet": abstract[:800], "text": abstract[:8000],
                    "grade": "primary", "year": year, "journal": journal,
                    "pmid": pmid, "pmcid": pmcid, "fulltext": False})
    return out


def _pmc_one(pid: str, timeout: int) -> dict | None:
    """拉一篇 PMC 全文。**单篇一个任务**——此前在一个 pmc() 里串行拉 4 篇，
    是尾延迟的头号来源（4 × 60s）。"""
    raw = _ncbi("efetch.fcgi", {"db": "pmc", "id": pid, "retmode": "xml"},
                timeout=timeout, max_bytes=8_000_000)
    if not raw:
        return None
    try:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(raw)
    except Exception:
        return None
    art = root.find(".//article")
    if art is None:
        return None
    title = _xml_text(art.find(".//article-meta/title-group/article-title"))
    if not title:
        return None
    doi = ""
    for aid in art.iter("article-id"):
        if (aid.get("pub-id-type") or "").lower() == "doi":
            doi = _xml_text(aid)
            break
    abstract = _xml_text(art.find(".//article-meta/abstract"))
    body = _xml_text(art.find(".//body"))
    full = (abstract + "\n" + body).strip()[:_PMC_FULLTEXT_MAX]
    year = _xml_text(art.find(".//pub-date/year"))
    journal = _xml_text(art.find(".//journal-title"))
    link = (f"https://doi.org/{doi}" if doi
            else f"https://pmc.ncbi.nlm.nih.gov/articles/PMC{pid}/")
    return {"provider": "pmc", "title": title[:200], "url": link,
            "snippet": abstract[:800], "text": full or abstract[:8000],
            "grade": "primary", "year": year, "journal": journal,
            "pmcid": f"PMC{pid}", "fulltext": bool(body)}


def pmc(q: str, limit: int = 3, timeout: int = 25,
        deadline: float | None = None) -> list[dict]:
    """PMC 免费全文：检索 + **并行**拉 JATS 全文（截断），research.ask 的主力来源。"""
    if not _left(deadline):
        _LAST_ERR.setdefault("pmc", []).append("通道预算用尽，未发起")
        return []
    ids = _ncbi_ids("pmc", q, limit, timeout=timeout)
    if not ids:
        return []
    ids = ids[:limit]
    out: list[dict] = []
    ex = ThreadPoolExecutor(max_workers=min(_PMC_MAX_WORKERS, len(ids)))
    try:
        futs = {_submit(ex, _pmc_one, pid, timeout): pid for pid in ids}
        budget = None if deadline is None else max(0.05, deadline - time.monotonic())
        try:
            for f in as_completed(futs, timeout=budget):
                try:
                    d = f.result()
                except Exception:  # noqa: BLE001
                    continue
                if d:
                    out.append(d)
        except FuturesTimeout:
            _LAST_ERR.setdefault("pmc", []).append(
                f"通道预算 {budget:.0f}s 用尽，{len(out)}/{len(ids)} 篇已取")
    finally:
        ex.shutdown(wait=False, cancel_futures=True)
    return out


# ---------------------------------------------------------------- curated pages
# 搜索对冷门史学题目并不稳定；每章配一组「已知相关」的百科条目作底料，
# 再由检索结果补充。它们只是**线索**，事实仍须逐字回原文校验。
CURATED_PAGES = {
    "0": ["流民", "游民", "帮会", "中国户籍制度", "里甲", "黄册", "灾荒", "中国人口史", "编户齐民", "保甲制度"],
    "1": ["长江三角洲", "冲积平原", "河口沙洲", "崇明岛", "扬中市", "靖江市", "张家港市",
          "常阴沙", "长兴岛", "横沙岛", "九段沙", "圩田", "鱼鳞图册", "里甲", "黄册", "保甲制度"],
    "2": ["疍民", "水上人", "船民", "崇明岛", "启东市", "海门区", "如东县", "靖江市",
          "扬中市", "张家港市", "吴语", "沙地话", "张謇", "盐垦"],
    "3": ["圩田", "圩", "鱼鳞图册", "永佃制", "田面权", "宗族", "械斗", "保甲制度",
          "里甲", "黄册", "乡绅", "团练"],
    "4": ["团练", "保甲制度", "乡绅", "崇明岛", "圩田", "太平天国", "湘军", "淮军"],
    "5": ["陈友谅", "朱元璋", "张士诚", "鄱阳湖之战", "元末民变", "太平天国", "湘军", "淮军", "水师", "水寨"],
    "6": ["波利尼西亚人", "南岛民族", "客家围屋", "福建土楼", "台湾垦殖", "洞庭湖",
          "珠江三角洲", "沙田", "圩田", "宗族", "垦殖"],
    "7": ["乡绅", "圩田", "基层治理", "保甲制度"],
}


def wiki_page(title: str, lang: str = "zh", timeout: int = 25) -> dict | None:
    """按条目标题直接取维基正文（比搜索更稳）。"""
    api = f"https://{lang}.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
        "action": "query", "prop": "extracts", "explaintext": 1,
        "titles": title, "format": "json", "redirects": 1,
    })
    try:
        _, t = _get(api, timeout=timeout)
        pages = json.loads(t).get("query", {}).get("pages", {})
        page = next(iter(pages.values()), {}) if pages else {}
        text = page.get("extract") or ""
        if not text:
            return None
        real = page.get("title") or title
        url = f"https://{lang}.wikipedia.org/wiki/" + urllib.parse.quote(real.replace(" ", "_"))
        return {"provider": f"curated-wiki-{lang}", "title": real, "url": url,
                "snippet": text[:600], "text": text[:20000], "grade": "secondary"}
    except Exception:
        return None


def curated(chapter_no: str, limit: int = 3, lang: str = "zh", offset: int = 0,
            pages: dict | None = None) -> list[dict]:
    """按章取「已知相关」百科条目作底料。

    pages 可传入自定义映射（如专著工作区 TOPIC.json 的 curated_pages），
    缺省用内置 CURATED_PAGES（沙洲拓殖专题）。
    """
    table = pages if pages is not None else CURATED_PAGES
    titles = table.get(str(chapter_no), [])
    if not titles:
        return []
    offset = offset % len(titles)
    titles = (titles[offset:] + titles[:offset])[:limit]
    CACHE.mkdir(parents=True, exist_ok=True)
    tag = "custom" if pages is not None else "default"
    cp = CACHE / f"curated_{tag}_{lang}_{chapter_no}_{limit}_{offset}_{abs(hash(tuple(titles))) % 10000}.json"
    if cp.exists():
        try:
            data = json.loads(cp.read_text(encoding="utf-8"))
            if len(data) >= min(2, len(titles)):
                return data
        except Exception:
            pass
    out = []
    for t in titles:                       # 顺序取，避免维基并发限流
        d = wiki_page(t, lang=lang)
        if d:
            out.append(d)
        time.sleep(0.2)
    if out:
        try:
            cp.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
    return out


# ---------------------------------------------------------------- gather
def _key(q: str, limit: int, fetch_n: int) -> str:
    return hashlib.sha1(f"v3|{q}|{limit}|{fetch_n}".encode("utf-8")).hexdigest()[:16]


def _dedupe(items: list[dict]) -> list[dict]:
    """按 URL 去重；同一篇论文常有 arXiv 摘要页 + 全文页两个 URL，故再按标题去重。"""
    seen_u, seen_t, out = set(), set(), []
    for it in items:
        u = (it.get("url") or "").split("#")[0].rstrip("/")
        if not u or u in seen_u:
            continue
        t = re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", (it.get("title") or "").lower())[:60]
        if len(t) >= 24 and t in seen_t:
            continue
        seen_u.add(u)
        if len(t) >= 24:
            seen_t.add(t)
        out.append(it)
    return out


_STOP = set("""的 了 在 是 有 和 与 及 或 为 以 于 而 对 从 到 把 被 将 我们 他们 这个 那个
一个 一种 如何 什么 为什么 怎么 历史 研究 资料 综述 背景 问题 概念 界定 机制 模型 视角
框架 创新 缺陷 空白 意义 启示 结论 不足 方向 对照 对比 异同 史料 档案 县志 文书 中国
传统 文化 社会 制度 地方 古代 近代 现代 当代""".split())


def _terms(q: str) -> list[str]:
    """粗分词：中文 2–6 字片段 + 拉丁词；不做词典分词，只用于相关性排序。"""
    q = (q or "").lower()
    out: list[str] = []
    for w in re.findall(r"[a-z][a-z0-9\-]{2,}", q):
        if w not in _STOP:
            out.append(w)
    for seg in re.findall(r"[\u4e00-\u9fff]{2,}", q):
        if len(seg) <= 6:
            if seg not in _STOP:
                out.append(seg)
        else:
            for n in (4, 3, 2):
                for i in range(0, len(seg) - n + 1):
                    w = seg[i:i + n]
                    if w not in _STOP:
                        out.append(w)
    # 去重保序、限制数量
    seen, out2 = set(), []
    for w in out:
        if w not in seen:
            seen.add(w)
            out2.append(w)
    return out2[:24]


def terms_of(text: str) -> list[str]:
    """对外暴露粗分词：门禁做“切题性”判定用（**不读全局状态**，因此线程安全）。"""
    return _terms(text)


def _relevance(it: dict, terms: list[str]) -> float:
    title = (it.get("title") or "").lower()
    snip = (it.get("snippet") or "").lower()
    text = (it.get("text") or "")[:6000].lower()
    s = 0.0
    for w in terms:
        if w in title:
            s += 3.0
        if w in snip:
            s += 1.0
        if w in text:
            s += 0.25
    # 首页/门户降权（不是资料页）
    path = urllib.parse.urlparse(it.get("url") or "").path
    if path in ("", "/") or re.search(r"/index\.(s?html?|php)$", path):
        s -= 4.0
    if re.search(r"(地图|登录|攻略|旅游|招聘|房产|天气|新闻中心)", title):
        s -= 3.0
    # 站内搜索结果页 / 百科编辑页不是资料页（例：「您搜索的关键词：扬中 共返回 16 条记录」）
    if re.search(r"(共返回\s*\d+\s*条|搜索结果|搜索关键词|的全部结果|添加义项|编辑词条)", title):
        s -= 6.0
    return s


def _relevance_head(it: dict, terms: list[str]) -> float:
    """只看标题+摘要的相关度：搜索阶段用它挡掉“正文里偶然出现关键词”的跑题页。"""
    title = (it.get("title") or "").lower()
    snip = (it.get("snippet") or "").lower()
    return sum((3.0 if w in title else 0.0) + (1.0 if w in snip else 0.0) for w in terms)


def _rank(it: dict) -> tuple:
    g = {"primary": 0, "official": 1, "secondary": 2, "weak": 3}.get(it.get("grade", "weak"), 4)
    # PMC 全文 > PubMed 摘要 > DeepSeek 网页；bing/wiki/openalex 检索已停用
    p = {"pmc": 0, "pubmed": 1, "curated-wiki-zh": 1, "curated-wiki-en": 1,
         "deepseek-search": 2, "cn-scholar": 3, "archive-org": 3,
         "semantic-scholar": 5, "crossref": 5}.get(it.get("provider", ""), 4)
    return (0 if it.get("curated") else 1, 0 if it.get("fulltext") else 1,
            -float(it.get("score", 0)), g, p,
            -float(it.get("rerank_score") or 0))


def _uniq(seq: list[str], cap: int) -> list[str]:
    seen, out = set(), []
    for s in seq:
        k = s.strip().lower()
        if not k or k in seen:
            continue
        seen.add(k)
        out.append(s.strip())
        if len(out) >= cap:
            break
    return out


def _rank_queries(question: str, queries: list[str] | None,
                  deadline: float | None = None) -> tuple[list[str], list[str], dict]:
    """分流检索式：返回 (中文/网页检索式, 喂给 NCBI 的英文检索式, 检索计划)。

    NCBI 没有中文索引（实测「阿尔茨海默病」也是 0 条），英文列表为空时先译一条兜底。
    调用方显式给了 queries（专著工作区）就**不**做 facet 规划，保持既有语义不变。
    """
    plan: dict = {"facets": [], "source": "none"}
    if queries:
        base = _uniq([q for q in queries if q and q.strip()], 3)
    else:
        base = _uniq([question], 3)
        if _left(deadline):
            plan = plan_queries(question)
    # 网页通道：原问题 + 每个 facet 的**同语言**式（中文题配中文式，英文题配英文式，
    # 否则英文题会去搜中文页，纯属噪声）
    facets = plan.get("facets") or []
    zh_side = _is_cjk(question)
    extra = [(f.get("zh") if zh_side else f.get("en")) for f in facets]
    web_qs = _uniq(base + [x for x in extra if x], 3)
    # 学术通道：facet 的英文式优先；没有再退回“原检索式里的英文 + 翻译兜底”
    en = _uniq([f["en"] for f in plan.get("facets") or [] if f.get("en")]
               + [q for q in base if not _is_cjk(q)], 3)
    if not en:
        for q in [q for q in web_qs if _is_cjk(q)][:1]:
            if not _left(deadline):
                _LAST_ERR.setdefault("translate", []).append("预算用尽，未翻译")
                break
            en.extend(translate_queries(q, n=2))
        en = _uniq(en, 3)
    return web_qs, en, plan


def _sufficient(items: list[dict]) -> bool:
    """停判据（P0-b）：独立域名 ≥2 且至少 1 条 official/primary。

    够了就不再深度抓正文；不够留给 P2 的补检轮去处理，这里只负责“别多花时间”。
    """
    doms: set[str] = set()
    strong = 0
    for it in items:
        host = (urllib.parse.urlparse(it.get("url") or "").hostname or "").lower()
        if host:
            doms.add(host)
        if str(it.get("grade") or "") in ("official", "primary"):
            strong += 1
    return len(doms) >= 2 and strong >= 1


_ROUND_BUDGET = 60.0      # 单轮检索总预算（P0-a：到点拿手上结果走，绝不无限等）
_CHANNEL_BUDGET = 30.0    # 单通道单问预算
_FETCH_BUDGET = 20.0      # 抓原页预算
_PER_CHANNEL = 3          # P0-b：每个通道每条检索式取 3 条（够写答案，不够就交给补检轮）
_SCI_MIN_HEAD = 2.0       # 学术条目入选的最低词面相关度（标题命中 3.0 / 摘要两处 1+1）
_LAST_META: dict = {}     # 最近一轮的检索计划/判据留痕，供排查与 P2 补检轮读取


def last_meta() -> dict:
    """最近一轮 gather 的元信息：facet 计划、用了哪些检索式、是否已达停判据。"""
    return dict(_LAST_META)


def _emit_meta(out_meta: dict | None, meta: dict) -> None:
    """同时写进模块级留痕（CLI/单线程排查用）和调用方自带的 box（并发安全）。"""
    _LAST_META.clear()
    _LAST_META.update(meta)
    if out_meta is not None:
        out_meta.clear()
        out_meta.update(meta)


def gather(question: str, *, queries: list[str] | None = None, limit: int = 8, fetch_n: int = 5,
           lang: str = "zh", use_cache: bool = True, cache_dir: Path | None = None,
           curated_docs: list[dict] | None = None, budget: float = _ROUND_BUDGET,
           out_meta: dict | None = None, out_errs: dict | None = None) -> list[dict]:
    """并发取回多源结果，抓取前 fetch_n 个原页正文，返回 S1..Sn。

    queries: 可给多条检索式（同义词/学术词/英文词）；默认只用 question。
    budget:  **整轮检索预算**（秒）。到点就用手上已有的结果返回，未完成的任务记进
             last_errors()，不等、不抛。尾延迟由此封顶，是“能给人用”的前提。
    out_meta: 调用方自带的 dict，本轮元信息（检索式/计划/是否达标）会写进去。
             **并发作业必须用这个**——模块级 last_meta() 是进程共享的，两个作业同时跑会串台。
    out_errs: 同上，失败留痕也写进调用方自带的 dict（不传则落全局，CLI 行为不变）。
    通道分工：DeepSeek Search 吃中文/原始检索式；PubMed/PMC 只吃英文检索式。
    未显式给 queries 时，先由 plan_queries() 把问题拆成 2-3 个 facet，每 facet 各出一条
    中英检索式；规划失败则回落成“原问题 + 一条译英”，不因为规划失败就查不到东西。
    每个通道每条检索式取 _PER_CHANNEL(3) 条；达到停判据后不再深挖正文。
    """
    # 绑定本轮的 sink，并在返回（含抛错）时复原：否则同一条线程的后续写入会落到上一轮的 dict。
    token = _LAST_ERR.bind(out_errs)
    try:
        return _gather_impl(question, queries=queries, limit=limit, fetch_n=fetch_n, lang=lang,
                            use_cache=use_cache, cache_dir=cache_dir,
                            curated_docs=curated_docs, budget=budget, out_meta=out_meta)
    finally:
        _ERR_SINK.reset(token)


def _gather_impl(question: str, *, queries: list[str] | None = None, limit: int = 8, fetch_n: int = 5,
                 lang: str = "zh", use_cache: bool = True, cache_dir: Path | None = None,
                 curated_docs: list[dict] | None = None, budget: float = _ROUND_BUDGET,
                 out_meta: dict | None = None) -> list[dict]:
    """实现体。错误 sink 由 gather() 绑定与复原，别直接调它。"""
    cache_dir = cache_dir or CACHE
    cache_dir.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + max(5.0, float(budget))
    qs, sci_qs, plan = _rank_queries(question, queries, deadline=deadline)
    if not qs:
        return []
    # v6：P0-b 起检索式来自 facet 分解，旧缓存一律不许命中
    cache_key = "v6|" + question + "|" + "|".join(qs) + "|" + "|".join(sci_qs) + "|" + "|".join(
        sorted((d.get("title") or "") for d in (curated_docs or [])))
    cp = cache_dir / (_key(cache_key, limit, fetch_n) + ".json")
    if use_cache and cp.exists():
        try:
            _emit_meta(out_meta, {"cache": True, "plan_source": plan.get("source"),
                                  "web_queries": list(qs), "sci_queries": list(sci_qs)})
            return json.loads(cp.read_text(encoding="utf-8"))
        except Exception:
            pass
    # 通道级预算：留给每个通道的窗口不超过 _CHANNEL_BUDGET
    ch_dl = min(deadline, time.monotonic() + _CHANNEL_BUDGET)
    tasks = {}
    # 通用网页（DeepSeek）：原问题 + facet 中文式，中文题只有这条路能出结果
    for i, qq in enumerate(qs[:_PER_CHANNEL]):
        tasks[f"web{i}"] = (lambda qq=qq, d=ch_dl: deepseek_search(
            qq, limit=_PER_CHANNEL, ori_question=question, deadline=d))
    # 中文学术题录（万方/知网）：只有**中文问题**才查，且只作线索
    if _is_cjk(question):
        tasks["cn_scholar"] = (lambda q=qs[0], d=ch_dl: cn_scholar(
            q, limit=2, deadline=d))
    # 学术通道：只喂英文检索式；PubMed 只跑主检索式（它是 PMC 的摘要兜底，不必每角度都查）
    for i, qq in enumerate(sci_qs[:_PER_CHANNEL]):
        n_pmc = _PER_CHANNEL if i == 0 else 2
        tasks[f"pmc{i}"] = (lambda qq=qq, n=n_pmc, d=ch_dl: pmc(qq, limit=n, deadline=d))
        if i == 0:
            tasks["pubmed0"] = (lambda qq=qq, d=ch_dl: pubmed(
                qq, limit=_PER_CHANNEL, deadline=d))
    items: list[dict] = []
    ex = ThreadPoolExecutor(max_workers=min(8, max(1, len(tasks))))
    try:
        futs = {_submit(ex, fn): name for name, fn in tasks.items()}
        try:
            for f in as_completed(futs, timeout=max(0.05, deadline - time.monotonic())):
                try:
                    items.extend(f.result() or [])
                except Exception as e:  # noqa: BLE001
                    _LAST_ERR.setdefault("gather", []).append(f"{futs[f]}: {type(e).__name__}")
        except FuturesTimeout:
            pending = [n for f, n in futs.items() if not f.done()]
            _LAST_ERR.setdefault("gather", []).append(
                f"检索总预算 {budget:.0f}s 用尽，放弃未完成任务：{','.join(pending[:6])}")
    finally:
        ex.shutdown(wait=False, cancel_futures=True)
    if curated_docs:
        items.extend(curated_docs)
    items = _dedupe(items)
    # 词面相关度用「中文原式 + 英文译式」一起算，中英文结果都能被正确排序
    terms = _terms(" ".join(qs + sci_qs))
    for it in items:
        it["score"] = round(_relevance(it, terms), 2)
        it["score_head"] = round(_relevance_head(it, terms), 2)
        if str(it.get("provider", "")).startswith("curated"):
            it["curated"] = True
    # 标题/摘要层面必须与问题有实际词面关系（curated 底料除外）
    # 学术源已由 PubMed/PMC 按相关性排序；其标题多为英文，用中文词面做相关度
    # 会全数误杀（实测中文问句召回 0），故学术源不参与词面过滤。
    SCI_PROVIDERS = ("pubmed", "pmc")

    def _keep(it: dict) -> bool:
        if it.get("provider") in SCI_PROVIDERS or it.get("curated"):
            return True
        if it["score_head"] > 0.5:
            return True
        # 搜索引擎自评高相关（rerank>=1.5）的条目，允许越过词面门槛
        return (it.get("provider") in ("deepseek-search", "cn-scholar")
                and float(it.get("rerank_score") or 0) >= _DS_RERANK_TRUST)

    items = [it for it in items if _keep(it)]
    items.sort(key=_rank)
    # 名额分配（P0-b）：纯按分数切会被中文网页挤满——中文标题能命中多个中文检索词，
    # 分数天然高于英文论文，实测 PMC 全被挤出前 6。故按“通道配额”取：
    #   学术 ≥2（有就给） + 其余按排名补满 + 题录 2 条垫底（线索，不伪装成证据）
    cap = max(limit, fetch_n)
    clues = [it for it in items if it.get("provider") == "cn-scholar"][:2]
    main_cap = max(0, cap - len(clues))
    pool = [it for it in items if it.get("provider") != "cn-scholar"]
    sci = [it for it in pool if it.get("provider") in SCI_PROVIDERS]
    # 学术通道也要看词面：英文检索词已在 terms 里。史学题上 PMC 会返回“最近邻但不相关”
    # 的论文（实测：圩田题返回“长江鱼类健康”），占掉中文网页的名额。
    # 阈值 2.0 = 至少标题命中一次（3.0）或摘要两处（1+1）；一条都不达标就退回原样，
    # 宁可给可疑证据也不给空——是否可信由模型与门禁判。
    sci_rel = [it for it in sci if float(it.get("score_head") or 0) >= _SCI_MIN_HEAD]
    if sci_rel:
        drop = {id(x) for x in sci} - {id(x) for x in sci_rel}
        pool = [it for it in pool if id(it) not in drop]
        sci = sci_rel
    chosen: list[dict] = sci[:min(len(sci), max(2, main_cap // 2))]
    taken = {id(x) for x in chosen}
    for it in pool:
        if len(chosen) >= main_cap:
            break
        if id(it) not in taken:
            chosen.append(it)
            taken.add(id(it))
    items = chosen[:main_cap] + clues

    # 停判据：证据已经够了就不再深挖正文（P0-b 只做“够了就省”，补检留给 P2）
    enough = _sufficient(items)
    if enough:
        fetch_n = max(1, fetch_n // 2)

    # 抓原页（通道已自带正文的不重复抓）；同样受预算约束，抓不到就用摘要兜底
    need = [it for it in items if not it.get("text")][:fetch_n]
    if need:
        fetch_dl = min(deadline, time.monotonic() + _FETCH_BUDGET)
        fex = ThreadPoolExecutor(max_workers=4)
        try:
            futs = {_submit(fex, fetch_text, it["url"]): it for it in need}
            try:
                for f in as_completed(futs, timeout=max(0.05, fetch_dl - time.monotonic())):
                    it = futs[f]
                    try:
                        it["text"] = f.result() or it.get("snippet", "")
                    except Exception:
                        it["text"] = it.get("snippet", "")
            except FuturesTimeout:
                _LAST_ERR.setdefault("gather", []).append(
                    f"抓正文预算 {_FETCH_BUDGET:.0f}s 用尽，未完成的用摘要兜底")
        finally:
            fex.shutdown(wait=False, cancel_futures=True)
    for it in items:
        if not it.get("text"):
            it["text"] = it.get("snippet", "")
    # 抓回正文后再按词面相关度重排一次（正文里命中才算数）
    for it in items:
        it["score"] = round(_relevance(it, terms), 2)
    items.sort(key=_rank)
    for i, it in enumerate(items, 1):
        it["id"] = f"S{i}"
    _emit_meta(out_meta, {
        "cache": False,
        "plan_source": plan.get("source"),
        "facets": [f.get("name") or f.get("zh") or "" for f in plan.get("facets") or []],
        "web_queries": list(qs),
        "sci_queries": list(sci_qs),
        "sufficient": enough,
        "per_channel": _PER_CHANNEL,
        "providers": sorted({str(it.get("provider") or "") for it in items}),
    })
    if use_cache:
        try:
            cp.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
    return items


def to_jsonl(docs: list[dict]) -> str:
    return "\n".join(json.dumps(d, ensure_ascii=False) for d in docs) + ("\n" if docs else "")


if __name__ == "__main__":  # 手工自测：python -m core.retrieval "问题"
    import sys
    q = " ".join(sys.argv[1:]) or "扬中 太平洲 圩 历史"
    docs = gather(q, limit=6, fetch_n=3, use_cache=False)
    print(f"—— {q!r}：{len(docs)} 条")
    for d in docs:
        print(f"[{d['id']}] {d.get('provider','?'):<16} {d['grade']:<9} "
              f"fulltext={bool(d.get('fulltext'))} {d['title'][:50]}")
        print(f"    {d['url']}")
    errs = last_errors()
    if errs:
        print("—— 失败留痕：", json.dumps(errs, ensure_ascii=False))
