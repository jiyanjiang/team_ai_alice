"""Host / Client role for a single TAA installation.

A node is a Host by default.  A Client points at the Host's web UI through a
writable share link; the Client keeps its own local Agent/runtime and never
needs to expose its own peer listener.

The role is deliberately a tiny local file so a failed center or a fresh
upgrade can never lose it:
    ~/.taa/host.json
        {"role":"host"} or
        {"role":"client","host_url":"http://host:6080","share_token":"..."}
"""
from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse


def home() -> Path:
    return Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")).expanduser()


def path() -> Path:
    return home() / "host.json"


def load() -> dict:
    try:
        data = json.loads(path().read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"role": "host"}
        role = str(data.get("role") or "host").lower()
        if role not in ("host", "client"):
            role = "host"
        data["role"] = role
        return data
    except Exception:  # noqa: BLE001
        return {"role": "host"}


def save(*, role: str, host_url: str = "", share_token: str = "") -> dict:
    role = "client" if str(role).lower() == "client" else "host"
    data = {"role": role, "updated_at": datetime.now().isoformat(timespec="seconds")}
    if role == "client":
        data["host_url"] = _clean_base(host_url)
        data["share_token"] = str(share_token or "").strip()
    p = path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return data


def is_client() -> bool:
    return load().get("role") == "client"


def host_url() -> str:
    return _clean_base(load().get("host_url") or "")


def share_token() -> str:
    return str(load().get("share_token") or "").strip()


def client_url() -> str:
    """URL the Client's local browser should open.

    The Host share link sets the Host's `taa_share` cookie; that is what makes
    a remote LAN browser writable without exposing an unauthenticated Host.
    """
    base = host_url()
    if not base:
        return ""
    token = share_token()
    if token:
        return base + "/app/s/" + token
    return base + "/app/chats"


def parse_invite(value: str) -> tuple[str, str]:
    """Accept a Host URL or a `/app/s/<token>` invite link."""
    raw = str(value or "").strip()
    if not raw:
        return "", ""
    if "://" not in raw:
        raw = "http://" + raw
    u = urlparse(raw)
    if not u.scheme or not u.netloc:
        return "", ""
    base = f"{u.scheme}://{u.netloc}".rstrip("/")
    token = ""
    m = re.search(r"/app/s/([^/?#]+)", u.path or "")
    if m:
        token = m.group(1)
    return base, token


def _clean_base(value: str) -> str:
    raw = str(value or "").strip().rstrip("/")
    if not raw:
        return ""
    if "://" not in raw:
        raw = "http://" + raw
    u = urlparse(raw)
    if not u.scheme or not u.netloc:
        return ""
    return f"{u.scheme}://{u.netloc}".rstrip("/")


def host_label() -> str:
    data = load()
    if data.get("role") == "client":
        return "Client"
    return "Host"
