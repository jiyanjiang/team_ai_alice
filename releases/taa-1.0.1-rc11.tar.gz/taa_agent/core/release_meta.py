"""发布契约的运行时视图（docs/specs/alice_personal/21）。

三件事必须说清，否则又会退回"四个版本号并存"：

1. `taa` 是唯一对外版本，来源是 `dist/VERSION`（回退根 `VERSION`）；
2. `runtime` **已冻结**，恒为 2.2.53，只作排障字段，不再递增、不参与任何判定；
3. `addons` 在 1.x 恒为 disabled（卡槽规范见 docs/specs/alice_personal/18）。
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from . import distribution

ROOT = Path(__file__).resolve().parent.parent
_VERSION_FILES = (ROOT / "dist" / "VERSION", ROOT / "VERSION")

# 冻结值：不要改。它记录的是最后一版独立的运行时版本号（2026-11-03）。
RUNTIME_FROZEN = "2.2.53"


def taa_version() -> str:
    """对外版本：dist/VERSION 优先，根 VERSION 仅作旧布局回退。"""
    for p in _VERSION_FILES:
        try:
            v = p.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if v:
            return v
    return "unknown"


def build_id() -> str:
    """构建指纹：优先环境变量（打包时注入），否则取 git 短 sha。

    用于"测试什么=发布什么"的核对；取不到就返回 unknown，不猜。
    """
    env = os.environ.get("TAA_BUILD", "").strip()
    if env:
        return env[:40]
    try:
        out = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "--short", "HEAD"],
                             capture_output=True, text=True, timeout=2)
        if out.returncode == 0:
            return out.stdout.strip()[:40]
    except Exception:  # noqa: BLE001 —— 构建指纹缺失不该阻断启动
        pass
    return "unknown"


def addons_state() -> str:
    return "enabled" if os.environ.get("TAA_ADDONS", "").strip().lower() in {"1", "true", "enabled"} else "disabled"


def channel() -> str:
    v = taa_version().lower()
    if "rc" in v or "beta" in v or "alpha" in v:
        return "beta"
    return "stable"


def payload() -> dict:
    """`GET /version` 的返回体（字段顺序即契约顺序）。"""
    return {
        "taa": taa_version(),
        "protocol": distribution.PROTOCOL_VERSION,
        "runtime": RUNTIME_FROZEN,
        "build": build_id(),
        "addons": addons_state(),
        "channel": channel(),
    }
