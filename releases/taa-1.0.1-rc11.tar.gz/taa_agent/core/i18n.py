"""最小 i18n：Cookie + JSON 词典；内容本身不自动翻译。"""
from __future__ import annotations

import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
DEFAULT = "zh-CN"
SUPPORTED = {"zh-CN": "中文", "en": "English"}
_cache: dict[str, dict] = {}


def _dict(locale: str) -> dict:
    loc = locale if locale in SUPPORTED else DEFAULT
    if loc not in _cache:
        try:
            _cache[loc] = json.loads((ROOT / "locales" / f"{loc}.json").read_text(encoding="utf-8"))
        except Exception:
            _cache[loc] = {}
    return _cache[loc]


def locale_of(cookie_value: str | None) -> str:
    return cookie_value if cookie_value in SUPPORTED else DEFAULT


def t(key: str, default: str = "", locale: str = DEFAULT, **kw) -> str:
    val = _dict(locale).get(key)
    if val is None:
        val = _dict(DEFAULT).get(key, default)
    try:
        return str(val).format(**kw) if kw else str(val)
    except Exception:
        return str(val)
