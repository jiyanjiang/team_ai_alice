"""脱敏扫描（docs/02 §8、docs/04 §13）。确定性层：正则 + 高熵字符串。

发帖门禁：high_count == 0 才允许发布。
"""
from __future__ import annotations

import math
import re
from collections import Counter

PATTERNS = [
    ("high", "api_key_sk", re.compile(r"sk-[A-Za-z0-9]{20,}")),
    ("high", "aws_akid", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("high", "bearer", re.compile(r"Bearer\s+[A-Za-z0-9._\-]{16,}")),
    ("high", "private_key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("high", "password", re.compile(r"(?i)(password|passwd|secret|token)\s*[:=]\s*\S{6,}")),
    ("high", "abs_path_users", re.compile(r"/Users/[A-Za-z0-9._-]+/")),
    ("high", "abs_path_home", re.compile(r"/home/[A-Za-z0-9._-]+/")),
    ("high", "abs_path_win", re.compile(r"[A-Za-z]:\\\\Users\\\\[A-Za-z0-9._-]+")),
    ("medium", "email", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("medium", "private_ip",
     re.compile(r"\b(10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)\b")),
]


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    return -sum((c / len(s)) * math.log2(c / len(s)) for c in counts.values())


def redact(text: str) -> str:
    """Remove high-risk payloads while preserving the rest of a feed."""
    out = str(text or "")
    for level, name, rx in PATTERNS:
        if level == "high":
            out = rx.sub(f"[已脱敏:{name}]", out)
    return out


def scan(text: str) -> dict:
    findings = []
    for level, name, rx in PATTERNS:
        for m in rx.finditer(text):
            findings.append({"level": level, "rule": name, "match": m.group(0)[:60],
                             "start": m.start()})
    for m in re.finditer(r"[A-Za-z0-9+/=_\-]{24,}", text):
        tok = m.group(0)
        if _entropy(tok) > 4.2:
            findings.append({"level": "medium", "rule": "high_entropy",
                             "match": tok[:40], "start": m.start()})
    counts = {"high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["level"]] += 1
    return {"counts": counts, "findings": findings, "pass": counts["high"] == 0}
