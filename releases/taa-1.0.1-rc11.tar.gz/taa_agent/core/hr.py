"""虚拟 HR：岗位匹配 + 入职档案（不设专门流程，复用现有房间/发言）。

- match_job(persona, job_req): 按岗位需求给技能/兴趣打分
- hire(conn, agent_id, ...): 落一条员工档案（外包/正式、岗位、匹配度）
- roster(conn): 员工名册
"""
from __future__ import annotations

import json
import re
from datetime import datetime

TOKEN = re.compile(r"[\w\u4e00-\u9fff]{2,}")


def _tokens(s: str) -> set:
    return set(TOKEN.findall((s or "").lower()))


def _skill_names(persona: dict) -> list[str]:
    out = []
    for s in persona.get("skills", []):
        if isinstance(s, dict):
            out.append(str(s.get("name", "")).lower())
        elif isinstance(s, str):
            out.append(s.lower())
    return [x for x in out if x]


def match_job(persona: dict, job_req: str) -> dict:
    """岗位需求 vs 人设：返回匹配度与命中项。"""
    toks = _tokens(job_req)
    skills = _skill_names(persona)
    interests = [str(i).lower() for i in persona.get("interests", [])]
    skill_hits = [s for s in skills if any(t in s or s in t for t in toks)]
    interest_hits = [i for i in interests if any(t in i or i in t for t in toks)]
    traits = persona.get("traits") or {}
    # 岗位关键词若含「严谨/质量」偏向高尽责，含「探索/创新」偏向高开放
    trait_bonus = 0.0
    if re.search(r"(严谨|质量|评审|流程)", job_req):
        trait_bonus += 0.15 * float(traits.get("conscientiousness", 0.5))
    if re.search(r"(探索|创新|原型|新|研究)", job_req):
        trait_bonus += 0.15 * float(traits.get("openness", 0.5))
    skill_ratio = len(skill_hits) / max(len(skills), 1)
    interest_ratio = len(interest_hits) / max(len(interests), 1)
    score = round(min(1.0, 0.55 * skill_ratio + 0.25 * interest_ratio + trait_bonus), 3)
    return {"score": score, "skill_hits": skill_hits[:6], "interest_hits": interest_hits[:6],
            "skills": skills}


def hire(conn, agent_id: str, position: str, department: str = "", job_req: str = "",
         level: str = "", employment_type: str = "outsourced", note: str = "",
         by: str = "human") -> dict:
    """确认入职：落一条员工档案（按人设与岗位需求算匹配度）。"""
    from . import persona as persona_mod
    a = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
    if not a:
        raise ValueError("unknown agent")
    p = persona_mod.load_persona(agent_id)
    m = match_job(p, job_req or position)
    conn.execute(
        "INSERT INTO employees(agent_id, position, department, employment_type, level, job_req, "
        "skills_json, match_score, status, onboarded_at, note, hired_by) "
        "VALUES (?,?,?,?,?,?,?,?, 'onboarded', datetime('now','localtime'), ?, ?) "
        "ON CONFLICT(agent_id) DO UPDATE SET position=excluded.position, department=excluded.department, "
        "employment_type=excluded.employment_type, level=excluded.level, job_req=excluded.job_req, "
        "skills_json=excluded.skills_json, match_score=excluded.match_score, status='onboarded', "
        "onboarded_at=excluded.onboarded_at, note=excluded.note, hired_by=excluded.hired_by",
        (agent_id, position, department, employment_type, level, job_req,
         json.dumps(m["skills"], ensure_ascii=False), m["score"], note, by))
    conn.commit()
    return {"agent_id": agent_id, "position": position, "match_score": m["score"],
            "skill_hits": m["skill_hits"]}


def roster(conn) -> list[dict]:
    rows = conn.execute(
        "SELECT e.*, a.full_name, a.role FROM employees e JOIN agents a ON a.id=e.agent_id "
        "ORDER BY e.onboarded_at DESC").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["skills"] = json.loads(d.pop("skills_json") or "[]")
        out.append(d)
    return out


def match_agents(conn, job_req: str) -> list[dict]:
    """给定岗位需求，给所有 AI 打分排序（选人用）。"""
    from . import persona as persona_mod
    out = []
    for a in conn.execute("SELECT id, full_name FROM agents WHERE kind='ai'").fetchall():
        p = persona_mod.load_persona(a["id"])
        m = match_job(p, job_req)
        out.append({"agent_id": a["id"], "full_name": a["full_name"], **m})
    out.sort(key=lambda x: x["score"], reverse=True)
    return out
