"""睡眠整理（Nightly Consolidation）：把"话痨"留下的过程文件收拢、合并、归档。

设计见 `docs/319_睡觉整理_过程文件维护_20261022.md`，承接 `docs/176 §1.3`。
原则（Owner 2026-10-22 定）：
  · **自检 + 触发**：先扫描出建议（plan），人批准（approve）后才执行（apply）；
  · **只动过程文件**：成品、证据、被帖子/任务/资产引用的文件、git 已跟踪文件一律不碰；
  · **可回滚**：删除=移入 `backups/sleep/<run_id>.tar.gz` + manifest（含 sha256），可 restore；
  · **报告可读**：每次扫描/执行都产出人可读的 Markdown 报告；
  · 判断权归人：工具只给候选与理由，不替人决定"哪篇值得留"。

用法见 `scripts/sleep.py`。本模块不发起任何网络请求；LLM 合并是可选项。
"""
from __future__ import annotations

import dataclasses
import difflib
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import tarfile
import time
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------- 边界与常量
# 只有这些根目录会被扫描；其余（agents/core/docs/scripts/static/config/data…）永不触碰。
ALLOWED_ROOTS = (
    "work", "research", "deliverables", "reports", "evidence",
    "runtime", "dist", ".staging",
)
# 永远不动的目录（即使出现在根目录下）
HARD_KEEP = (
    ".git", "agents", "core", "cli", "scripts", "docs", "static", "sources",
    "locales", "bootstrap", "config", "data", "tools", "certs", "releases",
    "handoff", "reading", "rooms", "style", "video", "backups",
)
SENSITIVE = re.compile(r"(\.key$|\.enc$|\.pem$|secret|credential|\.env$|persona.*\.ya?ml$)", re.I)
DOC_EXTS = {".md", ".txt", ".rst", ".html", ".htm"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"}
DATA_EXTS = {".csv", ".tsv", ".jsonl", ".parquet", ".duckdb", ".db", ".pkl", ".npz", ".h5", ".fits"}
JUNK_EXTS = {".pyc", ".pyo", ".tmp", ".orig", ".bak", ".swp", ".swo"}
VERSION_ONLY = re.compile(
    r"(?i)^(?:draft|final|fin|rev|ver|version|v|copy|new|old|update|backup|r)\d*$"
)
DATE_ONLY = re.compile(r"^(20\d{2})[-_.](\d{2})[-_.](\d{2})$")
DATE_REPORT = re.compile(r"^(20\d{2})-(\d{2})-(\d{2})")
PATH_RE = re.compile(
    r"(?<![\w/.-])((?:work|research|deliverables|reports|evidence|runtime|dist|\.staging)"
    r"/[A-Za-z0-9_./\-\u4e00-\u9fff]+)"
)
DB_TEXT_COLS = {
    "posts": ("body", "links", "attachments"),
    "tasks": ("description", "acceptance_criteria", "metadata"),
    "captures": ("path",),
    "share_items": ("ref",),
    "assets": ("path",),
}


def now_iso(ts: float | None = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts if ts is not None else time.time()))


def human_size(n: int | float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def sha256_file(path: Path, limit: int = 0) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
            if limit and f.tell() > limit:
                break
    return h.hexdigest()


def rel_posix(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


# ---------------------------------------------------------------- 策略
@dataclass
class Policy:
    days: int = 14                 # 过程文件"变冷"阈值
    log_days: int = 7              # 日志/缓存保留天数
    report_days: int = 7           # 日报合并门槛（满月且都超过该天数）
    evidence_days: int = 30        # 证据归档门槛
    deliverable_days: int = 30     # 交付目录里的过程件归档门槛
    staging_days: int = 7          # 打包暂存区
    big_bytes: int = 50 * 1024**2  # 大文件标记
    max_files: int = 400           # 单轮最多移动文件数
    max_bytes: int = 2 * 1024**3   # 单轮最多移动字节
    max_groups: int = 12           # 单轮最多合并组
    sim_threshold: float = 0.82    # 近似文章判定阈值
    keep_releases: int = 3         # dist 每个前缀保留的旧发行包数

    def as_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict | None) -> "Policy":
        d = d or {}
        allowed = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in allowed})


# ---------------------------------------------------------------- 保护索引
class Protected:
    """被引用的文件不删：git 已跟踪 + 帖子/任务/资产里出现过的路径。"""

    def __init__(self, paths: set[str] | None = None, notes: dict[str, str] | None = None):
        self.paths = {p.strip("/") for p in (paths or set()) if p}
        self.notes = notes or {}

    def __contains__(self, rel: str) -> bool:
        return rel.strip("/") in self.paths

    def reason(self, rel: str) -> str:
        return self.notes.get(rel.strip("/"), "被引用")


def _git_tracked(root: Path, timeout: int = 30) -> set[str]:
    try:
        out = subprocess.run(
            ["git", "-C", str(root), "-c", "core.quotepath=false", "ls-files", "-z"],
            capture_output=True, timeout=timeout, check=False,
        )
        if out.returncode != 0:
            return set()
        return {x for x in out.stdout.decode("utf-8", "ignore").split("\0") if x}
    except Exception:
        return set()


def _db_referenced(root: Path) -> tuple[set[str], dict[str, str]]:
    db = root / "data.db"
    if not db.exists():
        return set(), {}
    refs: set[str] = set()
    notes: dict[str, str] = {}
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
    except Exception:
        return set(), {}
    try:
        for table, cols in DB_TEXT_COLS.items():
            try:
                present = {r[1] for r in con.execute(f"pragma table_info({table})")}
            except Exception:
                continue
            sel = [c for c in cols if c in present]
            if not sel:
                continue
            sql = f"select {', '.join(sel)} from {table}"
            try:
                rows = con.execute(sql).fetchall()
            except Exception:
                continue
            for row in rows:
                for val in row:
                    if not val:
                        continue
                    text = val if isinstance(val, str) else str(val)
                    for m in PATH_RE.finditer(text):
                        p = m.group(1).rstrip(".,;:)]}'\"")
                        refs.add(p)
                        notes.setdefault(p, f"被 {table} 引用")
    finally:
        con.close()
    return refs, notes


def build_protected(root: Path = ROOT, extra: set[str] | None = None) -> Protected:
    tracked = _git_tracked(root)
    refs, notes = _db_referenced(root)
    keep_dirs = {f"{d}/" for d in ("deliverables/consolidated", "reports/monthly")}
    paths = set(tracked) | set(refs) | {p for p in (extra or set())}
    notes = dict(notes)
    for p in tracked:
        notes.setdefault(p, "git 已跟踪")
    for p in paths:
        if any(p.startswith(d) for d in keep_dirs):
            notes.setdefault(p, "本工具产出")
    return Protected(paths, notes)


# ---------------------------------------------------------------- 扫描
@dataclass
class Finding:
    path: str
    action: str          # keep | trash | archive | merge
    reason: str
    size: int
    mtime: float
    age_days: float
    group: str | None = None

    def as_dict(self) -> dict:
        return dataclasses.asdict(self)


def _walk(root: Path, allowed: tuple[str, ...] = ALLOWED_ROOTS):
    for top in allowed:
        base = root / top
        if not base.exists() or not base.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames.sort()
            for name in sorted(filenames):
                p = Path(dirpath) / name
                if p.is_symlink():
                    continue
                try:
                    st = p.stat()
                except OSError:
                    continue
                yield p, st


def _classify(rel: str, st: os.stat_result, pol: Policy, prot: Protected, now: float) -> Finding:
    p = PurePosixPath(rel)
    top = p.parts[0]
    name = p.name.lower()
    ext = p.suffix.lower()
    age = max(0.0, (now - st.st_mtime) / 86400.0)

    def mk(action: str, reason: str) -> Finding:
        return Finding(rel, action, reason, st.st_size, st.st_mtime, round(age, 1))

    if rel in prot:
        return mk("keep", f"保护：{prot.reason(rel)}")
    if SENSITIVE.search(rel):
        return mk("keep", "疑似含密钥/私密内容，保持不动")
    if top in HARD_KEEP or top not in ALLOWED_ROOTS:
        return mk("keep", "不在维护范围")
    if rel.startswith(("deliverables/consolidated/", "reports/monthly/")):
        return mk("keep", "本工具产出（整理稿/月报）")

    if name in (".ds_store", "thumbs.db") or ext in JUNK_EXTS:
        return mk("trash", "系统/编辑器垃圾文件")
    if "/__pycache__/" in f"/{rel}" or "/.cache/" in f"/{rel}":
        return mk("trash", "可再生缓存")
    if st.st_size == 0:
        return mk("trash", "零字节空文件")
    if ext == ".log" or name.endswith(".log.gz"):
        return mk("trash" if age > pol.log_days else "keep",
                  f"运行日志（>{pol.log_days} 天可清）" if age > pol.log_days else "近期日志")
    if "_retrieval_cache" in rel or "/.cache/" in rel:
        return mk("trash" if age > pol.log_days else "keep", "检索缓存")

    if top == "runtime":
        return mk("keep", "运行时文件（只清日志）")

    if top == "dist":
        if name.endswith(".tar.gz") and age > pol.days:
            return mk("archive", "旧发行包（保留最近几个版本）")
        return mk("keep", "发行产物")

    if top == ".staging":
        return mk("archive" if age > pol.staging_days else "keep", "打包暂存区（apply 沙箱，可重新解包）")

    if top == "reports":
        if DATE_REPORT.match(p.name) and ext == ".md":
            return mk("merge" if age > pol.report_days else "keep", "同一月的日报可合成月报")
        return mk("keep", "报告")

    if top == "evidence":
        return mk("archive" if age > pol.evidence_days else "keep", "过期证据（原件留档）")

    if top == "work":
        if age <= pol.days:
            return mk("keep", f"近 {pol.days} 天的工作文件")
        if ext in DOC_EXTS and not name.startswith(("deliverable", "report", "final")):
            return mk("merge", "工作稿（同主题多版本可合并）")
        return mk("archive", "过期工作过程文件")

    if top == "deliverables":
        if age <= pol.deliverable_days:
            return mk("keep", f"近 {pol.deliverable_days} 天的交付")
        if ext in DOC_EXTS | {".pdf", ".zip", ".pptx", ".xlsx", ".mp4"}:
            if ext in DOC_EXTS and not name.startswith(("deliverable", "post", "final")):
                return mk("merge", "交付目录里的同主题文稿可合并")
            return mk("keep", "成品/成品附件")
        if ext in IMAGE_EXTS | DATA_EXTS | JUNK_EXTS | {".py", ".sh", ".js", ".css"}:
            return mk("archive", "交付目录里的过程件（截图/数据/脚本）")
        return mk("keep", "未识别类型，保守保留")

    if top == "research":
        if age <= pol.days:
            return mk("keep", f"近 {pol.days} 天的研究文件")
        if ext in DOC_EXTS:
            stem = p.stem.lower()
            if re.search(r"(draft|plan|outline|fact|prompt|note|handoff|analysis|brief|log)", stem):
                return mk("merge", "研究过程稿（同主题可合并成一篇）")
            return mk("keep", "研究成稿/资料")
        if ext in DATA_EXTS or ext in IMAGE_EXTS or ext in {".py", ".log", ".json", ".sh"}:
            return mk("archive", "研究中间数据/脚本（可重跑或回档）")
        if ext in {".pdf", ".zip", ".pptx", ".docx"}:
            return mk("keep", "研究成品附件")
        return mk("keep", "未识别类型，保守保留")

    return mk("keep", "保守保留")


# ---------------------------------------------------------------- 合并分组
def _norm_stem(stem: str) -> str:
    """归一化词干：去掉**尾部**版本词（v2/draft/final/copy…），保留主题词。"""
    s = stem.lower().strip()
    if DATE_ONLY.match(s):
        return ""
    s = re.sub(r"\(\d+\)$", "", s).strip(" ._-（）()【】[]")
    parts = [x for x in re.split(r"[\s._-]+", s) if x]
    while len(parts) > 1 and VERSION_ONLY.match(parts[-1]):
        parts.pop()
    return "_".join(parts) or s


GENERIC_STEMS = {
    "draft", "plan", "outline", "notes", "note", "brief", "facts", "fact",
    "prompt", "analysis", "handoff", "readme", "log", "article", "final",
    "merged", "summary", "todo", "index",
}


def _display_stem(stem: str, directory: str) -> str:
    name = stem.strip(" ._-")
    base = PurePosixPath(directory).name
    if name.lower() in GENERIC_STEMS or len(name) < 3:
        if base and base not in ALLOWED_ROOTS:
            return f"{base}-{name}" if name else base
    return name or "merged"


def _read_text(path: Path, limit: int) -> str:
    try:
        data = path.read_bytes()[: limit * 4]
        return data.decode("utf-8", "ignore")[:limit]
    except OSError:
        return ""


def _similarity(a: str, b: str) -> float:
    a = re.sub(r"\s+", "", a)[:4000]
    b = re.sub(r"\s+", "", b)[:4000]
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def _merge_groups(findings: list[Finding], root: Path, pol: Policy,
                  prot: Protected, now: float | None = None) -> list[dict]:
    """把 merge 候选按「同目录 + 同主题版本族 / 高相似度」聚成组。"""
    cands = [f for f in findings if f.action == "merge" and f.path not in prot]
    by_dir: dict[str, list[Finding]] = {}
    for f in cands:
        by_dir.setdefault(str(PurePosixPath(f.path).parent), []).append(f)

    groups: list[dict] = []
    used: set[str] = set()
    for d, items in sorted(by_dir.items()):
        if d == "reports":
            # 日报只走"月报"通道，不参与版本族/近似聚类
            items = [f for f in items if not DATE_REPORT.match(PurePosixPath(f.path).name)]
        # ① 版本族：同目录、同归一化词干
        fam: dict[str, list[Finding]] = {}
        for f in items:
            fam.setdefault(_norm_stem(PurePosixPath(f.path).stem), []).append(f)
        for stem, fs in sorted(fam.items()):
            if len(fs) < 2 or len(stem) < 2:
                continue
            groups.append(_group(d, _display_stem(stem, d), fs))
            used.update(x.path for x in fs)

        # ② 近似文章：同目录、同扩展名、相似度超阈值
        rest = [f for f in items if f.path not in used]
        texts = {f.path: _read_text(root / f.path, 20000) for f in rest}
        merged_local: set[str] = set()
        for i, a in enumerate(rest):
            if a.path in merged_local:
                continue
            cluster = [a]
            for b in rest[i + 1:]:
                if b.path in merged_local:
                    continue
                if PurePosixPath(a.path).suffix.lower() != PurePosixPath(b.path).suffix.lower():
                    continue
                if _similarity(texts[a.path], texts[b.path]) >= pol.sim_threshold:
                    cluster.append(b)
                    merged_local.add(b.path)
            if len(cluster) >= 2:
                stem = _norm_stem(PurePosixPath(a.path).stem)
                groups.append(_group(d, _display_stem(stem, d), cluster))
                merged_local.update(x.path for x in cluster)

    # ③ 日报 → 月报（只合已经过完的月份，当月不动）
    daily = [f for f in findings if f.path.startswith("reports/") and DATE_REPORT.match(PurePosixPath(f.path).name)
             and f.action == "merge" and f.path not in prot]
    months: dict[str, list[Finding]] = {}
    for f in daily:
        m = DATE_REPORT.match(PurePosixPath(f.path).name)
        months.setdefault(f"{m.group(1)}-{m.group(2)}", []).append(f)
    cur = time.localtime(now or time.time())
    for month, fs in sorted(months.items()):
        y, mo = (int(x) for x in month.split("-"))
        if (y, mo) >= (cur.tm_year, cur.tm_mon):
            continue          # 当月/未来月份不合并
        if len(fs) >= 2:
            groups.append(_group("reports", month, fs, target=f"reports/monthly/{month}.md",
                                 kind="monthly", title=f"{month} 月报"))

    # 去掉与其它组合并集重叠的组（保守：一组文件只参与一次）
    groups.sort(key=lambda g: (-len(g["sources"]), g["id"]))
    seen: set[str] = set()
    targets: dict[str, int] = {}
    out: list[dict] = []
    for g in groups:
        src = {s["path"] for s in g["sources"]}
        if src & seen:
            continue
        seen |= src
        t = g["target"]
        if t in targets:
            targets[t] += 1
            stem, suffix = os.path.splitext(t)
            g["target"] = f"{stem}-{targets[t]}{suffix}"
        else:
            targets[t] = 1
        out.append(g)
        if len(out) >= pol.max_groups:
            break
    return out


def _group(directory: str, stem: str, fs: list[Finding], *, target: str | None = None,
           kind: str = "topic", title: str | None = None) -> dict:
    slug = re.sub(r"[^\w\u4e00-\u9fff.-]+", "-", stem).strip("-") or "merged"
    if target is None:
        target = f"deliverables/consolidated/{slug}.md"
    fs = sorted(fs, key=lambda x: x.path)
    return {
        "id": f"g-{hashlib.sha1(('|'.join(x.path for x in fs)).encode()).hexdigest()[:8]}",
        "kind": kind,
        "title": title or stem.replace("-", " ").strip() or "合并稿",
        "dir": directory,
        "target": target,
        "reason": "同主题多篇过程稿 → 合成一篇，原文入档",
        "sources": [{"path": x.path, "size": x.size, "mtime": x.mtime} for x in fs],
    }


# ---------------------------------------------------------------- 计划
def _canonical(plan: dict) -> str:
    body = {
        "plan_id": plan["plan_id"],
        "groups": [{"id": g["id"], "target": g["target"],
                    "sources": [s["path"] for s in g["sources"]]} for g in plan["groups"]],
        "actions": [{"path": a["path"], "action": a["action"], "group": a.get("group")}
                    for a in plan["actions"]],
    }
    return json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def plan_signature(plan: dict) -> str:
    return "sha256:" + hashlib.sha256(_canonical(plan).encode("utf-8")).hexdigest()


def _plan_paths(root: Path) -> tuple[Path, Path]:
    base = root / "data" / "sleep"
    return base / "plans", root / "reports" / "sleep"


def _new_plan_id() -> str:
    return time.strftime("%Y%m%d-%H%M%S") + "-" + hashlib.sha1(str(time.time_ns()).encode()).hexdigest()[:4]


def scan(root: Path = ROOT, *, policy: Policy | None = None, protected_extra: set[str] | None = None,
         now: float | None = None) -> dict:
    """只读扫描，返回 plan（不落盘）。"""
    root = root.resolve()
    pol = policy or Policy()
    now = now or time.time()
    prot = build_protected(root, extra=protected_extra)

    findings: list[Finding] = []
    for path, st in _walk(root):
        rel = rel_posix(path, root)
        findings.append(_classify(rel, st, pol, prot, now))

    # dist/ 旧发行包：每个前缀只保留最近 keep_releases 个
    dist_groups: dict[str, list[Finding]] = {}
    for f in findings:
        if f.path.startswith("dist/") and f.path.endswith(".tar.gz"):
            name = PurePosixPath(f.path).name
            prefix = re.sub(r"[-_]?v?\d+\.\d+\.\d+\.tar\.gz$", "", name)
            dist_groups.setdefault(prefix, []).append(f)
    for prefix, fs in dist_groups.items():
        fs.sort(key=lambda x: -x.mtime)
        for f in fs[: max(1, pol.keep_releases)]:
            f.action = "keep"
            f.reason = f"保留最近 {pol.keep_releases} 个发行包（{prefix}）"

    groups = _merge_groups(findings, root, pol, prot, now=now)
    grouped = {s["path"]: g["id"] for g in groups for s in g["sources"]}

    # 选入本轮的动作：垃圾文件全清（体积小），过期过程件按"最老优先"受配额约束
    trash = [f for f in findings if f.action == "trash"]
    archive = [f for f in findings if f.action == "archive"]
    archive.sort(key=lambda f: (-f.age_days, -f.size))
    selected: list[Finding] = list(trash)
    used_files = used_bytes = 0
    for f in archive:
        if used_files >= pol.max_files:
            continue
        # 软上限：允许"本轮第一个文件"超过 max_bytes（否则超大文件永远轮不到），
        # 但它会独占一轮，下轮继续。
        if used_bytes > 0 and used_bytes + f.size > pol.max_bytes:
            continue
        selected.append(f)
        used_files += 1
        used_bytes += f.size
    sel_paths = {f.path for f in selected}
    deferred = [f for f in archive if f.path not in sel_paths]

    actions = []
    for f in findings:
        if f.path in grouped:
            action, reason = "merge", f.reason
        elif f.action == "merge":
            action, reason = "keep", "过程稿（本轮没有可合并的同主题稿）"
        elif f.action in ("trash", "archive"):
            if f.path in sel_paths:
                action, reason = f.action, f.reason
            else:
                action, reason = "keep", "本轮配额用尽，顺延"
        else:
            action, reason = "keep", f.reason
        actions.append({"path": f.path, "action": action, "reason": reason,
                        "size": f.size, "mtime": f.mtime,
                        "group": grouped.get(f.path)})
    actions.sort(key=lambda a: a["path"])

    def total(pred) -> tuple[int, int]:
        fs = [f for f in findings if pred(f)]
        return len(fs), sum(f.size for f in fs)

    def by_dir(fs: list[Finding]) -> list[dict]:
        agg: dict[str, list[int]] = {}
        for f in fs:
            top = PurePosixPath(f.path).parts[0]
            a = agg.setdefault(top, [0, 0])
            a[0] += 1
            a[1] += f.size
        return [{"dir": k, "files": v[0], "bytes": v[1]}
                for k, v in sorted(agg.items(), key=lambda kv: -kv[1][1])]

    n_keep, b_keep = total(lambda f: f.action == "keep" and f.path not in grouped)
    n_trash, b_trash = total(lambda f: f.action == "trash")
    n_arch, b_arch = total(lambda f: f.action == "archive")
    n_merge, b_merge = total(lambda f: f.path in grouped)
    plan = {
        "version": 1,
        "plan_id": _new_plan_id(),
        "created_at": now_iso(now),
        "status": "pending",
        "approved_by": None,
        "approved_at": None,
        "policy": pol.as_dict(),
        "summary": {
            "scanned_files": len(findings),
            "scanned_bytes": sum(f.size for f in findings),
            "keep": {"files": n_keep, "bytes": b_keep},
            "trash": {"files": n_trash, "bytes": b_trash},
            "archive": {"files": n_arch, "bytes": b_arch},
            "merge": {"files": n_merge, "bytes": b_merge, "groups": len(groups)},
            "selected": {"files": len(sel_paths), "bytes": sum(f.size for f in selected)},
            "deferred": {"files": len(deferred), "bytes": sum(f.size for f in deferred),
                         "by_dir": by_dir(deferred)},
            "protected": len(prot.paths),
        },
        "groups": groups,
        "actions": actions,
        "warnings": [
            "只移动未被 git 跟踪、也未被帖子/任务/资产引用的过程文件。",
            "删除=移入 backups/sleep/<run_id>.tar.gz，可用 restore 原样取回。",
            "单轮有配额（文件数/字节）；超大文件允许单独占一轮，其余顺延。",
        ],
    }
    plan["signature"] = plan_signature(plan)
    return plan


def save_plan(plan: dict, root: Path = ROOT) -> Path:
    plans_dir, _ = _plan_paths(root)
    plans_dir.mkdir(parents=True, exist_ok=True)
    path = plans_dir / f"{plan['plan_id']}.json"
    path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    md = render_plan_report(plan)
    _, reports_dir = _plan_paths(root)
    reports_dir.mkdir(parents=True, exist_ok=True)
    (reports_dir / f"{plan['plan_id']}.md").write_text(md, encoding="utf-8")
    return path


def load_plan(plan_id: str, root: Path = ROOT) -> dict:
    plans_dir, _ = _plan_paths(root)
    path = plans_dir / f"{plan_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"找不到计划：{plan_id}")
    return json.loads(path.read_text(encoding="utf-8"))


def list_plans(root: Path = ROOT) -> list[dict]:
    plans_dir, _ = _plan_paths(root)
    out = []
    if not plans_dir.exists():
        return out
    for p in sorted(plans_dir.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            out.append({"plan_id": d.get("plan_id"), "created_at": d.get("created_at"),
                        "status": d.get("status"), "summary": d.get("summary"),
                        "signature": d.get("signature")})
        except Exception:
            continue
    return out


def approve(plan_id: str, by: str = "owner", root: Path = ROOT) -> dict:
    plan = load_plan(plan_id, root)
    if plan.get("status") == "applied":
        raise ValueError("该计划已执行，不能重复批准")
    sig = plan_signature(plan)
    if sig != plan.get("signature"):
        raise ValueError("计划内容与签名不一致（可能被手工改过），请重新 scan")
    plan["status"] = "approved"
    plan["approved_by"] = by
    plan["approved_at"] = now_iso()
    plan["approved_signature"] = sig
    save_plan(plan, root)
    return plan


# ---------------------------------------------------------------- 合并稿
def _title_of(path: Path, text: str) -> str:
    for line in text.splitlines()[:40]:
        s = line.strip()
        if s.startswith("#"):
            return s.lstrip("#").strip() or path.stem
    return path.stem


def render_merged_doc(group: dict, root: Path, *, mode: str = "stitch",
                      adapter: str = "opencode", model: str | None = None) -> tuple[str, str]:
    """返回 (正文, 实际使用的方法)。LLM 不可用/失败时回落到确定性拼接。"""
    srcs: list[tuple[str, str]] = []
    for s in group["sources"]:
        p = root / s["path"]
        srcs.append((s["path"], _read_text(p, 60_000)))
    if mode in ("auto", "llm"):
        try:
            text = _llm_merge(group, srcs, adapter=adapter, model=model)
            if text and len(text.strip()) > 200:
                return _with_provenance(group, text, method="llm"), "llm"
            if mode == "llm":
                raise RuntimeError("LLM 返回内容过短")
        except Exception as e:  # noqa: BLE001
            if mode == "llm":
                raise
            note = f"（LLM 合并不可用，已回落到确定性拼接：{type(e).__name__}）"
        else:
            note = ""
    else:
        note = ""
    body = _stitch_merge(group, srcs)
    if mode == "auto" and note:
        body = body.replace("<!-- provenance -->", f"<!-- {note} -->", 1)
    return body, "stitch"


def _stitch_merge(group: dict, srcs: list[tuple[str, str]]) -> str:
    title = group["title"] or "合并稿"
    parts = [f"# {title}（整理稿）\n",
             f"> 生成：{now_iso()} · 方法：确定性拼接 · 来源 {len(srcs)} 篇\n",
             "> 本文由维护脚本按来源顺序合成，未新增来源之外的事实；细节以文末来源为准。\n"]
    for i, (rel, text) in enumerate(srcs, 1):
        body = text.strip()
        # 去掉来源自己的 H1，避免多层标题
        lines = body.splitlines()
        if lines and lines[0].lstrip().startswith("# "):
            lines = lines[1:]
        body = "\n".join(lines).strip()
        head = _title_of(Path(rel), text)
        parts.append(f"\n## {i}. {head}\n\n{body}\n")
    return "\n".join(parts) + "\n<!-- provenance -->\n"


def _with_provenance(group: dict, body: str, *, method: str) -> str:
    return (body.rstrip() + "\n\n<!-- provenance -->\n\n---\n\n"
            f"> 整理方式：{method}（只重排来源内容，不新增事实）· {now_iso()}\n")


def _llm_merge(group: dict, srcs: list[tuple[str, str]], *, adapter: str, model: str | None) -> str:
    from core.llm import get as llm_get

    chunks = []
    for rel, text in srcs:
        chunks.append(f"===== 来源：{rel} =====\n{text[:20000]}")
    prompt = (
        "你是团队的资料整理员。下面同一主题有若干篇**过程稿**（草稿/版本稿）。请把它们合成**一篇**结构清晰的中文文章。\n"
        "纪律：① 只使用来源中出现的内容，不新增、不推断、不补数据；② 冲突处以较新/更具体者为准并注明；\n"
        "③ 保留可核验的数字与出处；④ 输出 Markdown，一个 H1 标题 + 若干 H2 小节，不要输出解释。\n"
        f"主题：{group['title']}\n\n" + "\n\n".join(chunks)
    )
    res = llm_get(adapter).run(prompt, model=model, cwd=str(ROOT), title="sleep-merge", timeout=240)
    if not getattr(res, "ok", False):
        raise RuntimeError(getattr(res, "error", "LLM 调用失败") or "LLM 调用失败")
    return res.text


# ---------------------------------------------------------------- 执行
def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _prune_empty(path: Path, stop: Path) -> None:
    cur = path
    while cur != stop and _within(cur, stop):
        try:
            cur.rmdir()
        except OSError:
            return
        cur = cur.parent


def apply_plan(plan_id: str, root: Path = ROOT, *, merge_mode: str = "auto",
               adapter: str = "opencode", model: str | None = None) -> dict:
    root = root.resolve()
    plan = load_plan(plan_id, root)
    if plan.get("status") != "approved":
        raise PermissionError("计划未批准：先运行 `sleep.py approve <plan_id>`")
    sig = plan_signature(plan)
    if sig != plan.get("signature") or plan.get("approved_signature") != sig:
        raise PermissionError("计划签名不一致（可能被改过），拒绝执行；请重新 scan + approve")

    run_id = plan["plan_id"]
    run_dir = root / "backups" / "sleep" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    tar_path = run_dir / "archive.tar.gz"
    started = now_iso()

    moved: list[dict] = []
    merged: list[dict] = []
    skipped: list[dict] = []
    errors: list[str] = []
    prot_now = build_protected(root)

    # 1) 合并稿（先写成品，再归档原文；失败则整组不动）
    for g in plan.get("groups", []):
        sources = [root / s["path"] for s in g["sources"]]
        missing = [str(p) for p in sources if not p.exists()]
        if missing:
            skipped.append({"group": g["id"], "reason": f"来源缺失 {len(missing)} 个"})
            continue
        newly_protected = [s["path"] for s in g["sources"] if s["path"] in prot_now]
        if newly_protected:
            skipped.append({"group": g["id"],
                            "reason": f"来源自扫描后已被引用（{len(newly_protected)} 个），跳过合并"})
            continue
        try:
            body, method = render_merged_doc(g, root, mode=merge_mode, adapter=adapter, model=model)
        except Exception as e:  # noqa: BLE001
            errors.append(f"合并失败 {g['id']}: {type(e).__name__}: {e}")
            continue
        target = root / g["target"]
        if target.exists():
            target = target.with_name(f"{target.stem}-{plan['plan_id'][-4:]}{target.suffix}")
        if not _within(target, root):
            errors.append(f"目标越界，跳过：{g['target']}")
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body, encoding="utf-8")
        merged.append({"group": g["id"], "target": rel_posix(target, root), "method": method,
                       "sources": [s["path"] for s in g["sources"]]})

    # 2) 归档并移除过程文件（成功合并的来源一并入档）
    ok_groups = {m["group"] for m in merged}
    archive_actions = [
        a for a in plan["actions"]
        if a["action"] in ("trash", "archive")
        or (a["action"] == "merge" and a.get("group") in ok_groups)
    ]
    to_move: list[tuple[dict, Path]] = []
    for a in archive_actions:
        p = root / a["path"]
        if not _within(p, root) or PurePosixPath(a["path"]).parts[0] not in ALLOWED_ROOTS:
            errors.append(f"路径越界，跳过：{a['path']}")
            continue
        if a["path"] in prot_now:
            skipped.append({"path": a["path"], "reason": "自扫描后已被引用，跳过"})
            continue
        if not p.exists():
            skipped.append({"path": a["path"], "reason": "已不存在"})
            continue
        st = p.stat()
        if int(st.st_size) != int(a["size"]) or abs(st.st_mtime - float(a["mtime"])) > 1:
            skipped.append({"path": a["path"], "reason": "自扫描后已变化，跳过"})
            continue
        to_move.append((a, p))

    manifest = {
        "run_id": run_id,
        "plan_id": plan_id,
        "started_at": started,
        "finished_at": None,
        "root_hint": "workspace",
        "merge_mode": merge_mode,
        "moved": [],
        "merged": merged,
        "skipped": skipped,
        "errors": errors,
    }
    if to_move:
        with tarfile.open(tar_path, "w:gz") as tar:
            for a, p in to_move:
                rel = a["path"]
                digest = sha256_file(p)
                tar.add(p, arcname=rel, recursive=False)
                manifest["moved"].append({
                    "path": rel, "size": a["size"], "mtime": a["mtime"],
                    "sha256": digest, "action": a["action"], "reason": a["reason"],
                })
        # 校验归档尺寸，再删原文件
        with tarfile.open(tar_path, "r:gz") as tar:
            members = {m.name: m.size for m in tar.getmembers()}
        ok_paths = set()
        for m in manifest["moved"]:
            if members.get(m["path"]) != m["size"]:
                errors.append(f"归档校验失败：{m['path']}")
                continue
            ok_paths.add(m["path"])
        for a, p in to_move:
            if a["path"] not in ok_paths:
                continue
            try:
                p.unlink()
                _prune_empty(p.parent, root / PurePosixPath(a["path"]).parts[0])
                a["removed"] = True
            except OSError as e:
                errors.append(f"删除失败 {a['path']}: {e}")
    else:
        tar_path = None

    manifest["finished_at"] = now_iso()
    manifest["stats"] = {
        "moved": len(manifest["moved"]),
        "bytes": sum(m["size"] for m in manifest["moved"]),
        "merged": len(merged),
        "skipped": len(skipped),
        "errors": len(errors),
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                           encoding="utf-8")

    plan["status"] = "applied"
    plan["applied_at"] = manifest["finished_at"]
    plan["run_id"] = run_id
    plan["result"] = manifest["stats"]
    # 注意：signature 只覆盖 groups/actions（未变），状态变更不影响签名，
    # 这样执行后仍可用原签名复核计划内容没有被改过。
    save_plan(plan, root)

    _, reports_dir = _plan_paths(root)
    reports_dir.mkdir(parents=True, exist_ok=True)
    (reports_dir / f"{run_id}-applied.md").write_text(render_run_report(manifest, plan),
                                                      encoding="utf-8")
    return manifest


def list_runs(root: Path = ROOT) -> list[dict]:
    base = root / "backups" / "sleep"
    out = []
    if not base.exists():
        return out
    for d in sorted(base.iterdir()):
        if not d.is_dir():
            continue
        mf = d / "manifest.json"
        try:
            m = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            m = {}
        out.append({"run_id": d.name, "finished_at": m.get("finished_at"),
                    "stats": m.get("stats"), "tar": (d / "archive.tar.gz").exists(),
                    "bytes": (d / "archive.tar.gz").stat().st_size if (d / "archive.tar.gz").exists() else 0})
    return out


def restore_run(run_id: str, root: Path = ROOT, *, overwrite: bool = False) -> dict:
    root = root.resolve()
    run_dir = root / "backups" / "sleep" / run_id
    mf = run_dir / "manifest.json"
    tar_path = run_dir / "archive.tar.gz"
    if not mf.exists():
        raise FileNotFoundError(f"找不到运行记录：{run_id}")
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    restored, mismatch, skipped = [], [], []
    if tar_path.exists():
        with tarfile.open(tar_path, "r:gz") as tar:
            members = {m.name: m for m in tar.getmembers()}
            for m in manifest.get("moved", []):
                rel = m["path"]
                member = members.get(rel)
                if member is None:
                    mismatch.append({"path": rel, "reason": "归档内缺失"})
                    continue
                dest = root / rel
                if not _within(dest, root):
                    mismatch.append({"path": rel, "reason": "路径越界"})
                    continue
                if dest.exists() and not overwrite:
                    skipped.append({"path": rel, "reason": "目标已存在（--overwrite 可覆盖）"})
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                src = tar.extractfile(member)
                if src is None:
                    mismatch.append({"path": rel, "reason": "无法读取归档成员"})
                    continue
                with dest.open("wb") as f:
                    shutil.copyfileobj(src, f)
                try:
                    os.utime(dest, (m["mtime"], m["mtime"]))
                except OSError:
                    pass
                if sha256_file(dest) != m.get("sha256"):
                    mismatch.append({"path": rel, "reason": "sha256 不一致"})
                else:
                    restored.append(rel)
    return {"run_id": run_id, "restored": len(restored), "restored_paths": restored,
            "mismatch": mismatch, "skipped": skipped}


def purge_runs(root: Path = ROOT, *, keep: int = 3, dry_run: bool = True) -> dict:
    runs = list_runs(root)
    victims = runs[:-keep] if keep > 0 else runs
    freed = sum(r.get("bytes") or 0 for r in victims)
    if not dry_run:
        for r in victims:
            shutil.rmtree(root / "backups" / "sleep" / r["run_id"], ignore_errors=True)
    return {"kept": [r["run_id"] for r in runs[-keep:]] if keep > 0 else [],
            "purged": [r["run_id"] for r in victims], "freed_bytes": freed, "dry_run": dry_run}


# ---------------------------------------------------------------- 报告
def _fmt_paths(items: list[dict], limit: int = 25) -> list[str]:
    lines = []
    for a in items[:limit]:
        lines.append(f"| `{a['path']}` | {human_size(a['size'])} | {a['reason']} |")
    if len(items) > limit:
        lines.append(f"| … | 余 {len(items) - limit} 条见计划 JSON | |")
    return lines


def render_plan_report(plan: dict) -> str:
    s = plan["summary"]
    lines = [
        f"# 睡眠整理 · 自检报告 `{plan['plan_id']}`",
        "",
        f"> 生成：{plan['created_at']} · 状态：**{plan['status']}** · 本轮需要你批准后才执行。",
        "",
        "## 1. 结论",
        "",
        f"- 扫描 **{s['scanned_files']}** 个文件（{human_size(s['scanned_bytes'])}），"
        f"建议保留 {s['keep']['files']} 个（{human_size(s['keep']['bytes'])}）。",
        f"- **合并** {s['merge']['groups']} 组 / {s['merge']['files']} 篇 → 生成 {s['merge']['groups']} 篇文章，原文入档。",
        f"- **清理**（垃圾/日志）{s['trash']['files']} 个 / {human_size(s['trash']['bytes'])}。",
        f"- **归档**（过期过程件）{s['archive']['files']} 个 / {human_size(s['archive']['bytes'])}。",
        f"- 本轮实际执行 {s['selected']['files']} 个文件 / {human_size(s['selected']['bytes'])}；"
        f"顺延 {s['deferred']['files']} 个 / {human_size(s['deferred']['bytes'])}（受单轮配额约束）。",
        f"- 受保护（被引用/已入库）{s['protected']} 个，一律不动。",
        "",
        "## 2. 合并建议",
        "",
    ]
    if not plan["groups"]:
        lines.append("本轮没有满足条件的合并组（同主题多版本、且都不是成品/未过期）。")
    for g in plan["groups"]:
        lines.append(f"### {g['title']} → `{g['target']}`")
        lines.append("")
        lines.append(f"理由：{g['reason']}；来源 {len(g['sources'])} 篇：")
        lines.append("")
        for src in g["sources"]:
            lines.append(f"- `{src['path']}`（{human_size(src['size'])}）")
        lines.append("")
    lines += ["## 3. 清理清单", "", "| 文件 | 体积 | 理由 |", "|---|---:|---|"]
    tr = [a for a in plan["actions"] if a["action"] in ("trash", "archive")]
    lines += _fmt_paths(tr)
    if not tr:
        lines.append("| （无） | | |")

    big = [a for a in plan["actions"] if a["action"] in ("trash", "archive")
           and a["size"] >= plan.get("policy", {}).get("big_bytes", 50 * 1024**2)]
    if big:
        lines += ["", "**大文件提醒**（单个 ≥50MB，执行前请确认是否还需要原文件）：", "",
                  "| 文件 | 体积 |", "|---|---:|"]
        for a in sorted(big, key=lambda x: -x["size"])[:10]:
            lines.append(f"| `{a['path']}` | {human_size(a['size'])} |")

    dd = (s.get("deferred") or {}).get("by_dir") or []
    if dd:
        lines += ["", "### 顺延到后续轮次（受单轮配额约束）", "",
                  "| 目录 | 文件数 | 体积 |", "|---|---:|---:|"]
        for d in dd[:8]:
            lines.append(f"| `{d['dir']}/` | {d['files']} | {human_size(d['bytes'])} |")
    lines += [
        "",
        "## 4. 安全边界",
        "",
        "- 只处理未跟踪、未被引用的文件；`docs/`、`agents/`、`core/`、`static/`、`config/` 等永不扫描。",
        "- 删除 = 移入 `backups/sleep/<run_id>.tar.gz`；manifest 记录每个文件的 sha256，可 `restore`。",
        "- 合并稿写到 `deliverables/consolidated/`，来源清单附在文末；原文一并入档，不丢。",
        "",
        "## 5. 批准与执行",
        "",
        "```bash",
        f"../venv/bin/python scripts/sleep.py approve {plan['plan_id']} --by owner",
        f"../venv/bin/python scripts/sleep.py apply {plan['plan_id']}",
        "```",
        "",
        "回滚：`scripts/sleep.py restore <run_id>`；只清理旧归档：`scripts/sleep.py purge --keep 3 --yes`。",
        "",
        "## 6. 说明",
        "",
    ]
    lines += [f"- {w}" for w in plan.get("warnings", [])]
    return "\n".join(lines) + "\n"


def render_run_report(manifest: dict, plan: dict) -> str:
    st = manifest.get("stats", {})
    lines = [
        f"# 睡眠整理 · 执行报告 `{manifest['run_id']}`",
        "",
        f"> 计划 `{manifest['plan_id']}` · {manifest['started_at']} → {manifest['finished_at']}",
        "",
        "## 结果",
        "",
        f"- 归档/清理 **{st.get('moved', 0)}** 个文件（{human_size(st.get('bytes', 0))}），"
        f"合并 **{st.get('merged', 0)}** 篇，跳过 {st.get('skipped', 0)}，错误 {st.get('errors', 0)}。",
        "",
    ]
    if manifest.get("merged"):
        lines += ["## 合并稿", ""]
        for m in manifest["merged"]:
            lines.append(f"- `{m['target']}`（{m['method']}，来源 {len(m['sources'])} 篇）")
        lines.append("")
    if manifest.get("moved"):
        lines += ["## 已归档", ""]
        for m in manifest["moved"]:
            lines.append(f"- `{m['path']}`（{human_size(m['size'])}，{m['reason']}）")
        lines.append("")
    if manifest.get("skipped"):
        lines += ["## 跳过", ""]
        for m in manifest["skipped"]:
            lines.append(f"- `{m.get('path') or m.get('group')}`：{m.get('reason')}")
        lines.append("")
    if manifest.get("errors"):
        lines += ["## 错误", ""] + [f"- {e}" for e in manifest["errors"]] + [""]
    lines += ["## 回滚", "", f"```bash", f"../venv/bin/python scripts/sleep.py restore {manifest['run_id']}", "```", ""]
    return "\n".join(lines)
