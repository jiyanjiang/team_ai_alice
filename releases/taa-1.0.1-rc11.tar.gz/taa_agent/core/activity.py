"""Agent 执行进度可见性 —— 统一状态上报（t-5e7abb71）。

问题：执行者（如 Carol）在后台拉起 headless opencode 执行任务时，外部只看到
任务粗粒度状态（claimed/in_progress/review）与 agent 状态（active），看不到
「当前在做什么、处于 start/progress/done 哪个阶段、耗时多久」。

方案：一张 `agent_activity` 表，每个 agent 一行「当前活动」；dispatcher 在执行
前/中/后调用 `report()` 上报 start/progress/done；`/v1/board` 直接读它渲染。

本模块只做纯数据操作（upsert / get / clear），HTTP 与签名在 server.py / report.py。
"""
from __future__ import annotations

import json
import time
from datetime import datetime

STAGES = ("idle", "start", "progress", "done", "blocked")


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def report(conn, agent_id: str, stage: str, task_id: str | None = None,
           title: str | None = None, detail: dict | None = None) -> dict:
    """上报一次活动状态（upsert）。返回当前记录。"""
    if stage not in STAGES:
        raise ValueError(f"bad stage: {stage}")
    detail = detail or {}
    # 附带服务器时间戳，供前端计算耗时
    detail.setdefault("updated_at", _now())
    now = _now()
    row = conn.execute("SELECT started_at, task_id FROM agent_activity WHERE agent_id=?",
                       (agent_id,)).fetchone()
    prev_started = row["started_at"] if row else None
    prev_task = row["task_id"] if row else None
    # 何时重置计时起点：显式 start；或换了新任务（task_id 变化）；或此前根本没有起点。
    # 否则沿用旧起点，保证同一任务内 progress 的 elapsed 单调递增。
    is_new = (stage == "start" or not prev_started
              or (task_id is not None and task_id != prev_task))
    started = now if is_new else prev_started
    conn.execute(
        "INSERT INTO agent_activity(agent_id, task_id, title, stage, detail, started_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(agent_id) DO UPDATE SET task_id=excluded.task_id, title=excluded.title, "
        "  stage=excluded.stage, detail=excluded.detail, started_at=excluded.started_at, "
        "  updated_at=excluded.updated_at",
        (agent_id, task_id, title, stage,
         json.dumps(detail, ensure_ascii=False), started, now))
    conn.commit()
    return get(conn, agent_id)


def get(conn, agent_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM agent_activity WHERE agent_id=?", (agent_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["detail"] = _loads(d.get("detail"))
    return d


def clear(conn, agent_id: str) -> None:
    conn.execute("DELETE FROM agent_activity WHERE agent_id=?", (agent_id,))
    conn.commit()


def all_activities(conn) -> dict:
    """agent_id -> activity dict（供 /v1/board 一次性取）。"""
    out = {}
    for r in conn.execute("SELECT * FROM agent_activity ORDER BY updated_at DESC"):
        d = dict(r)
        d["detail"] = _loads(d.get("detail"))
        out[d["agent_id"]] = d
    return out


def _loads(s):
    if not s:
        return {}
    try:
        return json.loads(s)
    except Exception:
        return {}


def elapsed_s(activity: dict | None) -> int | None:
    """从 started_at 与 detail.updated_at 估算当前已耗时（秒）。"""
    if not activity:
        return None
    started = activity.get("started_at")
    if not started:
        return None
    end = (activity.get("detail") or {}).get("updated_at") or _now()
    try:
        s = datetime.strptime(str(started), "%Y-%m-%d %H:%M:%S")
        e = datetime.strptime(str(end), "%Y-%m-%d %H:%M:%S")
        return max(0, int((e - s).total_seconds()))
    except Exception:
        return None


def age_s(activity: dict | None, now: str | None = None) -> int | None:
    """距最近一次上报的秒数（用于判断进度是否已过期/陈旧）。"""
    if not activity:
        return None
    upd = (activity.get("detail") or {}).get("updated_at") or activity.get("updated_at")
    if not upd:
        return None
    try:
        u = datetime.strptime(str(upd), "%Y-%m-%d %H:%M:%S")
        n = datetime.strptime(now, "%Y-%m-%d %H:%M:%S") if now else datetime.now()
        return max(0, int((n - u).total_seconds()))
    except Exception:
        return None


def is_stale(activity: dict | None, max_age_s: int = 900) -> bool:
    """start/progress 超过 max_age_s 未刷新 => 视为陈旧（执行进程可能已退出而状态未清）。"""
    if not activity:
        return False
    if activity.get("stage") not in ("start", "progress", "blocked"):
        return False
    a = age_s(activity)
    return a is not None and a > max_age_s
