"""LLM 用量与花费统计（数据源：本机 opencode `session_v2`）。

- tokens 是可靠口径；`cost` 列对**无价目的模型**（如 `deepseek-chat`）记 0 → 按费率**回填**。
- 厂商取价：`~/.cache/opencode/models.json` 精确 id（优先 deepseek/opencode），缺失用内置兜底费率。
- 供 `teamai usage` 与远程 `usage` 命令共用；**不发网络请求**。
"""
from __future__ import annotations

import collections
import datetime as dt
import json
import os
from pathlib import Path

DB = Path(os.path.expanduser("~/.local/share/opencode/opencode.db"))
MODELS_JSON = Path(os.path.expanduser("~/.cache/opencode/models.json"))

# (input, output, reasoning, cache_read) USD / 1M tokens —— 缺失价目时的兜底
FALLBACK = {
    "deepseek-flash": (0.15, 0.60, 0.60, 0.003),
    "deepseek-v4-flash-vision-exp": (0.15, 0.60, 0.60, 0.003),
    "deepseek-chat": (0.27, 1.10, 1.10, 0.07),
    "deepseek-reasoner": (0.55, 2.19, 2.19, 0.14),
    "deepseek-v4-pro": (0.66, 1.98, 1.98, 0.022),
}


def _prices() -> dict:
    out: dict[str, dict] = {}
    try:
        data = json.loads(MODELS_JSON.read_text(encoding="utf-8"))
    except Exception:
        return out
    for pid, pv in data.items():
        for mid, mv in (pv.get("models") or {}).items():
            c = mv.get("cost")
            if c:
                out.setdefault(mid, {})[pid] = c
    return out


def rate(model_id: str, prices: dict | None = None) -> tuple:
    prices = prices if prices is not None else _prices()
    for pid in ("deepseek", "opencode", "opencode-go"):
        c = (prices.get(model_id) or {}).get(pid)
        if c:
            return (c.get("input", 0), c.get("output", 0), c.get("reasoning", c.get("output", 0)),
                    c.get("cache_read", 0), c.get("cache_write", 0))
    if prices.get(model_id):
        c = next(iter(prices[model_id].values()))
        return (c.get("input", 0), c.get("output", 0), c.get("reasoning", c.get("output", 0)),
                c.get("cache_read", 0), c.get("cache_write", 0))
    f = FALLBACK.get(model_id, FALLBACK["deepseek-flash"])
    return (f[0], f[1], f[2], f[3], 0.0)


def _model_of(s: str) -> str:
    try:
        return (json.loads(s or "{}") or {}).get("id", "?")
    except Exception:
        return "?"


def _category(title: str) -> str:
    t = title or "?"
    if t.startswith("room:"):
        return "聊天室"
    if t.startswith("chatwork:"):
        return "指令识别"
    if t.startswith("harvest:"):
        return "事实收割"
    if t.startswith("obedience"):
        return "服从度"
    if t.startswith("style:") or t.startswith("learn:"):
        return "风格/学习"
    if ":t-" in t or ":p-" in t or t.startswith("plan-review"):
        return "任务执行"
    return "其他/交互"


def day_rows(day: dt.date) -> list[dict]:
    if not DB.exists():
        return []
    import sqlite3
    lo = int(dt.datetime.combine(day, dt.time.min).timestamp() * 1000)
    hi = lo + 86400000
    con = sqlite3.connect(str(DB))
    con.row_factory = sqlite3.Row
    # 表回退：新版 opencode 用 session_v2，旧版只有 session
    names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    tbl = "session_v2" if "session_v2" in names else ("session" if "session" in names else None)
    if not tbl:
        con.close()
        return []
    try:
        rows = [dict(r) for r in con.execute(
            f"SELECT model,title,cost,tokens_input ti,tokens_output ot,tokens_reasoning tr,"
            f"tokens_cache_read tcr,tokens_cache_write tcw FROM {tbl} "
            f"WHERE time_created>=? AND time_created<?", (lo, hi))]
    except sqlite3.OperationalError:
        rows = []
    con.close()
    return rows


def cost_of(model_id: str, r: dict, prices: dict | None = None) -> float:
    pi, po, pr, pcr, pcw = rate(model_id, prices)
    return (r.get("ti", 0) * pi + r.get("ot", 0) * po + r.get("tr", 0) * pr
            + r.get("tcr", 0) * pcr + r.get("tcw", 0) * pcw) / 1e6


def summarize(rows: list[dict]) -> dict:
    prices = _prices()
    by_cat: dict[str, dict] = collections.defaultdict(
        lambda: dict(n=0, rep=0.0, est=0.0, ti=0, ot=0, tr=0, tcr=0))
    by_model: dict[str, dict] = collections.defaultdict(
        lambda: dict(n=0, rep=0.0, est=0.0, ti=0, ot=0, tr=0, tcr=0))
    for r in rows:
        m = _model_of(r["model"])
        for bucket, key in ((by_cat, _category(r["title"])), (by_model, m)):
            x = bucket[key]
            x["n"] += 1
            x["rep"] += r["cost"] or 0
            x["est"] += cost_of(m, r, prices)
            for k in ("ti", "ot", "tr", "tcr"):
                x[k] += r[k]
    total = dict(n=len(rows), rep=sum(x["rep"] for x in by_cat.values()),
                 est=sum(x["est"] for x in by_cat.values()))
    return {"total": total, "by_cat": dict(by_cat), "by_model": dict(by_model)}


def summary(days: int = 7, today: dt.date | None = None) -> dict:
    today = today or dt.date.today()
    out = {}
    for i in range(days):
        d = today - dt.timedelta(days=i)
        out[str(d)] = summarize(day_rows(d))
    return out
