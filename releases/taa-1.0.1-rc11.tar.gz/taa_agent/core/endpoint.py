"""端点自愈（S2「地址变更可发现」的最小实现）。

问题（2026-10-14 实测）：本机 IP 从 .110 变到 .105 后，某个 chatroom 实例**抱着旧地址重试了 5 万+ 拍**
（`No route to host`）——**静默失败**。系统里虽有 UDP 信标可发现宿主，但这条连接路径没用它。

策略（顺序＝优先级）：
  1) 当前 base（若可达）；
  2) `TEAMAI_URL` 环境变量；
  3) 本机回环 `http://127.0.0.1:<port>`（同机 hub 最稳）；
  4) `config.topology.nodes[*].addrs`（人工指定/继承次序里的地址）；
  5) **UDP 信标发现**（`core.discovery`，若可用）。
任一变可达即切换并返回 `(new_base, tried[])`；全部不可达 → 返回 None（由上层报警，不静默）。
"""
from __future__ import annotations

import os
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def candidates(base: str = "", port: int = 6080) -> list[str]:
    out: list[str] = []

    def add(u: str) -> None:
        u = (u or "").rstrip("/")
        if u and u not in out:
            out.append(u)

    add(base)
    add(os.environ.get("TEAMAI_URL", ""))
    add(f"http://127.0.0.1:{port}")
    try:
        import sys
        sys.path.insert(0, str(ROOT))
        from core import config
        topo = config.get("topology") or {}
        for n in (topo.get("nodes") or []):
            for a in (n.get("addrs") or []):
                add(f"http://{a}:{port}")
    except Exception:  # noqa: BLE001
        pass
    try:
        from core import discovery as _disc
        ip = _disc.discover(timeout=1.5)          # 信标发现（可能返回 None）
        if ip:
            add(ip if str(ip).startswith("http") else f"http://{ip}:{port}")
    except Exception:  # noqa: BLE001
        pass
    return out


def probe(base: str, timeout: float = 1.5) -> bool:
    try:
        with urllib.request.urlopen(base + "/v1/health", timeout=timeout) as r:
            return bool((r.read(200) or b"").strip())
    except Exception:  # noqa: BLE001
        return False


def heal(base: str = "", port: int = 6080, probe_fn=None) -> tuple[str | None, list[str]]:
    """找到第一个可达端点；返回 (new_base_or_None, 已试列表)。"""
    pf = probe_fn or probe
    tried: list[str] = []
    for u in candidates(base, port):
        tried.append(u)
        if pf(u):
            return u, tried
    return None, tried
