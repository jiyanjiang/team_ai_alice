"""纯文本判断类 LLM 调用（HTTP 直连，不走 coding agent）。

为什么单列一个模块（docs/529 §1.2）：
  · coding agent（opencode 等）是**执行器**，会被提示词里的文件名/目录触发 Glob，
    工具日志混进输出、结构化内容被截断——实测 4 次调用失败 2 次；
  · 题材判定、风格提取、审稿这类**纯文本判断**不需要工具能力，走 HTTP 直连
    5 秒稳定返回，且 `temperature=0` 可复现。

凡"要一句判断/一份摘要"的地方都用这里；凡"要动手改文件"的地方才用执行器。
取不到 key 返回空串，由调用方决定是否回落 CLI。

**可插拔（2026-11-03）**：本模块按 OpenAI 兼容协议说话，端点/模型/密钥全部来自配置，
不判断模型名。用户换模型只改环境变量或配置，不改代码：

    TEAMAI_HTTP_URL    完整 chat/completions 地址（默认 DeepSeek 官方）
    TEAMAI_HTTP_MODEL  模型名（默认 deepseek-chat）
    TEAMAI_HTTP_KEY    密钥（优先；缺省时回落 config.deepseek_key()）
    TEAMAI_MODEL_PROFILE  能力档 small | standard | strong（默认 standard）

能力档只控制**兜底强度**（默认 max_tokens / 超时 / 重试次数），不是模型白名单：
弱模型多重试、强模型少兜底，避免"给强模型套小模型补丁"反而降质。
"""
from __future__ import annotations

import json
import os

#: 仅作兜底默认值；真正取值在 model_name()，调用时才读环境（便于运行期切换/自检）
DEFAULT_MODEL = "deepseek-chat"
DEFAULT_URL = "https://api.deepseek.com/v1/chat/completions"

#: 能力档 → 兜底强度。强模型不重试（失败就报，别偷偷重放掩盖问题）
PROFILES: dict[str, dict[str, int]] = {
    "small":    {"max_tokens": 1600, "timeout": 60,  "attempts": 3},
    "standard": {"max_tokens": 2400, "timeout": 120, "attempts": 2},
    "strong":   {"max_tokens": 4000, "timeout": 180, "attempts": 1},
}


def current_profile() -> str:
    p = (os.environ.get("TEAMAI_MODEL_PROFILE") or "").strip().lower()
    return p if p in PROFILES else "standard"


def endpoint() -> str:
    return (os.environ.get("TEAMAI_HTTP_URL") or "").strip() or DEFAULT_URL


def model_name(model: str | None = None) -> str:
    return model or (os.environ.get("TEAMAI_HTTP_MODEL") or "").strip() or DEFAULT_MODEL


def api_key() -> str:
    """密钥优先级：TEAMAI_HTTP_KEY > config.deepseek_key()（旧路径，向后兼容）。"""
    k = (os.environ.get("TEAMAI_HTTP_KEY") or "").strip()
    if k:
        return k
    try:
        from . import config as _cfg
        return str(_cfg.deepseek_key() or "")
    except Exception:  # noqa: BLE001
        return ""


def available() -> bool:
    return bool(api_key())


def ask(prompt: str, *, model: str | None = None, temperature: float = 0.0,
        max_tokens: int | None = None, timeout: int | None = None,
        url: str | None = None, profile: str | None = None) -> str:
    """一次问答，返回纯文本；任何失败返回空串（不抛）。"""
    prof = PROFILES.get((profile or current_profile()).lower(), PROFILES["standard"])
    key = api_key()
    if not key:
        return ""
    body = json.dumps({
        "model": model_name(model),
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": int(max_tokens if max_tokens is not None else prof["max_tokens"]),
        "stream": False,
    }).encode()
    tmo = max(5, min(int(timeout if timeout is not None else prof["timeout"]), 300))
    try:
        import urllib.request
        req = urllib.request.Request(url or endpoint(), data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {key}")
        try:
            from .net_retry import urlopen_retry
            ctx = urlopen_retry(req, timeout=tmo,
                                attempts=prof["attempts"], backoff=(1,))
        except ImportError:
            ctx = urllib.request.urlopen(req, timeout=tmo)
        with ctx as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        return str((d.get("choices") or [{}])[0].get("message", {}).get("content") or "")
    except Exception as e:  # noqa: BLE001
        print(f"[llm_http] 调用失败：{type(e).__name__}: {e}")
        return ""
