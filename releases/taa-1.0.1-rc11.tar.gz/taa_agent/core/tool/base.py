"""工具接口：内核只定「插槽」，具体工具可插拔。

- 工具 = agent **主动调用**的、无状态、可替换的能力。
- 内核不实现具体工具；只提供 `Tool` 协议 + 注册表（见 registry.py）。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Tool:
    name: str
    description: str
    schema: dict = field(default_factory=dict)      # 入参说明（供 LLM function-calling）
    fn: Callable[[str, dict], dict] | None = None   # (agent_id, args) -> result
    # ★ 2026-10-08（档 B「服务型工具」）：`kind="local"` = 本机代码工具（默认，行为不变）；
    #   `kind="service"` = **远程服务**（只通信如何使用，不交换代码，见 service_tool.py）。
    #   `service` 里放服务卡的摘要（provider_node / url / ops / billing），仅供 catalog 展示。
    kind: str = "local"
    service: dict | None = None

    def call(self, agent: str, args: dict | None = None) -> dict:
        if not self.fn:
            raise RuntimeError(f"tool {self.name} 未实现")
        return self.fn(agent, args or {})
