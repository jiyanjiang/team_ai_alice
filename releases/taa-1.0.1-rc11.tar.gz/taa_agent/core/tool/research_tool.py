"""research.ask 薄工具适配。

把 `core.research` 的 prompt → code/v1|v2 工作流暴露给工具注册表。
实现仍归 `core.research`；本文件只做参数映射，不另建存储或调用链。
"""
from __future__ import annotations

from .base import Tool
from .registry import register

SOURCE_SYSTEM = (
    "你是严谨的调研助手。你只能依据下方【检索来源】回答，不得凭记忆补事实。\n"
    "规则：\n"
    "1) 每个事实性结论后必须标来源编号，如 [S1]；一个结论至少一个来源。\n"
    "2) 至少引用两个独立域名；优先官方/一手/学术来源。\n"
    "3) 来源之间冲突要并列写冲突，不要擅自选一个。\n"
    "4) 来源不足、无法核验或只有弱二手来源时，明确写「来源不足，未核验」，不要给确定结论。\n"
    "5) 严格区分事实与判断；判断标明「判断」。\n"
    "6) 不要编造 URL、标题、数字或引文。\n"
)


def _source_block(sources: list[dict]) -> str:
    if not sources:
        return "【检索来源】无（未检索到可用来源）"
    lines = ["【检索来源】"]
    for s in sources[:8]:
        # 题录类来源（万方/知网）正文在付费墙后：必须显式标注，避免当成读过全文来引用
        tag = "（题录：正文付费墙后，只有题录与摘要，只能作线索）" if s.get("paywalled") else ""
        lines.append(f"[{s.get('id') or '?'}] {s.get('title') or ''}{tag}\n"
                     f"URL: {s.get('url') or ''}\n"
                     f"分级: {s.get('grade') or 'unknown'}\n"
                     f"摘录: {str(s.get('text') or s.get('snippet') or '')[:900]}")
    return "\n\n".join(lines)


def _research_ask(agent: str, a: dict, on_stage=None) -> dict:
    """Thin adapter: prompt → retrieval → source-gated ask.

    on_stage(name)：进度回调（后台作业用），在 retrieve/compose/gate 三个阶段各调一次。
    background=True：**不在这里跑**，只提交后台作业并立刻返回 job_id（见 core/research_jobs）。
    """
    from .. import fact_gate, research, retrieval

    def _stage(name: str) -> None:
        if on_stage:
            try:
                on_stage(name)
            except Exception:  # noqa: BLE001
                pass

    prompt = str(a.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("research.ask 需要 prompt")
    if a.get("background") and not a.get("job_id"):
        from .. import db, research_jobs
        sub = {k: v for k, v in a.items() if k not in ("background", "job_id")}
        conn = db.connect()
        try:
            job = research_jobs.submit(conn, agent_id=agent, prompt=prompt, args=sub,
                                       room_id=str(a.get("room_id") or ""))
        finally:
            conn.close()
        return {"ok": True, "background": True, "job_id": job.get("id"),
                "status": job.get("status"), "stage": job.get("stage"), "eta_s": 1800,
                "text": (f"已提交后台调研 {job.get('id')}（预计 30 分钟内，硬上限 4 小时）。"
                         f"完成后会自动回帖；也可用 research.job 查询进度。")}
    use_sources = a.get("sources", True) is not False
    sources: list[dict] = []
    meta: dict = {}
    src_errs: dict = {}
    _stage("retrieve")
    if use_sources:
        try:
            sources = retrieval.gather(prompt, limit=int(a.get("source_limit") or 8),
                                       fetch_n=int(a.get("fetch_n") or 4),
                                       budget=float(a.get("source_budget") or 60),
                                       out_meta=meta, out_errs=src_errs) or []
        except Exception as exc:  # noqa: BLE001
            sources = []
            src_errs.setdefault("gather", []).append(f"抛错：{type(exc).__name__}")
    system = SOURCE_SYSTEM + "\n" + _source_block(sources)
    slug = str(a.get("slug") or a.get("code") or "").strip()
    rounds = int(a.get("rounds") or 1)
    _stage("compose")
    kwargs = {
        "model": str(a.get("model") or "deepseek-v4-pro"),
        "ali_model": a.get("ali_model"),
        "tag": str(a.get("tag") or ""),
        "system": system,
    }
    try:
        if slug:
            if rounds > 1:
                result = research.ask_deep(slug, prompt, rounds=rounds,
                                           version=a.get("version"), **kwargs)
            else:
                result = research.ask(slug, prompt, version=a.get("version"), **kwargs)
        else:
            result = research.ask_prompt(prompt, title=a.get("title"), reuse=bool(a.get("reuse")),
                                         rounds=rounds, **kwargs)
    except Exception as exc:
        # Keep the source contract visible even when the provider fails.
        errs = src_errs
        reasons = ["模型调用失败"] + ([f"检索通道异常（{errs}）"[:200]] if errs else [])
        return {"ok": False, "error": str(exc)[:300], "sources": sources,
                "verified": False, "source_errors": errs,
                "gate": {"ok": False, "status": "unverified", "reasons": reasons}}
    _stage("gate")
    # 切题性判定用「本轮真正用过的检索式」（含英文译式）算，且走 gather 回填的 meta，
    # 不读模块级 last_meta()——后台多作业并发时才不会串台。
    used_q = list(meta.get("web_queries") or []) + list(meta.get("sci_queries") or [])
    gate = fact_gate.evaluate(str(result.get("text") or ""), sources,
                              query_terms=retrieval.terms_of(" ".join(used_q) or prompt)
                              if sources else None)
    # 检索通道的失败必须可见：否则只看到「来源不足」，分不清是 429、超时还是 key 缺失
    # 只认本轮 gather 回填的 src_errs——last_errors() 是进程共享的，并发作业会串台。
    if src_errs and not gate.get("ok"):
        brief = "；".join(f"{k}: {v[-1]}" for k, v in src_errs.items())[:200]
        reasons = list(gate.get("reasons") or [])
        reasons.append(f"检索通道异常（{brief}）")
        gate["reasons"] = reasons
    result.update({"sources": sources, "gate": gate,
                   "verified": bool(gate.get("ok")), "source_mode": use_sources,
                   "source_errors": src_errs})
    return result


def _research_job(agent: str, a: dict) -> dict:
    """查后台调研作业：给 job_id 看单个，不给就列自己的最近作业。"""
    from .. import db, research_jobs
    jid = str(a.get("job_id") or "").strip()
    conn = db.connect()
    try:
        if not jid:
            jobs = research_jobs.list_jobs(conn, agent_id=agent,
                                           status=(str(a.get("status") or "").strip() or None),
                                           limit=int(a.get("limit") or 10))
            return {"ok": True, "jobs": [
                {k: j.get(k) for k in ("id", "status", "stage", "created_at",
                                       "finished_at", "prompt", "last_error")}
                for j in jobs]}
        research_jobs.reap(conn)
        job = research_jobs.get(conn, jid)
    finally:
        conn.close()
    if not job:
        return {"ok": False, "error": f"job 不存在：{jid}"}
    if job.get("agent_id") != agent:
        return {"ok": False, "error": "无权查看该 job"}
    out = {k: job.get(k) for k in ("id", "status", "stage", "created_at",
                                   "started_at", "finished_at", "last_error")}
    res = job.get("result") or {}
    if res:
        out.update({k: res.get(k) for k in ("text", "gate", "sources", "verified")})
    return {"ok": True, **out}


register(Tool("research.ask", "主题调研：prompt → code/v1|v2，DeepSeek 优先、Ali 兜底；返回 provider/code/version",
              {"prompt": "str；研究问题/调研提示",
               "sources": "bool?；默认 true；先检索来源再回答",
               "source_limit": "int?；最多来源数（默认 8）",
               "fetch_n": "int?；抓原页数（默认 4）",
               "source_budget": "float?；整轮检索预算秒数（默认 60，到点用手上结果）",
               "background": "bool?；true=提交后台作业立刻返回 job_id（慢调研用这个）",
               "room_id": "str?；后台作业跑完后回帖的房间",
               "slug": "str?；legacy slug 或 r-<code>（可选）",
               "version": "str?；现代版本 v1/v2（可选）",
               "rounds": "int?；1=单轮，2-3=深挖（可选）",
               "reuse": "bool?；复用最新版本（重试时用）",
               "title": "str?；新版本标题",
               "model": "str?；默认 deepseek-v4-pro",
               "ali_model": "str?；默认 qwen-plus",
               "tag": "str?；输出文件标签"},
              _research_ask))

register(Tool("research.job", "查后台调研作业：给 job_id 看单个，不给就列自己的最近作业",
              {"job_id": "str?；作业 id（rj-xxxx）",
               "status": "str?；列作业时按状态筛（queued/running/done/failed/timeout）",
               "limit": "int?；列作业条数（默认 10）"},
              _research_job))
