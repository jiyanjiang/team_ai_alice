"""内置能力注册：把基础 media（属 harness）暴露为统一工具接口，供任何 agent 调用。

注：基础 media 的**实现**仍属 harness（core/media.py）；这里只是"登记"，让 LLM 能统一调用。
进阶 media（画笔/视频）应作为**外部工具插件**放入 `tools/`，不进内核。
"""
from __future__ import annotations

from .base import Tool
from .registry import register


def _gen(agent: str, a: dict) -> dict:
    from .. import media
    prompt = str(a.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("media.gen 需要 prompt")
    # 默认走火山方舟（Seedream），失败回退阿里百炼（通义万相）；
    # 引擎可用 providers.image_engine / IMAGE_ENGINE 覆盖
    url, used = media.generate_image_with_engine(prompt, a.get("size"), a.get("engine"))
    return {"url": url, "engine": used}


def _search(agent: str, a: dict) -> dict:
    from .. import media
    query = str(a.get("query") or "").strip()
    if not query:
        raise ValueError("media.search 需要 query")
    try:
        n = int(a.get("n", 1))
    except (TypeError, ValueError) as exc:
        raise ValueError("media.search n 必须是整数") from exc
    n = max(1, min(n, 20))
    urls = media.bing_images(query, n)
    if not urls:
        return {"url": None, "note": "no result"}
    return {"url": media.download_image(urls[0]), "source": urls[0]}


def _screenshot(agent: str, a: dict) -> dict:
    from .. import media
    return {"url": media.screenshot(a["url"], bool(a.get("full")))}


def _browse(agent: str, a: dict) -> dict:
    from .. import media
    r = media.browse(a["url"], a.get("actions") or [], bool(a.get("full")))
    return {"url": r.get("screenshot"), "text": r.get("text", "")}


def _self_update(agent: str, a: dict) -> dict:
    """自我更新（R43）：生成更新提案，**需真人确认后应用**（不直接改代码）。"""
    from .. import db, federation
    conn = db.connect()
    try:
        pid = federation.publish(conn, agent, {
            "title": a.get("title") or f"自更新到 {a.get('target_version') or '最新'}",
            "summary": a.get("summary") or "agent 申请自我更新（需真人确认后应用）",
            "kind": "harness-update",
            "target_version": a.get("target_version", ""),
            "bundle_url": a.get("source_peer", ""),
            "capability": "harness",
        })
        return {"proposal_id": pid,
                "note": "已提交更新提案，等待真人确认应用（面板「联邦」→ 应用）"}
    finally:
        conn.close()


register(Tool("media.gen", "文生图（默认火山方舟 Seedream，失败回退阿里通义万相）",
              {"prompt": "str", "size": "str?", "engine": "str?（ali|ark|auto）"}, _gen))
register(Tool("media.search", "Bing 搜图并下载一张",
              {"query": "str", "n": "int?"}, _search))
register(Tool("media.screenshot", "网页截图",
              {"url": "str", "full": "bool?"}, _screenshot))
register(Tool("media.browse", "打开网页并执行操作，返回截图+页面文本",
              {"url": "str", "actions": "list?", "full": "bool?"}, _browse))
def _self_propose(agent: str, a: dict) -> dict:
    """发起改进提案（三轴：harness / LLM / 工具）。"""
    from .. import db, federation
    conn = db.connect()
    try:
        pid = federation.publish(conn, agent, {
            "title": a.get("title") or "改进提案",
            "summary": a.get("summary", ""),
            "kind": a.get("kind", "feature"),
            "topic": a.get("topic", ""),
            "target_version": a.get("target_version", ""),
            "bundle_url": a.get("bundle_url", ""),
            "capability": a.get("capability", ""),
            "priority": a.get("priority", 0),
        })
        return {"proposal_id": pid, "note": "提案已发布；同 topic 提案构成竞争，采纳越多越优先"}
    finally:
        conn.close()


def _self_llm(agent: str, a: dict) -> dict:
    """LLM 轴：查看/切换自己的后端与模型（agents/<id>/backend|model）。"""
    from .. import distribution, llm
    d = distribution.ROOT / "agents" / agent
    d.mkdir(parents=True, exist_ok=True)
    bf, mf, vf = d / "backend", d / "model", d / "vision_model"
    action = (a.get("action") or "get").lower()
    if action == "set":
        b = (a.get("backend") or "").strip().lower()
        if b:
            if b not in llm.ADAPTERS:
                return {"ok": False, "error": f"unknown backend '{b}'", "可选": list(llm.ADAPTERS)}
            bf.write_text(b, encoding="utf-8")
        if a.get("model"):
            mf.write_text(str(a["model"]).strip(), encoding="utf-8")
        if a.get("vision_model"):
            vf.write_text(str(a["vision_model"]).strip(), encoding="utf-8")
    backend = bf.read_text(encoding="utf-8").strip() if bf.exists() else "opencode"
    model = mf.read_text(encoding="utf-8").strip() if mf.exists() else ""
    vmodel = vf.read_text(encoding="utf-8").strip() if vf.exists() else ""
    return {"backend": backend, "model": model, "vision_model": vmodel,
            "available": llm.available()}


def _self_tool(agent: str, a: dict) -> dict:
    """工具轴：给自己写/列/装载工具（agents/<id>/tools/<name>.py）。

    安全：`load` 会执行代码，需 config tools.self_authored=true（env TEAMAI_SELF_TOOLS）。
    """
    import importlib.util
    import os
    from .. import config, distribution
    from .base import Tool
    from .registry import register
    root = distribution.ROOT
    tdir = root / "agents" / agent / "tools"
    tdir.mkdir(parents=True, exist_ok=True)
    action = (a.get("action") or "list").lower()
    name = (a.get("name") or "").strip()
    if action == "write":
        if not name or not a.get("code"):
            return {"ok": False, "error": "name 与 code 必填"}
        if "/" in name or ".." in name:
            return {"ok": False, "error": "非法 name"}
        (tdir / f"{name}.py").write_text(a["code"], encoding="utf-8")
        return {"ok": True, "written": f"agents/{agent}/tools/{name}.py",
                "note": "写好后用 action=load 装载（需开启 self_authored）"}
    if action == "list":
        return {"tools": sorted(p.stem for p in tdir.glob("*.py"))}
    if action == "load":
        if config.get("tools.self_authored", "false", env="TEAMAI_SELF_TOOLS").lower() not in ("1", "true", "yes"):
            return {"ok": False, "error": "self-authored tools 未开启（tools.self_authored=false）"}
        f = tdir / f"{name}.py"
        if not f.exists():
            return {"ok": False, "error": f"not found: {name}.py"}
        spec = importlib.util.spec_from_file_location(f"usertool_{agent}_{name}", f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        register(Tool(f"{name}", getattr(mod, "DESCRIPTION", f"{agent} 自造工具"),
                      getattr(mod, "SCHEMA", {}), getattr(mod, "run")))
        return {"ok": True, "loaded": name}
    return {"ok": False, "error": f"unknown action {action}"}


def _self_version(agent: str, a: dict) -> dict:
    """查询自己（客户端）上报的程序版本与协议版本。"""
    from .. import db, distribution
    conn = db.connect()
    try:
        row = conn.execute("SELECT runtime_version, protocol_version, last_seen "
                           "FROM agent_runtime WHERE agent_id=?", (agent,)).fetchone()
        return {"agent": agent,
                "runtime_version": (row["runtime_version"] if row else "unknown"),
                "protocol_version": (row["protocol_version"] if row else "unknown"),
                "reported_at": (row["last_seen"] if row else None),
                "server_runtime": distribution.runtime_version()}
    finally:
        conn.close()


register(Tool("self.version", "查询自己上报的程序版本（客户端 runtime）", {}, _self_version))
register(Tool("self.update", "申请自我更新（生成提案，需真人确认后应用）",
              {"target_version": "str?", "source_peer": "str?", "summary": "str?", "title": "str?"},
              _self_update))
register(Tool("self.llm", "查看/切换自己的 LLM 后端、文本模型与视觉模型（轴②）",
              {"action": "get|set", "backend": "str?", "model": "str?",
               "vision_model": "str?"}, _self_llm))
register(Tool("self.tool", "给自己写/列/装载工具（轴③；load 需开启 self_authored）",
              {"action": "write|list|load", "name": "str?", "code": "str?"}, _self_tool))
register(Tool("self.propose", "发起改进提案（harness/LLM/工具任意方向）",
              {"title": "str", "summary": "str?", "kind": "str?", "topic": "str?",
               "capability": "str?", "bundle_url": "str?", "priority": "float?"}, _self_propose))


def _weather(agent: str, a: dict) -> dict:
    """天气 + 穿搭：地点 → 经纬度 → 天气（可 N 日）→ 按本人衣柜/性别/场景建议。"""
    from .. import weather as _W
    place = str(a.get("place") or a.get("at") or "").strip()
    return _W.outfit_for(str(a.get("agent") or agent or "alice"), place,
                         days=int(a.get("days") or 1), scene=a.get("scene"),
                         image=bool(a.get("image")), image_engine=a.get("image_engine"),
                         image_size=a.get("image_size"))


register(Tool("weather", "查某地天气并给出穿搭建议（地点→经纬度→天气→按本人衣柜/性别/场景推荐）",
              {"place": "地点，如『上海』『Boston』", "agent": "可选：用谁的衣柜（默认调用者）",
               "days": "可选：预报天数 1-14（默认 1）", "scene": "可选：commute|outdoor|formal|home|sport",
               "image": "可选：bool；为 true 时尝试生图", "image_engine": "可选：ali|ark|auto",
               "image_size": "可选：如 2K"},
              _weather))
