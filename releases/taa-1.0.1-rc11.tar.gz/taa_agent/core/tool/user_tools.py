"""工具包加载器：扫描 `tools/<name>/tool.py` 并注册为可调用工具。

工具包规范（详见 docs/22）：
  tools/<name>/
    TOOL.md          # 说明 / 用法 / 依赖 / 是否需要 key 或登录 / 隐私声明
    tool.py          # DESCRIPTION, SCHEMA, run(agent, args)->dict  （可选 NAME）
    requirements.txt # 可选
隐私红线：不含个人 key / 用户名密码 / 绝对路径；需要 key 的工具由使用者自填。
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

from .base import Tool
from .registry import register


def _tools_root() -> Path:
    from .. import distribution
    return distribution.ROOT / "tools"


def load_all() -> list[str]:
    root = _tools_root()
    if not root.exists():
        return []
    loaded: list[str] = []
    for d in sorted(root.iterdir()):
        if not d.is_dir():
            continue
        # ★ 2026-10-08（档 B）：**服务卡**优先 —— 只有 `service.json`（无 tool.py）的目录
        #   注册为 `kind="service"` 的远程服务工具：调用方只发请求，不装代码。
        if (d / "service.json").exists() and not (d / "tool.py").exists():
            try:
                from .service_tool import load_service_card
                t = load_service_card(d, d.name)
                if t:
                    register(t)
                    loaded.append(t.name)
            except Exception as e:                             # noqa: BLE001
                print(f"[tools] 加载服务卡 {d.name} 失败：{e}")
            continue
        f = d / "tool.py"
        if not f.exists():
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"usertool_{d.name}", f)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            name = getattr(mod, "NAME", d.name)
            register(Tool(name, getattr(mod, "DESCRIPTION", d.name),
                          getattr(mod, "SCHEMA", {}), getattr(mod, "run", None)))
            loaded.append(name)
        except Exception as e:  # noqa: BLE001
            print(f"[tools] 加载 {d.name} 失败：{e}")
    return loaded


def installed() -> list[dict]:
    root = _tools_root()
    out = []
    if root.exists():
        for d in sorted(root.iterdir()):
            if not d.is_dir():
                continue
            if (d / "tool.py").exists():
                out.append({"name": d.name, "kind": "local",
                            "has_doc": (d / "TOOL.md").exists(),
                            "has_req": (d / "requirements.txt").exists()})
            elif (d / "service.json").exists():                 # 服务型：只登记，不安装
                out.append({"name": d.name, "kind": "service", "has_doc": (d / "TOOL.md").exists(),
                            "has_req": False, "installable": False})
    return out
