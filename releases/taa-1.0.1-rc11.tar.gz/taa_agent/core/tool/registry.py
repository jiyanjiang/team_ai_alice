"""工具注册表：注册 / 发现 / 目录。内核只依赖此接口。"""
from __future__ import annotations

from .base import Tool

_TOOLS: dict[str, Tool] = {}


def register(tool: Tool) -> None:
    _TOOLS[tool.name] = tool


def get(name: str) -> Tool | None:
    return _TOOLS.get(name)


def names() -> list[str]:
    return sorted(_TOOLS)


def catalog() -> list[dict]:
    """工具目录（供 `/v1/tools` 与 agent 发现）。

    ★ 2026-10-08：每个条目多带 `kind`（`local` / `service`）；服务型工具另带
    `service`（provider_node / url / ops / call_only）—— 调用方据此知道"这是**别人机器上的服务**，
    只发请求、不装代码"。
    """
    out = []
    for t in _TOOLS.values():
        item = {"name": t.name, "description": t.description, "schema": t.schema,
                "kind": getattr(t, "kind", "local")}
        if getattr(t, "service", None):
            # ★ CR-2026-10-09-01 · 返工 G1：**不输出 public_url**。
            #   理由（CodeBuddy 实测）：GET /v1/tools **匿名可读** ⇒ 输出 public_url 会把
            #   提供者内网地址公开。调用方真正需要的是 call 结果里的 urls/link_paths，
            #   而那两者只对**已签名调用者**可见（call 有签名门）⇒ 撤掉本字段功能零损失。
            item["service"] = dict(t.service)
            # ★ 2026-10-08：明确告诉调用方"这是**服务**，不可安装"（实测 Carol 去翻了
            #   `/v1/tools/packages` 市场 —— 服务型工具本来就不在市场里，别让她白找）。
            item["installable"] = False
            item["reason"] = "service (call-only)：只发请求、不下发代码，市场里不存在它的包"
        else:
            item["installable"] = True
        out.append(item)
    return out
