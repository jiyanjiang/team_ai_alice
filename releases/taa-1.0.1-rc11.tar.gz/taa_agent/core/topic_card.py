"""第 0 工位：题材判定卡（docs/529）。

一次补齐四件事：**数据源 / 一手来源定义 / 事实标准档位 / 写作风格样本**。

分工（关键，别弄反）：
  · **题材由 LLM 判**（判断权归 LLM，规则不做"这是什么题"的判定）；
  · **路由查表**（题材 → 数据源）由本模块的常量给出，不让 LLM 自由编源；
  · 规则只做枚举校验与兜底，缺字段绝不崩、也不编造。

收敛：信息不足时 LLM 自问自答 **3–5 问**（上限 5，太多无意义），答完即判，
不留"字段没填满就继续问"的循环。问答对落盘，它同时是问题树的第 0 层与事实
标准档位的审计依据。

本模块**不碰检索、不碰写作、不碰审稿**，只产出一张卡并写入
`research/<slug>/TOPIC.json` 的 `topic_card` 字段。
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path

from .harvest import extract_json

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "research"
STYLE_DIR = WORK / "style"

DEFAULT_MODEL = os.environ.get("TEAMAI_TOPIC_MODEL", "deepseek/deepseek-flash")

# 收敛口径：固定 3–5 问（Owner 2026-11-01：太多没有意义）
QA_MIN, QA_MAX = 3, 5
CONFIDENCE_FLOOR = 0.6

TOPIC_TYPES = ("science", "academic", "humanity", "current", "fiction", "mixed")

# 题材 → 数据源路由（规则查表；LLM 只判题材，不判源）
SOURCE_ROUTES: dict[str, dict] = {
    "science": {
        "primary": ["PubMed", "PMC", "OpenAlex"],
        "first_hand": "全文原文（PMC 免费全文或 OA 副本）；摘要不算事实",
    },
    "academic": {
        "primary": ["OpenAlex", "arXiv"],
        "first_hand": "预印本或正式发表全文；摘要不算事实",
    },
    "humanity": {
        "primary": ["百科", "档案", "一手文献"],
        "first_hand": "原始文献/档案原件；转引不算一手",
    },
    "current": {
        "primary": ["DeepSeek search API"],
        "first_hand": "官方一手公告/原始数据；二手报道需回指一手",
    },
    "fiction": {
        "primary": ["素材检索"],
        "first_hand": "设定与史料；虚构内容不适用事实核查口径",
    },
    "mixed": {
        "primary": ["OpenAlex", "DeepSeek search API"],
        "first_hand": "以题材占比最高的那一类为准，逐节标注",
    },
}
SECONDARY_SOURCES = ["DeepSeek search API"]

# 题材 → 风格样本 front matter 里可接受的 category
TYPE_CATEGORY = {
    "science": ("science-report", "science", "popular-science"),
    "academic": ("science-report", "academic"),
    "humanity": ("history", "humanities"),
    "current": ("journalism", "news"),
    "fiction": ("fiction", "novel"),
    "mixed": (),
}

# 事实标准档位（条数是派生量；真正的判据是 p 值 + 回指覆盖率）
FACT_STANDARDS: dict[str, dict] = {
    "strict": {"min_facts_per_claim": 3, "min_independent_sources": 2,
               "min_counter_facts": 1, "facts_per_1000_chars": 12,
               "coverage_min": 0.95, "primary_ratio_min": 0.50,
               "weak_secondary_max": 0.20},
    "standard": {"min_facts_per_claim": 3, "min_independent_sources": 2,
                 "min_counter_facts": 1, "facts_per_1000_chars": 8,
                 "coverage_min": 0.95, "primary_ratio_min": 0.40,
                 "weak_secondary_max": 0.25},
    "light": {"min_facts_per_claim": 2, "min_independent_sources": 2,
              "min_counter_facts": 0, "facts_per_1000_chars": 5,
              "coverage_min": 0.90, "primary_ratio_min": None,
              "weak_secondary_max": None},
}
DEFAULT_STANDARD = {"science": "strict", "academic": "strict", "humanity": "strict",
                    "current": "standard", "fiction": "light", "mixed": "standard"}

# 缺省风格样本：QJ_5 公开版（科学报道类，绕开未授权语料的合规问题）
DEFAULT_STYLE = "QJ_5.public"


# ------------------------------------------------------------------ 风格样本
def _front_matter(path: Path) -> dict:
    """读 `---` 包裹的 front matter（只取扁平的 key: value）。"""
    try:
        text = path.read_text(encoding="utf-8")[:2000]
    except Exception:
        return {}
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.S)
    if not m:
        return {}
    out = {}
    for ln in m.group(1).splitlines():
        if ":" in ln and not ln.lstrip().startswith("#"):
            k, v = ln.split(":", 1)
            out[k.strip()] = v.split("#")[0].strip()
    return out


def style_index() -> dict[str, dict]:
    """风格样本库索引：name → {path, category, priority}。"""
    out: dict[str, dict] = {}
    if not STYLE_DIR.exists():
        return out
    for f in sorted(STYLE_DIR.glob("*.md")):
        fm = _front_matter(f)
        try:
            pri = int(str(fm.get("priority") or "99").strip())
        except ValueError:
            pri = 99
        out[f.stem] = {"path": f, "category": fm.get("category") or "", "priority": pri}
    return out


def resolve_style(name: str | None = None, topic_type: str = "mixed") -> dict:
    """解析风格样本，返回 {name, path, source, note}。

    优先级：指定已有样本 > 按题材 category 匹配 > 缺省 QJ_5.public。
    category 命中多个时按 front matter 的 `priority`（小者先）再按名字定序——
    **不允许靠文件名字典序碰运气**（同题材两份样本时命中会变得不可复现）。

    **只解析，不生成**——"通读后生成"是另一件事（`scripts/extract_style.py`），
    因为生成需要公开/授权语料，不能由本函数凭空造。
    """
    idx = style_index()
    if name:
        n = str(name).strip()
        if n.endswith(".md"):
            n = n[:-3]
        if n in idx:
            return {"name": n, "path": f"research/style/{n}.md", "source": "existing",
                    "note": ""}
        # 指定了但库里没有（如某个作家名）：不擅自编造，退回缺省并标注
        return {"name": DEFAULT_STYLE, "path": f"research/style/{DEFAULT_STYLE}.md",
                "source": "default",
                "note": f"未找到风格样本「{name}」；可用 scripts/extract_style.py "
                        f"从公开/授权文本生成，当前暂用缺省"}
    wants = TYPE_CATEGORY.get(topic_type) or ()
    cands = [(m["priority"], n, m) for n, m in idx.items()
             if m.get("category") and m["category"] in wants]
    if cands:
        cands.sort(key=lambda x: (x[0], x[1]))
        _, n, meta = cands[0]
        note = f"按题材 {topic_type} 匹配 category={meta['category']}"
        if len(cands) > 1:
            note += f"（同题材 {len(cands)} 份，取 priority={meta['priority']} 的 {n}）"
        return {"name": n, "path": f"research/style/{n}.md", "source": "existing",
                "note": note}
    return {"name": DEFAULT_STYLE, "path": f"research/style/{DEFAULT_STYLE}.md",
            "source": "default", "note": "题材未匹配到风格样本，用缺省公开版"}


def save_generated_style(name: str, text: str, *, evidence: str,
                         category: str = "") -> Path:
    """落盘一份生成出来的风格样本，带出处留档（否则不可复现）。

    evidence：依据什么材料生成（书名/篇目/授权说明）。**禁止**拿未授权全文当语料。
    """
    name = re.sub(r"[^\w\-.]", "_", str(name).strip()) or "generated"
    STYLE_DIR.mkdir(parents=True, exist_ok=True)
    p = STYLE_DIR / f"{name}.md"
    fm = ["---", f"generated: {_today()}", f"evidence: {evidence.strip()}"]
    if category:
        fm.append(f"category: {category}")
    fm.append("---")
    p.write_text("\n".join(fm) + "\n\n" + text.strip() + "\n", encoding="utf-8")
    return p


def _today() -> str:
    import datetime
    return datetime.date.today().isoformat()


# ------------------------------------------------------------------ 提示词
def build_prompt(need: str) -> str:
    types = " / ".join(TOPIC_TYPES)
    routes = "\n".join(f"  - {k}: 主源 {'+'.join(v['primary'])}；一手＝{v['first_hand']}"
                       for k, v in SOURCE_ROUTES.items())
    return (
        "你是调研/写作流水线的『第 0 工位』。任务：读用户需求，判定**题材**，"
        "并产出一张执行卡。\n\n"
        f"题材枚举（必须选一个）：{types}\n"
        "数据源已按题材固定，你**不需要也不允许**另编数据源：\n" + routes + "\n\n"
        "步骤：\n"
        f"1) 信息不足就自问自答 {QA_MIN}–{QA_MAX} 个**能区分题材**的问题"
        "（读者是谁 / 结论强度要临床级还是科普级 / 时间窗与地域 / 是否接受非英文源与预印本 / "
        f"有无必须回应的反方立场）。上限 {QA_MAX} 个，不要没完没了。\n"
        "2) 答完即判，输出执行卡。\n\n"
        "纪律：\n"
        "· 不确定的写进 open_questions，不要瞎编；\n"
        "· 判定权在你，但只判题材与档位，**不编造来源、不编造事实**；\n"
        "· 只输出一个 JSON，不要多余文字。\n\n"
        "JSON 结构：\n"
        '{"topic_type":"science|academic|humanity|current|fiction|mixed",'
        '"confidence":0.0~1.0,'
        '"qa":[{"q":"...","a":"..."}],'
        '"first_hand_definition":"什么算一手来源（可按题材细化）",'
        '"fact_standard":"strict|standard|light",'
        '"style":{"name":"风格样本名（如 QJ_5.public）或作家名","reason":"为什么"},'
        '"expert_domain":"需要专家审稿的领域；不需要则 null",'
        '"open_questions":["..."],"rationale":"一句话判断依据"}\n\n'
        "用户需求：\n" + need.strip()
    )


# ------------------------------------------------------------------ 判定
def _num(v, default=0.0) -> float:
    try:
        return max(0.0, min(1.0, float(v)))
    except Exception:
        return default


def _qa_list(v) -> list[dict]:
    out = []
    for item in (v or []):
        if isinstance(item, dict):
            q, a = str(item.get("q") or "").strip(), str(item.get("a") or "").strip()
            if q:
                out.append({"q": q, "a": a})
        elif isinstance(item, str) and item.strip():
            out.append({"q": item.strip(), "a": ""})
    return out[:QA_MAX]


def _normalize(d: dict, need: str, style_override: str | None = None,
               standard_override: str | None = None) -> dict:
    """枚举校验 + 兜底。缺字段不崩、不编造，只标注。"""
    d = d if isinstance(d, dict) else {}
    open_q = [str(x).strip() for x in (d.get("open_questions") or []) if str(x).strip()]

    t = str(d.get("topic_type") or "").strip().lower()
    if t not in TOPIC_TYPES:
        if t:
            open_q.append(f"LLM 给出的题材「{t}」不在枚举内，已按 mixed 处理")
        t = "mixed"

    # ★ 档位由**题材**定，不由 LLM 定：同需求两次跑，LLM 会在 strict/standard 间漂移
    #   （2026-11-01 实测）。判断权归 LLM（题材），规则权归规则（档位映射）。
    std = DEFAULT_STANDARD[t]
    std_llm = str(d.get("fact_standard") or "").strip().lower()
    if standard_override and standard_override in FACT_STANDARDS:
        std = standard_override
    elif std_llm in FACT_STANDARDS and std_llm != std:
        open_q.append(f"档位按题材定为 {std}（LLM 建议 {std_llm}，未采纳：档位属规则不属判断）")
    elif std_llm and std_llm not in FACT_STANDARDS:
        open_q.append(f"LLM 给出的档位「{std_llm}」不合法，按题材定为 {std}")

    qa = _qa_list(d.get("qa"))
    if len(qa) < QA_MIN:
        open_q.append(f"自问自答只有 {len(qa)} 问（下限 {QA_MIN}），"
                      "题材判断依据偏薄，建议真人补一句读者/强度")

    # ★ 风格样本与档位同理：由**题材**匹配决定，不由 LLM 挑名字。
    #   LLM 不知道库里有哪些样本，只能瞎猜（实测给"李零"→ 找不到 → 退回科学报道体）。
    #   显式 `--style` 优先；LLM 的建议只作记录，不采纳。
    hint = ((d.get("style") or {}) if isinstance(d.get("style"), dict) else {}).get("name") \
        if not style_override else None
    st = resolve_style(style_override, t)
    if hint and str(hint).strip() not in ("", st["name"]):
        # 不记录建议的具体名字：产出要脱敏，人名不进卡片
        open_q.append(f"LLM 建议了另一风格样本，按题材用 {st['name']}"
                      "（风格由规则定，要换请用 --style）")
    if st["source"] == "default":
        open_q.append(st["note"])

    route = SOURCE_ROUTES[t]
    card = {
        "topic_type": t,
        "confidence": _num(d.get("confidence"), 0.5),
        "confident_enough": _num(d.get("confidence"), 0.5) >= CONFIDENCE_FLOOR,
        "primary_sources": list(route["primary"]),
        "secondary_sources": list(SECONDARY_SOURCES),
        "first_hand_definition": (str(d.get("first_hand_definition") or "").strip()
                                  or route["first_hand"]),
        "fact_standard": std,
        "fact_thresholds": dict(FACT_STANDARDS[std]),
        "style": st,
        "expert_domain": (str(d.get("expert_domain") or "").strip() or None),
        "qa": qa,
        "open_questions": open_q,
        "rationale": str(d.get("rationale") or "").strip(),
        "need": need.strip()[:4000],
        "generated_at": _today(),
        "model": None,
        "degraded": False,      # True = 兜底卡，**不可用于门禁**
        "version": 1,
    }
    return card


def default_card(need: str, style: str | None = None,
                 standard: str | None = None) -> dict:
    """不调 LLM 的兜底卡（dry-run / 单测 / LLM 不可用时）。"""
    card = _normalize({"topic_type": "mixed", "confidence": 0.0,
                       "qa": [], "rationale": "未调用 LLM，按混合题材兜底"},
                      need, style, standard)
    card["degraded"] = True
    return card


def _ask_http(prompt: str, *, timeout: int = 90) -> str:
    """直连 DeepSeek（**默认通道**，实现见 `core/llm_http.py`）。

    为什么不用 coding agent 跑判定（2026-11-01 实测）：
      · opencode 是 coding agent，提示词里一提到"风格样本/目录"它就去 Glob
        搜文件，工具日志混进输出、JSON 被截断 → 解析失败（4 次里失败 2 次）；
      · 同一条提示走 HTTP 约 1–3 秒，且 temperature=0 可复现。
    判定/审稿这类**纯文本判断**不需要工具能力，走这里；取不到 key 才回落 CLI。
    """
    from . import llm_http
    return llm_http.ask(prompt, temperature=0, max_tokens=2400, timeout=timeout)


def _ask(prompt: str, *, llm, model: str | None, backend: str, timeout: int) -> str:
    if llm is not None:
        return llm(prompt) or ""
    text = _ask_http(prompt, timeout=timeout)
    if text:
        return text
    try:
        from core.llm import get as llm_get
        res = llm_get(backend).run(prompt, model=model or DEFAULT_MODEL,
                                   cwd=str(ROOT), title="topic_card", timeout=timeout)
        return res.text if res.ok else ""
    except Exception as e:  # noqa: BLE001
        print(f"[topic_card] CLI 回落失败：{type(e).__name__}: {e}")
        return ""


def judge(need: str, *, llm=None, model: str | None = None,
          backend: str = "opencode", style: str | None = None,
          standard: str | None = None, timeout: int = 180,
          retries: int = 1) -> dict:
    """调 LLM 判定题材，返回规范化后的卡。LLM 失败 → 兜底卡（不抛）。

    解析失败**重试一次**：实测 flash 偶发输出不可解析（2026-11-01），
    旧实现会静默降级成 mixed 卡，看起来"正常"但污染下游。降级必须显式
    （`degraded=True`），因为兜底卡不可用于门禁。
    """
    need = (need or "").strip()
    if not need:
        raise ValueError("need 不能为空")
    prompt = build_prompt(need)
    d: dict = {}
    for i in range(retries + 1):
        d = extract_json(_ask(prompt, llm=llm, model=model, backend=backend,
                              timeout=timeout)) or {}
        if d:
            break
        if i < retries:
            print("[topic_card] 输出不可解析，重试一次")
    if not d:
        card = default_card(need, style, standard)
        card["open_questions"].append("LLM 两次均未返回可解析的 JSON，已按混合题材兜底；"
                                      "此卡为降级产物，不得用于门禁")
        card["model"] = model or DEFAULT_MODEL
        return card
    card = _normalize(d, need, style, standard)
    card["model"] = model or DEFAULT_MODEL
    return card


# ------------------------------------------------------------------ 落盘
def save(slug: str, card: dict, *, force: bool = True) -> Path:
    """写入 `research/<slug>/TOPIC.json` 的 topic_card，并同步 style_corpus。

    同步 style_corpus 是**写判同源**的落点：写作与文风核查共用这一句柄
    （`core/monograph.py` 的 style_path 读的就是它）。
    """
    slug = str(slug or "").strip()
    if not re.match(r"^[\w\-]{1,60}$", slug) or slug == "style":
        raise ValueError("slug 仅限字母数字-_（≤60），且不能是 style")
    d = WORK / slug
    d.mkdir(parents=True, exist_ok=True)
    p = d / "TOPIC.json"
    topic = {}
    if p.exists():
        try:
            topic = json.loads(p.read_text(encoding="utf-8")) or {}
        except Exception:
            topic = {}
    if topic.get("topic_card") and not force:
        raise ValueError("topic_card 已存在；要覆盖请加 force")
    topic["topic_card"] = card
    topic["style_corpus"] = card["style"]["path"]      # 写判同源
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(topic, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)
    return p
