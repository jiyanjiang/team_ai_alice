"""后台调研作业（P1）：提交即返回，跑完把结果发回房间。

为什么要有这一层（Owner 2026-11-02 定）：
  · 调研本身就该慢（多轮检索 + 综合 + 核查），但**同步接口慢就等于坏了**——
    群聊里让人等 10 分钟的请求，失败时连"它还在不在跑"都判断不了；
  · 所以使用模式改成云计算式：提交 → 立刻拿到 job_id → 后台跑 → 跑完推送结果。
  · 及格线：半小时返回；可接受：1 小时；**硬上限 4 小时**（到点标 timeout，不再无限等）。

状态机：
    queued ──(拿到并发名额)──> running ──> done
                                     └──> failed / timeout

约定：
  · 结果写进 research_jobs.result_json；正文**先落帖**（posts），房间里只发一条系统通知 + 帖子卡片；
  · 投递失败不影响报告本身（正文已在 posts，last_error 留痕并写明 post_id）；
  · 进程重启会丢在跑的线程 → running 超过 HARD_LIMIT 由 reap() 标 timeout。
"""
from __future__ import annotations

import json
import os
import threading
import time
import uuid

from . import db

HARD_LIMIT = int(os.environ.get("TEAMAI_RESEARCH_JOB_LIMIT", "14400"))        # 4 小时
MAX_RUNNING = int(os.environ.get("TEAMAI_RESEARCH_JOB_CONCURRENCY", "3"))
_RESULT_MAX = 200_000          # 单份结果落库上限（字符），防止把库撑爆
_SEM = threading.Semaphore(max(1, MAX_RUNNING))

FINAL = ("done", "failed", "timeout")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def ensure(conn) -> None:
    conn.execute("""
      CREATE TABLE IF NOT EXISTS research_jobs (
        id TEXT PRIMARY KEY,
        agent_id TEXT NOT NULL,
        room_id TEXT,
        prompt TEXT NOT NULL,
        args_json TEXT,
        status TEXT NOT NULL DEFAULT 'queued',
        stage TEXT,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        started_at TEXT,
        finished_at TEXT,
        result_json TEXT,
        last_error TEXT
      )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS ix_research_jobs_agent_status "
                 "ON research_jobs(agent_id,status,created_at)")
    conn.commit()


def _row_to_dict(row) -> dict:
    if row is None:
        return {}
    d = dict(row)
    for k in ("args_json", "result_json"):
        if d.get(k):
            try:
                d[k[:-5]] = json.loads(d[k])
            except Exception:  # noqa: BLE001
                d[k[:-5]] = None
        elif k in d:
            d[k[:-5]] = None
        d.pop(k, None)
    return d


def get(conn, job_id: str) -> dict:
    ensure(conn)
    row = conn.execute("SELECT * FROM research_jobs WHERE id=?", (job_id,)).fetchone()
    return _row_to_dict(row)


def list_jobs(conn, *, agent_id: str | None = None, status: str | None = None,
              limit: int = 20) -> list[dict]:
    ensure(conn)
    sql, args = "SELECT * FROM research_jobs WHERE 1=1", []
    if agent_id:
        sql += " AND agent_id=?"; args.append(agent_id)
    if status:
        sql += " AND status=?"; args.append(status)
    sql += " ORDER BY created_at DESC LIMIT ?"; args.append(max(1, min(100, limit)))
    return [_row_to_dict(r) for r in conn.execute(sql, args).fetchall()]


def submit(conn, *, agent_id: str, prompt: str, args: dict | None = None,
           room_id: str = "") -> dict:
    """建作业并起后台线程；立刻返回 job（status=queued）。"""
    ensure(conn)
    prompt = (prompt or "").strip()
    if not prompt:
        raise ValueError("prompt 不能为空")
    jid = "rj-" + uuid.uuid4().hex[:12]
    payload = dict(args or {})
    conn.execute(
        "INSERT INTO research_jobs(id,agent_id,room_id,prompt,args_json,status,stage,created_at) "
        "VALUES(?,?,?,?,?, 'queued','queued',?)",
        (jid, agent_id, room_id or "", prompt, json.dumps(payload, ensure_ascii=False), _now()))
    conn.commit()
    threading.Thread(target=_worker, args=(jid,), name=f"research-job-{jid}",
                     daemon=True).start()
    return get(conn, jid)


def reap(conn) -> int:
    """把跑超 4 小时（或进程重启后没人回收）的作业标成 timeout。"""
    ensure(conn)
    cutoff = time.time() - HARD_LIMIT
    n = 0
    for row in conn.execute("SELECT id,started_at FROM research_jobs WHERE status='running'").fetchall():
        ts = row["started_at"]
        try:
            started = time.mktime(time.strptime(ts, "%Y-%m-%d %H:%M:%S")) if ts else 0
        except Exception:  # noqa: BLE001
            started = 0
        if started and started < cutoff:
            conn.execute("UPDATE research_jobs SET status='timeout', finished_at=?, "
                         "last_error=? WHERE id=? AND status='running'",
                         (_now(), f"超过 {HARD_LIMIT}s 硬上限", row["id"]))
            n += 1
    if n:
        conn.commit()
    return n


def _update(conn, job_id: str, **fields) -> None:
    if not fields:
        return
    keys = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE research_jobs SET {keys} WHERE id=?", (*fields.values(), job_id))
    conn.commit()


def _stage_cb(conn, job_id: str):
    def _cb(stage: str) -> None:
        try:
            _update(conn, job_id, stage=str(stage)[:40])
        except Exception:  # noqa: BLE001
            pass
    return _cb


def _render(job: dict, res: dict) -> str:
    """回帖正文：结论 + 门禁状态。不做二次加工，避免和前台看到的不一致。"""
    text = str(res.get("text") or "").strip()
    gate = res.get("gate") or {}
    lines = [f"## 调研完成 · {job.get('id')}", "", text or "（无正文）", "",
             f"来源门禁：{gate.get('status') or 'unverified'}"]
    if gate.get("reasons"):
        lines.append("门禁原因：" + "；".join(str(x) for x in gate["reasons"][:5]))
    srcs = res.get("sources") or []
    if srcs:
        lines.append("")
        lines.append("来源：")
        for s in srcs[:8]:
            lines.append(f"- [{s.get('id')}] {s.get('title') or ''} {s.get('url') or ''}")
    return "\n".join(lines)[:20000]


_FALLBACK_CHANNEL = "#projects/team-ai"


def _report_channel(conn, job: dict) -> str:
    """报告落帖的频道：房间所属频道，取不到就回落到项目频道。

    房间 channel_id 未必是真实频道：好友房存的是虚拟键 `friend:<human id>`，
    群聊/私信可能为空。直接拿它插 posts 会撞 `posts.channel_id` 外键 → 报告丢失。
    """
    rid = job.get("room_id") or ""
    cand = ""
    if rid:
        row = conn.execute("SELECT channel_id FROM rooms WHERE id=?", (rid,)).fetchone()
        cand = str((row[0] if row else "") or "")
    if cand and conn.execute("SELECT 1 FROM channels WHERE id=?", (cand,)).fetchone():
        return cand
    return _FALLBACK_CHANNEL


def _publish_post(conn, job: dict, res: dict, status: str) -> str:
    """把调研结果落成帖子，返回 post_id。

    "先落库、再投递"：房间消息只是通知 + 卡片，正文永远在 posts 里。
    这样即使发消息被回合纪律/房间状态挡住，报告也不会只剩一行 last_error。
    """
    text = str(res.get("text") or "").strip()
    gate = res.get("gate") or {}
    if text:
        body = _render(job, res)
    else:
        body = (f"## 调研未完成 · {job.get('id')}\n\n"
                f"{res.get('error') or '作业未产出正文'}\n\n状态：{status}")
    if gate.get("ok") is False:
        why = "；".join(str(x) for x in (gate.get("reasons") or [])[:3]) or "未核验"
        body += f"\n\n> ⚠️ 质量警告（不影响阅读，仅说明核验状态）：{why}"
    from . import community, quota
    channel = _report_channel(conn, job)
    title = str(job.get("prompt") or "调研").strip()[:40] or "调研"
    args = (job.get("agent_id"), channel, "note", body)
    kw = {"title": f"调研 · {title}", "tags": ["research"],
          "kind": "public_channel", "visibility": "public"}
    try:
        return community.create_post_and_emit(conn, *args, **kw)
    except quota.QuotaExceeded:
        # 社交额度用尽是"可以不发朋友圈"，不是"可以把报告丢掉"：
        # 调研报告属工作产物，改落 #projects/* （不计社交额度）。
        if channel == _FALLBACK_CHANNEL:
            raise
        return community.create_post_and_emit(
            conn, job.get("agent_id"), _FALLBACK_CHANNEL, "note", body, **kw)


def _notice(job: dict, res: dict, status: str, post_id: str) -> str:
    """房间里那条通知：结论首句 + 质量警告 + 帖子 id。

    p-xxxxxxxx 由聊天页 `_post_refs()` 自动渲染成卡片，点开进入右侧详情——
    所以正文只放 id，不贴长文（Owner 2026-11-03：别在聊天里贴原文）。
    """
    text = str(res.get("text") or "").strip()
    gate = res.get("gate") or {}
    out = []
    if text:
        first = next((ln.strip().lstrip("#").strip() for ln in text.splitlines() if ln.strip()), "")
        out.append(f"调研完成：{first[:80]}")
    else:
        out.append(f"调研未完成 · {job.get('id')}（{status}）")
    if gate.get("ok") is False:
        why = "；".join(str(x) for x in (gate.get("reasons") or [])[:2]) or "未核验"
        out.append(f"⚠️ 质量警告（不影响阅读）：{why}")
    out.append(f"全文：{post_id}" if post_id else "全文落帖失败，见 research_jobs.result_json")
    return "\n".join(out)


def _worker(job_id: str) -> None:
    conn = db.connect()
    try:
        job = get(conn, job_id)
        if not job or job.get("status") != "queued":
            return
        if not _SEM.acquire(timeout=HARD_LIMIT):
            _update(conn, job_id, status="timeout", finished_at=_now(),
                    last_error="排队超过硬上限")
            return
        try:
            _update(conn, job_id, status="running", stage="retrieve", started_at=_now())
            from .tool import research_tool
            res = research_tool._research_ask(  # noqa: SLF001 — 同一进程内的唯一入口
                job["agent_id"], job.get("args") or {}, on_stage=_stage_cb(conn, job_id))
            elapsed = time.time() - (time.mktime(time.strptime(job.get("started_at") or _now(),
                                                              "%Y-%m-%d %H:%M:%S")))
            status = "done" if res.get("ok", True) is not False else "failed"
            if elapsed > HARD_LIMIT:
                status = "timeout"
            # 结果先落库（status 仍是 running），交付完成后再标终态——
            # 否则轮询方一看到 done 就去取帖子，可能扑空（帖子还没写完）。
            _update(conn, job_id, stage="done",
                    result_json=json.dumps(res, ensure_ascii=False)[:_RESULT_MAX],
                    last_error=(str(res.get("error") or "")[:300] or None))
            room_id = job.get("room_id") or ""
            if room_id:
                # 先落库、再投递：房间消息只是一条通知 + 卡片，正文永远在 posts 里。
                # 即使投递被挡（回合/房间状态），报告也不会丢成一行 last_error。
                post_id = ""
                try:
                    post_id = _publish_post(conn, job, res, status)
                except Exception as e:  # noqa: BLE001
                    _update(conn, job_id, last_error=f"落帖失败：{type(e).__name__}: {e}"[:300])
                try:
                    from . import rooms
                    rooms.system_say(conn, room_id, job["agent_id"],
                                     _notice(job, res, status, post_id))
                except Exception as e:  # noqa: BLE001
                    tail = f"（正文已落帖 {post_id}）" if post_id else "（正文见 result_json）"
                    _update(conn, job_id, last_error=f"回帖失败{tail}：{type(e).__name__}: {e}"[:300])
            _update(conn, job_id, status=status, finished_at=_now())
        finally:
            _SEM.release()
    except Exception as e:  # noqa: BLE001
        try:
            _update(conn, job_id, status="failed", stage="done", finished_at=_now(),
                    last_error=f"{type(e).__name__}: {e}"[:300])
        except Exception:  # noqa: BLE001
            pass
    finally:
        try:
            conn.close()
        except Exception:  # noqa: BLE001
            pass
