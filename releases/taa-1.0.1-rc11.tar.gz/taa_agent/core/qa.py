"""质量监督闭环 qa —— Alice 对某目标(target)某主题(topic)的逐轮质检与收敛记录。

用法：`core.qa.run_cycle(agent, topic, target, posts)`：
  对一轮产出（论坛帖/消息）按判据打分 → 记一条 review_cycle → 给收敛判据 + 短反馈。
目标：**用最少循环收敛到合格**（缺陷序列单调不增并以 0 收尾）。

判据来源：docs/26《项目组织与命名规范》（存档/索引帖）。
确定性判据优先，不盲信 LLM；反馈走 Alice 口语风格（短、结论先行）。
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from . import memory as mem

ROOT = Path(__file__).resolve().parent.parent

# 确定性判据（对「索引帖」）
_SECRET_PAT = [r"sk-[A-Za-z0-9]{8,}", r"AKIA[0-9A-Z]{12,}", r"password\s*[:=]",
               r"/Users/", r"http://192\.168\.", r"http://10\.", r"http://172\."]
_QUOTE_PAT = ["「", "」", "“", "”", '"']
_MARK_PAT = ["一手", "转述", "原话", "paraphrase", "直接引语"]


def _text(post: dict) -> str:
    links = post.get("links") or []
    if isinstance(links, str):
        links = [links]
    return "\n".join([post.get("title") or "", post.get("body") or "", " ".join(map(str, links))])


def evaluate_post(post: dict) -> list[dict]:
    """返回该帖的缺陷列表（空=合格）。"""
    t = _text(post)
    ref = post.get("id") or post.get("post_id") or "?"
    defects: list[dict] = []

    def bad(c: str, detail: str):
        defects.append({"ref": ref, "criterion": c, "detail": detail})

    if not (post.get("title") or "").strip():
        bad("C1 标题", "缺标题")
    if not re.search(r"https?://\S+", t):
        bad("C2 原文URL", "缺原文链接")
    if not re.search(r"\bdata/[\w\-./]+", t):
        bad("C3 文件路径", "缺落档路径（data/…）")
    body = (post.get("body") or "")
    body_no_link = re.sub(r"https?://\S+", "", body).strip()
    if len(body_no_link) < 60:
        bad("C4 摘要", f"摘要过短（{len(body_no_link)}字）")
    if any(q in body for q in _QUOTE_PAT) and not any(m in body for m in _MARK_PAT):
        bad("C5 一手/转述标注", "有引语但未标一手/转述")
    hit = [p for p in _SECRET_PAT if re.search(p, t)]
    if hit:
        bad("C6 脱敏", f"疑似敏感：{hit[0]}")
    # C7 附件（若帖带附件）：URL 合法且文件在库
    for a in (post.get("attachments") or []):
        u = (a.get("url") if isinstance(a, dict) else a) or ""
        if not re.match(r"^/static/uploads/[\w.\-]+$", u):
            bad("C7 附件", f"附件URL非法：{u}")
            break
        if not (ROOT / "static" / "uploads" / Path(u).name).exists():
            bad("C7 附件", f"附件不存在：{u}")
            break
    # C8 附件完整性：索引帖声明了落档文件（data/…）时，应附上对应件（或打包 zip/tar）
    declared = re.findall(r"data/[\w\-./]+\.\w+", body)
    atts = post.get("attachments") or []
    if declared and atts:
        names = [(a.get("name") if isinstance(a, dict) else "") or "" for a in atts]
        base = os.path.basename(declared[0])
        packed = any(n.endswith((".zip", ".tar", ".gz", ".tgz")) for n in names)
        if not (any(base in n for n in names) or packed):
            bad("C8 附件完整性", f"未附上声明的落档文件 {base}")
    return defects


# ---------------------------------------------------------------- 脚本模式（短视频脚本）
SCRIPT_MIN, SCRIPT_MAX = 600, 1000
_STRUCT_KEYS = ["开场", "钩子", "主体", "结尾", "收尾", "画面", "景别", "镜头", "旁白", "字幕"]
_PLACEHOLDER = re.compile(r"待补|待核|TODO|XX+|\?\?\?|【】")


def han_len(s: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]", s or ""))


def _att_files(post: dict) -> list[tuple[str, str]]:
    out = []
    for a in (post.get("attachments") or []):
        u = (a.get("url") if isinstance(a, dict) else a) or ""
        nm = ((a.get("name") if isinstance(a, dict) else "") or Path(u).name) or ""
        if not u:
            continue
        p = ROOT / "static" / "uploads" / Path(u).name
        if p.exists() and p.suffix.lower() in (".md", ".markdown", ".txt"):
            out.append((nm, p.read_text(encoding="utf-8", errors="ignore")))
    return out


def _att_texts(post: dict) -> list[str]:
    return [t for _, t in _att_files(post)]


def _facts_struct(text: str) -> list[str]:
    """事实库结构检查（对齐 scripts/facts_check.py）。"""
    blocks = [b for b in re.split(r"\n(?=## )", text) if b.startswith("## ")]
    bad: list[str] = []
    if not blocks:
        bad.append("事实库为空")
    for b in blocks:
        fid = b[3:].split()[0] if len(b) > 3 else "?"
        if not re.match(r"^F\d{3}$", fid):
            bad.append(f"{fid}: ID 格式应为 F###")
        if not ("http://" in b or "https://" in b or "无公开 URL" in b):
            bad.append(f"{fid}: 缺 URL")
        if "用于" not in b:
            bad.append(f"{fid}: 缺「用于」")
    return bad


def _audit_numbers(draft: str, facts: str) -> list[str]:
    """数字/数量词逐条对事实源审计（对齐 scripts/fact_audit.py）。"""
    nums = set(re.findall(r"\d[\d,，]*\.?\d*", re.sub(r"<[^>]+>", "", draft)))

    def present(n: str) -> bool:
        return re.search(r"(?<!\d)" + re.escape(n) + r"(?!\d)", facts) is not None

    return sorted(n for n in nums if not present(n) and n not in {"1", "2", "3", "4", "5"})


def evaluate_script(post: dict) -> list[dict]:
    """短视频脚本判据 S1–S7（长度/结构/来源/占位/脱敏/事实层/事实一致）。

    **S1 只量"脚本本体"**：优先取非事实附件（如 `稿.md`）；无脚本附件时才回退帖正文。
    `FACTS.md`（证据）与索引帖正文**不计入** S1 字数——它们是证据/索引，不是口播正文。
    （此前把全部附件+正文相加，会与"脚本 600–1000 字"的本意冲突，逼执行者做字数预算。）
    """
    body = post.get("body") or ""
    files = _att_files(post)
    facts = [t for nm, t in files if "fact" in nm.lower()]
    script_texts = [t for nm, t in files if "fact" not in nm.lower()]
    script_text = "\n".join(script_texts) if script_texts else body      # S1 计量范围
    draft_text = body + "\n" + "\n".join(script_texts)                   # S7 审计范围
    whole = body + "\n" + "\n".join(t for _, t in files)                 # S2–S5 检查范围
    ref = post.get("id") or "?"
    d: list[dict] = []

    def bad(c: str, detail: str):
        d.append({"ref": ref, "criterion": c, "detail": detail})

    n = han_len(script_text)
    if not (SCRIPT_MIN <= n <= SCRIPT_MAX):
        bad("S1 长度", f"脚本 {n} 字（需 {SCRIPT_MIN}-{SCRIPT_MAX}）")
    if not any(k in whole for k in _STRUCT_KEYS):
        bad("S2 结构", "缺口播结构（开场/主体/结尾 或 画面/景别提示）")
    if "physicsworld.com" not in whole:
        bad("S3 来源", "未含 physicsworld 原文链接")
    m = _PLACEHOLDER.search(whole)
    if m:
        bad("S4 占位", f"含未完成占位：{m.group(0)}")
    hit = [p for p in _SECRET_PAT if re.search(p, whole)]
    if hit:
        bad("S5 脱敏", f"疑似敏感：{hit[0]}")
    # S6 事实层 + S7 事实一致
    if not facts:
        bad("S6 事实层", "缺事实库 FACTS.md（先事实层，再写作）")
    else:
        fs = _facts_struct(facts[0])
        if fs:
            bad("S6 事实层", "；".join(fs[:3]))
        miss = _audit_numbers(draft_text, facts[0])
        if miss:
            bad("S7 事实一致", f"{len(miss)} 个数字无源：{', '.join(miss[:6])}")
    return d


def evaluate_posts_script(posts: list[dict]) -> dict:
    items = len(posts or [])
    defects: list[dict] = []
    per: dict[str, int] = {}
    for p in posts or []:
        for x in evaluate_script(p):
            defects.append(x)
            per[x["criterion"]] = per.get(x["criterion"], 0) + 1
    return {"items": items, "defects": defects, "defect_count": len(defects),
            "by_criterion": per, "passed": items > 0 and not defects}


def evaluate_posts(posts: list[dict]) -> dict:
    items = len(posts or [])
    defects: list[dict] = []
    per_criterion: dict[str, int] = {}
    for p in posts or []:
        for d in evaluate_post(p):
            defects.append(d)
            per_criterion[d["criterion"]] = per_criterion.get(d["criterion"], 0) + 1
    passed = items > 0 and not defects
    return {"items": items, "defects": defects, "defect_count": len(defects),
            "by_criterion": per_criterion, "passed": passed}


def human_feedback(target: str, cycle_no: int, result: dict, topic: str) -> str:
    """仿人（导师）风格：结论先行、短、直接、点硬伤、给下一步。"""
    n = cycle_no
    if result["items"] == 0:
        return f"{target}，第{n}轮：没有可审的产出。回我一条帖（标题+链接+落档路径+摘要），我才有得看。"
    if result["passed"]:
        return f"{target}，第{n}轮：过。判据全绿，这版我签。下一件事按主题继续，别回头改。"
    ds = result["defects"]
    bullets = "；".join(f"{i + 1}）{d['criterion']}——{d['detail']}" for i, d in enumerate(ds[:4]))
    more = f"（共{len(ds)}处）" if len(ds) > 4 else ""
    return f"{target}，第{n}轮：不通过，{len(ds)}处{more}——{bullets}。照单改，下一轮交齐，别拖。"


def run_cycle(agent: str, topic: str, target: str, posts: list[dict], *,
              dry_run: bool = False, last_seen: str | None = None, mode: str = "post",
              require_plan: bool = False) -> dict:
    """跑一轮：评估 → 记录 → 收敛 + 反馈。mode: post（索引帖）| script（短视频脚本）。"""
    res = evaluate_posts_script(posts) if mode == "script" else evaluate_posts(posts)
    # 规划优先门禁（可选）：未过方案不得开工。方案评审(LLM)见 core/plan.py。
    if require_plan:
        from . import plan as plan_mod
        g = plan_mod.plan_gate(agent, topic, target)
        if not g.get("ok"):
            res["defects"].insert(0, {"criterion": "P0 方案先行", "detail": g.get("reason"), "ref": "-"})
            res["defect_count"] = len(res["defects"])
            res["by_criterion"]["P0 方案先行"] = 1
            res["passed"] = False
    refs = [p.get("id") for p in (posts or [])]
    if dry_run:
        cycle_no = len(mem.list_review_cycles(agent, topic, target)) + 1
        rec = {"cycle_no": cycle_no}
    else:
        rec = mem.add_review_cycle(agent, topic, target, res["items"], res["defect_count"],
                                   res["passed"], criteria=res["by_criterion"],
                                   detail=res["defects"], refs=refs, last_seen=last_seen)
    conv = mem.review_convergence(agent, topic, target)
    return {"topic": topic, "target": target, "mode": mode, "cycle_no": rec["cycle_no"],
            "items": res["items"], "defects": res["defect_count"], "by_criterion": res["by_criterion"],
            "detail": res["defects"], "passed": res["passed"],
            "feedback": human_feedback(target, rec["cycle_no"], res, topic),
            "convergence": conv, "dry_run": dry_run}
