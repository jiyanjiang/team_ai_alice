"""discovery —— 局域网宿主地址**发现**（抗 IP 漂移）。纯基础设施，**不调 LLM**。

机制：宿主每 ~5s 向 UDP 广播 `{"teamai":"<ip>:<port>","node":"…"}`；客户端驱动监听该端口，
收到候选地址后**先验真**（用自身签名访问候选的 /v1/me，能返回本 agent 身份才算数）→ 采纳并持久化。

优先级：显式 --url/TEAMAI_URL > 信标发现 > `bootstrap/host_url`（上次记住的）> 默认。
"""
from __future__ import annotations

import json
import os
import socket
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BEACON_PORT = int(os.environ.get("TEAMAI_BEACON_PORT", "6099"))
HOST_URL_FILE = ROOT / "bootstrap" / "host_url"
MAGIC = "teamai-host"


def save_host_url(url: str) -> None:
    try:
        HOST_URL_FILE.parent.mkdir(parents=True, exist_ok=True)
        HOST_URL_FILE.write_text(url.strip(), encoding="utf-8")
    except Exception:
        pass


def load_host_url() -> str | None:
    try:
        u = HOST_URL_FILE.read_text(encoding="utf-8").strip()
        return u or None
    except Exception:
        return None


def local_ips() -> list[str]:
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return sorted(set(ips))


def _bcast_addr(ip: str) -> str:
    p = (ip or "").split(".")
    if len(p) == 4 and all(x.isdigit() for x in p):
        return ".".join(p[:3]) + ".255"
    return "255.255.255.255"


def broadcast_beacon(url_host: str, url_port: int, node: str = "", port: int = BEACON_PORT,
                     interval: float = 5.0, stop: threading.Event | None = None) -> None:
    """宿主侧：周期性 UDP 广播本机 TeamAI 地址。"""
    payload = json.dumps({"magic": MAGIC, "teamai": f"{url_host}:{url_port}",
                          "node": node, "ts": int(time.time())}).encode("utf-8")
    dests = [_bcast_addr(url_host), "255.255.255.255"]
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    while not (stop and stop.is_set()):
        for dest in dests:
            try:
                s.sendto(payload, (dest, port))
                break                      # 成功后不再试回退地址
            except Exception:
                continue
        time.sleep(interval)


def listen_beacons(on_candidate, port: int = BEACON_PORT, stop: threading.Event | None = None,
                   log=print) -> None:
    """客户端侧：监听信标；对每个候选调用 on_candidate(base_url, node)（由调用方验真/采纳）。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("", port))
    except Exception as e:
        log(f"[discovery] 监听 {port} 失败：{e}")
        return
    s.settimeout(2.0)
    seen = {}
    while not (stop and stop.is_set()):
        try:
            data, addr = s.recvfrom(2048)
        except socket.timeout:
            continue
        except Exception:
            break
        try:
            j = json.loads(data.decode("utf-8", "replace"))
        except Exception:
            continue
        if j.get("magic") != MAGIC or not j.get("teamai"):
            continue
        base = "http://" + str(j["teamai"]).strip().rstrip("/")
        now = time.time()
        if now - seen.get(base, 0) < 10:      # 去抖：同一地址 10s 内只处理一次
            continue
        seen[base] = now
        try:
            on_candidate(base, j.get("node") or "", addr)
        except Exception as e:
            log(f"[discovery] on_candidate 出错：{e}")
