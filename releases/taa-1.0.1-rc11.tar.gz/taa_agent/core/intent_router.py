"""指令裁决器（Intent Router）v1：把群里的一句话判成 **执行 / 回答 / 忽略**。

为什么要有这一层（2026-10-30 实测事故）：
  `@Alice 只回复 P1A_OK` 被 `executor_bridge.should_execute()` 的关键词表命中
  （"回复"在动作词里）→ 起了一整个 opencode 执行器，跑 2m24s，
  最后在群里发 ACK + 结果帖，而人只要三个字。判路的活儿本来就该 LLM 干。

设计原则（Owner 2026-10-30 定）：
  1) **充分利用 LLM**：不再用关键词白名单决定"要不要动手"；
  2) **树状分叉 + 快速 Yes/No**：directive → needs_tools → backend，前一级为否立即短路；
  3) **结构快通道**（0 LLM）：`/exec`、`/say` 前缀直接定路，确定性优先；
  4) **弹性**：判据在 `prompts/intent_router_v1.yaml`，执行器清单在 `core.llm.ADAPTERS`，
     换提示词 / 加执行器都不用改本文件；提示词支持按 mtime 热加载与 v2 切换；
  5) **失败不 brick**：LLM 超时/JSON 坏 → 回落本文件的**窄**关键词兜底（比旧的宽词表保守），
     并打 `source="fallback"` 便于事后审计。

三个出口：
  execute → 交给执行器（backend = LLM 建议 ∩ 本机可用，兜底 opencode）
  answer  → 轻通道：群里只回一句，不进执行器、不发帖、不发 ACK
  ignore  → 不动作（系统播报、闲聊、给别人的活儿）
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROMPT_DIR = ROOT / "prompts"

DEFAULT_PROMPT = "intent_router_v1.yaml"
#: 降级日志：裁决器的六条降级路径原先完全静默（只留 source=fallback），
#: 2026-11-01 事故里只能靠事后反推"提示词根本没加载"。这里补一条可 grep 的流水。
LOG = ROOT / "runtime" / "intent_router.log"
#: 后端偏好顺序：显式指定 > 本机已装 > 默认。
#: `codebuddy` 排在最后：它是 GUI 启动器（INTERACTIVE），拿不到终端输出，
#: 只该在显式指定时使用，不该抢占能同步出结果的 opencode。
PREFERRED = ("opencode", "qoder", "workbuddy", "omp", "pi", "codebuddy")

_prompt_cache: dict[str, tuple[float, dict]] = {}
_backend_cache: dict[str, object] = {"at": 0.0, "map": {}}
_cache_lock = threading.Lock()

_log_seen: dict[str, float] = {}


def _log(line: str, key: str = "", *, every: float = 60.0) -> None:
    """降级流水（best-effort，绝不抛）。同一 key 默认 60s 内只记一次，避免刷屏。"""
    if key:
        now = time.time()
        with _cache_lock:
            last = float(_log_seen.get(key) or 0.0)
            if now - last < every:
                return
            _log_seen[key] = now
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            # 压成单行：yaml 报错自带多行上下文，会把日志切碎
            flat = " ".join(str(line).split())
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {flat}\n")
    except OSError:
        pass

#: LLM 全挂时的窄兜底词表——只认"明显要动手"的动词。
#: 刻意**不含**「回复/解释/说明/告诉我」：那类正是 answer，旧词表把它们算成执行是事故根因。
_ACTION_WORDS = (
    "执行", "修复", "实现", "改成", "跑一下", "测试", "部署", "提交", "安装", "构建",
    "调试", "抓取", "迁移", "删除", "重跑", "截图", "生成图片", "画一张", "发帖",
    "改成", "重构", "排查", "清理",
)
#: 明确"只要一句话"的否定信号：命中则不判 execute（即便同时含动作词）。
_ANSWER_WORDS = ("只回复", "仅回复", "只回答", "仅回答", "不要动手", "别动手", "不用做",
                 "不要修改", "别改", "一句话", "回我一句")


@dataclass
class Decision:
    action: str = "ignore"          # execute | answer | ignore
    backend: str = ""               # 仅 execute 有意义
    reply: str = ""                 # 仅 answer 有意义
    reason: str = ""
    source: str = ""                # prefix | llm | fallback | default
    trace: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {"action": self.action, "backend": self.backend, "reply": self.reply,
                "reason": self.reason, "source": self.source, "trace": self.trace}


# ------------------------------------------------------------------ 提示词（热加载）
def _load_prompt(name: str | None = None) -> dict:
    """按 mtime 热加载提示词；文件坏了就退回内置最小集，不让调用方崩。"""
    fname = (name or os.environ.get("TEAMAI_ROUTE_PROMPT") or DEFAULT_PROMPT).strip()
    path = PROMPT_DIR / fname
    try:
        mt = path.stat().st_mtime
    except OSError:
        _log(f"degrade prompt_missing file={fname} dir={PROMPT_DIR.name}/ (裁决器将退回关键词兜底)",
             key="prompt_missing")
        return {"system": "", "user": "{text}", "answer_system": "", "limits": {}}
    with _cache_lock:
        hit = _prompt_cache.get(fname)
        if hit and hit[0] == mt:
            return hit[1]
    try:
        import yaml
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            _log(f"degrade prompt_not_mapping file={fname} type={type(data).__name__}",
                 key="prompt_not_mapping")
            data = {}
    except Exception as e:  # noqa: BLE001
        _log(f"degrade prompt_bad_yaml file={fname} {type(e).__name__}: {e}", key="prompt_bad_yaml")
        data = {}
    with _cache_lock:
        _prompt_cache[fname] = (mt, data)
    return data


def _render(tpl: str, **kw) -> str:
    """只替换已知占位符，不用 str.format——提示词里含 JSON 花括号。"""
    out = tpl or ""
    for k, v in kw.items():
        out = out.replace("{" + k + "}", str(v))
    return out


# ------------------------------------------------------------------ 后端（带缓存探测）
def available_backends(*, ttl: float = 300.0, refresh: bool = False) -> dict[str, bool]:
    now = time.time()
    with _cache_lock:
        if not refresh and now - float(_backend_cache["at"] or 0) < ttl:
            return dict(_backend_cache["map"] or {})
    try:
        from core.llm import available as _avail
        mp = _avail()
    except Exception:  # noqa: BLE001
        mp = {}
    with _cache_lock:
        _backend_cache["at"] = now
        _backend_cache["map"] = mp
    return mp


def resolve_backend(pref: str = "", *, agent: str = "") -> str:
    """把 LLM 的建议落到"本机真的能用"的后端上。

    优先级：agents/<id>/backend 文件 > 环境 TEAM_AGENT_BACKEND > LLM 建议 > 偏好顺序。
    """
    if agent:
        try:
            p = ROOT / "agents" / agent / "backend"
            if p.exists():
                b = (p.read_text(encoding="utf-8").strip() or "").lower()
                if b:
                    return b
        except OSError:
            pass
    env = (os.environ.get("TEAM_AGENT_BACKEND") or "").strip().lower()
    if env:
        return env
    want = (pref or "").strip().lower()
    av = available_backends()
    if want and want != "auto" and av.get(want):
        return want
    for name in PREFERRED:
        if av.get(name):
            return name
    return want if (want and want != "auto") else "opencode"


def backend_names() -> list[str]:
    try:
        from core.llm import ADAPTERS
        names = [k for k in ADAPTERS if k not in ("pi",)]   # pi 是 omp 的别名，不重复展示
    except Exception:  # noqa: BLE001
        names = list(PREFERRED)
    return names


# ------------------------------------------------------------------ 解析
def _extract_json(text: str) -> dict | None:
    if not text:
        return None
    s = text.strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.S)
    try:
        d = json.loads(s)
        return d if isinstance(d, dict) else None
    except Exception:  # noqa: BLE001
        pass
    m = re.search(r"\{.*\}", s, re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
        return d if isinstance(d, dict) else None
    except Exception:  # noqa: BLE001
        return None


def _truthy(v) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("true", "1", "yes", "y", "是")


# ------------------------------------------------------------------ 快通道
def _prefix_route(text: str) -> Decision | None:
    """结构快通道：显式前缀不需要花 LLM。"""
    m = re.match(r"^\s*/(?:exec|run)\s+(.+)$", text or "", re.S | re.I)
    if m:
        return Decision(action="execute", reason="显式 /exec", source="prefix")
    m = re.match(r"^\s*/say\s+(.+)$", text or "", re.S | re.I)
    if m:
        return Decision(action="answer", reply=m.group(1).strip(), reason="显式 /say", source="prefix")
    return None


def _keyword_fallback(text: str, *, why: str) -> Decision:
    low = (text or "").lower()
    if any(w in low for w in _ANSWER_WORDS):
        return Decision(action="answer", reason=f"{why}·只答信号", source="fallback")
    if any(w in text for w in _ACTION_WORDS):
        return Decision(action="execute", reason=f"{why}·动作词", source="fallback")
    return Decision(action="ignore", reason=why, source="fallback")


# ------------------------------------------------------------------ 主入口
def decide(text: str, *, agent: str = "", agent_id: str = "", room: str = "",
           mention: bool = False, llm=None, prompt: str | None = None,
           _llm_hint=None) -> Decision:
    """判一条消息该走哪条路。

    agent/agent_id 只用于提示词与后端选择；llm / _llm_hint 是测试注入口
    （`llm(prompt) -> str` 或 `LLMAdapter`）。
    """
    body = (text or "").strip()
    if not body:
        return Decision(action="ignore", reason="空消息", source="default")

    pre = _prefix_route(body)
    if pre:
        if pre.action == "execute":
            pre.backend = resolve_backend("", agent=agent_id)
        return pre

    spec = _load_prompt(prompt)
    limits = spec.get("limits") or {}
    timeout = int(limits.get("timeout_seconds") or 12)
    max_chars = int(limits.get("reply_max_chars") or 200)

    sys_tpl = str(spec.get("system") or "")
    usr_tpl = str(spec.get("user") or "{text}")
    if not sys_tpl:
        _log("degrade prompt_empty_system (yaml 存在但 system 为空)", key="prompt_empty_system")
        return _keyword_fallback(body, why="提示词缺失")
    prompt_text = (_render(sys_tpl, backends=", ".join(backend_names()))
                   + "\n\n"
                   + _render(usr_tpl, room=room or "-", agent=agent or "-",
                             mention="是" if mention else "否", text=body[:1500]))

    started = time.time()
    try:
        raw = _call_llm(prompt_text, timeout=timeout, llm=llm, hinted=_llm_hint)
    except Exception as e:  # noqa: BLE001
        _log(f"degrade llm_error {type(e).__name__}: {e}", key="llm_error")
        return _keyword_fallback(body, why=f"LLM异常:{type(e).__name__}")
    elapsed_ms = int((time.time() - started) * 1000)

    data = _extract_json(raw)
    if not data:
        _log(f"degrade non_json raw={(raw or '')[:120]!r}", key="non_json")
        return _keyword_fallback(body, why="非JSON")

    trace = {"ms": elapsed_ms, "raw": (raw or "")[:300]}

    # 第 1 级：是不是给我的
    if "directive" in data and not _truthy(data.get("directive")):
        return Decision(action="ignore", reason=str(data.get("reason") or "非指令")[:40],
                        source="llm", trace=trace)

    # 第 2 级：要不要动手
    needs = _truthy(data.get("needs_tools"))
    if not needs:
        reply = str(data.get("reply") or "").strip()
        if not reply:
            reply = _answer_once(body, agent=agent, spec=spec, llm=llm, hinted=_llm_hint)
        reply = reply.strip()[:max_chars]
        if not reply:
            _log("degrade empty_answer (needs_tools=false 但没给出 reply)", key="empty_answer")
            return _keyword_fallback(body, why="空回答")
        return Decision(action="answer", reply=reply,
                        reason=str(data.get("reason") or "只需回答")[:40],
                        source="llm", trace=trace)

    # 第 3 级：用哪个执行器
    backend = resolve_backend(str(data.get("backend") or "auto"), agent=agent_id)
    return Decision(action="execute", backend=backend,
                    reason=str(data.get("reason") or "需要动手")[:40],
                    source="llm", trace=trace)


def _http_call(prompt_text: str, *, timeout: int) -> str:
    """直连 DeepSeek chat/completions（快通道）。

    为什么不让 CLI 干这件事（2026-10-30 实测）：
      opencode 当"裁决器"用，一次 **92 秒**（它要先起 agent 运行时）；
      同一条提示走 HTTP **约 1 秒**。裁决只是个三字段 JSON，不需要工具能力。
    取不到 key / 网络不通时返回空串，由调用方回落到 CLI 适配器。
    """
    if os.environ.get("TEAMAI_ROUTE_HTTP", "1") == "0":
        return ""
    try:
        from core import config as _cfg
        key = _cfg.deepseek_key()
    except Exception:  # noqa: BLE001
        key = ""
    if not key:
        return ""
    url = os.environ.get("TEAMAI_ROUTE_URL") or "https://api.deepseek.com/v1/chat/completions"
    model = os.environ.get("TEAMAI_ROUTE_MODEL") or "deepseek-chat"
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt_text}],
        "temperature": 0,
        "max_tokens": 300,
        "stream": False,
    }).encode()
    try:
        import urllib.request
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {key}")
        # 裁决不需要强一致：最多重试 1 次、退避 1s。
        # 不用默认的 (2,5,60)——那会在 DNS 抖动时把一条群消息卡住一分多钟。
        import urllib.request as _u
        try:
            from core.net_retry import urlopen_retry
            with urlopen_retry(req, timeout=max(3, min(timeout, 20)),
                               attempts=2, backoff=(1,)) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
        except ImportError:
            with _u.urlopen(req, timeout=max(3, min(timeout, 20))) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
        return str((d.get("choices") or [{}])[0].get("message", {}).get("content") or "")
    except Exception:  # noqa: BLE001
        return ""


def _call_llm(prompt_text: str, *, timeout: int, llm=None, hinted=None) -> str:
    if hinted is not None:                      # 适配器/函数注入（测试用）
        if callable(hinted) and not hasattr(hinted, "run"):
            return str(hinted(prompt_text) or "")
        llm = hinted
    if llm is not None:
        if callable(llm) and not hasattr(llm, "run"):
            return str(llm(prompt_text) or "")
        res = llm.run(prompt_text, cwd=str(ROOT), title="taa-route", timeout=timeout)
        return res.text if getattr(res, "ok", False) else ""
    # 快通道 → CLI 兜底
    out = _http_call(prompt_text, timeout=timeout)
    if out.strip():
        return out
    from core.llm import get as llm_get
    ad = llm_get(resolve_backend(""))
    res = ad.run(prompt_text, cwd=str(ROOT), title="taa-route", timeout=timeout)
    return res.text if res.ok else ""


def _answer_once(body: str, *, agent: str, spec: dict, llm=None, hinted=None) -> str:
    """模型没在裁决里给 reply 时，补一次"只回一句"。"""
    limits = spec.get("limits") or {}
    timeout = int(limits.get("answer_timeout_seconds") or 20)
    sys_tpl = str(spec.get("answer_system") or "")
    if not sys_tpl:
        return ""
    prompt_text = f"{sys_tpl}\n\n对方的话：{body[:1500]}\n\n只输出那一句回答。"
    try:
        raw = _call_llm(prompt_text, timeout=timeout, llm=llm, hinted=hinted)
    except Exception:  # noqa: BLE001
        return ""
    return (raw or "").strip().strip('"')


__all__ = ["Decision", "decide", "resolve_backend", "available_backends", "backend_names",
           "PREFERRED"]
