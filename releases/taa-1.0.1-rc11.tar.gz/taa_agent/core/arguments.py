"""论证图 + 贝叶斯后验 + 渲染（docs/11 §4，M3）。

- 段落 → 小图（node: claim/premise/evidence；edge: support/attack）
- 先验按来源类型；独立支持 noisy-OR；攻击边削弱；得结论后验
- rigor = 奥卡姆（节点/边越少、后验越高 → 越高分）
- PNG 渲染：Playwright 优先，Pillow 兜底
"""
from __future__ import annotations

import re
from pathlib import Path

PRIOR = {"citation": 0.90, "computation": 0.85, "observation": 0.80, "assertion": 0.50}
NODE_COLOR = {"claim": "#e0e7ff", "premise": "#f3e8ff", "evidence": "#fff7e6",
              "chance": "#fff7cc", "decision": "#e0f2fe", "value": "#dcfce7"}
NODE_BADGE = {"claim": "结论", "premise": "前提", "evidence": "证据",
              "chance": "概率", "decision": "决策", "value": "效用"}


def _short(s, n=16) -> str:
    s = (s or "").strip().replace("\n", " ")
    return s if len(s) <= n else s[:n] + "…"

CITE = re.compile(r"(TLP|命题|坐标|§|引用|文献|页|编号|\d+\.\d+)")
COMPUTE = re.compile(r"(计算|推导|测试|实验|数据|复现|python|公式|证明)")
OBSERVE = re.compile(r"(观察|复现|实测|样例|例子|实验)")
ATTACK = re.compile(r"(但是|然而|反驳|然而|不过|counter|反例|不成立|矛盾)")


def _source_type(sentence: str) -> str:
    if CITE.search(sentence):
        return "citation"
    if COMPUTE.search(sentence):
        return "computation"
    if OBSERVE.search(sentence):
        return "observation"
    return "assertion"


def extract_graph(body: str, kind: str = "assertion") -> dict:
    """无外部图时的确定性抽取：结论 + 证据句 → support 边。文本尽量短。"""
    sents = [s.strip() for s in re.split(r"[。；;\n]", body or "") if s.strip()]
    if not sents:
        sents = [body or "（空）"]
    conclusion = {"id": "c", "type": "claim", "text": sents[0][:20],
                  "source_type": "assertion", "prior": PRIOR["assertion"]}
    nodes = [conclusion]
    edges = []
    for i, s in enumerate(sents[1:], 1):
        st = _source_type(s)
        nid = f"e{i}"
        nodes.append({"id": nid, "type": "evidence", "text": s[:20],
                      "source_type": st, "prior": PRIOR[st]})
        rel = "attack" if ATTACK.search(s) else "support"
        edges.append({"from": nid, "to": "c", "rel": rel, "strength": 0.7})
    return {"nodes": nodes, "edges": edges, "conclusion": "c"}


def posterior(graph: dict) -> float:
    """结论后验：支持 noisy-OR 合并，攻击按强度削弱。"""
    concl = graph.get("conclusion", "c")
    supports = [e for e in graph.get("edges", []) if e["to"] == concl and e.get("rel") == "support"]
    attacks = [e for e in graph.get("edges", []) if e["to"] == concl and e.get("rel") == "attack"]
    priors = {n["id"]: float(n.get("prior", 0.5)) for n in graph.get("nodes", [])}
    prod = 1.0
    for e in supports:
        prod *= (1.0 - priors.get(e["from"], 0.5))
    p = 1.0 - prod
    if not supports:
        p = priors.get(concl, 0.5) * 0.5  # 无支持 → 打折
    for e in attacks:
        p *= (1.0 - float(e.get("strength", 0.5)))
    return round(max(0.0, min(1.0, p)), 4)


def occam_rigor(graph: dict) -> float:
    """奥卡姆：节点/边越少、越简洁 → 越高分（同后验下）。"""
    n, m = len(graph.get("nodes", [])), len(graph.get("edges", []))
    rigor = 0.92 - 0.05 * max(0, n - 2) - 0.03 * m
    return round(max(0.2, min(0.95, rigor)), 4)


# ------------------------------------------------------------------ 影响图 / EV（#73）
# 节点类型：chance（概率/世界）、decision（决策/选择）、value（效用）
#          + 辩证层 claim/premise/evidence（向后兼容 v1）
NODE_TYPES = {"chance", "decision", "value", "claim", "premise", "evidence"}


def _nodes(graph: dict) -> dict:
    return {n["id"]: n for n in graph.get("nodes", []) if n.get("id")}


def _adj(graph: dict) -> dict:
    adj = {nid: [] for nid in _nodes(graph)}
    for e in graph.get("edges", []):
        if e.get("from") in adj and e.get("to") in adj:
            adj[e["from"]].append(e["to"])
    return adj


def _ancestors(graph: dict, target: str) -> set:
    """所有能到达 target 的节点（反向可达）。"""
    rev = {}
    for e in graph.get("edges", []):
        rev.setdefault(e.get("to"), []).append(e.get("from"))
    seen, stack = set(), [target]
    while stack:
        cur = stack.pop()
        for p in rev.get(cur, []):
            if p not in seen:
                seen.add(p)
                stack.append(p)
    return seen


def _has_cycle(graph: dict) -> bool:
    adj = _adj(graph)
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {k: WHITE for k in adj}

    def dfs(u):
        color[u] = GRAY
        for v in adj.get(u, []):
            if color.get(v) == GRAY:
                return True
            if color.get(v) == WHITE and dfs(v):
                return True
        color[u] = BLACK
        return False

    return any(color[k] == WHITE and dfs(k) for k in list(adj))


def _norm_ok(d: dict, tol: float = 0.02) -> tuple[bool, float]:
    try:
        s = sum(float(x) for x in d.values())
    except (TypeError, ValueError):
        return False, float("nan")
    return abs(s - 1.0) <= tol, round(s, 4)


def validate(graph: dict) -> dict:
    """影响图校验器：局部归一化 / 决策不赋概率 / 跨样本空间连乘 / 环。"""
    errors, warnings = [], []
    nodes = _nodes(graph)
    for n in nodes.values():
        t = n.get("type")
        if t == "chance":
            states = n.get("states")
            if not states:
                errors.append(f"chance 节点 {n['id']} 缺少 states")
            if "p" in n:
                ok, s = _norm_ok(n["p"])
                if not ok:
                    errors.append(f"chance 节点 {n['id']} 概率和={s} ≠ 1（局部未归一化）")
                if states and set(n["p"]) != set(states):
                    errors.append(f"chance 节点 {n['id']} 的 p 键与 states 不一致")
            if "p_by_parent" in n:
                for opt, dist in n["p_by_parent"].items():
                    ok, s = _norm_ok(dist)
                    if not ok:
                        errors.append(f"chance 节点 {n['id']}[{opt}] 概率和={s} ≠ 1")
            if "p" not in n and "p_by_parent" not in n:
                warnings.append(f"chance 节点 {n['id']} 未给概率")
        elif t == "decision":
            if any(k in n for k in ("p", "probability", "p_by_parent")):
                errors.append(f"决策节点 {n['id']} 被赋概率（范畴错误：概率描述世界，决策描述选择）")
            if not n.get("options"):
                errors.append(f"决策节点 {n['id']} 缺少 options")
        elif t == "value":
            oc = nodes.get(n.get("outcome"))
            if not oc or oc.get("type") != "chance":
                errors.append(f"value 节点 {n['id']} 的 outcome 必须指向一个 chance 节点")
            elif not set(n.get("utility", {})) >= set(oc.get("states", [])):
                errors.append(f"value 节点 {n['id']} 的 utility 未覆盖 outcome 的全部状态")
    if _has_cycle(graph):
        warnings.append("图中含环/回边：不能当作树做连乘，应按序列决策（MDP）处理")
    # 跨样本空间连乘：显式声明了不同 outcome_space 的 chance 节点不可混乘
    for v in [n for n in nodes.values() if n.get("type") == "value"]:
        oc = nodes.get(v.get("outcome"))
        if not oc:
            continue
        declared = {}
        if "outcome_space" in oc:
            declared[oc["id"]] = oc["outcome_space"]
        for a in _ancestors(graph, oc["id"]):
            an = nodes.get(a)
            if an and an.get("type") == "chance" and "outcome_space" in an:
                declared[an["id"]] = an["outcome_space"]
        if len(set(declared.values())) > 1:
            pairs = " vs ".join(f"{k}({s})" for k, s in declared.items())
            errors.append(f"跨样本空间连乘：{pairs} 量纲不同，EV 不可直接相乘")
    return {"ok": not errors, "errors": errors, "warnings": warnings}


def expected_value(graph: dict, value_id: str | None = None) -> dict | None:
    """结论节点的期望值：EV = Σ_s P(s|a)·U(s)。带决策父节点时给出每个选项的 EV。"""
    nodes = _nodes(graph)
    values = [n for n in nodes.values() if n.get("type") == "value"]
    if not values:
        return None
    v = next((n for n in values if n["id"] == value_id), values[0]) if value_id else values[0]
    oc = nodes.get(v.get("outcome"))
    if not oc or oc.get("type") != "chance":
        return None
    util = v.get("utility", {})
    states = oc.get("states", [])
    parent = oc.get("parent")
    if parent and oc.get("p_by_parent"):
        per = {}
        for opt in nodes.get(parent, {}).get("options", []):
            dist = oc["p_by_parent"].get(opt, {})
            per[opt] = round(sum(float(dist.get(s, 0)) * float(util.get(s, 0)) for s in states), 4)
        best = max(per, key=per.get) if per else None
        return {"value_id": v["id"], "outcome": oc["id"], "states": states,
                "ev": per.get(best) if best else None, "per_option": per, "best_option": best}
    dist = oc.get("p", {})
    ev = sum(float(dist.get(s, 0)) * float(util.get(s, 0)) for s in states)
    return {"value_id": v["id"], "outcome": oc["id"], "states": states, "ev": round(ev, 4)}


def evaluate(body: str, kind: str, provided: dict | None = None) -> dict:
    """返回 {graph, evidence, rigor, validation, ev}。"""
    if kind == "assertion":
        g = provided if (provided and provided.get("nodes")) else extract_graph(body, kind)
        ev, rg = posterior(g), occam_rigor(g)
    else:
        # 非断言：证据=来源可靠性的一半；rigor 固定中低
        g = provided if (provided and provided.get("nodes")) else extract_graph(body, kind)
        ev, rg = 0.5, 0.4
    val = validate(g)
    evd = expected_value(g)
    return {"graph": g, "evidence": ev, "rigor": rg,
            "validation": val, "ev": (evd or {}).get("ev"), "ev_detail": evd}


# ------------------------------------------------------------------ render
#: 降级原因只打印一次（旧实现 `except: pass` 静默降级，豆腐块坏了很久没人发现）
_FONT_WARNED = [False]
_PW_WARNED = [False]


def render_png(graph: dict, out_path: Path) -> str:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        return _render_playwright(graph, out_path)
    except Exception as e:                                    # noqa: BLE001
        if not _PW_WARNED[0]:
            _PW_WARNED[0] = True
            print(f"[render] playwright 不可用，降级 pillow（{type(e).__name__}: {str(e)[:120]}）；"
                  "要恢复浏览器级渲染：pip install playwright && playwright install chromium")
        return _render_pillow(graph, out_path)


def _layout(graph: dict) -> tuple[dict, int, int]:
    """左→右分层布局（更像网络/流程图，正方形画布），结论在最右列。"""
    from collections import Counter
    nodes = graph.get("nodes", [])
    if not nodes:
        return {"others": [], "concl": {"id": "c", "text": "?"}, "pos": {}, "W": 360, "H": 220}, 360, 220
    concl = graph.get("conclusion", "c")
    ids = [n["id"] for n in nodes]
    adj = {i: [] for i in ids}
    for e in graph.get("edges", []):
        a, b = e.get("from"), e.get("to")
        if a in adj and b in adj:
            adj[a].append(b)
    layer = {i: 0 for i in ids}
    for _ in range(len(ids) + 1):
        changed = False
        for u in ids:
            for v in adj[u]:
                if layer[v] < layer[u] + 1:
                    layer[v] = layer[u] + 1
                    changed = True
        if not changed:
            break
    maxL = max(layer.values())
    if concl in layer:
        layer[concl] = maxL
    cnt = Counter(layer.values())
    maxrows = max(cnt.values()) if cnt else 1
    DX, DY = 210, 96
    W = (maxL + 1) * DX + 160
    H = maxrows * DY + 100
    pos = {}
    for L in range(maxL + 1):
        col = [n for n in nodes if layer[n["id"]] == L]
        for k, n in enumerate(col):
            x = 92 + L * DX                                # 卡片半宽 78 → 左边距 14px，不再切图
            y = 70 + k * DY + (maxrows - len(col)) * DY // 2
            pos[n["id"]] = (x, y)
    others = [n for n in nodes if n["id"] != concl]
    concl_node = next((n for n in nodes if n["id"] == concl), {"id": concl, "text": "?"})
    return {"others": others, "concl": concl_node, "pos": pos, "W": W, "H": H}, W, H


def _node_label(n: dict, evd: dict | None) -> str:
    t = n.get("type") or n.get("source_type", "")
    extra = ""
    if n.get("type") == "decision" and n.get("options"):
        extra = "［" + "/".join(str(o) for o in n["options"]) + "］"
    if n.get("type") == "chance" and n.get("states"):
        extra = "{" + ",".join(str(s) for s in n["states"]) + "}"
    if n.get("type") == "value" and evd and evd.get("value_id") == n["id"]:
        extra = f"EV={evd.get('ev')}"
    return f"{t}{(' ' + extra) if extra else ''}"


_RENDER_CSS = (
    '<style>'
    'body{margin:0;background:#fbfbfd;font-family:-apple-system,"PingFang SC","Noto Sans SC",sans-serif}'
    '.node{position:absolute;width:156px;box-sizing:border-box;border-radius:12px;'
    'border:1px solid #d0d7de;padding:9px 8px 7px;box-shadow:0 2px 8px rgba(16,24,40,.07);text-align:center}'
    '.badge{position:absolute;top:-9px;left:9px;background:#0f1720;color:#fff;font-size:9px;'
    'border-radius:6px;padding:1px 7px;letter-spacing:.05em}'
    '.txt{font-size:12.5px;color:#1f2937;line-height:1.35;margin-top:5px;word-break:break-word}'
    '.ev{font-size:10px;color:#4338ca;margin-top:3px}'
    '.legend{position:absolute;left:14px;bottom:9px;display:flex;gap:6px;align-items:center;font-size:10px;color:#64748b}'
    '.lg,.edge{border-radius:5px;padding:1px 7px}'
    '.edge.sup{background:#dcfce7;color:#166534}.edge.att{background:#fee2e2;color:#991b1b}'
    '.cap{position:absolute;right:14px;bottom:9px;font-size:10px;color:#94a3b8}'
    '</style>'
)


def _render_playwright(graph: dict, out_path: Path) -> str:
    L, W, H = _layout(graph)
    evd = expected_value(graph)
    divs = []
    for n in L["others"] + [L["concl"]]:
        x, y = L["pos"][n["id"]]
        t = n.get("type") or n.get("source_type", "claim")
        color = NODE_COLOR.get(t, "#f6f8fa")
        badge = NODE_BADGE.get(t, t)
        extra = ""
        if t == "value" and evd and evd.get("value_id") == n["id"]:
            extra = f'<div class="ev">EV={evd.get("ev")}</div>'
        elif t == "decision" and n.get("options"):
            extra = f'<div class="ev">{_esc(" / ".join(map(str, n["options"])))}</div>'
        elif t == "chance" and n.get("states"):
            extra = f'<div class="ev">{_esc(" / ".join(map(str, n["states"])))}</div>'
        divs.append(f'<div class="node" style="left:{x-78}px;top:{y-26}px;background:{color}">'
                    f'<span class="badge">{_esc(badge)}</span>'
                    f'<div class="txt">{_esc(_short(n.get("text", "")))}</div>{extra}</div>')
    svg = [f'<svg width="{W}" height="{H}" style="position:absolute;left:0;top:0">',
           '<defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto">'
           '<path d="M0,0 L7,3 L0,6" fill="#64748b"/></marker></defs>']
    for e in graph.get("edges", []):
        a, b = L["pos"].get(e.get("from")), L["pos"].get(e.get("to"))
        if not a or not b:
            continue
        attack = e.get("rel") == "attack"
        col = "#dc2626" if attack else "#16a34a"
        dash = 'stroke-dasharray="6,4"' if attack else ""
        svg.append(f'<line x1="{a[0]+78}" y1="{a[1]}" x2="{b[0]-78}" y2="{b[1]}" stroke="{col}" '
                   f'stroke-width="2" {dash} marker-end="url(#ah)"/>')
    svg.append('</svg>')
    legend = ('<div class="legend">'
              '<span class="lg" style="background:#e0e7ff">结论</span>'
              '<span class="lg" style="background:#f3e8ff">前提</span>'
              '<span class="lg" style="background:#fff7e6">证据</span>'
              '<span class="lg" style="background:#dcfce7">效用</span>'
              '<span class="lg" style="background:#e0f2fe">决策</span>'
              '<span class="lg" style="background:#fff7cc">概率</span>'
              '<span class="edge sup">支持</span><span class="edge att">攻击</span></div>')
    html = (f'<html><head>{_RENDER_CSS}</head><body><div style="position:relative;'
            f'width:{W}px;height:{H}px">{"".join(svg)}{"".join(divs)}{legend}</div></body></html>')
    tmp = out_path.with_suffix(".html")
    tmp.write_text(html, encoding="utf-8")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={"width": W, "height": H})
        pg.goto(tmp.as_uri())
        pg.screenshot(path=str(out_path))
        b.close()
    return str(out_path)


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _render_pillow(graph: dict, out_path: Path) -> str:
    from PIL import Image, ImageDraw
    L, W, H = _layout(graph)
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    # 中文字体（2026-10-31 事故）：PIL 默认位图字体没有 CJK 字形 → 豆腐块。
    f_badge, fpath = load_cjk_font(11)
    f_text, _ = load_cjk_font(12)
    if not fpath and not _FONT_WARNED[0]:
        _FONT_WARNED[0] = True
        print("[render] 未找到中文字体：中文标签会渲染成豆腐块。"
              "请装 Hiragino Sans GB / Noto Sans CJK，或安装 playwright 走浏览器渲染")
    for e in graph.get("edges", []):
        a, b = L["pos"].get(e["from"]), L["pos"].get(e["to"])
        if not a or not b:
            continue
        col = (220, 38, 38) if e.get("rel") == "attack" else (22, 163, 74)
        d.line([a[0] + 78, a[1], b[0] - 78, b[1]], fill=col, width=2)
    evd = expected_value(graph)
    hexmap = {"claim": (224, 231, 255), "premise": (243, 232, 255), "evidence": (255, 247, 230),
              "chance": (255, 247, 204), "decision": (224, 242, 254), "value": (220, 252, 231)}
    for n in L["others"] + [L["concl"]]:
        x, y = L["pos"][n["id"]]
        t = n.get("type") or n.get("source_type")
        fill = hexmap.get(t, (246, 248, 250))
        d.rounded_rectangle([x - 78, y - 24, x + 78, y + 24], radius=10, fill=fill, outline=(208, 215, 222))
        badge = _esc(NODE_BADGE.get(t, t or ""))
        label = _short(n.get("text", ""), 14)
        for txt, yy, fnt, col in ((badge, y - 18, f_badge, (15, 23, 32)),
                                  (label, y - 2, f_text, (31, 35, 40))):
            if not txt:
                continue
            try:
                w = d.textlength(txt, font=fnt)          # 居中且不溢出卡片（156px）
            except Exception:                             # noqa: BLE001
                w = len(txt) * 7
            d.text((x - min(w / 2, 72), yy), txt, font=fnt, fill=col)
    img.save(out_path)
    return str(out_path)


# ---------------------------------------------------------------- 中文字体（2026-10-31）
# 事故：聊天室论证图在无 playwright 时降级到 PIL，而 `_render_pillow` 用 PIL **默认位图
# 字体**（无 CJK 字形）→ 中文全渲染成豆腐块 □□□，且 `except` 静默吞掉，坏了很久没报。
# 这里按候选表找**真实存在且能加载**的中文字体；找不到就明确告警，绝不用默认字体冒充。
CJK_FONT_CANDIDATES: tuple[str, ...] = (
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
)
_FONT_CACHE: dict = {}


def cjk_font_path() -> str:
    """第一个可用中文字体路径；没有则空串（**不**返回默认字体）。"""
    if "path" in _FONT_CACHE:
        return _FONT_CACHE["path"]
    hit = ""
    for p in CJK_FONT_CANDIDATES:
        try:
            if Path(p).is_file():
                hit = p
                break
        except OSError:
            continue
    _FONT_CACHE["path"] = hit
    return hit


def load_cjk_font(size: int):
    """加载中文字体，返回 `(font, path)`；path 为空表示本机没有中文字体。"""
    key = f"f{size}"
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    from PIL import ImageFont
    path = cjk_font_path()
    font = None
    if path:
        try:
            font = ImageFont.truetype(path, size)
        except Exception:                                     # noqa: BLE001
            font = None
    if font is None:
        path = ""
        try:
            font = ImageFont.load_default()
        except Exception:                                     # noqa: BLE001
            font = None
    _FONT_CACHE[key] = (font, path)
    return font, path
