"""P2P 事件拉取循环（docs/532 · P-C，修 docs/513 N3）。

背景：`peer_sync.sync_from_peer` 之前**全仓无调用点** —— 事件只推不拉。
对端把结果帖写在自己库里，本机永远不会去取，于是 `/app/p/<id>` 在本机 404，
这就是"死链"的根因。

做法：按 `peer_nodes`（中心下发的节点目录）逐个增量拉，游标由
`p2p_cursors` 维护（在 `sync_from_peer` 内部），拉回来的消息由
`apply_events` 直接派活（source='p2p'）。

边界：
* 没有 `TAA_PEER_TOKEN` 直接跳过（beta 用共享密钥；owner/group grant 另立项）。
* 单次最多拉 `TAA_PEER_PULL_PEERS`（默认 5）个对端，避免一轮卡太久。
* 单个对端失败只记进返回值，不抛、不影响其它对端，更不影响主循环。
* 节流 `TAA_PEER_PULL_SECONDS`（默认 20 秒），`force=True` 可绕过。
"""

from __future__ import annotations

import json
import os
import time

from . import peer_sync

_LAST: dict = {"at": 0.0}


def _token() -> str:
    return (os.environ.get("TAA_PEER_TOKEN") or "").strip()


def _int_env(name: str, default: int, floor: int = 1) -> int:
    try:
        return max(floor, int(os.environ.get(name, str(default))))
    except (TypeError, ValueError):
        return default


def _allow_unsigned() -> bool:
    return str(os.environ.get("TAA_PEER_ALLOW_UNSIGNED") or "") not in ("", "0", "false", "False")


def peer_bases(conn, limit: int | None = None) -> list[tuple[str, str]]:
    """[(node_id, base_url)]：优先探测出的 selected_url，其次 endpoint_json 里的 http 地址。"""
    try:
        rows = conn.execute(
            "select node_id, selected_url, endpoint_json from peer_nodes "
            "order by coalesce(latency_ms, 99999)").fetchall()
    except Exception:                                            # noqa: BLE001
        return []
    out: list[tuple[str, str]] = []
    seen: set[str] = set()
    for r in rows:
        node_id = str(r["node_id"] or "")
        cands: list[str] = []
        sel = str((r["selected_url"] or "")).strip()
        if sel.startswith("http"):
            cands.append(sel)
        try:
            eps = json.loads(r["endpoint_json"] or "[]")
        except Exception:                                        # noqa: BLE001
            eps = []
        for ep in eps if isinstance(eps, list) else []:
            u = str(ep or "").strip()
            if u.startswith("http"):
                cands.append(u)
        for u in cands:
            base = u.rstrip("/")
            if base in seen:
                continue
            seen.add(base)
            out.append((node_id, base))
            break
    return out[:limit] if limit else out


def pull_all(conn, *, force: bool = False, limit: int | None = None) -> dict:
    """拉一轮。返回结构化结果，绝不抛异常。"""
    now = time.time()
    every = _int_env("TAA_PEER_PULL_SECONDS", 20, floor=5)
    if not force and now - float(_LAST["at"] or 0) < every:
        return {"ok": True, "skipped": "interval", "peers": 0}
    _LAST["at"] = now
    token = _token()
    if not token:
        return {"ok": True, "skipped": "no_token", "peers": 0}
    cap = limit if limit is not None else _int_env("TAA_PEER_PULL_PEERS", 5, floor=1)
    bases = peer_bases(conn, cap)
    results: list[dict] = []
    errors: list[str] = []
    applied = 0
    for node_id, base in bases:
        try:
            res = peer_sync.sync_from_peer(base, token, conn, log=None,
                                           allow_unsigned=_allow_unsigned())
            applied += int(res.get("applied") or 0)
            results.append({"node": node_id, "peer": base, "events": int(res.get("events") or 0),
                            "applied": int(res.get("applied") or 0),
                            "next_since": int(res.get("next_since") or 0),
                            "ok": bool(res.get("ok"))})
            for e in res.get("blob_errors") or []:
                errors.append(f"{base}: blob {e}")
        except Exception as exc:                                 # noqa: BLE001
            errors.append(f"{base}: {type(exc).__name__}: {exc}"[:200])
    return {"ok": not errors, "peers": len(bases), "applied": applied,
            "results": results, "errors": errors[:10]}
