"""scene —— 按「此刻几点、工作日还是周末」推断在做什么、在哪。

为什么不靠 LLM：这一步是**确定性的日程推断**，规则清楚、可解释、可测试；
LLM 只在需要润色语气时参与。参考历史上的
`soul/scripts/virtual_girlfriend_v2.py: get_current_activity()`。

输出同时给两处用：
  · weather.recommend(scene=...)  —— 选该场合合适的单品；
  · weather.image_prompt(...)     —— 决定背景、光线、姿态。

数据在 `presets/scenes.yaml`，改作息不用动代码。
"""
from __future__ import annotations

import datetime as _dt
import pathlib
from zoneinfo import ZoneInfo

ROOT = pathlib.Path(__file__).resolve().parent.parent
SCENES_PATH = ROOT / "presets" / "scenes.yaml"

_CACHE: dict = {}

#: 场景 → 姿态短语（生图用；避免所有图都是「行走」一种姿势）
_POSE = {
    "sleeping": "刚睡醒或正要休息，靠在床头或坐在床边，头发松松的",
    "morning": "站在洗漱台前，毛巾搭在肩上",
    "commute": "走在人行道上或站在站台等车，肩上挎着包",
    "working": "坐在书桌前，手边摊着笔记本和一杯水，视线落在屏幕上",
    "lunch": "坐在沙发上稍微放松，手里端着杯子",
    "cooking": "站在厨房台面前，袖子挽到手肘",
    "evening": "窝在沙发一角，腿收起来，姿态松散",
    "reading": "靠坐在床头或沙发里看书，灯光偏暗",
    "exercise": "刚做完一组动作，站在垫子边调整呼吸",
    "outing": "在公园步道上散步，手里拿着一杯外带咖啡",
}


def load() -> dict:
    """读取场景表（带缓存）；文件缺失时返回空表，调用方自行降级。"""
    if _CACHE:
        return _CACHE
    data: dict = {}
    if SCENES_PATH.is_file():
        try:
            import yaml
            data = yaml.safe_load(SCENES_PATH.read_text(encoding="utf-8")) or {}
        except Exception:  # noqa: BLE001 —— 坏了不能阻断出图
            data = {}
    _CACHE.update(data)
    return _CACHE


def _daypart(hour: int) -> str:
    if hour < 5:
        return "凌晨"
    if hour < 8:
        return "早上"
    if hour < 11:
        return "上午"
    if hour < 13:
        return "中午"
    if hour < 17:
        return "下午"
    if hour < 19:
        return "傍晚"
    if hour < 23:
        return "晚上"
    return "深夜"


def current(tz: str = "Asia/Shanghai", now: _dt.datetime | None = None) -> dict:
    """返回当前场景。任何异常都降级为「白天在家」，绝不抛给调用方。"""
    data = load()
    try:
        zone = ZoneInfo(tz or "Asia/Shanghai")
    except Exception:  # noqa: BLE001
        zone = ZoneInfo("Asia/Shanghai")
    if now is None:
        now = _dt.datetime.now(zone)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=zone)

    hour = now.hour
    is_weekend = now.weekday() >= 5
    table = data.get("weekend" if is_weekend else "weekday") or []
    row = None
    for it in table:
        try:
            if int(it.get("start", 0)) <= hour < int(it.get("end", 24)):
                row = it
                break
        except Exception:  # noqa: BLE001
            continue
    if row is None:
        row = {"id": "home", "name": "在家", "room": "living", "scene": "home", "mood": "放松"}

    rooms = data.get("rooms") or {}
    room = rooms.get(str(row.get("room") or "")) or {}
    sid = str(row.get("id") or "home")
    light = str(room.get("light") or "自然光，柔和")
    # 光线必须跟着钟点走：晚间不能再出现「白天自然光」（实测 21:00 出过白天的图）
    if hour >= 19 or hour < 6:
        light = "室内暖色灯光为主，窗外是夜色，柔和"
    elif 6 <= hour < 9:
        light = "清晨的侧光，偏冷且柔"
    elif 17 <= hour < 19:
        light = "傍晚的暖调斜光"
    return {
        "id": sid,
        "name": str(row.get("name") or ""),
        "room": str(room.get("room") or "干净整洁的室内"),
        "room_name": str(room.get("name") or ""),
        "light": light,
        "indoor": bool(row.get("indoor", True)),
        "scene": str(row.get("scene") or "home"),
        "mood": str(row.get("mood") or ""),
        "pose": _POSE.get(sid, "自然站着或坐着，姿态放松"),
        "hour": hour,
        "weekend": is_weekend,
        "daypart": _daypart(hour),
        "clock": now.strftime("%H:%M"),
        "tz": str(getattr(zone, "key", tz) or tz),
    }
