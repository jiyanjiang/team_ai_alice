"""Owner/agent identity boundary.

`agents.owner_id` is the canonical owner relation.  The local `human` and
`remote-human-*` rows are projections only; routing and execution must use the
owner id, never display names.
"""
from __future__ import annotations

from dataclasses import dataclass


class OwnerIdentityError(ValueError):
    pass


@dataclass(frozen=True)
class AgentIdentity:
    agent_id: str
    kind: str
    owner_id: str


def lookup(conn, agent_id: str) -> AgentIdentity | None:
    if not agent_id:
        return None
    row = conn.execute(
        "select id,kind,owner_id from agents where id=?", (agent_id,)).fetchone()
    if not row:
        return None
    return AgentIdentity(str(row["id"]), str(row["kind"] or ""),
                         str(row["owner_id"] or ""))


def require_agent_owner(conn, agent_id: str, expected_owner_id: str = "") -> AgentIdentity:
    ident = lookup(conn, agent_id)
    if ident is None:
        raise OwnerIdentityError("unknown_agent")
    if ident.kind != "ai":
        raise OwnerIdentityError("not_an_agent")
    if not ident.owner_id:
        raise OwnerIdentityError("agent_owner_missing")
    if expected_owner_id and ident.owner_id != expected_owner_id:
        raise OwnerIdentityError("agent_owner_mismatch")
    return ident


def require_human_owner(conn, agent_id: str, expected_owner_id: str = "") -> AgentIdentity:
    ident = lookup(conn, agent_id)
    if ident is None:
        raise OwnerIdentityError("unknown_human")
    if ident.kind != "human":
        raise OwnerIdentityError("not_a_human")
    if not ident.owner_id:
        raise OwnerIdentityError("human_owner_missing")
    if expected_owner_id and ident.owner_id != expected_owner_id:
        raise OwnerIdentityError("human_owner_mismatch")
    return ident
