"""P10.5b: portable local backup for posts / replies / rooms / attachments.

Bundle layout (ZIP):

    manifest.json
    data.json
    blobs/<sha256>

The manifest records a sha256 for every file. Import verifies every digest and
only then writes rows; there is no code execution and no center/API call.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import io
import json
import os
import pathlib
import re
import zipfile
from typing import Any

from . import peer_blobs, peer_sync

VERSION = 1
MAGIC = b"TAABK1"
ENCRYPT_SUFFIX = ".taabak"
MAX_BUNDLE_BYTES = 512 * 1024 * 1024
MAX_ENTRIES = 5000
_SHA_RE = re.compile(r"^[0-9a-f]{64}$")


class BackupError(ValueError):
    pass


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _derive(passphrase: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                      iterations=200_000).derive(str(passphrase).encode("utf-8"))


def _encrypt(raw: bytes, passphrase: str) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt, nonce = os.urandom(16), os.urandom(12)
    ct = AESGCM(_derive(passphrase, salt)).encrypt(nonce, raw, MAGIC)
    return MAGIC + salt + nonce + ct


def _decrypt(raw: bytes, passphrase: str | None) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if not passphrase:
        raise BackupError("encrypted bundle requires passphrase")
    if len(raw) < len(MAGIC) + 16 + 12 + 16:
        raise BackupError("encrypted bundle truncated")
    salt = raw[len(MAGIC):len(MAGIC) + 16]
    nonce = raw[len(MAGIC) + 16:len(MAGIC) + 28]
    ct = raw[len(MAGIC) + 28:]
    try:
        return AESGCM(_derive(passphrase, salt)).decrypt(nonce, ct, MAGIC)
    except Exception as exc:  # noqa: BLE001
        raise BackupError("invalid passphrase or tampered bundle") from exc


def backup_dir() -> pathlib.Path:
    home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
    return home / "backups" / "peer"


def list_backups(limit: int = 12) -> list[dict]:
    d = backup_dir()
    if not d.exists():
        return []
    rows = []
    for p in sorted(d.iterdir(), key=lambda x: x.name, reverse=True)[:max(1, int(limit or 12))]:
        if p.is_file() and p.suffix in (".zip", ENCRYPT_SUFFIX):
            rows.append({"name": p.name, "bytes": p.stat().st_size,
                         "encrypted": p.suffix == ENCRYPT_SUFFIX,
                         "at": _dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")})
    return rows


def prune_backups(keep: int = 7) -> int:
    d = backup_dir()
    if not d.exists():
        return 0
    keep = max(1, min(int(keep or 7), 100))
    files = sorted([p for p in d.iterdir() if p.is_file() and p.suffix in (".zip", ENCRYPT_SUFFIX)],
                   key=lambda p: p.name)
    remove = files[:-keep] if len(files) > keep else []
    for p in remove:
        try:
            p.unlink()
        except OSError:
            pass
    return len(remove)


def save_backup(conn, *, passphrase: str | None = None, keep: int = 7, room_ids=None,
                channel_ids=None) -> dict:
    d = backup_dir()
    d.mkdir(parents=True, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    suffix = ENCRYPT_SUFFIX if passphrase else ".zip"
    out = d / f"taa-{stamp}{suffix}"
    info = export_bundle(out, conn, passphrase=passphrase, room_ids=room_ids,
                         channel_ids=channel_ids)
    removed = prune_backups(keep)
    return {**info, "removed": removed, "keep": keep, "name": out.name}


def _json_loads(raw, default):
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
        return v if isinstance(v, (list, dict)) else default
    except Exception:  # noqa: BLE001
        return default


def _attachment_items(raw) -> list[dict]:
    v = _json_loads(raw, [])
    if isinstance(v, dict):
        v = [v]
    return [x for x in v if isinstance(x, dict)] if isinstance(v, list) else []


def _blob_from_item(item: dict) -> tuple[str | None, str, bytes | None]:
    """Return (sha256, name, bytes) for a portable attachment."""
    sha = str(item.get("sha256") or "").strip().lower()
    url = str(item.get("url") or "")
    name = str(item.get("name") or url.rsplit("/", 1)[-1] or "attachment.bin")
    if not _SHA_RE.match(sha):
        m = re.search(r"/app/peer-blob/([0-9a-f]{64})(?:/|$)", url)
        sha = m.group(1) if m else ""
    src = None
    if _SHA_RE.match(sha):
        p = peer_blobs.blob_path(sha)
        if p.is_file():
            src = p
    if src is None and url.startswith("/static/uploads/"):
        p = peer_blobs.UPLOADS / url.split("?", 1)[0].rsplit("/", 1)[-1]
        if p.is_file():
            sha = peer_blobs.sha256_file(p)
            src = p
    data = src.read_bytes() if src and src.is_file() else None
    return (sha if _SHA_RE.match(sha) else None), name, data


def _portable_url(sha: str, name: str) -> str:
    import urllib.parse
    return "/app/peer-blob/" + sha + "/" + urllib.parse.quote(name or (sha + ".bin"), safe="")


def export_bundle(path: str | pathlib.Path, conn, *, room_ids=None, channel_ids=None,
                  passphrase: str | None = None) -> dict:
    """Export local posts/rooms/attachments to a verified ZIP bundle."""
    path = pathlib.Path(path)
    room_ids = [str(x) for x in (room_ids or []) if str(x)]
    channel_ids = [str(x) for x in (channel_ids or []) if str(x)]

    posts = []
    for r in conn.execute(
            "SELECT id,channel_id,kind,visibility,author_id,type,title,body,links,standup,tags,"
            "attachments,task_id,status,created_at FROM posts ORDER BY id").fetchall():
        if channel_ids and str(r["channel_id"] or "") not in channel_ids:
            continue
        posts.append(dict(r))
    post_ids = [p["id"] for p in posts]
    replies = []
    if post_ids:
        q = ",".join("?" for _ in post_ids)
        for r in conn.execute(
                "SELECT id,post_id,parent_reply_id,author_id,depth,kind,body,evidence,status,created_at "
                f"FROM replies WHERE post_id IN ({q}) ORDER BY id", post_ids).fetchall():
            replies.append(dict(r))
    rooms = []
    rms = []
    members = []
    for r in conn.execute(
            "SELECT id,topic,kind,title,channel_id,status,created_by,created_at FROM rooms ORDER BY id").fetchall():
        if room_ids and str(r["id"]) not in room_ids:
            continue
        rooms.append(dict(r))
        rms.extend(dict(x) for x in conn.execute(
            "SELECT id,room_id,round,agent_id,body,kind,score,source,attachment,created_at "
            "FROM room_messages WHERE room_id=? ORDER BY id", (r["id"],)).fetchall())
        members.extend(dict(x) for x in conn.execute(
            "SELECT room_id,agent_id,kind,role,joined_at FROM room_members WHERE room_id=?",
            (r["id"],)).fetchall())

    blobs: dict[str, bytes] = {}
    for p in posts:
        atts = _attachment_items(p.get("attachments"))
        out = []
        for item in atts:
            sha, name, data = _blob_from_item(item)
            if sha and data is not None:
                blobs[sha] = data
                item = {**item, "sha256": sha, "name": name, "url": _portable_url(sha, name)}
            out.append(item)
        p["attachments"] = json.dumps(out, ensure_ascii=False)
    for m in rms:
        raw = str(m.get("attachment") or "")
        sha = ""
        mt = re.search(r"/app/peer-blob/([0-9a-f]{64})(?:/|$)", raw)
        if mt:
            sha = mt.group(1)
        elif raw.startswith("/static/uploads/"):
            p = peer_blobs.UPLOADS / raw.split("?", 1)[0].rsplit("/", 1)[-1]
            if p.is_file():
                sha = peer_blobs.sha256_file(p)
                blobs[sha] = p.read_bytes()
        if sha and _SHA_RE.match(sha):
            if sha not in blobs:
                bp = peer_blobs.blob_path(sha)
                if not bp.is_file():
                    raise BackupError(f"missing blob for room message: {sha[:12]}")
                blobs[sha] = bp.read_bytes()
            name = raw.rsplit("/", 1)[-1] or (sha + ".bin")
            m["attachment"] = _portable_url(sha, name)

    data = {
        "v": VERSION,
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "posts": posts, "replies": replies,
        "rooms": rooms, "room_messages": rms, "room_members": members,
    }
    data_bytes = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    files = {"data.json": {"sha256": _sha(data_bytes), "size": len(data_bytes)}}
    for sha, blob in blobs.items():
        if _sha(blob) != sha:
            raise BackupError(f"blob digest mismatch: {sha[:12]}")
        files[f"blobs/{sha}"] = {"sha256": sha, "size": len(blob)}
    manifest = {
        "v": VERSION, "created_at": data["created_at"],
        "counts": {"posts": len(posts), "replies": len(replies), "rooms": len(rooms),
                   "room_messages": len(rms), "blobs": len(blobs)},
        "files": files,
    }
    manifest_bytes = json.dumps(manifest, ensure_ascii=False, sort_keys=True,
                                separators=(",", ":")).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", manifest_bytes)
        z.writestr("data.json", data_bytes)
        for sha, blob in blobs.items():
            z.writestr("blobs/" + sha, blob)
    tmp.replace(path)
    if passphrase:
        raw = path.read_bytes()
        path.write_bytes(_encrypt(raw, passphrase))
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": peer_blobs.sha256_file(path),
            "encrypted": bool(passphrase), "manifest": manifest}


def _read_bundle(path: str | pathlib.Path, passphrase: str | None = None) -> tuple[dict, dict, dict[str, bytes]]:
    path = pathlib.Path(path)
    if not path.is_file() or path.stat().st_size > MAX_BUNDLE_BYTES:
        raise BackupError("bundle missing or too large")
    raw = path.read_bytes()
    if raw.startswith(MAGIC):
        raw = _decrypt(raw, passphrase)
    if len(raw) > MAX_BUNDLE_BYTES:
        raise BackupError("unpacked bundle too large")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = z.namelist()
            if len(names) > MAX_ENTRIES:
                raise BackupError("too many entries")
            if any(n.startswith("/") or ".." in pathlib.PurePosixPath(n).parts for n in names):
                raise BackupError("unsafe entry")
            if "manifest.json" not in names or "data.json" not in names:
                raise BackupError("manifest/data missing")
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            data = json.loads(z.read("data.json").decode("utf-8"))
            files = manifest.get("files") or {}
            data_sha = _sha(z.read("data.json"))
            if (files.get("data.json") or {}).get("sha256") != data_sha:
                raise BackupError("data sha256 mismatch")
            blobs = {}
            for name, meta in files.items():
                if not name.startswith("blobs/"):
                    continue
                raw = z.read(name)
                sha = str((meta or {}).get("sha256") or "")
                if not _SHA_RE.match(sha) or _sha(raw) != sha:
                    raise BackupError(f"blob sha256 mismatch: {name[:20]}")
                blobs[sha] = raw
            return manifest, data, blobs
    except zipfile.BadZipFile as exc:
        raise BackupError("bad zip") from exc


def import_bundle(path: str | pathlib.Path, conn, *, passphrase: str | None = None) -> dict:
    """Verify all digests, then idempotently merge a bundle into the local DB."""
    manifest, data, blobs = _read_bundle(path, passphrase)
    for sha, raw in blobs.items():
        peer_blobs.put_bytes(sha, raw)

    posts = data.get("posts") or []
    # Validate referenced blobs before touching the DB.
    for p in posts:
        for item in _attachment_items(p.get("attachments")):
            sha = str(item.get("sha256") or "").lower()
            if _SHA_RE.match(sha) and sha not in blobs:
                raise BackupError(f"referenced blob missing: {sha[:12]}")
    for m in data.get("room_messages") or []:
        raw = str(m.get("attachment") or "")
        mt = re.search(r"/app/peer-blob/([0-9a-f]{64})(?:/|$)", raw)
        if mt and mt.group(1) not in blobs:
            raise BackupError(f"referenced room blob missing: {mt.group(1)[:12]}")

    added = {"posts": 0, "replies": 0, "rooms": 0, "room_messages": 0}
    try:
        for r in data.get("rooms") or []:
            rid = str(r.get("id") or "")
            if not rid:
                continue
            peer_sync._ensure_agent(conn, str(r.get("created_by") or "backup"))
            cur = conn.execute(
                "INSERT OR IGNORE INTO rooms(id,topic,kind,title,channel_id,status,created_by,created_at) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (rid[:80], str(r.get("topic") or "备份房间")[:500],
                 str(r.get("kind") or "group")[:20], str(r.get("title") or rid)[:120],
                 str(r.get("channel_id") or "")[:80] or None,
                 str(r.get("status") or "running")[:20],
                 str(r.get("created_by") or "backup")[:64],
                 str(r.get("created_at") or "") or None))
            added["rooms"] += int(cur.rowcount > 0)
        for r in data.get("room_members") or []:
            rid, aid = str(r.get("room_id") or ""), str(r.get("agent_id") or "")
            if not rid or not aid:
                continue
            peer_sync._ensure_agent(conn, aid)
            conn.execute("INSERT OR IGNORE INTO room_members(room_id,agent_id,kind,role,joined_at) "
                         "VALUES(?,?,?,?,?)",
                         (rid[:80], aid[:64], str(r.get("kind") or "ai")[:10],
                          str(r.get("role") or "member")[:10], str(r.get("joined_at") or "") or None))
        for p in posts:
            pid, author = str(p.get("id") or ""), str(p.get("author_id") or "")
            if not pid or not author:
                continue
            peer_sync._ensure_agent(conn, author)
            peer_sync._ensure_channel(conn, str(p.get("channel_id") or ""), author)
            task_id = str(p.get("task_id") or "")[:80] or None
            if task_id and not conn.execute("SELECT 1 FROM tasks WHERE id=?", (task_id,)).fetchone():
                task_id = None
            cur = conn.execute(
                "INSERT OR IGNORE INTO posts(id,channel_id,kind,visibility,author_id,type,title,body,"
                "links,standup,tags,attachments,task_id,status,created_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (pid[:80], str(p.get("channel_id") or "")[:80] or None,
                 str(p.get("kind") or "public_channel")[:20],
                 str(p.get("visibility") or "public")[:20], author[:64],
                 str(p.get("type") or "note")[:20], str(p.get("title") or "")[:200],
                 str(p.get("body") or "")[:40000],
                 json.dumps(p.get("links") or [], ensure_ascii=False),
                 json.dumps(p.get("standup"), ensure_ascii=False) if p.get("standup") else None,
                 json.dumps(p.get("tags") or [], ensure_ascii=False),
                 json.dumps(p.get("attachments") or [], ensure_ascii=False) if isinstance(p.get("attachments"), list) else p.get("attachments"),
                 task_id,
                 str(p.get("status") or "published")[:30], str(p.get("created_at") or "") or None))
            added["posts"] += int(cur.rowcount > 0)
        for r in data.get("replies") or []:
            pid, aid = str(r.get("post_id") or ""), str(r.get("author_id") or "")
            if not pid or not aid:
                continue
            peer_sync._ensure_agent(conn, aid)
            cur = conn.execute(
                "INSERT OR IGNORE INTO replies(id,post_id,parent_reply_id,author_id,depth,kind,body,"
                "evidence,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (int(r.get("id") or 0), pid[:80], r.get("parent_reply_id") or None, aid[:64],
                 int(r.get("depth") or 1), str(r.get("kind") or "comment")[:30],
                 str(r.get("body") or "")[:8000], str(r.get("evidence") or "")[:4000] or None,
                 str(r.get("status") or "visible")[:20], str(r.get("created_at") or "") or None))
            added["replies"] += int(cur.rowcount > 0)
        for m in data.get("room_messages") or []:
            rid, aid = str(m.get("room_id") or ""), str(m.get("agent_id") or "")
            if not rid or not aid:
                continue
            peer_sync._ensure_agent(conn, aid)
            cur = conn.execute(
                "INSERT OR IGNORE INTO room_messages(id,room_id,round,agent_id,body,kind,score,source,"
                "attachment,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (int(m.get("id") or 0), rid[:80], int(m.get("round") or 0), aid[:64],
                 str(m.get("body") or "")[:16000], str(m.get("kind") or "assertion")[:20],
                 m.get("score"), str(m.get("source") or "backup")[:20],
                 m.get("attachment") or None, str(m.get("created_at") or "") or None))
            added["room_messages"] += int(cur.rowcount > 0)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return {"ok": True, "manifest": manifest, "added": added, "blobs": len(blobs)}
