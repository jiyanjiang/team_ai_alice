"""跨局域网协作 · 中心节点上的「反向 HTTP 隧道」（v1）。

现状（`JOIN.md`）：第二台电脑是**客户端**，直接访问 A 的 `http://<A内网IP>:6080`。
跨局域网时 A 通常没有公网地址，B 无法直接连 A。中心节点 + 反向隧道解决这个问题：

    外部调用者（B/手机/其他组）
        │  HTTPS  https://hub/n/<node_id>/v1/...
        ▼
    中心节点（公网） ── 长轮询下发 ──▶ 节点侧 TunnelClient（只出站）
        ▲                                   │
        └──────── 回传响应 ◀───────────────┘  访问 127.0.0.1:6080

要点：
- 节点**只出站**，无需公网 IP / 端口映射；
- 转发时**剥掉 `/n/<node_id>` 前缀**，节点侧看到的仍是 `/v1/...`；
  因此 CLI 的 HMAC 签名（只签路径）**无需改动**即可穿过隧道；
- 调用方也必须带 `X-Hub-Token`，且与节点同组——中心不是开放代理。
"""
from __future__ import annotations

import base64
import json
import threading
import time
import uuid
from collections import deque

MAX_BODY = 32 * 1024 * 1024
NODE_ONLINE_SEC = 45.0
PULL_WAIT = 20.0
TIMEOUT = 30.0


class _Node:
    def __init__(self, node_id: str, group: str):
        self.node_id = node_id
        self.group = group
        self.pending: deque[dict] = deque()
        self.last_seen = time.time()
        self.pulling = False
        self.delivered = 0


class _Pending:
    def __init__(self, rid: str):
        self.rid = rid
        self.event = threading.Event()
        self.status = 504
        self.headers: list[tuple[str, str]] = []
        self.body = b""


class TunnelHub:
    """中心侧：按 node_id 排队 + 长轮询下发 + 等待回传。"""

    def __init__(self, timeout: float = TIMEOUT, pull_wait: float = PULL_WAIT,
                 online_sec: float = NODE_ONLINE_SEC):
        self.timeout = max(0.1, float(timeout))
        self.pull_wait = max(1.0, float(pull_wait))
        self.online_sec = max(0.1, float(online_sec))
        self._lock = threading.RLock()
        self._cond = threading.Condition(self._lock)
        self._nodes: dict[str, _Node] = {}
        self._waiting: dict[str, _Pending] = {}

    # ---------------- 节点侧 ----------------
    def touch(self, node_id: str, group: str) -> _Node:
        with self._lock:
            n = self._nodes.get(node_id)
            if n is None:
                n = self._nodes[node_id] = _Node(node_id, group)
            n.group = group
            n.last_seen = time.time()
            return n

    def group_of(self, node_id: str) -> str | None:
        with self._lock:
            n = self._nodes.get(node_id)
            return n.group if n else None

    def pull(self, node_id: str, group: str, wait: float | None = None) -> dict | None:
        """节点长轮询取一条待转发请求；没有则返回 None。"""
        wait = self.pull_wait if wait is None else max(0.0, min(float(wait), 60.0))
        end = time.time() + wait
        with self._cond:
            n = self.touch(node_id, group)
            if n.pulling:
                raise RuntimeError("another pull is already active for this node")
            n.pulling = True
            try:
                while not n.pending:
                    left = end - time.time()
                    if left <= 0:
                        return None
                    self._cond.wait(left)
                    n.last_seen = time.time()
                req = n.pending.popleft()
                n.delivered += 1
                return req
            finally:
                n.pulling = False
                n.last_seen = time.time()

    def respond(self, node_id: str, group: str, rid: str, status: int,
                headers: list[tuple[str, str]], body: bytes) -> bool:
        self.touch(node_id, group)
        with self._cond:
            p = self._waiting.pop(rid, None)
            if p is None:
                return False
            p.status = int(status)
            p.headers = headers[:50]
            p.body = body[:MAX_BODY]
            p.event.set()
            return True

    # ---------------- 外部调用侧 ----------------
    def forward(self, node_id: str, group: str, method: str, path: str,
                headers: list[tuple[str, str]], body: bytes) -> tuple[int, list[tuple[str, str]], bytes]:
        """把一次外部请求排给节点并等待回传；离线/超时返回 503/504。"""
        with self._lock:
            node = self._nodes.get(node_id)
            if not node or node.group != group:
                return 404, [("content-type", "application/json")], b'{"ok":false,"error":"unknown node"}'
            if time.time() - node.last_seen > self.online_sec:
                return 503, [("content-type", "application/json")], b'{"ok":false,"error":"node offline"}'
        rid = uuid.uuid4().hex
        p = _Pending(rid)
        with self._cond:
            self._waiting[rid] = p
            node.pending.append({"rid": rid, "method": method.upper(), "path": path,
                                 "headers": headers[:50],
                                 "body": base64.b64encode(body[:MAX_BODY]).decode("ascii")})
            self._cond.notify_all()
        if not p.event.wait(self.timeout):
            with self._lock:
                self._waiting.pop(rid, None)
            return 504, [("content-type", "application/json")], b'{"ok":false,"error":"node timeout"}'
        return p.status, p.headers, p.body

    def stats(self) -> dict:
        now = time.time()
        with self._lock:
            return {"nodes": [
                {"node_id": n.node_id, "group": n.group,
                 "online": now - n.last_seen <= self.online_sec,
                 "last_seen": n.last_seen, "pending": len(n.pending),
                 "delivered": n.delivered} for n in self._nodes.values()],
                "waiting": len(self._waiting)}
