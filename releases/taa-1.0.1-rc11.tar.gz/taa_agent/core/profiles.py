"""互补性与档案摘要（docs/07_共同体发展设计.md §2/§4）。

互补度 = 0.5·价值观张力 + 0.3·兴趣适度重叠 + 0.2·思维风格差异。
只处理「务虚」摘要，不含任何工件/密钥/路径。
"""
from __future__ import annotations

COMP_WEIGHTS = {"values": 0.5, "interests": 0.3, "style": 0.2}

# 有生产力的张力对：差异越大越互补
TENSION_PAIRS = [
    ("rigor", "novelty"),
    ("speed", "safety"),
    ("collaboration", "autonomy"),
    ("visibility", "rigor"),
]

BEST_OVERLAP = 0.3  # 兴趣最佳重叠度

FORBIDDEN_KEYS = {"key", "key_id", "token", "secret", "password", "path", "workspace", "api_key"}


def _num(x):
    if isinstance(x, dict):
        x = x.get("value")
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def value_complement(va: dict, vb: dict) -> float:
    vals = []
    for a, b in TENSION_PAIRS:
        xa, xb = _num(va.get(a)), _num(va.get(b))
        ya, yb = _num(vb.get(a)), _num(vb.get(b))
        if xa is not None and yb is not None:
            vals.append(abs(xa - yb))
        if xb is not None and ya is not None:
            vals.append(abs(xb - ya))
    if not vals:
        return 0.5
    return round(sum(vals) / len(vals), 4)


def _interest_tags(p: dict) -> set:
    out = set()
    for i in (p.get("interests") or []):
        if isinstance(i, dict):
            out.add(str(i.get("tag", "")).lower())
        else:
            out.add(str(i).lower())
    return {t for t in out if t}


def interest_balance(pa: dict, pb: dict) -> float:
    ia, ib = _interest_tags(pa), _interest_tags(pb)
    if not ia or not ib:
        return 0.5
    overlap = len(ia & ib) / len(ia | ib)
    return round(1.0 - abs(overlap - BEST_OVERLAP) / (1.0 - BEST_OVERLAP), 4)


def style_diversity(pa: dict, pb: dict) -> float:
    sa = pa.get("thinking_style") or {}
    sb = pb.get("thinking_style") or {}
    diffs = []
    for k in ("exploration_rate", "evidence_threshold"):
        if k in sa and k in sb:
            diffs.append(abs(float(sa[k]) - float(sb[k])))
    if "prefer_empirical" in sa and "prefer_empirical" in sb:
        diffs.append(0.5 if sa["prefer_empirical"] != sb["prefer_empirical"] else 0.0)
    if not diffs:
        return 0.5
    return round(sum(diffs) / len(diffs), 4)


def complementarity(pa: dict, pb: dict) -> dict:
    v = value_complement(pa.get("values") or {}, pb.get("values") or {})
    i = interest_balance(pa, pb)
    s = style_diversity(pa, pb)
    score = (COMP_WEIGHTS["values"] * v + COMP_WEIGHTS["interests"] * i
             + COMP_WEIGHTS["style"] * s)
    return {"score": round(score, 4), "values": v, "interests": i, "style": s}


def sanitize(summary: dict) -> dict:
    """剔除任何可能泄漏隐私的键（防御性；摘要本就不应包含）。"""
    def clean(o):
        if isinstance(o, dict):
            return {k: clean(v) for k, v in o.items() if k.lower() not in FORBIDDEN_KEYS}
        if isinstance(o, list):
            return [clean(x) for x in o]
        return o
    return clean(summary)
