"""对等网络层（S4）：事件溯源 + gossip。"""
from __future__ import annotations

from .events import EventLog, fold
from .gossip import Gossip

__all__ = ["EventLog", "fold", "Gossip"]
