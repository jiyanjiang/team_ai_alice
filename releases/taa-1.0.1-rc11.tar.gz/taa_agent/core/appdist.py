"""手机 APP 分发：打包发布 → 扫码令牌 → 下载（docs/331）。

为什么不是"直接给 GitHub 私有库链接"：私有库的 raw/Release 资源**不带鉴权就 404**，
把 PAT 放进二维码等于把钥匙贴在门上。因此中心节点只做两件事：

1. **仓库（registry）**：把人工/自动构建的产物（.apk / .ipa / .zip(PWA)）落盘 + 记 sha256；
2. **令牌（token）**：扫码得到的是中心节点签发的**短期、限量、只读**下载令牌，
   下载时**逐字节校验 sha256**，过期或超次即失效。

GitHub 私有库仍然可以是**构建与归档的源头**（CI 产出 Release），
但对外分发一律走这里的令牌，节点只读本地 registry，不向 GitHub 要凭证。
"""
from __future__ import annotations

import hashlib
import html
import io
import re
import secrets
import shutil
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 允许的平台/渠道（free-form 会变成路径穿越与错误提示的温床）
PLATFORMS = ("android", "harmony", "ios", "pwa")
CHANNELS = ("stable", "beta", "dev")
_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")

SCHEMA = """
CREATE TABLE IF NOT EXISTS app_releases (
  app        TEXT NOT NULL,
  version    TEXT NOT NULL,
  platform   TEXT NOT NULL,
  filename   TEXT NOT NULL,
  sha256     TEXT NOT NULL,
  size       INTEGER NOT NULL,
  notes      TEXT,
  channel    TEXT NOT NULL DEFAULT 'stable',
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (app, version, platform)
);
CREATE TABLE IF NOT EXISTS app_tokens (
  token_hash TEXT PRIMARY KEY,
  app        TEXT,
  version    TEXT,
  platform   TEXT,
  expires_at TEXT NOT NULL,
  max_uses   INTEGER NOT NULL DEFAULT 50,
  uses       INTEGER NOT NULL DEFAULT 0,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_app_tokens_exp ON app_tokens(expires_at);
"""


def ensure(conn) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def app_root() -> Path:
    """产物根目录。可用 TEAMAI_APPS_DIR 指向临时目录（自检隔离）。"""
    import os
    p = Path(os.environ.get("TEAMAI_APPS_DIR") or (ROOT / "apps"))
    p.mkdir(parents=True, exist_ok=True)
    return p


def _check(name: str, what: str) -> str:
    v = (name or "").strip().lower()
    if not _NAME_RE.match(v):
        raise ValueError(f"{what} 不合法：{name!r}（只允许小写字母/数字/._-，≤64）")
    return v


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _now() -> datetime:
    return datetime.now()


def _ts(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def publish(conn, src: Path, app: str, version: str, platform: str,
            notes: str = "", channel: str = "stable", by: str | None = None) -> dict:
    """把一个构建产物登记进 registry（同 app/version/platform 覆盖旧包）。"""
    ensure(conn)
    app = _check(app, "app")
    version = _check(version, "version")
    platform = _check(platform, "platform")
    channel = _check(channel, "channel")
    if platform not in PLATFORMS:
        raise ValueError(f"platform 只支持 {', '.join(PLATFORMS)}")
    if channel not in CHANNELS:
        raise ValueError(f"channel 只支持 {', '.join(CHANNELS)}")
    src = Path(src)
    if not src.is_file():
        raise FileNotFoundError(str(src))

    sha = sha256_file(src)
    size = src.stat().st_size
    dest_dir = app_root() / app / version / platform
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    if src.resolve() != dest.resolve():
        tmp = dest.with_suffix(dest.suffix + ".part")
        shutil.copyfile(src, tmp)
        tmp.replace(dest)          # 原子替换：下载中的读者不会看到半截文件
    if sha256_file(dest) != sha:
        raise IOError("落盘后 sha256 不一致（磁盘/并发问题）")

    conn.execute(
        "INSERT INTO app_releases(app,version,platform,filename,sha256,size,notes,channel,"
        "created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(app,version,platform) DO UPDATE SET filename=excluded.filename,"
        "sha256=excluded.sha256,size=excluded.size,notes=excluded.notes,"
        "channel=excluded.channel,created_by=excluded.created_by,created_at=excluded.created_at",
        (app, version, platform, dest.name, sha, size, notes, channel, by, _ts(_now())))
    conn.commit()
    return {"app": app, "version": version, "platform": platform, "filename": dest.name,
            "sha256": sha, "size": size, "notes": notes, "channel": channel,
            "created_by": by, "path": str(dest.relative_to(app_root()))}


def list_releases(conn, app: str | None = None) -> list[dict]:
    ensure(conn)
    if app:
        rows = conn.execute("SELECT * FROM app_releases WHERE app=? "
                            "ORDER BY created_at DESC", (_check(app, "app"),)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM app_releases ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


def get_release(conn, app: str, version: str, platform: str) -> dict | None:
    ensure(conn)
    row = conn.execute("SELECT * FROM app_releases WHERE app=? AND version=? AND platform=?",
                       (_check(app, "app"), _check(version, "version"),
                        _check(platform, "platform"))).fetchone()
    return dict(row) if row else None


def latest(conn, app: str, platform: str | None = None) -> dict | None:
    ensure(conn)
    if platform:
        row = conn.execute("SELECT * FROM app_releases WHERE app=? AND platform=? "
                           "ORDER BY created_at DESC LIMIT 1",
                           (_check(app, "app"), _check(platform, "platform"))).fetchone()
    else:
        row = conn.execute("SELECT * FROM app_releases WHERE app=? "
                           "ORDER BY created_at DESC LIMIT 1",
                           (_check(app, "app"),)).fetchone()
    return dict(row) if row else None


def blob_path(rel: dict) -> Path | None:
    """把 registry 记录映射回文件，并确认仍在 app_root 之下（防穿越）。"""
    p = (app_root() / rel["app"] / rel["version"] / rel["platform"] / rel["filename"]).resolve()
    root = app_root().resolve()
    if root not in p.parents or not p.is_file():
        return None
    return p


# ---------------------------------------------------------------- tokens
def issue_token(conn, app: str | None = None, version: str | None = None,
                platform: str | None = None, ttl_hours: int = 72,
                max_uses: int = 50, by: str | None = None) -> dict:
    """签发扫码下载令牌。`app=None` 表示"通用安装页"（只到落地页，不带包）。"""
    ensure(conn)
    app = _check(app, "app") if app else None
    version = _check(version, "version") if version else None
    platform = _check(platform, "platform") if platform else None
    if app and not version:
        rel = None
        if platform:
            rel = latest(conn, app, platform)
        if not rel:
            # 未指定版本：取该 app 最近一次的任意平台
            row = conn.execute("SELECT * FROM app_releases WHERE app=? "
                               "ORDER BY created_at DESC LIMIT 1", (app,)).fetchone()
            rel = dict(row) if row else None
        if not rel:
            raise ValueError(f"app 尚未发布：{app}")
        version, platform = rel["version"], rel["platform"]
    tok = secrets.token_urlsafe(24)
    exp = _ts(_now() + timedelta(hours=max(1, int(ttl_hours))))
    conn.execute("INSERT INTO app_tokens(token_hash,app,version,platform,expires_at,max_uses,"
                 "uses,created_by) VALUES (?,?,?,?,?,?,0,?)",
                 (hashlib.sha256(tok.encode()).hexdigest(), app, version, platform,
                  exp, max(1, int(max_uses)), by))
    conn.commit()
    return {"token": tok, "app": app, "version": version, "platform": platform,
            "expires_at": exp, "max_uses": max(1, int(max_uses))}


def resolve_token(conn, token: str) -> dict | None:
    """校验令牌：存在、未过期、未超次。不消费。"""
    if not token:
        return None
    ensure(conn)
    row = conn.execute("SELECT * FROM app_tokens WHERE token_hash=?",
                       (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
    if not row:
        return None
    d = dict(row)
    if d["expires_at"] < _ts(_now()):
        return None
    if d["uses"] >= d["max_uses"]:
        return None
    return d


def consume_token(conn, token: str) -> bool:
    """下载计数 +1（并发安全：只有 uses<max_uses 的那次才会成功）。"""
    if not token:
        return False
    cur = conn.execute(
        "UPDATE app_tokens SET uses=uses+1 WHERE token_hash=? AND expires_at>=? "
        "AND uses<max_uses",
        (hashlib.sha256(token.encode()).hexdigest(), _ts(_now())))
    conn.commit()
    return cur.rowcount > 0


def revoke_expired(conn) -> int:
    cur = conn.execute("DELETE FROM app_tokens WHERE expires_at < ?",
                       (_ts(_now() - timedelta(days=7)),))
    conn.commit()
    return cur.rowcount


# ---------------------------------------------------------------- qr / landing
def qr_png(data: str) -> bytes:
    import qrcode
    qr = qrcode.QRCode(box_size=8, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0f1720", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


_INSTALL = {
    "android": "下载后点开 APK，允许「安装未知来源应用」即可。",
    "harmony": "鸿蒙 4 可直接装 APK；HarmonyOS NEXT 需在「应用市场」签名上架，见文档 §5。",
    "ios": "未上架 App Store 的包只能用 TestFlight / 企业签名分发，需本人 Apple 账号，见文档 §5。",
    "pwa": "用手机浏览器打开后「添加到主屏幕」，无需安装包、无需证书。",
}


def landing_html(app: str, version: str, platform: str, sha: str, size: int,
                 expire: str, download_url: str) -> str:
    """扫码落地页：只给一个按钮和一句真话（安装限制不粉饰）。"""
    a, v, p = html.escape(app), html.escape(version), html.escape(platform)
    inst = html.escape(_INSTALL.get(platform, "下载后按系统提示安装。"))
    mb = f"{size / 1048576:.1f} MB" if size >= 1048576 else f"{size / 1024:.0f} KB"
    return f"""<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{a} {v}</title>
<style>body{{font:16px/1.6 -apple-system,system-ui,sans-serif;margin:0;padding:24px;
background:#0f1720;color:#e6edf3}}main{{max-width:520px;margin:8vh auto}}
h1{{font-size:22px;margin:0 0 4px}}.m{{color:#8b98a5;font-size:13px}}
a.btn{{display:block;margin:24px 0;padding:16px;text-align:center;border-radius:12px;
background:#2f81f7;color:#fff;text-decoration:none;font-weight:600}}
code{{font-size:12px;color:#8b98a5;word-break:break-all}}</style></head>
<body><main>
<h1>{a} <span class="m">{v} · {p}</span></h1>
<p>{inst}</p>
<a class="btn" href="{html.escape(download_url)}">下载 {mb}</a>
<p class="m">sha256（下载后请核对）：</p><code>{html.escape(sha)}</code>
<p class="m">此链接 {html.escape(expire)} 前有效，限量下载；过期请重新扫码。</p>
</main></body></html>"""
