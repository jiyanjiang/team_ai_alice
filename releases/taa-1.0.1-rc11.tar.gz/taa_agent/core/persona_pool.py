"""persona_pool —— 人格特征池的抽样与合成（确定性，不联网）。

设计（2026-11-01，替代「按性别写死外观」的模板先验）：

    池子（男女各 100，按领域分层）→ 确定性抽 3 人（同性别）→ 角色分配 → 合成

三个人不是平权混合，而是**分工**：
  · 主干 main：定价值观与行为基调（冲突时的裁决者）
  · 补位 support：定气质与表达方式（说话节奏、待人方式）
  · 反差 contrast：只贡献**一个有张力的点**，不得改变主干价值观

三条原则：
1. **只存抽象特征**：池子里没有任何真名、作品、机构、地域。合成产物不得指向
   任何可识别个人——这既是合规要求，也恰好是反 slop 的关键。
2. **确定性**：同 `(name, seed)` 必得同 3 人、同角色、同规则产物。
3. **可降级**：`rule_profile()` 是纯规则合成（无网络）。LLM 只是措辞增强，
   失败不影响生成。
"""
from __future__ import annotations

import hashlib
import pathlib
import random

ROOT = pathlib.Path(__file__).resolve().parent.parent
POOL_DIR = ROOT / "presets" / "persona_pool"

_CACHE: dict[str, list[dict]] = {}
GENDERS = ("female", "male")

#: 角色说明（同时用于提示词，改这里即改口径）
ROLES = (
    ("main", "主干：定价值观与行为基调，三者冲突时以它为准"),
    ("support", "补位：定气质与表达方式（说话节奏、待人方式）"),
    ("contrast", "反差：只贡献一个有张力的点，不得改变主干价值观"),
)


def _path(gender: str) -> pathlib.Path:
    return POOL_DIR / f"{gender}.yaml"


def load(gender: str) -> list[dict]:
    """读取某一性别的特征池（带缓存）。缺失或损坏时返回空列表。"""
    g = (gender or "").strip().lower()
    if g not in GENDERS:
        raise ValueError(f"gender 必须是 {GENDERS}，收到 {gender!r}")
    if g in _CACHE:
        return _CACHE[g]
    p = _path(g)
    items: list[dict] = []
    if p.is_file():
        try:
            import yaml
            raw = yaml.safe_load(p.read_text(encoding="utf-8")) or []
            items = [x for x in raw if isinstance(x, dict) and x.get("id")]
        except Exception:  # noqa: BLE001 —— 池子坏了也不能让生成流程崩
            items = []
    _CACHE[g] = items
    return items


def pick(gender: str, name: str, seed: str | None = None, n: int = 3) -> list[dict]:
    """确定性抽 n 人（同性别），并尽量让领域分散。

    返回顺序即角色顺序：[main, support, contrast]。
    """
    items = load(gender)
    if not items:
        return []
    key = f"{name}|{seed or ''}|{gender}|pool-v1"
    h = int(hashlib.sha256(key.encode("utf-8")).hexdigest()[:16], 16)
    rng = random.Random(h)

    pool = items[:]
    rng.shuffle(pool)
    chosen: list[dict] = []
    used_fields: set[str] = set()
    for it in pool:
        if len(chosen) >= n:
            break
        f = str(it.get("field") or "")
        # 领域优先分散；候选池足够时跳过同领域
        if f and f in used_fields and len({x.get("field") for x in pool}) >= n:
            continue
        chosen.append(it)
        used_fields.add(f)
    for it in pool:                      # 兜底：池子领域数不足时按序补齐
        if len(chosen) >= n:
            break
        if it not in chosen:
            chosen.append(it)
    return chosen[:n]


def by_ids(gender: str, ids: list[str]) -> list[dict]:
    """按 id 顺序取回特征卡（enrich 阶段用；顺序即角色顺序）。"""
    if not ids:
        return []
    index = {str(x.get("id")): x for x in load(gender)}
    return [index[i] for i in ids if i in index]


def rule_profile(basis: list[dict]) -> dict:
    """纯规则合成（无 LLM、确定性）。作为 enrich 失败时的兜底。"""
    if not basis:
        return {}
    main = basis[0]
    sup = basis[1] if len(basis) > 1 else {}
    con = basis[2] if len(basis) > 2 else {}

    face = str(main.get("face") or "").strip("，。 ")
    hair = str(main.get("hair") or "").strip("，。 ")
    build = str(main.get("build") or "").strip("，。 ")
    style = str(main.get("style") or "").strip("，。 ")
    head = "，".join(x for x in (build, hair, face) if x)
    appearance = head + (f"；常穿{style}" if style else "")
    if len(appearance) > 60:
        appearance = appearance[:58] + "…"

    values = str(main.get("values") or "").strip("。 ")
    temper = str(sup.get("temper") or "").strip("。 ")
    tension = str(con.get("tension") or "").strip("。 ")
    # 第一人称语境下直接陈述即可；避免 "说话说话冷" 这类叠词
    bio = (values + "。") if values else ""
    if temper:
        bio += (temper if temper.startswith("说话") else f"说话{temper}") + "。"
    if tension:
        bio += tension + "。"
    if len(bio) > 60:
        bio = bio[:58] + "…"
    return {"appearance": appearance, "bio": bio}


def voice_of(basis: list[dict]) -> str:
    """语气取自「补位」的说话节奏（无补位时用主干）；模板只留性格基线。"""
    src = basis[1] if len(basis) > 1 else (basis[0] if basis else {})
    return str(src.get("temper") or "").strip("。 ")


PHRASES_PATH = POOL_DIR / "phrases.yaml"
_PHRASE_CACHE: dict[str, list[str]] = {}


def load_phrases() -> dict[str, list[str]]:
    """读取口癖池（按领域分组，带缓存）。缺失时返回空表。"""
    if _PHRASE_CACHE:
        return _PHRASE_CACHE
    data: dict[str, list[str]] = {}
    if PHRASES_PATH.is_file():
        try:
            import yaml
            raw = yaml.safe_load(PHRASES_PATH.read_text(encoding="utf-8")) or {}
            data = {str(k): [str(x) for x in (v or [])] for k, v in raw.items()}
        except Exception:  # noqa: BLE001
            data = {}
    _PHRASE_CACHE.update(data)
    return _PHRASE_CACHE


def phrases_of(basis: list[dict], seed: str | None = None, n: int = 3) -> list[str]:
    """按主干领域抽口癖（确定性）；同 (seed, 卡片 id) 恒得同一组。

    模板里的 catchphrases 不再使用——那会让抽到同一模板的两个人说同一组口头禅。
    """
    if not basis:
        return []
    main = basis[0]
    table = load_phrases()
    field = str(main.get("field") or "")
    cands = list(table.get(field) or []) + list(table.get("通用") or [])
    if not cands:
        return []
    key = f"{seed or ''}|{main.get('id') or ''}|phrase-v1"
    h = int(hashlib.sha256(key.encode("utf-8")).hexdigest()[:16], 16)
    rng = random.Random(h)
    return rng.sample(cands, min(n, len(cands)))


def build_prompt(basis: list[dict], name: str, gender: str, age: int | None,
                 height_cm: int | None, hint: str = "") -> str:
    """构造合成提示词。

    要点：明确三人分工、冲突裁决、禁止可识别身份、**显式禁止小动作套路**。
    """
    lines = []
    for (role, desc), it in zip(ROLES, basis):
        lines.append(
            f"- {desc}\n"
            f"  面部：{it.get('face', '')}；发型：{it.get('hair', '')}；"
            f"体型：{it.get('build', '')}；穿着：{it.get('style', '')}\n"
            f"  说话节奏：{it.get('temper', '')}；价值观：{it.get('values', '')}；"
            f"张力：{it.get('tension', '')}"
        )
    cards = "\n".join(lines)
    return f"""你在为一个 AI agent 合成一份初始人设，只输出 JSON。

【依据】三位同性别普通人的抽象特征卡（已脱敏，无姓名、无职业成就、无作品、无地域）：
{cards}

【已知】名字：{name}；性别：{gender}；年龄：{age or '-'}；身高：{height_cm or '-'}cm
【设定】{hint or '无'}

【合成规则】
1. `appearance`：60 字以内。外形以「主干」的体型/发型/面部/穿着为底，最多吸收「补位」的一处细节；
   必须具体可感（可数的、可看的），不要形容词堆砌。
2. `bio`：50 字以内，第一人称，写这个人怎么做事、在意什么；不写履历、不写成就。
3. 「反差」只体现为一个具体的偏好或忌讳，不得改变主干价值观；三者冲突时以主干为准。
4. 禁止出现任何可识别个人的信息：姓名、艺名、作品名、机构名、地名、"像某某"。合成结果必须是虚构的。
5. 禁止小动作与神态套路：扶/推/整理眼镜、扶额、挑眉、抱臂、点头示意、加快语速、压低声音、
   深吸一口气、微微一笑、意味深长地看、目光坚定 等一律不得出现。
6. 不要用性别气质标签词（温柔、强势、细腻、刚强、飒、man 等），用可观察的行为体现。
7. 输出严格为一个 JSON 对象：
{{"appearance": "...", "bio": "...", "tags": ["...", "...", "..."]}}
"""


def describe(basis: list[dict]) -> dict:
    """给审计/留痕用的精简描述：只记 id 与领域，不复制整张卡。"""
    return {"roles": [r for r, _ in ROLES][:len(basis)],
            "ids": [str(x.get("id") or "") for x in basis],
            "fields": [str(x.get("field") or "") for x in basis]}
