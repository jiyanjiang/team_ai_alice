"""经验收割 playbook —— 读工作群，让 **LLM** 判断哪些值得进知识库、哪些是「今天学到的有用经验」。

与 harvest 的分工（TLP 4.1212 说/显示）：
- `harvest` 收「可说的事实」（真假/成败/未决）→ `facts`。
- `playbook` 收「不可说、但可复用的经验/规范」→ `playbook`：事实源优先级、检索工具、
  规划与协作纪律、写作/制作流程、品味与选题、导师偏好、踩过的坑。

**判断权完全交给 LLM**（值不值得学、类型、scope、显著度都由它判断）；规则只做结构护栏、
去重和游标，不参与取舍（不用关键词）。
自检友好：`harvest_learnings(..., llm=...)` 可注入假 LLM，全程不触网。
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from . import memory as mem
from .harvest import _fmt_messages, _persona_note, extract_json

ROOT = Path(__file__).resolve().parent.parent

LEARN_TYPES = {"source", "tool", "planning", "process", "taste", "style", "preference", "pitfall"}
DEFAULT_MODEL = os.environ.get("TEAMAI_LEARN_MODEL", "deepseek/deepseek-flash")
DEFAULT_MIN_CONFIDENCE = 0.55


# ------------------------------------------------------------------ prompt（LLM 判断）
def build_prompt(agent: str, room: dict, messages: list[dict], existing: list[dict] | None = None) -> str:
    topic = (room or {}).get("topic") or (room or {}).get("id") if isinstance(room, dict) else str(room)
    rid = room.get("id") if isinstance(room, dict) else str(room)
    known = ""
    if existing:
        known = ("\n【你已知的经验（避免重复记；可判断是否要修正/取代）】\n"
                 + "\n".join(f"- [{e.get('type')}] {e.get('statement')}" for e in existing[:15]) + "\n")
    return (
        "你是团队的「经验收割器」。注意：事实收割(harvest)只收「可说的事实」；\n"
        "你负责收**不可说、但可复用的经验与规范**——它们决定团队「怎么做事」。\n"
        f"{_persona_note(agent)}"
        "请判断下面群聊里**哪些内容值得进入你的知识库**，尤其导师(human)表达过的：\n"
        "- 事实源与检索(source/tool)：优先用哪些源、如何交叉验证、原文怎么存/命名；\n"
        "- 规划与协作(planning)：先出方案再执行、分工与验收、分步实施；\n"
        "- 流程(process)：写作/制作/质检的步骤与门禁；\n"
        "- 品味与选题(taste)：什么算好、什么算低劣；\n"
        "- 导师偏好/禁忌(preference)、踩过的坑(pitfall)、语言风格(style)。\n"
        "**判断权在你**：什么值得记、什么只是闲聊/一次性指令/情绪，由你判断，宁少勿滥。\n"
        "一条经验必须：①能脱离本次语境复用；②能指导下次行为；③有出处（引用消息编号 [12] 或链接）。\n"
        "scope：team=全队通用；agent=只对你自己（按你的人设/定位取舍）。\n"
        "type 取值：source|tool|planning|process|taste|style|preference|pitfall。\n"
        f"{known}\n"
        f"群聊《{topic}》（{rid}）发言：\n"
        f"{_fmt_messages(messages)}\n"
        "-------------------\n\n"
        "只输出一个 JSON（不要多余文字）：\n"
        '{"learnings":[{"statement":"一句可执行的经验/规范","type":"planning",'
        '"why":"为什么值得记住","evidence":"[12]","scope":"team",'
        '"confidence":0.8,"salience":0.7,"msg_ids":[12]}]}\n'
        "若没有值得入库的，输出 {\"learnings\":[]}。"
    )


# ------------------------------------------------------------------ gate（仅结构护栏，不判取舍）
def _norm_type(t) -> str | None:
    if not isinstance(t, str):
        return None
    t = t.strip().lower()
    alias = {"来源": "source", "事实源": "source", "工具": "tool", "检索": "tool",
             "规划": "planning", "计划": "planning", "协作": "planning",
             "流程": "process", "规范": "process", "品味": "taste", "选题": "taste",
             "风格": "style", "偏好": "preference", "禁忌": "preference", "教训": "pitfall",
             "坑": "pitfall"}
    t = alias.get(t, t)
    return t if t in LEARN_TYPES else None


def gate_learnings(raw_learnings, lo: int, hi: int, min_confidence: float = DEFAULT_MIN_CONFIDENCE):
    """把 LLM 给的原始条目做结构校验/去重。返回 (accepted, rejected)。"""
    accepted, rejected, seen = [], [], set()
    if not isinstance(raw_learnings, list):
        return accepted, rejected
    for r in raw_learnings:
        if not isinstance(r, dict):
            continue
        statement = (r.get("statement") or r.get("text") or "").strip()
        type_ = _norm_type(r.get("type"))
        evidence = (r.get("evidence") or "").strip()
        scope = (r.get("scope") or "agent").strip().lower()
        scope = scope if scope in ("team", "agent") else "agent"
        try:
            conf = float(r.get("confidence", 0.6))
        except (TypeError, ValueError):
            conf = 0.6
        conf = max(0.0, min(1.0, conf))
        try:
            sal = float(r.get("salience", 0.5))
        except (TypeError, ValueError):
            sal = 0.5
        sal = max(0.0, min(1.0, sal))

        why = None
        if not (4 <= len(statement) <= 300):
            why = "statement 长度不合规"
        elif type_ is None:
            why = "type 非法/缺失"
        elif not evidence:
            why = "缺出处（不可复用/不可回溯）"
        elif conf < min_confidence:
            why = f"置信度 {conf:.2f} < {min_confidence}"
        else:
            fp = mem.fact_fingerprint(statement)
            if fp in seen:
                why = "批内重复"
            else:
                seen.add(fp)

        if why:
            rejected.append({"statement": statement, "type": type_, "reason": why})
            continue
        accepted.append({"statement": statement, "type": type_,
                         "rationale": (r.get("why") or "").strip() or None,
                         "evidence": evidence, "scope": scope,
                         "confidence": conf, "salience": sal})
    return accepted, rejected


# ------------------------------------------------------------------ apply（写知识库）
def apply_learnings(agent: str, room_id: str, accepted: list[dict], *, lo: int, hi: int,
                    source: str | None = None, dry_run: bool = False) -> dict:
    wrote = {"playbook": 0, "semantic": 0, "dup": 0}
    if dry_run:
        return {"new": len(accepted), "wrote": wrote, "dry_run": True}
    for l in accepted:
        lid = mem.add_learning(
            agent, l["statement"], type_=l["type"], rationale=l.get("rationale"),
            evidence=l["evidence"], scope=l["scope"], room_id=room_id,
            msg_from=lo, msg_to=hi, confidence=l["confidence"], salience=l["salience"])
        if lid is None:
            wrote["dup"] += 1
            continue
        wrote["playbook"] += 1
        # 全队通用 / 高显著 → 沉淀进语义记忆，规划时可直接召回
        if l["scope"] == "team" or l["salience"] >= 0.7:
            mem.remember_semantic(agent, f"learn:{room_id}:{mem.fact_fingerprint(l['statement'])[:8]}",
                                  l["statement"], confidence=l["confidence"],
                                  source=source or f"room:{room_id}")
            wrote["semantic"] += 1
    mem.set_learning_cursor(agent, room_id, hi)
    return {"new": len(accepted), "wrote": wrote, "dry_run": False}


# ------------------------------------------------------------------ orchestrator
def harvest_learnings(agent: str, room_id: str, messages: list[dict], *, room: dict | None = None,
                      llm=None, model: str = DEFAULT_MODEL,
                      min_confidence: float = DEFAULT_MIN_CONFIDENCE,
                      dry_run: bool = False, cursor: int | None = None,
                      max_msgs: int = 80) -> dict:
    """读增量消息 → LLM 判断值得入库的经验/规范 → 结构护栏 → 写 playbook。"""
    all_msgs = [m for m in messages if m.get("id") is not None]
    if cursor is None:
        cursor = mem.get_learning_cursor(agent, room_id)
    pending = sorted((m for m in all_msgs if int(m["id"]) > cursor), key=lambda m: int(m["id"]))
    if not pending:
        return {"room_id": room_id, "new_msgs": 0, "accepted": [], "rejected": [],
                "wrote": {}, "cursor": cursor}
    new = pending[:max(1, int(max_msgs))]
    lo, hi = int(new[0]["id"]), int(new[-1]["id"])
    chatter = [m for m in new if (m.get("body") or "").strip() and m.get("kind") not in ("skip", "system")]
    if not chatter:
        mem.set_learning_cursor(agent, room_id, hi)
        return {"room_id": room_id, "new_msgs": len(new), "pending": len(pending),
                "accepted": [], "rejected": [], "wrote": {}, "cursor": hi}

    existing = mem.list_learnings(agent, limit=15)
    prompt = build_prompt(agent, room or {"id": room_id}, chatter, existing=existing)
    if llm is None:
        from core.llm import get as llm_get
        backend_file = ROOT / "agents" / agent / "backend"
        backend = backend_file.read_text(encoding="utf-8").strip() if backend_file.exists() else "opencode"
        llm = llm_get(backend)
        res = llm.run(prompt, model=model, cwd=str(ROOT),
                      title=f"learn:{room_id}:{agent}", timeout=240)
        text = res.text if res.ok else ""
        if not res.ok:
            return {"room_id": room_id, "new_msgs": len(new), "accepted": [], "rejected": [],
                    "wrote": {}, "cursor": cursor, "error": "llm_failed", "raw": text[-400:]}
    else:
        text = llm(prompt)

    parsed = extract_json(text) or {}
    accepted, rejected = gate_learnings(parsed.get("learnings"), lo, hi, min_confidence)
    result = apply_learnings(agent, room_id, accepted, lo=lo, hi=hi, dry_run=dry_run)
    return {"room_id": room_id, "new_msgs": len(new), "pending": len(pending), "range": [lo, hi],
            "accepted": accepted, "rejected": rejected, "cursor": hi, **result}


def playbook_note(agent: str, limit: int = 12) -> str:
    """把已沉淀的经验拼成 prompt 块，供规划/写作时召回。"""
    rows = mem.list_learnings(agent, status="active", limit=limit)
    if not rows:
        return ""
    lines = [f"- [{r['type']}] {r['statement']}" for r in rows]
    return "\n【我的经验库（来自导师与实战，规划前先看）】\n" + "\n".join(lines) + "\n"
