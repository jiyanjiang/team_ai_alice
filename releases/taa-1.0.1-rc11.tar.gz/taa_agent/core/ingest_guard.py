"""采集准入护栏（**根上三条** · Owner 口径 2026-10-14）。

> ① **采集对象只有「文章详情页」**：源首页、栏目页、列表页、分页、搜索页 **一律不是采集对象**（拒绝入库）；
> ② **必须真人参与**：没有真人浏览证据（真实停留时长 + 浏览器会话 + 页面可见）**不许入库**；
> ③ **文章详情页以 URL 为唯一标识去重**（URL 规范化后唯一）。

任何入口（浏览器脚本、内部调用、将来别的采集器）在写库前**都必须过这里**。
本模块 fail-closed：源未声明「文章 URL 形态」时，**一律按非文章拒绝**（先声明、再采集）。
"""
from __future__ import annotations

import json
import re

from .capture_dedupe import canonical_url

MIN_DWELL_S = 3            # 真人停留下限（秒）：低于此视为"没真的在看"

# 明显不是文章详情页的路径形态
SECTION_HINT = re.compile(
    r"^/(news|category|categories|section|sections|topic|topics|tag|tags|archive|archives|"
    r"channel|channels|list|lists|column|columns|author|authors|search|page|pages|about|"
    r"contact|privacy|terms|subscribe|newsletter|advertise|jobs|events)(/|$)", re.I)
PAGINATION = re.compile(r"(^|/)(page|p)/?\d+/?$", re.I)
ASSET_EXT = re.compile(r"\.(jpg|jpeg|png|gif|webp|svg|pdf|zip|mp3|mp4|css|js|xml|json)$", re.I)


def _path(url: str) -> str:
    m = re.match(r"^[a-zA-Z][\w+.-]*://[^/]*(/[^?#]*)?", url or "")
    return (m.group(1) or "/") if m else "/"


def classify(url: str, patterns: list[str] | None = None,
             exclude: list[str] | None = None) -> tuple[str, str]:
    """判定 URL 类别：`article` / `home` / `section` / `pagination` / `asset` / `unknown`。

    ★ 判定前先做 **URL 规范化**（去 utm/锚点/尾斜杠）——真人分享出来的链接常带 `?utm_…`，
      不规范化会把**同一篇文章误判成非文章**（实测踩过）。
    """
    url = (url or "").split("#")[0]          # ★ 剥掉 #片段（清单点开时带的来源标记）
    cu = canonical_url(url)
    if exclude and any(re.search(p, u) for p in exclude for u in (url, cu)):
        return "section", "命中该源「非采集页形态」（栏目/列表/专题页，非采集对象）"
    path = _path(cu)
    if ASSET_EXT.search(path):
        return "asset", f"静态资源 {path}"
    if path.rstrip("/") == "" or path in ("/", "/index.html", "/home"):
        return "home", "站点首页（非采集对象）"
    if PAGINATION.search(path.rstrip("/")):
        return "pagination", f"分页 {path}（非采集对象）"
    if SECTION_HINT.search(path):
        return "section", f"栏目/列表页 {path}（非采集对象）"
    if patterns and any(re.search(p, u) for p in patterns for u in (url, cu)):
        return "article", "命中该源「文章 URL 形态」"
    return "unknown", "未命中该源「文章 URL 形态」（fail-closed：先声明再采集）"


def human_signal(payload: dict) -> tuple[bool, list[str]]:
    """真人浏览证据：① 停留 ≥ MIN_DWELL_S 秒；② 有浏览器会话 id；③ 页面处于可见状态。"""
    reasons: list[str] = []
    try:
        dwell = int(payload.get("dwell_s") or 0)
    except (TypeError, ValueError):
        dwell = 0
    if dwell < MIN_DWELL_S:
        reasons.append(f"no_dwell({dwell}s<{MIN_DWELL_S}s)")
    if not str(payload.get("session") or "").strip():
        reasons.append("no_session")
    if payload.get("visible") is False:
        reasons.append("not_visible")
    return (not reasons), reasons


def admit(source_url_patterns, url: str, payload: dict,
          exclude_patterns=None) -> tuple[bool, str, list[str]]:
    """总准入：返回 (ok, kind, reasons)。patterns/exclude 均可为 JSON 字符串或 list。"""
    def _as_list(v):
        if isinstance(v, str):
            try:
                v = json.loads(v or "[]")
            except json.JSONDecodeError:
                v = []
        return [str(x) for x in (v or []) if str(x).strip()]
    patterns = _as_list(source_url_patterns)
    kind, why = classify(url, patterns, _as_list(exclude_patterns))
    reasons: list[str] = []
    if kind != "article":
        reasons.append(f"not_article_url[{kind}]: {why}")
    ok_h, h_reasons = human_signal(payload or {})
    if not ok_h:
        reasons += h_reasons
    return (not reasons), kind, reasons


def canonical(url: str) -> str:
    """URL 唯一键（去 utm/锚点/尾斜杠）——文章详情页以此去重。"""
    return canonical_url(url)
