-- 团队AI · Agent 本地记忆库 schema（每个 agent 一个 memory.db）
-- 对应 docs/05_Agent记忆与人格设计.md §5/§6。

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- 情景记忆：发生了什么
CREATE TABLE IF NOT EXISTS episodic (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  kind TEXT,
  summary TEXT NOT NULL,
  refs TEXT,                    -- JSON: task_id/post_id/agent
  salience REAL DEFAULT 0.5,
  decayed REAL DEFAULT 0.5
);
CREATE INDEX IF NOT EXISTS idx_episodic_ts ON episodic(ts);

-- 语义记忆：总结出的知识
CREATE TABLE IF NOT EXISTS semantic (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  confidence REAL DEFAULT 0.5,
  source TEXT,
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 短期热记忆：随时可召集
CREATE TABLE IF NOT EXISTS working (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  kind TEXT NOT NULL,           -- focus/intent/open_question/recent_event/active
  content TEXT NOT NULL,
  priority REAL DEFAULT 0.5,
  expires_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_working_kind ON working(kind);

-- 技能矩阵
CREATE TABLE IF NOT EXISTS skills (
  name TEXT PRIMARY KEY,
  level REAL, target REAL, strategy TEXT,
  evidence TEXT,
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 兴趣向量
CREATE TABLE IF NOT EXISTS interests (
  tag TEXT PRIMARY KEY,
  weight REAL DEFAULT 0.5,
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 价值观 / 权重（人格核心，可被 reflect 修改）
CREATE TABLE IF NOT EXISTS values_t (
  key TEXT PRIMARY KEY,
  value REAL NOT NULL,
  min REAL DEFAULT 0.05,
  max REAL DEFAULT 0.95,
  core INTEGER NOT NULL DEFAULT 0,
  rationale TEXT,
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 权重演化史（审计 / 回滚）
CREATE TABLE IF NOT EXISTS weight_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL, old REAL, new REAL, reason TEXT,
  ts TEXT DEFAULT (datetime('now','localtime'))
);

-- 关系
CREATE TABLE IF NOT EXISTS relationships (
  other_agent TEXT PRIMARY KEY,
  trust REAL DEFAULT 0.5,
  interactions INTEGER DEFAULT 0,
  notes TEXT,
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 决策与教训
CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  context TEXT, decision TEXT, outcome TEXT, lesson TEXT
);

-- 反思记录
CREATE TABLE IF NOT EXISTS reflections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  trigger TEXT, summary TEXT, adjustments TEXT   -- JSON
);

-- 本地信誉镜像
CREATE TABLE IF NOT EXISTS reputation_local (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  event_type TEXT, points REAL, ref TEXT
);

-- 事实记忆（TLP 1.1：世界是事实的总和，而非物的总和）
-- 由「事实收割」(core/harvest.py) 从工作群/任务/论坛增量提炼：可说、可判定、带证据坐标。
-- 梯子(TLP 6.54)：每条事实可溯源到消息区间 msg_from..msg_to，可 superseded/discarded 而不删除。
CREATE TABLE IF NOT EXISTS facts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  statement TEXT NOT NULL,          -- 一句「可说」的命题
  verdict TEXT,                     -- success|failure|true|false|open|decision|lesson
  kind TEXT DEFAULT 'fact',         -- fact|decision|lesson|blocker|artifact
  evidence TEXT,                    -- 证据：消息坐标/命令/链接（可说性判据）
  source TEXT,                      -- room:<id> / task:<id> / post:<id>
  room_id TEXT,
  msg_from INTEGER,                 -- 覆盖的消息区间（溯源/可重算）
  msg_to INTEGER,
  speaker TEXT,
  confidence REAL DEFAULT 0.6,
  salience REAL DEFAULT 0.5,
  status TEXT DEFAULT 'active',     -- active|superseded|discarded
  fingerprint TEXT UNIQUE,          -- 规范化去重
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_facts_room ON facts(room_id);
CREATE INDEX IF NOT EXISTS idx_facts_verdict ON facts(verdict);

-- 事实收割游标：某 agent 在某房间已读到哪条消息
CREATE TABLE IF NOT EXISTS fact_cursor (
  agent TEXT NOT NULL,
  room_id TEXT NOT NULL,
  last_msg_id INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(agent, room_id)
);

-- 监督工作循环：Alice 对某目标(target)某主题(topic)的 QA 循环记录；质量须显式收敛
CREATE TABLE IF NOT EXISTS review_cycles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  agent TEXT,                       -- 监督者（alice）
  topic TEXT NOT NULL,              -- 主题，如 salam-archive
  target TEXT NOT NULL,             -- 被监督者，如 carol
  cycle_no INTEGER NOT NULL,        -- 第几轮（从 1 起，同一 topic 递增）
  items INTEGER DEFAULT 0,          -- 本轮审阅条目数
  defects INTEGER DEFAULT 0,        -- 缺陷总数
  passed INTEGER DEFAULT 0,         -- 是否达标 1/0
  criteria TEXT,                    -- JSON：判据 → 通过数/总数
  detail TEXT,                      -- JSON：缺陷明细
  refs TEXT,                        -- JSON：相关帖子/消息 id
  last_seen TEXT                    -- 本轮覆盖到的最新创建时间（增量用）
);
CREATE INDEX IF NOT EXISTS idx_review_topic ON review_cycles(topic, cycle_no);

-- 经验 / 规范知识库（playbook）：由「经验收割」(core/playbook.py) 让 **LLM 判断**哪些值得入库。
-- 与 facts 的分工（TLP 4.1212 说/显示）：facts 收「可说的事实」；playbook 收「不可说但可复用的
-- 经验/规范」——事实源优先级、检索工具、规划与协作纪律、写作流程、品味与选题、导师偏好、踩过的坑。
CREATE TABLE IF NOT EXISTS playbook (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  type TEXT,                        -- source|tool|planning|process|taste|style|preference|pitfall
  statement TEXT NOT NULL,          -- 一句可执行的经验/规范
  rationale TEXT,                   -- LLM 给的「为什么值得记住」
  evidence TEXT,                    -- 引用消息坐标/链接（可回溯）
  scope TEXT DEFAULT 'agent',       -- team(全队通用) | agent(只对自己)
  room_id TEXT,
  msg_from INTEGER, msg_to INTEGER,
  confidence REAL DEFAULT 0.6,
  salience REAL DEFAULT 0.5,
  status TEXT DEFAULT 'active',     -- active|superseded|discarded
  fingerprint TEXT UNIQUE,          -- 规范化去重
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_playbook_type ON playbook(type);
CREATE INDEX IF NOT EXISTS idx_playbook_scope ON playbook(scope);

-- 经验收割游标：某 agent 在某房间已读到哪条消息（与 fact_cursor 分开）
CREATE TABLE IF NOT EXISTS learning_cursor (
  agent TEXT NOT NULL,
  room_id TEXT NOT NULL,
  last_msg_id INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(agent, room_id)
);

-- 规划优先：执行前的方案与逐轮评审（core/plan.py 让 LLM 判断方案是否可执行）。
-- 门禁：qa/loop 可要求「先有 approved 方案，才允许开工」。
CREATE TABLE IF NOT EXISTS plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT DEFAULT (datetime('now','localtime')),
  agent TEXT,                        -- 主 agent（评审者/出方案者）
  topic TEXT NOT NULL,
  target TEXT NOT NULL,              -- 执行者
  plan TEXT NOT NULL,                -- 方案全文
  status TEXT DEFAULT 'draft',       -- draft|approved|rejected
  review TEXT,                       -- JSON：{ok, missing, verdict, feedback}
  cycle INTEGER DEFAULT 0,           -- 第几轮方案（多轮确认）
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_plans_topic ON plans(topic, target, cycle);
