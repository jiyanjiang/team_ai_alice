"""外部命令解析（**服务进程 PATH 被收窄**这条坑的统一解法）。

背景（真实事故两次）：launchd 起的服务 PATH 只有 /usr/bin:/bin，
  · `opencode` 找不到 → 全部 LLM 调用失败（解读产物全是 `[llm] 未找到命令`）；
  · 同型问题在 ffmpeg 上出现过（已用运行时通配修）。
所以：**凡是要调用外部命令，一律先经 resolve()**，不要在业务代码里写裸命令。

resolve(name) 优先级：环境变量 <NAME>_BIN → PATH(which) → 常见安装位置 → 裸命令兜底。
"""
from __future__ import annotations

import os
import shutil

COMMON = ("/opt/homebrew/bin/{n}", "/usr/local/bin/{n}", "/usr/bin/{n}",
          "~/.{n}/bin/{n}", "~/.local/bin/{n}", "~/.bun/bin/{n}", "~/bin/{n}")


def resolve(name: str) -> str:
    """返回可用路径；找不到则原样返回（让调用方报出真实错误，不吞）。"""
    env = os.environ.get(f"{name.upper().replace('-', '_')}_BIN")
    for c in [env, shutil.which(name)] + [os.path.expanduser(p.format(n=name)) for p in COMMON]:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return name


def describe(name: str) -> dict:
    """自检用：这条命令在**当前 PATH** 下能不能解析到。"""
    p = resolve(name)
    return {"cmd": name, "resolved": p, "ok": p != name and os.path.isfile(p)}
