"""Network-interface discovery and direct-peer endpoint selection.

This module is the missing layer between "a center returned a URL" and
"actually send a message".  It enumerates every usable local interface,
keeps candidate endpoints, ranks same-subnet physical LAN addresses first,
and probes `/peer/v1/ping` before a direct message is attempted.

It deliberately does not use the default-route trick as the only source:
multi-homed machines and VPNs make that choice unreliable.
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import subprocess
import time
import urllib.parse
import urllib.request
from typing import Any

DEFAULT_PEER_PORT = int(os.environ.get("TAA_PEER_PORT", "6090") or 6090)


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=3).stdout
    except Exception:  # noqa: BLE001
        return ""


def _vpn_iface(name: str) -> bool:
    n = name.lower()
    return any(x in n for x in ("utun", "tun", "tap", "ppp", "wg", "tailscale", "vpn", "ipsec"))


def _physical_iface(name: str) -> bool:
    n = name.lower()
    return n.startswith(("en", "eth", "wlan", "wifi", "wl", "bridge", "bond", "em"))


def _mask_from_hex(value: str) -> str:
    try:
        n = int(value, 16)
        return str(ipaddress.IPv4Address(n))
    except Exception:  # noqa: BLE001
        return ""


def _netmask_from_prefix(prefix: str) -> str:
    try:
        return str(ipaddress.IPv4Network("0.0.0.0/" + str(int(prefix)), strict=False).netmask)
    except Exception:  # noqa: BLE001
        return ""


def _add(out: list[dict], *, iface: str, ip: str, netmask: str = "", family: str = "inet",
         scope: str = "") -> None:
    try:
        addr = ipaddress.ip_address(ip.split("%", 1)[0])
    except ValueError:
        return
    if addr.is_loopback:
        iface_scope = "loopback"
    elif addr.is_link_local:
        iface_scope = "link-local"
    elif _vpn_iface(iface):
        iface_scope = "vpn"
    elif addr.is_private:
        iface_scope = "private"
    else:
        iface_scope = "public"
    if scope:
        iface_scope = scope
    item = {"iface": iface, "ip": str(addr), "family": family, "scope": iface_scope}
    if netmask:
        item["netmask"] = netmask
    if item not in out:
        out.append(item)


def interfaces() -> list[dict]:
    """Return all local IPv4/IPv6 interface addresses, never one guessed IP."""
    out: list[dict] = []
    # macOS / BSD ifconfig
    if os.uname().sysname == "Darwin" if hasattr(os, "uname") else False:
        current = ""
        for line in _run(["ifconfig"]).splitlines():
            m = re.match(r"^([A-Za-z0-9_.:-]+):", line)
            if m:
                current = m.group(1)
                continue
            m = re.match(r"^\s+inet\s+(\S+)\s+netmask\s+(\S+)", line)
            if m and current:
                _add(out, iface=current, ip=m.group(1), netmask=_mask_from_hex(m.group(2)), family="inet")
                continue
            m = re.match(r"^\s+inet6\s+([^/\s]+)(?:/(\d+))?", line)
            if m and current:
                addr = m.group(1).split("%", 1)[0]
                if addr.startswith("fe80:"):
                    continue
                prefix = m.group(2) or "64"
                _add(out, iface=current, ip=addr, netmask=prefix, family="inet6")
        if out:
            return out
    # Linux iproute2
    text = _run(["ip", "-o", "addr", "show"])
    if text:
        for line in text.splitlines():
            m = re.match(r"^\d+:\s+(\S+)\s+inet6?\s+(\S+)", line)
            if not m:
                continue
            iface, cidr = m.group(1), m.group(2)
            parts = cidr.split("/", 1)
            ip, prefix = parts[0], (parts[1] if len(parts) > 1 else "")
            fam = "inet6" if ":" in ip else "inet"
            if ip.lower().startswith("fe80:"):
                continue
            netmask = _netmask_from_prefix(prefix) if fam == "inet" else prefix
            _add(out, iface=iface, ip=ip, netmask=netmask, family=fam)
        if out:
            return out
    # Portable fallback: hostname addresses + the default route source.
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None):
            addr = info[4][0].split("%", 1)[0]
            if ":" in addr:
                continue
            _add(out, iface="hostname", ip=addr, netmask="", family="inet")
    except OSError:
        pass
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        _add(out, iface="default-route", ip=s.getsockname()[0], netmask="", family="inet")
    except OSError:
        pass
    finally:
        s.close()
    return out


def local_networks() -> list[ipaddress._BaseNetwork]:
    nets: list[ipaddress._BaseNetwork] = []
    for item in interfaces():
        ip = str(item.get("ip") or "")
        mask = str(item.get("netmask") or "")
        try:
            addr = ipaddress.ip_address(ip)
            if item.get("family") == "inet6":
                net = ipaddress.ip_network(f"{ip}/{mask or 64}", strict=False)
            elif mask:
                net = ipaddress.ip_network(f"{ip}/{mask}", strict=False)
            else:
                net = ipaddress.ip_network(f"{ip}/32", strict=False)
            if net not in nets:
                nets.append(net)
        except ValueError:
            continue
    return nets


def _endpoint_host(url: str) -> str:
    try:
        return str(urllib.parse.urlsplit(url).hostname or "")
    except ValueError:
        return ""


def _endpoint_port(url: str, default: int = DEFAULT_PEER_PORT) -> int:
    try:
        return int(urllib.parse.urlsplit(url).port or default)
    except ValueError:
        return default


def candidate_endpoints(port: int | None = None) -> list[dict]:
    """All candidates for the dedicated peer listener, not the 6080 UI."""
    p = int(port or os.environ.get("TAA_PEER_PORT", DEFAULT_PEER_PORT))
    raw: list[dict] = [{
        "kind": "peer-loopback", "iface": "loopback", "ip": "127.0.0.1",
        "netmask": "", "scope": "loopback", "priority": 999,
        "url": f"http://127.0.0.1:{p}",
    }]
    for item in interfaces():
        ip = str(item.get("ip") or "")
        scope = str(item.get("scope") or "")
        if not ip or scope in ("loopback", "link-local") or ip.startswith("127."):
            continue
        if item.get("family") == "inet6":
            url = f"http://[{ip}]:{p}"
            kind = "peer-ipv6"
            priority = 30
        else:
            url = f"http://{ip}:{p}"
            kind = "peer-vpn" if scope == "vpn" else "peer-lan"
            priority = 40 if scope == "vpn" else 10
        raw.append({
            "kind": kind, "iface": str(item.get("iface") or ""), "ip": ip,
            "netmask": str(item.get("netmask") or ""), "scope": scope,
            "priority": priority, "url": url,
        })
    # Explicit legacy override; still a candidate, not a replacement for discovery.
    override = (os.environ.get("TAA_LAN_IP") or "").strip()
    if override:
        raw.append({"kind": "peer-lan", "iface": "override", "ip": override,
                    "netmask": "", "scope": "private", "priority": 5,
                    "url": f"http://{override}:{p}"})
    public = (os.environ.get("TAA_PEER_PUBLIC_URL") or "").strip().rstrip("/")
    if public:
        if not public.startswith(("http://", "https://")):
            public = "https://" + public
        raw.append({"kind": "peer-public", "iface": "public", "ip": "",
                    "netmask": "", "scope": "public", "priority": 20, "url": public})
    seen: set[str] = set()
    out: list[dict] = []
    for item in sorted(raw, key=lambda x: int(x.get("priority") or 99)):
        url = str(item.get("url") or "").rstrip("/")
        if not url or url in seen:
            continue
        seen.add(url)
        item["url"] = url
        out.append(item)
    return out[:8]


def same_subnet(peer_ip: str, local_nets: list[ipaddress._BaseNetwork] | None = None) -> bool:
    try:
        addr = ipaddress.ip_address(str(peer_ip).split("%", 1)[0])
    except ValueError:
        return False
    for net in (local_nets if local_nets is not None else local_networks()):
        try:
            if addr.version == net.version and addr in net:
                return True
        except Exception:  # noqa: BLE001
            pass
    return False


def rank_endpoints(endpoints: list[dict], local_nets: list[ipaddress._BaseNetwork] | None = None) -> list[dict]:
    nets = local_nets if local_nets is not None else local_networks()
    ranked: list[tuple[int, float, dict]] = []
    for item in endpoints or []:
        if isinstance(item, str):
            item = {"kind": "peer", "url": item}
        if not isinstance(item, dict):
            continue
        url = str(item.get("url") or "").rstrip("/")
        if not url:
            continue
        host = _endpoint_host(url)
        if not host or host in ("127.0.0.1", "localhost", "::1"):
            continue
        is_same = same_subnet(host, nets)
        try:
            addr = ipaddress.ip_address(host.split("%", 1)[0])
            is_private = addr.is_private
            is_public = addr.is_global
        except ValueError:
            is_private = False
            is_public = False
        kind = str(item.get("kind") or "")
        if is_same:
            rank = 0
        elif kind == "peer-lan" or is_private:
            rank = 10
        elif kind in ("peer-ipv6", "peer-public") or is_public:
            rank = 20
        else:
            rank = 40
        if kind in ("peer-vpn",) or "vpn" in str(item.get("scope") or ""):
            rank = max(rank, 30)
        ranked.append((rank, 0.0, item))
    ranked.sort(key=lambda x: (x[0], x[1]))
    return [x[2] for x in ranked]


def probe_endpoint(url: str, *, expected_node_id: str = "", timeout: float = 1.5) -> dict[str, Any]:
    base = str(url or "").rstrip("/")
    if not base:
        return {"ok": False, "error": "empty_url"}
    target = base + "/peer/v1/ping"
    started = time.monotonic()
    try:
        req = urllib.request.Request(target, headers={"user-agent": "TAA-PeerProbe/1"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read(8192)
            data = json.loads(raw.decode("utf-8"))
        latency = round((time.monotonic() - started) * 1000, 1)
        node = str(data.get("node_id") or "")
        if expected_node_id and node != expected_node_id:
            return {"ok": False, "latency_ms": latency, "error": "node_id_mismatch",
                    "node_id": node, "url": base}
        return {"ok": bool(data.get("ok")), "latency_ms": latency, "node_id": node,
                "version": data.get("version", ""), "url": base}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "latency_ms": round((time.monotonic() - started) * 1000, 1),
                "error": f"{type(exc).__name__}: {exc}", "url": base}
