"""本地认领（P0-5 前置）：不依赖中心账号，把本机的人认成 Owner。

为什么需要（docs/534 §13.6）：`/setup/` 走的是 v0.5 那套**中心账号**向导，
没有中心就没法认领，于是安装 e2e 永远测不到"装完能不能用"。
本模块给一条**只在本机**的捷径：第一次调用创建 human Owner，并把已有的 AI
挂到它名下；第二次起一律拒绝（不覆盖已有 Owner）。

安全边界（写死在路由层，模块只做数据）：
  * 仅接受回环地址（127.0.0.1 / ::1）；
  * 仅在"尚无 Owner"时可用，幂等拒绝重复认领；
  * 每次调用都落审计（`core.audit`，source=setup）；
  * 环境变量 `TAA_LOCAL_CLAIM=0` 可整条关掉。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

OWNER_ID_PREFIX = "owner-"


def _slug(name: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff_-]+", "-", (name or "").strip().lower()).strip("-")
    return s[:32] or "owner"


def current_owner(conn) -> dict | None:
    """已认领的 Owner（human 行）；没有就 None。"""
    try:
        row = conn.execute(
            "SELECT id,name,owner_id FROM agents WHERE kind='human' "
            "ORDER BY created_at, id LIMIT 1").fetchone()
    except Exception:                                            # noqa: BLE001
        return None
    if not row:
        return None
    return {"id": str(row["id"]), "name": str(row["name"] or "")}


def claim(conn, name: str, *, home: str | Path = "") -> dict:
    """创建本地 Owner 并把无主的 AI 挂过去。

    返回 `{"ok": True|False, "reason": str, "owner": {...}, "agents_linked": n}`。
    **不抛异常**：调用方是 HTTP handler，任何异常都要变成结构化结果。
    """
    name = (name or "").strip()[:32]
    if not name:
        return {"ok": False, "reason": "name_required"}
    # 幂等：bootstrap 可能已经建了 human Owner（实测 owner id=`human`）。
    # 这种情况认领**算成功**（本机已可用），但绝不覆盖、不新建第二个 Owner。
    existing = current_owner(conn)
    if existing:
        return {"ok": True, "reason": "already_claimed", "owner": existing, "agents_linked": 0}

    owner_id = OWNER_ID_PREFIX + _slug(name)
    try:
        exists = conn.execute("SELECT 1 FROM agents WHERE id=?", (owner_id,)).fetchone()
        if exists:
            return {"ok": False, "reason": "id_taken", "owner": {"id": owner_id, "name": name}}
        conn.execute(
            "INSERT INTO agents(id,name,kind,persona_json,status,role) "
            "VALUES(?,?,'human','{}','active','coordinator')", (owner_id, name))
        linked = conn.execute(
            "UPDATE agents SET owner_id=?, owner_name=? "
            "WHERE kind='ai' AND COALESCE(owner_id,'')=''", (owner_id, name)).rowcount
        conn.commit()
    except Exception as exc:                                     # noqa: BLE001
        return {"ok": False, "reason": f"db_error:{type(exc).__name__}"}

    if home:
        try:
            p = Path(home).expanduser() / "owner.json"
            p.write_text(json.dumps({"id": owner_id, "name": name}, ensure_ascii=False) + "\n",
                         encoding="utf-8")
            p.chmod(0o600)
        except OSError:
            pass

    return {"ok": True, "reason": "claimed", "owner": {"id": owner_id, "name": name},
            "agents_linked": int(linked or 0)}
