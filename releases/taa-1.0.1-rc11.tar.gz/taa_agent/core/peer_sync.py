"""P2P event sync primitives (P10.4R-100-4).

The event log is the canonical append-only exchange; this module only provides
token-gated export/merge and deterministic validation. It does not copy SQLite
files and does not put content on the center.

For beta, the peer token is a local/shared secret (``TAA_PEER_TOKEN``). A later
step replaces it with owner/group-issued grants.
"""
from __future__ import annotations

import datetime as _dt
import hmac
import json
import os
import time
import urllib.error
import urllib.request
from typing import Any

from . import timeutil


def expected_token() -> str:
    return (os.environ.get("TAA_PEER_TOKEN") or "").strip()


def authorized(header_value: str) -> bool:
    expected = expected_token()
    if not expected:
        return False
    return hmac.compare_digest(str(header_value or ""), expected)


def validate_events(raw: Any, limit: int = 500) -> list[dict]:
    if not isinstance(raw, list):
        raise ValueError("events must be a list")
    if len(raw) > limit:
        raise ValueError(f"too many events (max {limit})")
    out: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        eid = item.get("id")
        type_ = item.get("type")
        payload = item.get("payload")
        if not isinstance(eid, str) or not eid or not isinstance(type_, str) or not type_:
            continue
        if not isinstance(payload, dict):
            continue
        try:
            lamport = int(item.get("lamport") or 0)
            ts = float(item.get("ts") or 0)
        except (TypeError, ValueError):
            continue
        event = {
            "id": eid[:128], "lamport": lamport, "node_id": str(item.get("node_id") or "")[:128],
            "type": type_[:64], "payload": payload, "ts": ts,
        }
        for k in ("signed_by", "pubkey", "signature"):
            if item.get(k):
                event[k] = str(item[k])[:4096]
        out.append(event)
    return out


def _now(ts: float | None = None) -> str:
    d = _dt.datetime.fromtimestamp(float(ts or 0), _dt.timezone.utc) if ts else _dt.datetime.now(_dt.timezone.utc)
    return d.astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _ensure_agent(conn, agent_id: str) -> None:
    agent_id = (agent_id or "").strip()
    if not agent_id:
        return
    if conn.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
        return
    from .agent_names import next_available_name
    name, _renamed = next_available_name(conn, agent_id, exclude_agent_id=agent_id[:64])
    conn.execute(
        "INSERT OR IGNORE INTO agents(id,name,kind,full_name,role,persona_json,status,last_seen) "
        "VALUES(?,?, 'ai', ?, 'executor', '{}', 'offline', datetime('now','localtime'))",
        (agent_id[:64], name[:64], name[:64]),
    )


def _ensure_channel(conn, channel_id: str, author_id: str) -> None:
    channel_id = (channel_id or "").strip()
    if not channel_id:
        return
    if conn.execute("SELECT 1 FROM channels WHERE id=?", (channel_id,)).fetchone():
        return
    name = channel_id if channel_id.startswith("#") else "#" + channel_id
    conn.execute(
        "INSERT OR IGNORE INTO channels(id,name,kind,purpose,created_by) "
        "VALUES(?,?, 'public', 'P2P synced channel', ?)",
        (channel_id[:80], name[:80], author_id[:64]),
    )


def _ensure_room(conn, room_id: str, agent_id: str) -> None:
    room_id = (room_id or "").strip()
    if not room_id:
        return
    if not conn.execute("SELECT 1 FROM rooms WHERE id=?", (room_id,)).fetchone():
        conn.execute(
            "INSERT OR IGNORE INTO rooms(id,topic,kind,title,status,created_by) "
            "VALUES(?,?, 'group', ?, 'running', ?)",
            (room_id[:80], "P2P synced room", "P2P synced room", agent_id[:64]),
        )
    if agent_id:
        conn.execute(
            "INSERT OR IGNORE INTO room_members(room_id,agent_id,kind,role) VALUES(?,?, 'ai','member')",
            (room_id[:80], agent_id[:64]),
        )


def _seen(conn, event_id: str) -> bool:
    conn.execute("CREATE TABLE IF NOT EXISTS p2p_applied(event_id TEXT PRIMARY KEY, at TEXT)")
    return bool(conn.execute("SELECT 1 FROM p2p_applied WHERE event_id=?", (event_id,)).fetchone())


def _mark(conn, event_id: str) -> None:
    conn.execute("INSERT OR IGNORE INTO p2p_applied(event_id,at) VALUES(?,datetime('now','localtime'))",
                 (event_id,))


def apply_events(conn, events: list[dict]) -> int:
    """Apply remote events to local posts/replies/room_messages.

    Idempotent by event id. Remote authors/channels/rooms get local placeholder
    rows so the existing /app UI can render them; this does not import remote
    attachment bytes (that is the next /peer/blob step).
    """
    applied = 0
    for e in events or []:
        eid = str(e.get("id") or "")
        typ = str(e.get("type") or "")
        p = e.get("payload") or {}
        if not eid or _seen(conn, eid):
            continue
        try:
            if typ == "post.created":
                author = str(p.get("author") or "")
                if not author or not p.get("id"):
                    continue
                _ensure_agent(conn, author)
                _ensure_channel(conn, str(p.get("channel") or ""), author)
                ptype = str(p.get("type") or "note")
                if ptype not in {"standup", "share", "reading", "idea", "question", "announcement",
                                 "retro", "artifact", "review", "intent", "note"}:
                    ptype = "note"
                from . import peer_blobs
                atts = []
                for a in (p.get("attachments") or []):
                    if isinstance(a, dict) and a.get("sha256"):
                        a = {**a, "url": peer_blobs.peer_url(a)}
                    atts.append(a)
                # 分享跨机：share_of 保留引用，share_snapshot 让对端在「没有原帖」时也能渲染，
                # 不留一条点开就 404 的分享卡（docs/531 的跨机补齐）。
                _snap = p.get("share_snapshot")
                if isinstance(_snap, dict):
                    _snap = json.dumps(_snap, ensure_ascii=False)
                cur = conn.execute(
                    "INSERT OR IGNORE INTO posts(id,channel_id,author_id,type,title,body,links,standup,"
                    "tags,attachments,kind,visibility,share_of,share_snapshot,status,created_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'published',?)",
                    (str(p["id"])[:80], str(p.get("channel") or "")[:80] or None, author[:64],
                     ptype, str(p.get("title") or "")[:200], str(p.get("body") or "")[:16000],
                     json.dumps(p.get("links") or [], ensure_ascii=False),
                     json.dumps(p.get("standup") or {}, ensure_ascii=False) if p.get("standup") else None,
                     json.dumps(p.get("tags") or [], ensure_ascii=False),
                     json.dumps(atts, ensure_ascii=False),
                     str(p.get("kind") or "public_channel"), str(p.get("visibility") or "public"),
                     str(p.get("share_of") or "")[:80] or None, _snap or None,
                     _now(e.get("ts"))))
                if cur.rowcount:
                    conn.execute("INSERT OR IGNORE INTO thread_state(post_id,last_activity) VALUES(?,?)",
                                 (str(p["id"])[:80], _now(e.get("ts"))))
                    applied += 1
            elif typ == "reply.created":
                post_id = str(p.get("post_id") or "")
                author = str(p.get("author") or "")
                if not post_id or not author or not p.get("body"):
                    continue
                if not conn.execute("SELECT 1 FROM posts WHERE id=?", (post_id,)).fetchone():
                    continue
                _ensure_agent(conn, author)
                kind = str(p.get("kind") or "comment")
                if kind not in {"fact", "derivation", "computation", "counterexample",
                                "proposal", "question", "ack", "disagree", "comment"}:
                    kind = "comment"
                conn.execute(
                    "INSERT INTO replies(post_id,parent_reply_id,author_id,depth,kind,body,evidence,status,created_at) "
                    "VALUES(?,?,?,1,?,?,?, 'visible',?)",
                    (post_id[:80], None, author[:64], kind, str(p.get("body") or "")[:8000],
                     str(p.get("evidence") or "")[:4000] or None, _now(e.get("ts"))))
                conn.execute("UPDATE thread_state SET reply_count=reply_count+1,last_activity=? WHERE post_id=?",
                             (_now(e.get("ts")), post_id))
                applied += 1
            elif typ == "room.message":
                rid = str(p.get("room_id") or "")
                agent = str(p.get("agent") or "")
                if not rid or not agent or not p.get("body"):
                    continue
                _ensure_agent(conn, agent)
                _ensure_room(conn, rid, agent)
                kind = str(p.get("kind") or "assertion")
                if kind not in {"assertion", "fact", "question", "emotion", "skip", "system"}:
                    kind = "assertion"
                from . import peer_blobs
                att = p.get("attachment_manifest")
                att_url = str(p.get("attachment") or "")
                if isinstance(att, dict) and att.get("sha256"):
                    att_url = peer_blobs.peer_url(att)
                created_utc = timeutil.from_epoch(e.get("ts")) if e.get("ts") else timeutil.now_utc_iso()
                cur = conn.execute(
                    "INSERT INTO room_messages(room_id,round,agent_id,body,kind,source,attachment,"
                    "created_at,created_at_utc) VALUES(?,?,?,?,?, 'p2p', ?,?,?)",
                    (rid[:80], int(p.get("round") or 0), agent[:64], str(p.get("body") or "")[:16000],
                     kind, att_url or None, timeutil.to_local_text(created_utc, assume="utc"),
                     created_utc))
                if cur.lastrowid:
                    try:
                        from . import app_ui
                        payload = app_ui._ws_payload(conn, rid[:80], int(cur.lastrowid))
                        if payload:
                            app_ui._ws_broadcast(rid[:80], {"type": "message", "message": payload})
                    except Exception:  # noqa: BLE001
                        pass
                    # docs/532 · P-C：拉取入库同样要派活。此前只有 push 路径
                    # （peer_server 收到 POST 后）调 _maybe_dispatch_remote，
                    # 拉回来的消息只入库不执行 —— 这就是"消息发了没人干"的一半。
                    try:
                        from . import app_ui
                        app_ui._maybe_dispatch_remote(
                            conn, rid=rid[:80], mid=int(cur.lastrowid),
                            body=str(p.get("body") or ""), source="p2p")
                    except Exception:  # noqa: BLE001
                        pass
                applied += 1
            else:
                # Unknown event types are still marked as seen to avoid replay.
                _mark(conn, eid)
                continue
            _mark(conn, eid)
        except Exception:
            # One malformed/remote event must not block the rest.
            continue
    conn.commit()
    return applied


def pull_events(base: str, token: str, since: int = 0, *, timeout: int = 30) -> list[dict]:
    """Pull incremental events from a peer's /v1/peer/events endpoint."""
    events, _next, _node = pull_events_page(base, token, since, timeout=timeout)
    return events


def push_events(base: str, token: str, events: list[dict], *, timeout: int = 30) -> dict:
    """Push events to a peer's /v1/peer/events endpoint."""
    body = json.dumps({"events": events}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request((base or "").rstrip("/") + "/v1/peer/events",
                                 data=body, method="POST",
                                 headers={"content-type": "application/json",
                                          "X-TAA-Peer-Token": token,
                                          "user-agent": "TAA-Peer/0.1"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ------------------------------------------------------------------ P2P orchestration
def _peer_base(base: str) -> str:
    return (base or "").strip().rstrip("/")


def _cursor_table(conn) -> None:
    conn.execute("CREATE TABLE IF NOT EXISTS p2p_cursors("
                 "peer TEXT PRIMARY KEY, since INTEGER NOT NULL DEFAULT 0, updated_at TEXT)")
    conn.commit()


def cursor_get(conn, base: str) -> int:
    _cursor_table(conn)
    row = conn.execute("SELECT since FROM p2p_cursors WHERE peer=?", (_peer_base(base),)).fetchone()
    return int(row["since"]) if row else 0


def cursor_set(conn, base: str, since: int) -> None:
    _cursor_table(conn)
    conn.execute(
        "INSERT INTO p2p_cursors(peer,since,updated_at) VALUES(?,?,datetime('now','localtime')) "
        "ON CONFLICT(peer) DO UPDATE SET since=excluded.since,updated_at=excluded.updated_at",
        (_peer_base(base), int(since or 0)))
    conn.commit()


def _retry(fn, *, attempts: int = 3, base_delay: float = 0.25):
    """Retry transient peer failures with bounded exponential backoff."""
    last = None
    for i in range(max(1, int(attempts or 1))):
        try:
            return fn()
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            last = exc
            if i + 1 < attempts:
                time.sleep(base_delay * (2 ** i))
    raise last


def pull_events_page(base: str, token: str, since: int = 0, *, timeout: int = 30,
                     attempts: int = 3) -> tuple[list[dict], int, str]:
    """Return (events, source_next_since, source_node) with retry."""
    url = _peer_base(base) + "/v1/peer/events?since=" + str(int(since or 0))

    def one():
        req = urllib.request.Request(url, headers={
            "X-TAA-Peer-Token": token,
            "user-agent": "TAA-Peer/0.1",
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    d = _retry(one, attempts=attempts)
    events = validate_events(d.get("events") or [])
    next_since = int(d.get("next_since") or 0)
    if next_since <= 0:
        next_since = max([int(e.get("lamport") or 0) for e in events] or [int(since or 0)])
    return events, next_since, str(d.get("node") or "")


def event_blob_manifests(events: list[dict]) -> dict[str, dict]:
    """Collect sha256 manifests carried by remote post/room events."""
    out: dict[str, dict] = {}
    for e in events or []:
        typ = str(e.get("type") or "")
        p = e.get("payload") or {}
        items = []
        if typ == "post.created" and isinstance(p.get("attachments"), list):
            items = p.get("attachments") or []
        elif typ == "room.message":
            if isinstance(p.get("attachment_manifest"), dict):
                items = [p.get("attachment_manifest")]
        for item in items:
            if not isinstance(item, dict):
                continue
            sha = str(item.get("sha256") or "").strip().lower()
            if len(sha) == 64 and all(c in "0123456789abcdef" for c in sha):
                out.setdefault(sha, item)
    return out


def sync_from_peer(base: str, token: str, conn, *, since: int | None = None,
                   log=None, fetch_blobs: bool = True, timeout: int = 30,
                   attempts: int = 3, allow_unsigned: bool = False) -> dict:
    """Pull -> merge -> apply -> fetch missing blobs.

    The cursor only advances when every referenced blob was fetched and verified.
    If a blob is unavailable, the next call re-pulls the same events and retries
    the blob instead of permanently losing the attachment.
    """
    from . import peer_blobs, peer_sign

    base = _peer_base(base)
    if not base:
        raise ValueError("peer base required")
    current = cursor_get(conn, base) if since is None else int(since or 0)
    events, next_since, node = pull_events_page(base, token, current, timeout=timeout,
                                                attempts=attempts)
    events, signature_errors = peer_sign.verify_events(conn, events, allow_unsigned=allow_unsigned)
    if signature_errors:
        raise ValueError("peer signature rejected: " + ",".join(signature_errors[:3]))
    accepted = log.merge(events) if log is not None else 0
    applied = apply_events(conn, events)

    fetched = 0
    errors: list[str] = []
    missing = 0
    if fetch_blobs:
        for sha, item in event_blob_manifests(events).items():
            try:
                target = peer_blobs.blob_path(sha)
            except ValueError:
                errors.append("bad sha256")
                continue
            if target.is_file():
                continue
            missing += 1
            try:
                _retry(lambda s=sha: peer_blobs.fetch_blob(base, token, s, timeout=timeout),
                       attempts=attempts)
                fetched += 1
            except Exception as exc:  # noqa: BLE001 — keep syncing other blobs
                errors.append(f"{sha[:12]}: {type(exc).__name__}")
    if not errors:
        cursor_set(conn, base, next_since)
    conn.commit()
    return {
        "ok": not errors,
        "peer": base,
        "node": node,
        "since": current,
        "next_since": next_since,
        "events": len(events),
        "accepted": accepted,
        "applied": applied,
        "blobs_fetched": fetched,
        "blobs_missing": missing,
        "blob_errors": errors,
    }
