"""首席 agent 裁决（唯一真相点）。

Owner 定稿（2026-11-03）：
  1) 7 天积分最高者；
  2) **选不出**（与最高分同档不足 1.0 分，或全无积分）→ 资料最完整的 agent；
  3) **再选不出**（完整度并列）→ 第一个被创建的 agent。

工程约定：
  - 不是"三次 if-else 尝试"，而是**一个排序键的优先级**；`elect()` 一次算完。
  - **单 agent 短路**：`len(candidates) <= 1` 直接返回，不评分、不写 primary_terms。
    （绝大多数 owner 名下只有一个 agent，默认路径必须零开销、零 UI。）
  - 结果落 `agents.is_primary`（状态，不是每次现算），换人时追加一条 `primary_terms`
    （任期 7 天，一年最多 52 行/owner）。
  - 全部纯 SQL + 文件存在性，无 LLM、无随机 → 同一份数据在任何机器上裁决结果相同。

对外入口：
  `elect(conn, owner_id, persist=True)` / `my_agent(conn, owner_id)` / `sync(conn)`。
"""
from __future__ import annotations

import json

SCORE_TOLERANCE = 1.0      # 与最高分差不足一档 → 视为"选不出"
SCORE_WINDOW_DAYS = 7      # 任期 7 天

# 资料完整度：逐项可算、可解释，不引 LLM 判断（满分 14）
COMPLETENESS_SPEC = (
    ("persona_json 非空且非 {} / null", 3),
    ("full_name 非空", 1),
    ("agent_profiles: summary_json / values_json / interests_json 各 1", 3),
    ("employees: position / skills_json / job_req 各 1", 3),
    ("agents/<id>/resume.md 存在且 >200 字", 2),
    ("agents/<id>/working.json 存在", 1),
    ("agents/<id>/memory.db 存在且 >1KB", 1),
)
COMPLETENESS_FULL = sum(p for _, p in COMPLETENESS_SPEC)

_SYS_EXCLUDE = " and id<>'system' and coalesce(name,'')<>'系统'"


# ------------------------------------------------------------------ 候选
def candidates(conn, owner_id: str) -> list:
    """同一 owner 名下的 active ai agent，按"第一个被创建"排序（第三级判据天然就位）。"""
    return conn.execute(
        "select id, created_at from agents "
        "where kind='ai' and coalesce(owner_id,'')=? and status<>'paused'" + _SYS_EXCLUDE +
        " order by created_at, id", (owner_id or "",)).fetchall()


def score_7d(conn, agent_ids: list[str]) -> dict[str, float]:
    """近 7 天积分（负分也计入，扣分应当拉低排名）。

    数据源 = `score_events`（由 `core/score.settle` 从 reputation_events 折算，
    幂等、口径可换版）。**不直接读 reputation_events** —— 那是原始事实，不是裁决口径。
    """
    if not agent_ids:
        return {}
    from . import score as _score
    try:
        return _score.totals(conn, agent_ids, days=SCORE_WINDOW_DAYS)
    except Exception:                                          # noqa: BLE001
        return {}


# ------------------------------------------------------------------ 完整度
def completeness(conn, agent_id: str) -> int:
    """资料完整度 0–14（字段清单见本模块 `COMPLETENESS_SPEC`）。

    缺表/缺目录一律算 0，绝不抛错 —— 裁决不能因为某个可选档案缺失就失败。
    """
    pts = 0
    try:
        row = conn.execute(
            "select persona_json, full_name from agents where id=?", (agent_id,)).fetchone()
    except Exception:                                          # noqa: BLE001
        row = None
    if row:
        persona = str(row[0] or "").strip()
        if persona and persona not in ("{}", "null", "None"):
            pts += 3
        if str(row[1] or "").strip():
            pts += 1

    for sql in (
        "select summary_json, values_json, interests_json from agent_profiles where agent_id=?",
        "select position, skills_json, job_req from employees where agent_id=?",
    ):
        try:
            r = conn.execute(sql, (agent_id,)).fetchone()
        except Exception:                                      # noqa: BLE001
            r = None
        if r:
            pts += sum(1 for v in r if str(v or "").strip())

    try:
        from .persona import agent_dir
        d = agent_dir(agent_id)
        resume = d / "resume.md"
        if resume.exists() and len(resume.read_text(encoding="utf-8", errors="ignore")) > 200:
            pts += 2
        if (d / "working.json").exists():
            pts += 1
        mem = d / "memory.db"
        if mem.exists() and mem.stat().st_size > 1024:
            pts += 1
    except Exception:                                          # noqa: BLE001
        pass
    return pts


# ------------------------------------------------------------------ 裁决
def elect(conn, owner_id: str, *, persist: bool = True) -> dict:
    """三级裁决。返回裁决详情；`persist=True` 时同步 `agents.is_primary` 与任期账本。

    ★ `persist=True` 会**先折算积分**（`score.settle`，幂等）。这一步不能省：
      `settle` 若只在启动时跑，惰性重评（7 天到期）读到的就是过期积分 —— 端到端自检
      实测踩到过（新事件没折进去，裁决退化成"最早创建"）。
    """
    if persist:
        try:
            from . import score as _score
            _score.settle(conn, owner_id)
        except Exception:                                      # noqa: BLE001
            pass
    cands = candidates(conn, owner_id)
    ids = [str(r[0]) for r in cands]
    if not ids:
        return {"owner_id": owner_id or "", "agent_id": "", "reason": "none",
                "changed": False, "candidates": []}

    if len(ids) == 1:
        # 单 agent：只把 is_primary 写成唯一真相，**不记任期**（没有竞争就没有任期）。
        res = {"owner_id": owner_id or "", "agent_id": ids[0], "reason": "single",
               "changed": False,
               "candidates": [{"id": ids[0], "score": 0.0, "completeness": 0,
                               "created_at": str(cands[0][1] or "")}]}
        if persist:
            res["changed"] = _persist(conn, owner_id, ids[0], "single", [], record_term=False)
        return res

    scores = score_7d(conn, ids)
    comps = {aid: completeness(conn, aid) for aid in ids}
    detail = [{"id": aid, "score": scores.get(aid, 0.0), "completeness": comps[aid],
               "created_at": str(cands[i][1] or "")} for i, aid in enumerate(ids)]

    # ① 7 天积分：与最高分同档（差 < 1.0）者进入下一级
    top = max(d["score"] for d in detail)
    pool = [d for d in detail if d["score"] >= top - SCORE_TOLERANCE]
    reason = "score"

    # ② 选不出 → 资料最完整
    if len(pool) > 1:
        best = max(d["completeness"] for d in pool)
        pool = [d for d in pool if d["completeness"] == best]
        reason = "completeness"

    # ③ 再选不出 → 第一个被创建的（detail 已按 created_at, id 升序）
    if len(pool) > 1:
        pool = pool[:1]
        reason = "created_at"

    winner = pool[0]["id"]
    changed = False
    if persist:
        changed = _persist(conn, owner_id, winner, reason, detail)
    return {"owner_id": owner_id or "", "agent_id": winner, "reason": reason,
            "changed": changed, "candidates": detail}


def _persist(conn, owner_id: str, agent_id: str, reason: str, detail: list,
             *, record_term: bool = True) -> bool:
    """写 `agents.is_primary`；`record_term` 时才追加任期（换人）。返回是否发生变更。"""
    cur = conn.execute(
        "select id from agents where kind='ai' and coalesce(owner_id,'')=? and is_primary=1"
        + _SYS_EXCLUDE + " order by created_at, id limit 1", (owner_id or "",)).fetchone()
    prev = str(cur[0]) if cur else ""
    snapshot = json.dumps(detail, ensure_ascii=False)
    if prev == agent_id:
        return False
    conn.execute("update agents set is_primary=0 where kind='ai' and coalesce(owner_id,'')=?"
                 + _SYS_EXCLUDE, (owner_id or "",))
    conn.execute("update agents set is_primary=1 where id=?", (agent_id,))
    if record_term:
        conn.execute("update primary_terms set to_at=datetime('now','localtime') "
                     "where owner_id=? and to_at is null", (owner_id or "",))
        conn.execute("insert into primary_terms(owner_id, agent_id, reason, score_snapshot) "
                     "values(?,?,?,?)", (owner_id or "", agent_id, reason, snapshot))
    conn.commit()
    return True


def my_agent(conn, owner_id: str) -> str:
    """我这边的首席。

    任期制（7 天）用**惰性重评**实现，不挂后台调度：
      - 任期内 → 直接返回已落库状态，积分再变也不换人（这正是任期的意义）；
      - 任期到期 / 从没裁决过 → 现算并落库。
    好处：不需要 cron、不会因为进程没起而漏评，且 `elect` 只在真换人时才写库。
    """
    row = conn.execute(
        "select id from agents where kind='ai' and coalesce(owner_id,'')=? and is_primary=1"
        + _SYS_EXCLUDE + " and status<>'paused' order by created_at, id limit 1",
        (owner_id or "",)).fetchone()
    aid = str(row[0]) if row else ""
    if aid:
        if len(candidates(conn, owner_id)) <= 1 or not term_expired(conn, owner_id):
            return aid
    return str(elect(conn, owner_id).get("agent_id") or "") or aid


def owners(conn) -> list[str]:
    rows = conn.execute(
        "select distinct coalesce(owner_id,'') o from agents where kind='ai' and status<>'paused'"
        + _SYS_EXCLUDE).fetchall()
    return [str(r[0] or "") for r in rows]


def sync(conn) -> list[dict]:
    """启动时对每个 owner 跑一次裁决（多 agent 才有实质；单 agent 直接短路）。"""
    out = []
    for oid in owners(conn):
        try:
            out.append(elect(conn, oid))
        except Exception as e:                                 # noqa: BLE001
            out.append({"owner_id": oid, "agent_id": "", "reason": "error", "error": str(e)})
    return out


def current_term(conn, owner_id: str) -> dict | None:
    try:
        r = conn.execute(
            "select agent_id, from_at, reason from primary_terms "
            "where owner_id=? and to_at is null order by id desc limit 1",
            (owner_id or "",)).fetchone()
    except Exception:                                          # noqa: BLE001
        return None
    return {"agent_id": str(r[0]), "from_at": r[1], "reason": r[2]} if r else None


def term_expired(conn, owner_id: str, *, days: int = SCORE_WINDOW_DAYS) -> bool:
    """任期是否满 7 天（满则下一轮应重评；供后续调度器调用，当前只读）。"""
    t = current_term(conn, owner_id)
    if not t:
        return True
    try:
        from datetime import datetime, timedelta
        start = datetime.fromisoformat(str(t["from_at"]))
        return datetime.now() - start >= timedelta(days=days)
    except Exception:                                          # noqa: BLE001
        return True


__all__ = ["elect", "my_agent", "sync", "candidates", "score_7d", "completeness",
           "owners", "current_term", "term_expired", "SCORE_TOLERANCE", "SCORE_WINDOW_DAYS"]
