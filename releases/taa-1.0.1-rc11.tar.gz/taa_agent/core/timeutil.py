"""UTC / local time helpers for chat messages.

Wire format is UTC ISO-8601 (`YYYY-MM-DDTHH:MM:SSZ`). SQLite keeps the
legacy local `created_at` for compatibility, plus canonical `created_at_utc`.
"""
from __future__ import annotations

import datetime as _dt
from zoneinfo import ZoneInfo

UTC = _dt.timezone.utc
LOCAL_TZ = _dt.datetime.now().astimezone().tzinfo or UTC
UTC_FMT = "%Y-%m-%dT%H:%M:%SZ"
LOCAL_FMT = "%Y-%m-%d %H:%M:%S"


def parse(value, *, assume: str = "local") -> _dt.datetime | None:
    """Parse ISO/SQLite timestamps; naive values use `assume` (local/utc)."""
    if value is None or value == "":
        return None
    if isinstance(value, _dt.datetime):
        dt = value
    else:
        text = str(value).strip()
        if not text:
            return None
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            dt = _dt.datetime.fromisoformat(text)
        except ValueError:
            for fmt in (LOCAL_FMT, "%Y-%m-%d %H:%M", "%Y-%m-%d"):
                try:
                    dt = _dt.datetime.strptime(text, fmt)
                    break
                except ValueError:
                    continue
            else:
                return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC if assume == "utc" else LOCAL_TZ)
    return dt


def to_utc_iso(value, *, assume: str = "local") -> str:
    dt = parse(value, assume=assume)
    return "" if dt is None else dt.astimezone(UTC).strftime(UTC_FMT)


def to_local_text(value, *, assume: str = "utc") -> str:
    dt = parse(value, assume=assume)
    return "" if dt is None else dt.astimezone(LOCAL_TZ).strftime(LOCAL_FMT)


def display_local(value, *, assume: str = "utc") -> str:
    """Display as local `YYYY-MM-DD HH:MM`; used by chat UI."""
    dt = parse(value, assume=assume)
    return "" if dt is None else dt.astimezone(LOCAL_TZ).strftime("%Y-%m-%d %H:%M")


def now_utc_iso() -> str:
    return _dt.datetime.now(UTC).strftime(UTC_FMT)


def now_local_text() -> str:
    return _dt.datetime.now(LOCAL_TZ).strftime(LOCAL_FMT)


def from_epoch(ts) -> str:
    try:
        return _dt.datetime.fromtimestamp(float(ts), UTC).strftime(UTC_FMT)
    except (TypeError, ValueError, OSError):
        return now_utc_iso()


def message_time(row, *, assume_missing_utc: bool = False) -> str:
    """Best display time for a room_messages row/dict.

    New rows have `created_at_utc`; legacy rows fall back to `created_at`.
    Legacy local rows are interpreted as local, center/peer rows as UTC.
    """
    try:
        utc = row["created_at_utc"]
    except (KeyError, IndexError, TypeError):
        utc = None
    if utc:
        shown = display_local(utc, assume="utc")
        if shown:
            return shown
    try:
        local = row["created_at"]
    except (KeyError, IndexError, TypeError):
        local = None
    if not local:
        return ""
    source = ""
    try:
        source = str(row["source"] or "")
    except (KeyError, IndexError, TypeError):
        pass
    assume = "utc" if assume_missing_utc or source in ("center", "peer", "p2p") else "local"
    return display_local(local, assume=assume)
