"""极简 HTML DOM + CSS 子集选择器（只服务本项目抽取器）。

**为什么不用正则**（2026-10-14 实测教训，三处真缺陷）：
  · `re.findall` **不重叠** → 嵌套标签看不见：`<time datetime>` 落在 `<p class="meta">` 里会被整段吞掉 → 抽不到日期；
  · 自闭合标签（`<meta>` / `<img>`）没有闭合标签 → 「同名闭合」匹配永远失败 → 抽不到作者；
  · 句子拼接会把 `<p>` 之间的空行抹掉 → 门禁的「段落数」检查误判为不完整。
真 DOM 一次解决以上三件事。选择器只支持本项目用到的 CSS 子集。
"""
from __future__ import annotations

import re
from html.parser import HTMLParser

VOID = frozenset({"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
                  "meta", "param", "source", "track", "wbr"})
BLOCK = frozenset({"address", "article", "aside", "blockquote", "br", "dd", "div", "dl", "dt",
                   "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4",
                   "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section",
                   "table", "td", "th", "tr", "ul", "figcaption"})


class Node:
    __slots__ = ("tag", "attrs", "children", "parent", "text")

    def __init__(self, tag: str, attrs: dict | None = None, parent: "Node | None" = None):
        self.tag = tag
        self.attrs = attrs or {}
        self.children: list[Node] = []
        self.parent = parent
        self.text = ""


class _Builder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("#document")
        self.cur = self.root

    def handle_starttag(self, tag, attrs):
        node = Node(tag, {k: (v or "") for k, v in attrs}, self.cur)
        self.cur.children.append(node)
        if tag not in VOID:
            self.cur = node

    def handle_startendtag(self, tag, attrs):
        self.cur.children.append(Node(tag, {k: (v or "") for k, v in attrs}, self.cur))

    def handle_endtag(self, tag):
        n = self.cur
        while n is not self.root and n.tag != tag:
            n = n.parent
        if n is not self.root:
            self.cur = n.parent

    def handle_data(self, data):
        if data.strip():
            t = Node("#text", parent=self.cur)
            t.text = data
            self.cur.children.append(t)


def parse(html: str) -> Node:
    b = _Builder()
    b.feed(html or "")
    b.close()
    return b.root


def _match(node: Node, part: str) -> bool:
    m = re.match(r"^([a-zA-Z][\w-]*)?((?:\.[\w-]+)*)((?:\[[\w-]+(?:=[^\]]*)?\])*)$", part)
    if not m:
        return False
    tag, classes, atts = m.group(1), m.group(2) or "", m.group(3) or ""
    if tag and node.tag.lower() != tag.lower():
        return False
    want = re.findall(r"\.([\w-]+)", classes)
    if want:
        have = set((node.attrs.get("class") or "").split())
        if not all(c in have for c in want):
            return False
    for k, v in re.findall(r"\[([\w-]+)(?:=\"?([^\]\"]*)\"?)?\]", atts):
        if k not in node.attrs:
            return False
        if v and v.lower() not in (node.attrs[k] or "").lower():
            return False
    return True


def _descendants(node: Node, part: str, out: list[Node]) -> None:
    for c in node.children:
        if c.tag == "#text":
            continue
        if _match(c, part):
            out.append(c)
        _descendants(c, part, out)


def select_all(node: Node, sel: str) -> list[Node]:
    """CSS 子集：`tag` / `.cls` / `tag.cls` / `[attr]` / `[attr=val]`；空格 = 后代组合。返回文档序。"""
    cur = [node]
    for part in (sel or "").strip().split():
        nxt: list[Node] = []
        for n in cur:
            _descendants(n, part, nxt)
        cur = nxt
        if not cur:
            return []
    return cur


def attr(node: Node, name: str, default: str = "") -> str:
    return (node.attrs.get(name) or default) if node is not None else default


def text(node: Node, skip: frozenset = frozenset({"script", "style"})) -> str:
    """取文本；**块级标签之间留空行**（保留段落结构，供完整性门禁查段落数）。"""
    if node is None:
        return ""
    parts: list[str] = []

    def walk(n: Node) -> None:
        for c in n.children:
            if c.tag == "#text":
                parts.append(c.text)
            elif c.tag in skip:
                continue
            elif c.tag in BLOCK:
                parts.append("\n\n")
                walk(c)
                parts.append("\n\n")
            else:
                parts.append(" ")
                walk(c)
                parts.append(" ")

    walk(node)
    s = "".join(parts)
    s = re.sub(r"[ \t\r\f\v]+", " ", s)
    s = re.sub(r" *\n *", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()
