"""私聊 DM（M2）：请求制 + 未读 + 撤回。

依据：`docs/79_朋友圈与私聊DM_方案.md` §4（数据模型）/ §5（交互）/ §7（M2 判据）。
M2 判据（docs/79 §7）：① 非好友首条 →「请求」态，接受前对方**看不到正文**；
② 会话列表未读数准确（发 3 条未读 = 3）；③ 撤回后显示占位且**不计未读**；
④ 消息附件走既有隐私门禁（复用 `/v1/uploads`）。

设计红线（docs/79 §9）：
  * 正文可见性**一律服务端过滤**——pending 会话对收方把 body/attachments 置空，
    前端藏不算实现；单会话不可见一律 404（不泄露存在性）。
  * 屏蔽（blocked）后**不再收到任何消息**：发送直接 403。
  * 撤回一律**软删**（recalled_at），行保留可审计；撤回占位**不计未读**。
  * 复用既有通知（`community.add_notification`）与上传层（`/v1/uploads`）。

会话身份口径：**私聊不授予朋友圈可见性**。接受一个陌生人私聊 ≠ 加为好友
（好友仅由 `project_members` 派生或显式 `friendships` 请求产生，见 docs/80 §2）。
但**屏蔽**同步写 `friendships.status='blocked'`（与 docs/79 §3「blocked 一律视为非好友」一致）。
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime

from . import community
from . import moments as moments_mod

MAX_BODY = 2000
MAX_ATTACH = 9
UPLOAD_PREFIX = "/static/uploads/"
# 每台机器约 3 台；单会话一次拉取上限
MAX_LIMIT = 200
VISIBLE_STATES = ("pending", "accepted")


class DmError(ValueError):
    """业务校验失败 → 422（code 为契约错误码）。"""

    http = 422

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class DmNotFound(Exception):
    """会话/消息不存在，或当前 agent 不是参与者 → 404（不泄露存在性）。"""


class DmForbidden(Exception):
    """被屏蔽 / 已拒绝 / 非发送者撤回 → 403。"""


class DmConflict(Exception):
    """请求未接受前不能回复 → 409。"""


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def new_id(prefix: str = "dm") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _loads(v, default):
    try:
        return json.loads(v) if v else default
    except (TypeError, ValueError):
        return default


def norm_pair(x: str, y: str) -> tuple[str, str]:
    """a_id < b_id 规范化（docs/79 §4：避免重复会话）。"""
    return (x, y) if x < y else (y, x)


# ------------------------------------------------------------------ 读取
def _row(conn, thread_id: str):
    return conn.execute("SELECT * FROM dm_threads WHERE id=?", (thread_id,)).fetchone()


def peer_of(row, me: str) -> str:
    return row["b_id"] if row["a_id"] == me else row["a_id"]


def is_participant(row, me: str) -> bool:
    return me in (row["a_id"], row["b_id"])


def get_thread(conn, me: str, thread_id: str):
    """取会话；非参与者 → 404（不泄露存在性）。"""
    row = _row(conn, thread_id)
    if not row or not is_participant(row, me):
        raise DmNotFound()
    return row


def _get_pair(conn, x: str, y: str):
    a, b = norm_pair(x, y)
    return conn.execute("SELECT * FROM dm_threads WHERE a_id=? AND b_id=?", (a, b)).fetchone()


def _is_blocked(conn, x: str, y: str) -> bool:
    """friendships 里任一方向 blocked 即视为屏蔽（与 docs/79 §3 口径一致）。"""
    r = conn.execute(
        "SELECT 1 FROM friendships WHERE status='blocked' AND "
        "((a_id=? AND b_id=?) OR (a_id=? AND b_id=?)) LIMIT 1",
        (x, y, y, x)).fetchone()
    return bool(r)


def _check_agent(conn, agent_id: str) -> None:
    if not conn.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
        raise DmError("bad_target")


def reconcile_friend_threads(conn, me: str | None = None) -> int:
    """把**好友之间**遗留的 `pending` 会话升为 `accepted`（好友不该再停在「请求」态）。

    背景：会话状态在**建会话那一刻**由 `is_friend` 决定（见 `get_or_create_thread`）。
    若两人之前不是好友、后来因**项目组/全队派生**成为好友（`source` project/team），
    旧会话会一直停在 pending，导致好友之间无法互发（`send` 对收方返回 409）。
    本函数幂等补偿这种滞后：`blocked` 不受影响（屏蔽优先）。
    """
    sql = "SELECT * FROM dm_threads WHERE state='pending'"
    params: tuple = ()
    if me is not None:
        sql += " AND (a_id=? OR b_id=?)"
        params = (me, me)
    rows = conn.execute(sql, params).fetchall()
    changed = 0
    for r in rows:
        x, y = (me, peer_of(r, me)) if me is not None else (r["a_id"], r["b_id"])
        if x and y and moments_mod.is_friend(conn, x, y):
            conn.execute("UPDATE dm_threads SET state='accepted', requested_by=NULL WHERE id=?",
                         (r["id"],))
            changed += 1
    if changed:
        conn.commit()
    return changed


# ------------------------------------------------------------------ 会话
def get_or_create_thread(conn, me: str, to: str):
    """取会话；不存在则建。

    * 好友 → `state='accepted'`（可直接聊）。
    * 非好友 → `state='pending'`，`requested_by=me`（**请求制**，防骚扰）。
    """
    if not to or to == me:
        raise DmError("bad_target")
    _check_agent(conn, to)
    if _is_blocked(conn, me, to):
        raise DmForbidden()
    row = _get_pair(conn, me, to)
    if row:
        if row["state"] == "blocked":
            raise DmForbidden()
        # 好友间遗留的 pending 会话：此刻升 accepted，保证「好友即可直接私聊」
        if row["state"] == "pending" and moments_mod.is_friend(conn, me, to):
            conn.execute("UPDATE dm_threads SET state='accepted', requested_by=NULL WHERE id=?",
                         (row["id"],))
            conn.commit()
            row = _row(conn, row["id"])
        return row
    friends = moments_mod.is_friend(conn, me, to)
    a, b = norm_pair(me, to)
    tid = new_id("dm")
    now = _now()
    state = "accepted" if friends else "pending"
    requested_by = None if friends else me
    conn.execute(
        "INSERT INTO dm_threads(id,a_id,b_id,state,requested_by,last_at,a_read_at,b_read_at,"
        "a_muted,b_muted,created_at) VALUES (?,?,?,?,?,?,?,?,0,0,?)",
        (tid, a, b, state, requested_by, now,
         now if a == me else None, now if b == me else None, now))
    conn.commit()
    if not friends:
        # 「请求」也通知对方（body 在对方接受前不可见）
        community.add_notification(conn, to, "dm_request", tid,
                                   f"{me} 请求与你私聊（接受后可见）")
        conn.commit()
    return _row(conn, tid)


def send(conn, sender: str, thread_id: str, body: str = "", attachments=None):
    """发消息。校验顺序：参与者 → 屏蔽/拒绝 → 请求未接受 → 内容合法性。"""
    body = (body or "").strip()
    attachments = attachments or []
    row = get_thread(conn, sender, thread_id)
    peer = peer_of(row, sender)
    if row["state"] == "blocked" or _is_blocked(conn, sender, peer):
        raise DmForbidden()                       # ④ 屏蔽后对方再发消息被拒
    if row["state"] == "rejected":
        raise DmForbidden()
    if row["state"] == "pending" and row["requested_by"] != sender:
        raise DmConflict()                         # 收方须先 accept
    norm = _validate_content(body, attachments)
    mid = new_id("dmm")
    conn.execute(
        "INSERT INTO dm_messages(id,thread_id,sender_id,body,attachments,created_at) "
        "VALUES (?,?,?,?,?,?)",
        (mid, thread_id, sender, body, json.dumps(norm, ensure_ascii=False), _now()))
    conn.execute("UPDATE dm_threads SET last_at=? WHERE id=?", (_now(), thread_id))
    community.add_notification(conn, peer, "dm", thread_id,
                               f"{sender} 给你发了私信")
    conn.commit()
    return _msg_view(conn, conn.execute("SELECT * FROM dm_messages WHERE id=?", (mid,)).fetchone(),
                     sender, row)


def _validate_content(body: str, attachments) -> list[dict]:
    if not isinstance(attachments, list):
        raise DmError("bad_attachment")
    if len(attachments) > MAX_ATTACH:
        raise DmError("too_many_attachments")
    if not body and not attachments:
        raise DmError("body required")
    if len(body) > MAX_BODY:
        raise DmError("bad_body")
    norm: list[dict] = []
    for it in attachments:
        if isinstance(it, str):
            it = {"url": it}
        if not isinstance(it, dict) or not str(it.get("url") or "").strip():
            raise DmError("bad_attachment")
        u = str(it["url"])
        if not u.startswith(UPLOAD_PREFIX) or "/" in u[len(UPLOAD_PREFIX):]:
            raise DmError("bad_attachment_url")   # 未过上传层的 URL 一律拒绝
        item: dict = {"url": u}
        # 保留原始文件名/大小（供前端下载卡片显示；可选、有长度上限、纯展示字段）
        if it.get("name"):
            item["name"] = str(it["name"])[:120]
        if it.get("size") is not None:
            try:
                item["size"] = int(it["size"])
            except (TypeError, ValueError):
                pass
        norm.append(item)
    return norm


# ------------------------------------------------------------------ 消息视图
def _msg_view(conn, row, viewer: str, thread) -> dict:
    """单条消息的可见性投影。

    * `pending` 且 viewer 是**收方**（非发送者）→ body/attachments 置空，`hidden=true`。
    * 已撤回 → body 置空、`recalled=true`（占位由前端渲染，不返回原文）。
    """
    hidden = bool(thread["state"] == "pending" and viewer != row["sender_id"])
    recalled = bool(row["recalled_at"])
    body = None if (hidden or recalled) else row["body"]
    atts = [] if (hidden or recalled) else _loads(row["attachments"], [])
    return {
        "id": row["id"], "thread_id": row["thread_id"], "sender_id": row["sender_id"],
        "from_me": row["sender_id"] == viewer, "body": body, "attachments": atts,
        "created_at": row["created_at"], "read_at": row["read_at"],
        "recalled": recalled, "recalled_at": row["recalled_at"], "hidden": hidden,
    }


def list_messages(conn, me: str, thread_id: str, limit: int = 50,
                  before: str | None = None) -> dict:
    row = get_thread(conn, me, thread_id)
    try:
        limit = max(1, min(int(limit), MAX_LIMIT))
    except (TypeError, ValueError):
        limit = 50
    sql = "SELECT * FROM dm_messages WHERE thread_id=?"
    params: list = [thread_id]
    if before:
        sql += " AND created_at < ?"
        params.append(before)
    # ★ 排序按**插入顺序**（rowid），不能按 id：id 是随机 hex（`dmm-<8位>`），按 id 排是乱序，
    #   会让「最后一条/先接人再答事」读错上下文（DM 运行时实测踩到）。
    sql += " ORDER BY rowid DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(sql, params).fetchall()
    msgs = [_msg_view(conn, r, me, row) for r in reversed(rows)]
    return {"thread": _thread_public(conn, row, me), "messages": msgs}


def _thread_public(conn, row, me: str) -> dict:
    peer = peer_of(row, me)
    # 同上：`last_message` 也须按插入顺序（rowid），按随机 id 会取到「假最后一条」
    last = conn.execute("SELECT * FROM dm_messages WHERE thread_id=? ORDER BY rowid DESC LIMIT 1",
                        (row["id"],)).fetchone()
    return {
        "id": row["id"], "peer": moments_mod._author_view(conn, peer),
        "state": row["state"], "requested_by": row["requested_by"],
        "is_requester": row["requested_by"] == me,
        "pending_in": row["state"] == "pending" and row["requested_by"] != me,
        "accepted": row["state"] == "accepted",
        "unread": unread_in_thread(conn, me, row),
        "last_message": (_msg_view(conn, last, me, row) if last else None),
        "last_at": row["last_at"], "created_at": row["created_at"],
    }


def unread_in_thread(conn, me: str, row) -> int:
    """未读 = 对方发来的、未读、**未撤回**的消息数（撤回占位不计未读）。"""
    if row["state"] not in VISIBLE_STATES:
        return 0
    return conn.execute(
        "SELECT COUNT(*) c FROM dm_messages WHERE thread_id=? AND sender_id<>? "
        "AND read_at IS NULL AND recalled_at IS NULL", (row["id"], me)).fetchone()["c"]


def unread_total(conn, me: str) -> int:
    rows = conn.execute("SELECT * FROM dm_threads WHERE (a_id=? OR b_id=?) AND state IN (?,?)",
                        (me, me, *VISIBLE_STATES)).fetchall()
    return sum(unread_in_thread(conn, me, r) for r in rows)


def list_threads(conn, me: str) -> dict:
    reconcile_friend_threads(conn, me)      # 好友间遗留的 pending 会话升 accepted（幂等）
    rows = conn.execute(
        "SELECT * FROM dm_threads WHERE a_id=? OR b_id=? ORDER BY "
        "COALESCE(last_at, created_at) DESC, rowid DESC", (me, me)).fetchall()
    out = []
    for r in rows:
        item = _thread_public(conn, r, me)
        # 被自己屏蔽的会话保留在列表（可解封），被对方屏蔽的照常显示但发不出
        out.append(item)
    return {"threads": out, "unread_total": unread_total(conn, me)}


# ------------------------------------------------------------------ 已读
def mark_read(conn, me: str, thread_id: str) -> dict:
    """已读回执：把对方发来的未读消息全部置 read_at。仅 accepted 会话生效。"""
    row = get_thread(conn, me, thread_id)
    if row["state"] != "accepted":
        raise DmConflict()                         # 请求未接受：不产已读回执
    cur = conn.execute(
        "UPDATE dm_messages SET read_at=? WHERE thread_id=? AND sender_id<>? "
        "AND read_at IS NULL AND recalled_at IS NULL", (_now(), thread_id, me))
    col = "a_read_at" if row["a_id"] == me else "b_read_at"
    conn.execute(f"UPDATE dm_threads SET {col}=? WHERE id=?", (_now(), thread_id))
    # 复用通知：清掉该会话未读通知
    conn.execute("UPDATE notifications SET read=1 WHERE agent_id=? AND kind IN ('dm','dm_request') "
                 "AND ref=?", (me, thread_id))
    conn.commit()
    return {"marked": cur.rowcount, "unread": unread_in_thread(conn, me, _row(conn, thread_id))}


# ------------------------------------------------------------------ 请求制动作
def accept(conn, me: str, thread_id: str) -> dict:
    row = get_thread(conn, me, thread_id)
    if row["state"] == "blocked" or _is_blocked(conn, me, peer_of(row, me)):
        raise DmForbidden()
    if row["state"] == "rejected":
        raise DmForbidden()
    if row["state"] == "pending" and row["requested_by"] == me:
        raise DmForbidden()                        # 自己不能接受自己的请求
    conn.execute("UPDATE dm_threads SET state='accepted' WHERE id=?", (thread_id,))
    conn.execute("UPDATE notifications SET read=1 WHERE agent_id=? AND kind='dm_request' AND ref=?",
                 (me, thread_id))
    conn.commit()
    return {"ok": True, "thread": _thread_public(conn, _row(conn, thread_id), me)}


def reject(conn, me: str, thread_id: str) -> dict:
    """拒绝请求：不建会话（防骚扰），请求者不能再发。"""
    row = get_thread(conn, me, thread_id)
    if row["state"] != "pending" or row["requested_by"] == me:
        raise DmForbidden()
    conn.execute("UPDATE dm_threads SET state='rejected' WHERE id=?", (thread_id,))
    conn.execute("UPDATE notifications SET read=1 WHERE agent_id=? AND kind='dm_request' AND ref=?",
                 (me, thread_id))
    conn.commit()
    return {"ok": True, "thread": _thread_public(conn, _row(conn, thread_id), me)}


def block(conn, me: str, thread_id: str) -> dict:
    """屏蔽：本会话 blocked，且同步 friendships（docs/79 §3：blocked 一律非好友）。"""
    row = get_thread(conn, me, thread_id)
    peer = peer_of(row, me)
    conn.execute("UPDATE dm_threads SET state='blocked' WHERE id=?", (thread_id,))
    moments_mod.friendship_action(conn, me, peer, "block")
    conn.commit()
    return {"ok": True, "thread": _thread_public(conn, _row(conn, thread_id), me)}


# ------------------------------------------------------------------ 撤回
def recall(conn, me: str, message_id: str) -> dict:
    """撤回：仅发送者可撤；幂等；撤回后 body 置空（占位），且不再计入未读。"""
    m = conn.execute("SELECT * FROM dm_messages WHERE id=?", (message_id,)).fetchone()
    if not m:
        raise DmNotFound()
    row = get_thread(conn, me, m["thread_id"])
    if m["sender_id"] != me:
        raise DmForbidden()
    if not m["recalled_at"]:
        conn.execute("UPDATE dm_messages SET recalled_at=?, read_at=COALESCE(read_at,?) WHERE id=?",
                     (_now(), _now(), message_id))
        conn.commit()
    return _msg_view(conn, conn.execute("SELECT * FROM dm_messages WHERE id=?",
                                        (message_id,)).fetchone(), me, row)
