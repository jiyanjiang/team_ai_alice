"""执行审计（P0-6 · docs/534 §8.4）：**只读留痕，不拦截**。

口径（最小集，够查"谁在什么时候让 agent 干了什么"）：
  ts            时间（本地时区，ISO8601）
  actor         谁：agent id（子体记 `agent.sub`）或 `human`
  tool          哪个工具：执行后端名（opencode / codebuddy / claude …）
  args          参数摘要：指令前 200 字，脱敏后（去 key、去绝对路径）
  exit_code     退出码（拿不到就是 null，不猜 0）
  duration_ms   耗时（毫秒）
  ok            是否通过既有核验（沿用 executor 的判定，不另造标准）
  source        调用来源（executor / tool / cli）

设计约束：
  * `record()` **绝不抛异常**——审计不能把执行搞挂；写失败只丢一条记录；
  * 一条一行 append 到 `$TAA_HOME/audit/audit-YYYYMMDD.jsonl`（O_APPEND，不加锁）；
  * `export()` 打 tar.gz + 同名 `.sha256`，可离线校验；
  * 不记录执行输出正文、不记录文件内容——那是 `runtime/executor/` 的职责。
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_ARGS = 200

_REQUIRED = ("ts", "actor", "tool", "args", "exit_code", "duration_ms", "ok", "source")


def _home() -> Path:
    """晚绑定：测试在 import 之后才设 TAA_HOME，不能在模块级算死。"""
    env = os.environ.get("TAA_HOME", "").strip()
    return Path(env).expanduser() if env else ROOT.parent


def audit_dir() -> Path:
    return _home() / "audit"


def _scrub(text: str, limit: int = MAX_ARGS) -> str:
    """脱敏 + 截断。复用诊断包的 scrub（key / 绝对路径 / 仓库根）。"""
    try:
        from core.diag import scrub
        out = scrub(str(text or ""))
    except Exception:                                            # noqa: BLE001
        out = str(text or "")
    out = " ".join(out.split())
    return out[:limit]


def record(*, actor: str, tool: str, args: str = "", exit_code: int | None = None,
           duration_ms: int | None = None, ok: bool | None = None,
           source: str = "executor", extra: dict | None = None) -> None:
    """记一条审计。**永不抛异常**：审计失败不该影响执行。"""
    try:
        row = {
            "ts": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "actor": str(actor or "")[:80],
            "tool": str(tool or "")[:80],
            "args": _scrub(args),
            "exit_code": exit_code if isinstance(exit_code, int) else None,
            "duration_ms": duration_ms if isinstance(duration_ms, int) else None,
            "ok": bool(ok) if ok is not None else None,
            "source": str(source or "")[:40],
        }
        if extra:
            row["extra"] = {str(k)[:40]: _scrub(v, 120) for k, v in list(extra.items())[:8]}
        d = audit_dir()
        d.mkdir(parents=True, exist_ok=True)
        name = f"audit-{datetime.date.today().strftime('%Y%m%d')}.jsonl"
        path = d / name
        line = json.dumps(row, ensure_ascii=False) + "\n"
        # O_APPEND + 单次 write：多线程各写一行不会互相截断。
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.write(fd, line.encode("utf-8"))
        finally:
            os.close(fd)
    except Exception:                                            # noqa: BLE001
        pass


def files() -> list[Path]:
    d = audit_dir()
    if not d.is_dir():
        return []
    return sorted(d.glob("audit-*.jsonl"))


def stats() -> dict:
    """文件数 / 行数 / 时间范围（给 `taa audit stats` 与自检用）。"""
    fs = files()
    lines = 0
    first = last = ""
    for p in fs:
        try:
            for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
                if not raw.strip():
                    continue
                lines += 1
                try:
                    ts = json.loads(raw).get("ts") or ""
                except Exception:                                # noqa: BLE001
                    continue
                if ts and not first:
                    first = ts
                if ts:
                    last = ts
        except OSError:
            continue
    return {"dir": str(audit_dir()), "files": len(fs), "lines": lines,
            "first": first, "last": last}


def tail(n: int = 20) -> list[dict]:
    out: list[dict] = []
    for p in reversed(files()):
        try:
            for raw in reversed(p.read_text(encoding="utf-8", errors="replace").splitlines()):
                if not raw.strip():
                    continue
                try:
                    out.append(json.loads(raw))
                except Exception:                                # noqa: BLE001
                    continue
                if len(out) >= n:
                    return list(reversed(out))
        except OSError:
            continue
    return list(reversed(out))


def export(out: str | Path = "") -> Path:
    """把 `$TAA_HOME/audit/` 打成 tar.gz，并在旁边写 `<name>.sha256`。"""
    if not out:
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        out = Path.cwd() / f"taa-audit-{stamp}.tar.gz"
    path = Path(out).expanduser()
    if not path.name.endswith(".tar.gz"):
        path = path.with_suffix(path.suffix + ".tar.gz" if path.suffix else ".tar.gz")
    path.parent.mkdir(parents=True, exist_ok=True)
    d = audit_dir()
    with tarfile.open(path, "w:gz") as tf:
        if d.is_dir():
            for p in sorted(d.glob("audit-*.jsonl")):
                tf.add(p, arcname=f"audit/{p.name}")
        readme = d / "README.txt"
        if readme.is_file():
            tf.add(readme, arcname="audit/README.txt")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    Path(str(path) + ".sha256").write_text(f"{digest}  {path.name}\n", encoding="utf-8")
    return path


def verify(path: str | Path) -> tuple[bool, str]:
    """校验导出包的 sha256 旁文件。"""
    p = Path(path).expanduser()
    side = Path(str(p) + ".sha256")
    if not p.is_file():
        return False, "包不存在"
    if not side.is_file():
        return False, "缺少 .sha256"
    want = side.read_text(encoding="utf-8").split()[0].strip()
    got = hashlib.sha256(p.read_bytes()).hexdigest()
    return got == want, got
