"""把本地首席结果上报中心（**唯一 I/O 点**，`core/primary.py` 保持纯逻辑）。

为什么必须有这一步：中心 `node_agents.is_primary` 是"对方看到的我"的真相源
（好友列表、拉群成员都按它取人）。本地裁决不推上去，对方看到的就永远还是
`ORDER BY created_at` 的第一个 —— 两边判定分叉。

设计约束：
  - **best-effort**：任何失败只返回原因，绝不改本地状态、绝不抛给调用方；
  - **短超时**：5s（默认 15s 会把启动拖慢）；
  - **可注入 client**：自检里用假 client，不触网；
  - **id 映射**：本地 `agents.id` 在安装/bridge 布局下本身就是 `agt_xxx`；
    开发布局下是 `alice`，此时按 `name` ↔ 中心 `display_name` 对应（中心负责全局唯一名）。
"""
from __future__ import annotations

TIMEOUT = 5


def identity_home():
    """`identity.json` 所在目录（**与 app_ui._local_owner_id 同口径**：TAA_HOME > ~/.taa）。

    注意不要用 `db.HOME`：那是 data.db 的位置（开发布局下 = 代码根），两者不是一回事。
    """
    from pathlib import Path
    import os
    return Path(os.environ.get("TAA_HOME") or "~/.taa").expanduser()


def _local_agent_id(conn, owner_id: str) -> str:
    from . import primary as _primary
    return _primary.my_agent(conn, owner_id)


def _local_name(conn, agent_id: str) -> str:
    row = conn.execute("select name from agents where id=?", (agent_id,)).fetchone()
    return str(row[0] or "") if row else ""


def resolve_center_agent_id(conn, local_id: str, center_agents: list) -> str:
    """本地 agent id → 中心 agent_id（`agt_xxx`）。对不上返回空串。"""
    local_id = str(local_id or "").strip()
    if not local_id:
        return ""
    if local_id.startswith("agt_"):                 # 安装/bridge 布局：本来就是中心 id
        return local_id
    name = _local_name(conn, local_id).strip().lower()
    by_name = [a for a in center_agents
               if str(getattr(a, "display_name", "") or "").strip().lower() == name]
    if len(by_name) == 1:
        return str(by_name[0].agent_id)
    if len(center_agents) == 1:                      # 单 agent：没有歧义
        return str(center_agents[0].agent_id)
    return ""


def publish(conn, owner_id: str = "", *, client=None, home=None) -> dict:
    """上报一次。返回 `{"ok": bool, "reason"/"agent_id": ...}`，从不抛错。"""
    try:
        aid = _local_agent_id(conn, owner_id)
        if not aid:
            return {"ok": False, "reason": "no_local_agent"}

        from pathlib import Path
        from taa_node_v05.identity import load_state
        state = load_state(Path(home) if home else identity_home())

        target = resolve_center_agent_id(conn, aid, list(state.agents))
        if not target:
            return {"ok": False, "reason": "unmapped", "local_agent": aid}

        if client is None:
            if not state.center.base or not state.node.node_key:
                return {"ok": False, "reason": "not_connected"}
            from taa_node_v05.center import CenterClient
            client = CenterClient(state.center.base, timeout=TIMEOUT)

        client.set_primary_agent(node_key=state.node.node_key, agent_id=target)
        return {"ok": True, "agent_id": target, "local_agent": aid}
    except Exception as e:                                     # noqa: BLE001
        return {"ok": False, "reason": f"{type(e).__name__}: {e}"}


__all__ = ["publish", "resolve_center_agent_id", "identity_home", "TIMEOUT"]
