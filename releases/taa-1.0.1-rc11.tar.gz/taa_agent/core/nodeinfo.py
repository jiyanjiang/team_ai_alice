"""节点硬件探测与别名生成（D6/D7/D22）。

别名规则：自动探测 + 可手工覆盖（环境变量 TEAM_NODE_ALIAS）。
  macOS  -> MBP32G / MBA16G / MAC32G
  其他   -> WS32G / PC64G
"""
from __future__ import annotations

import hashlib
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


def _cpu_model() -> str:
    system = platform.system()
    if system == "Darwin":
        return _run(["sysctl", "-n", "machdep.cpu.brand_string"]) or platform.processor()
    if system == "Linux":
        try:
            for line in open("/proc/cpuinfo", encoding="utf-8"):
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
        except OSError:
            pass
    return platform.processor() or "unknown"


def _ram_gb() -> float:
    system = platform.system()
    if system == "Darwin":
        out = _run(["sysctl", "-n", "hw.memsize"])
        if out.isdigit():
            return round(int(out) / (1024 ** 3))
    if system == "Linux":
        try:
            for line in open("/proc/meminfo", encoding="utf-8"):
                if line.startswith("MemTotal"):
                    kb = int(line.split()[1])
                    return round(kb / (1024 ** 2))
        except OSError:
            pass
    return 0.0


def _disk() -> tuple[float, float]:
    try:
        usage = shutil.disk_usage(os.path.expanduser("~"))
        total = round(usage.total / (1024 ** 3))
        free = round(usage.free / (1024 ** 3))
        return total, free
    except Exception:
        return 0.0, 0.0


def _lan_ip() -> str:
    """本机局域网 IP。可用 TEAM_LAN_IP 覆盖；优先 192.168.x（避免 VPN/utun）。"""
    override = os.environ.get("TEAM_LAN_IP")
    if override:
        return override
    candidates: list[str] = []
    # 枚举所有网卡 inet 地址（macOS: ifconfig / Linux: ip addr）
    try:
        out = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=5).stdout
        candidates += re.findall(r"inet (?:addr:)?(\d+\.\d+\.\d+\.\d+)", out)
    except Exception:
        pass
    if not candidates:
        try:
            out = subprocess.run(["ip", "-o", "addr"], capture_output=True, text=True,
                                 timeout=5).stdout
            candidates += re.findall(r"inet (\d+\.\d+\.\d+\.\d+)", out)
        except Exception:
            pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        candidates.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidates.append(info[4][0])
    except Exception:
        pass
    def rank(ip: str) -> int:
        if ip.startswith("192.168."):
            return 0
        if ip.startswith("10."):
            return 1
        if ip.startswith("172."):
            return 3          # 含 VPN 常见段，靠后
        return 2
    usable = [ip for ip in candidates if not ip.startswith("127.")]
    if usable:
        return sorted(set(usable), key=rank)[0]
    return candidates[0] if candidates else "127.0.0.1"


def lan_ip() -> str:
    """公开接口：本机局域网 IP（`TEAM_LAN_IP` 可覆盖，优先 192.168.x）。

    全系统**对外地址**都应经此派生，**不得写死任何 LAN IP**。
    """
    return _lan_ip()


def rewrite_loopback(url: str, port: int | None = None) -> str:
    """把 URL 中的回环/通配主机换成本机当前 LAN IP（供对外分享/回传链接用）。

    - `http://127.0.0.1:6020` → `http://<当前LAN IP>:6020`（端口沿用原 URL，除非显式给 port）
    - 非回环主机原样返回（不篡改用户显式给的地址）
    """
    from urllib.parse import urlsplit, urlunsplit

    try:
        p = urlsplit(url or "")
    except Exception:
        return url
    if p.hostname not in ("127.0.0.1", "localhost", "0.0.0.0", "::1"):
        return url
    return urlunsplit(p._replace(netloc=f"{_lan_ip()}:{port or p.port or 0}"))


def public_host(fallback_port: int = 6080) -> str:
    """本机 `ip:port` 形式的对外主机（默认 6080）。"""
    return f"{_lan_ip()}:{fallback_port}"


def _available_ides() -> list[str]:
    found = []
    for ide in ("opencode", "code", "cursor", "qoder", "codebuddy", "idea", "nvim"):
        if shutil.which(ide):
            found.append(ide)
    return found


_MAC_MODEL_MAP = {
    "MacBook Pro": "MBP", "MacBook Air": "MBA", "Mac mini": "MINI",
    "iMac": "IMAC", "Mac Studio": "STUDIO", "Mac Pro": "PRO",
}


def _mac_model_name() -> str:
    out = _run(["system_profiler", "SPHardwareDataType"])
    for line in out.splitlines():
        s = line.strip()
        if s.startswith("Model Name:"):
            return s.split(":", 1)[1].strip()
    return ""


def _gpu() -> str:
    if platform.system() != "Darwin":
        return ""
    out = _run(["system_profiler", "SPDisplaysDataType"])
    for line in out.splitlines():
        s = line.strip()
        if s.startswith("Chipset Model:"):
            return s.split(":", 1)[1].strip()
    return ""


def _alias_base() -> str:
    system = platform.system()
    if system == "Darwin":
        name = _mac_model_name()
        for k, v in _MAC_MODEL_MAP.items():
            if k.lower() in name.lower():
                return v
        model = _run(["sysctl", "-n", "hw.model"])
        if model.startswith("MacBookPro"):
            return "MBP"
        if model.startswith("MacBookAir"):
            return "MBA"
        host = socket.gethostname().lower()
        if "mbp" in host or "macbookpro" in host:
            return "MBP"
        if "mba" in host:
            return "MBA"
        return "MAC"
    if system == "Windows":
        return "PC"
    return "WS"


def fingerprint() -> str:
    """稳定硬件/环境指纹：同机可复现、跨机几乎必异。

    组成 = 平台机器码（macOS IOPlatformUUID / Linux machine-id）
          + hostname + CPU 型号 + 核数 + 内存。
    """
    parts: list[str] = []
    if platform.system() == "Darwin":
        try:
            out = subprocess.run(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                capture_output=True, text=True, timeout=5).stdout
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
            if m:
                parts.append(m.group(1))
        except Exception:
            pass
    elif platform.system() == "Linux":
        for f in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                parts.append(Path(f).read_text(encoding="utf-8").strip())
                break
            except OSError:
                pass
    parts += [socket.gethostname(), _cpu_model(), str(os.cpu_count() or 0), str(_ram_gb())]
    return "|".join(parts)


def node_code(alias: str) -> str:
    """唯一机器码：`别名-<指纹4hex>`。别名段可反推机型+内存，指纹段保证去重。"""
    p = ROOT / "bootstrap" / "node_code"
    try:
        if p.exists():
            c = p.read_text(encoding="utf-8").strip()
            if c:
                return c
    except OSError:
        pass
    code = f"{alias}-{hashlib.sha256(fingerprint().encode()).hexdigest()[:4]}"
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(code, encoding="utf-8")
        os.chmod(p, 0o600)
    except OSError:
        pass
    return code


def saved_alias() -> str | None:
    p = ROOT / "bootstrap" / "node_alias"
    try:
        return p.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def save_alias(alias: str) -> None:
    if not alias:
        return
    p = ROOT / "bootstrap" / "node_alias"
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(alias, encoding="utf-8")
    except OSError:
        pass


def detect() -> dict:
    """探测本机硬件画像。别名优先级：TEAM_NODE_ALIAS > bootstrap/node_alias > 自动。"""
    ram = _ram_gb()
    disk_total, disk_free = _disk()
    alias = os.environ.get("TEAM_NODE_ALIAS") or saved_alias() or f"{_alias_base()}{int(ram)}G"
    hostname = socket.gethostname().split(".")[0]
    return {
        "hostname": hostname,
        "alias": alias,
        "node_code": node_code(alias),
        "os": f"{platform.system()} {platform.release()}",
        "arch": platform.machine(),
        "cpu_model": _cpu_model(),
        "cpu_cores": os.cpu_count() or 0,
        "ram_gb": ram,
        "gpu": _gpu(),
        "disk_total_gb": disk_total,
        "disk_free_gb": disk_free,
        "lan_ip": _lan_ip(),
        "python_version": platform.python_version(),
        "available_ides": _available_ides(),
        "is_main": 1,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(detect(), ensure_ascii=False, indent=2))
    print(f"# python={sys.version.split()[0]}", file=sys.stderr)
