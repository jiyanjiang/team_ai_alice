"""Local directory of approved friends, their Nodes, and endpoint candidates.

The center is the source of truth for friendships and node ownership.  This
module keeps a local, queryable projection so a chat page never has to ask the
center "where is my friend?" and so endpoint selection can be tested in the
background.
"""
from __future__ import annotations

import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from core.peer_network import interfaces, local_networks, probe_endpoint, rank_endpoints


def ensure_tables(conn) -> None:
    conn.execute("""
        create table if not exists peer_nodes(
            node_id text primary key,
            owner_id text not null,
            owner_username text,
            alias text,
            node_status text,
            version text,
            last_seen text,
            endpoint_json text,
            selected_url text,
            selected_kind text,
            direct_status text default 'unknown',
            latency_ms real,
            last_error text,
            updated_at text
        )
    """)
    conn.execute("""
        create table if not exists peer_candidates(
            node_id text not null,
            url text not null,
            kind text,
            iface text,
            ip text,
            netmask text,
            scope text,
            priority integer default 99,
            last_probe_at text,
            latency_ms real,
            status text default 'unknown',
            error text,
            primary key(node_id, url)
        )
    """)
    conn.execute("create index if not exists ix_peer_candidates_node on peer_candidates(node_id)")
    conn.commit()


def _parse_endpoints(raw: Any) -> list[dict]:
    if not raw:
        return []
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return [{"kind": "legacy", "url": raw}] if raw.startswith(("http://", "https://")) else []
    if isinstance(raw, list):
        endpoints = raw
    elif isinstance(raw, dict):
        endpoints = raw.get("endpoints") or []
    else:
        endpoints = []
    out: list[dict] = []
    seen: set[str] = set()
    for item in endpoints:
        if isinstance(item, str):
            item = {"kind": "peer", "url": item}
        if not isinstance(item, dict):
            continue
        url = str(item.get("url") or "").rstrip("/")
        if not url or not url.startswith(("http://", "https://")) or url in seen:
            continue
        seen.add(url)
        out.append({
            "kind": str(item.get("kind") or "peer"),
            "url": url,
            "iface": str(item.get("iface") or ""),
            "ip": str(item.get("ip") or ""),
            "netmask": str(item.get("netmask") or ""),
            "scope": str(item.get("scope") or ""),
            "priority": int(item.get("priority") or 99),
        })
    return out


def sync_from_center(conn, state, client=None) -> dict:
    """Fetch all approved friends and all their Nodes; never trust one primary."""
    ensure_tables(conn)
    if client is None:
        from taa_node_v05.center import CenterClient
        client = CenterClient(state.center.base)
    friends = (client.friends_for_node(node_key=state.node.node_key).get("friends") or [])
    seen_nodes: set[str] = set()
    total_candidates = 0
    for f in friends:
        if str(f.get("status") or "") != "approved":
            continue
        owner_id = str(f.get("friend_id") or "")
        if not owner_id:
            continue
        username = str(f.get("friend_username") or f.get("friend_alias") or owner_id)
        try:
            detail = client.friend_nodes_for_node(node_key=state.node.node_key, owner_id=owner_id)
        except Exception:
            continue
        for node in detail.get("nodes") or []:
            node_id = str(node.get("node_id") or "")
            if not node_id:
                continue
            seen_nodes.add(node_id)
            endpoints = _parse_endpoints(node.get("endpoint"))
            conn.execute(
                "insert into peer_nodes(node_id,owner_id,owner_username,alias,node_status,version,last_seen,"
                "endpoint_json,updated_at) values(?,?,?,?,?,?,?,?,datetime('now','localtime')) "
                "on conflict(node_id) do update set owner_id=excluded.owner_id,owner_username=excluded.owner_username,"
                "alias=excluded.alias,node_status=excluded.node_status,version=excluded.version,"
                "last_seen=excluded.last_seen,endpoint_json=excluded.endpoint_json,updated_at=excluded.updated_at",
                (node_id, owner_id, username, str(node.get("alias") or ""), str(node.get("status") or ""),
                 str(node.get("version") or ""), str(node.get("last_seen") or ""),
                 json.dumps(endpoints, ensure_ascii=False)),
            )
            conn.execute("delete from peer_candidates where node_id=?", (node_id,))
            for ep in endpoints:
                conn.execute(
                    "insert or replace into peer_candidates(node_id,url,kind,iface,ip,netmask,scope,priority) "
                    "values(?,?,?,?,?,?,?,?)",
                    (node_id, ep["url"], ep["kind"], ep["iface"], ep["ip"], ep["netmask"],
                     ep["scope"], ep["priority"]),
                )
                total_candidates += 1
    # docs/532 · P-B：把中心 approved 好友（owner 级）投影到本机，供
    # post_share 判定「好友可见」时把对方名下的 agent 视为好友。
    try:
        from core import friend_sync
        friend_sync.project(conn, [
            {"owner_id": str(f.get("friend_id") or ""),
             "username": str(f.get("friend_username") or f.get("friend_alias") or ""),
             "status": str(f.get("status") or "approved")}
            for f in friends])
    except Exception:                                            # noqa: BLE001
        pass
    # Remove nodes no longer returned for approved friends.
    if seen_nodes:
        placeholders = ",".join("?" for _ in seen_nodes)
        conn.execute(f"delete from peer_candidates where node_id not in ({placeholders})", tuple(seen_nodes))
        conn.execute(f"delete from peer_nodes where node_id not in ({placeholders})", tuple(seen_nodes))
    conn.commit()
    return {"ok": True, "friends": len(friends), "nodes": len(seen_nodes), "candidates": total_candidates}


def _node_rows(conn) -> list[dict]:
    ensure_tables(conn)
    rows = conn.execute("select * from peer_nodes order by owner_username,node_id").fetchall()
    return [dict(r) for r in rows]


def probe_all(conn, *, timeout: float = 1.2, max_workers: int = 12) -> dict:
    """Probe candidates and persist one selected direct endpoint per friend node."""
    ensure_tables(conn)
    rows = _node_rows(conn)
    nets = local_networks()
    jobs = []
    for node in rows:
        crows = conn.execute("select * from peer_candidates where node_id=?", (node["node_id"],)).fetchall()
        eps = [dict(r) for r in crows]
        if not eps:
            conn.execute("update peer_nodes set direct_status='unreachable',selected_url=NULL,selected_kind=NULL,"
                         "last_error='no_endpoints',latency_ms=NULL where node_id=?", (node["node_id"],))
            continue
        ranked = rank_endpoints(eps, nets)
        for ep in ranked:
            jobs.append((node, ep))
    results: list[tuple[str, dict, dict]] = []
    with ThreadPoolExecutor(max_workers=max(1, min(max_workers, len(jobs) or 1))) as pool:
        futs = {
            pool.submit(probe_endpoint, ep["url"], expected_node_id=node["node_id"], timeout=timeout): (node, ep)
            for node, ep in jobs
        }
        for fut in as_completed(futs):
            node, ep = futs[fut]
            try:
                res = fut.result()
            except Exception as exc:  # noqa: BLE001
                res = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
            results.append((node["node_id"], ep, res))
    selected: dict[str, tuple[dict, dict]] = {}
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    for node_id, ep, res in results:
        ok = bool(res.get("ok"))
        conn.execute(
            "update peer_candidates set last_probe_at=?,latency_ms=?,status=?,error=? where node_id=? and url=?",
            (now, res.get("latency_ms"), "direct" if ok else "unreachable",
             str(res.get("error") or ""), node_id, ep["url"]),
        )
        if ok:
            prev = selected.get(node_id)
            if prev is None or float(res.get("latency_ms") or 1e9) < float(prev[1].get("latency_ms") or 1e9):
                selected[node_id] = (ep, res)
    for node in rows:
        node_id = node["node_id"]
        if node_id in selected:
            ep, res = selected[node_id]
            conn.execute("update peer_nodes set selected_url=?,selected_kind=?,direct_status='direct',"
                         "latency_ms=?,last_error=NULL,updated_at=? where node_id=?",
                         (ep["url"], ep.get("kind"), res.get("latency_ms"), now, node_id))
        else:
            conn.execute("update peer_nodes set selected_url=NULL,selected_kind=NULL,direct_status='relay',"
                         "last_error='no_direct_candidate',latency_ms=NULL,updated_at=? where node_id=?",
                         (now, node_id))
    conn.commit()
    return {"ok": True, "nodes": len(rows), "probed": len(results), "direct": len(selected)}


def status(conn) -> list[dict]:
    try:
        out = []
        for row in _node_rows(conn):
            d = dict(row)
            try:
                d["endpoint_count"] = len(json.loads(d.get("endpoint_json") or "[]"))
            except Exception:
                d["endpoint_count"] = 0
            d.pop("endpoint_json", None)
            out.append(d)
        return out
    except Exception:
        return []
