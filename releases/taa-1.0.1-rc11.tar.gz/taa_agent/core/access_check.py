"""登录态 / 付费墙 → **内容不全**判断（Owner 2026-10-14）。

> 你说：**"如果不是登录状态，physicsworld 文章详情页很可能内容不全，这是需要做判断的！"**

所以"解析完整"不只看字数与段落，还要判**这一页是不是被墙截断了**：
未登录/未订阅时站点只放出前几段 → 抓下来的正文是**残的**，**不许入库**（记 `login_required`，
信息收集页标成「需登录」，你登录后重新点开一次即可）。

判据分层（**只认确定性信号，绝不拿"有没有 Subscribe 按钮"瞎猜**——页头厂告位也有 Subscribe）：
  ① **结构化**（最硬）：`<meta content_tier=locked>`、`isAccessibleForFree=false`、JSON-LD 同义字段；
  ② **文章区内的墙**：文章正文区域（`article`/`main`）内出现付费墙元素（`class/id` 含
     paywall / subscriber-wall / registration-wall / gated / truncat）或订阅墙**文案**
     （"sign in to read" / "subscribe to continue reading" / "subscribers only" …）；
  ③ **截断形态**：正文**末尾没有句末标点**（明显的半句截断），且页面出现登录/订阅 CTA → 判截断。
"""
from __future__ import annotations

import re

from .simple_dom import attr, parse, select_all
from .simple_dom import text as _text

#: 文章区内的付费墙/截断元素（类名或 id）
WALL_ATTR = re.compile(r"(paywall|subscriber[-_]?wall|registration[-_]?wall|premium[-_]?gate|"
                       r"gated[-_]?content|article[-_]?truncat|content[-_]?gate)", re.I)
#: 订阅墙文案（命中即"这页被墙"）
WALL_TEXT = re.compile(
    r"(sign in to (?:read|continue|view)|log\s?in to (?:read|continue)|subscribers? only|"
    r"subscribe to (?:continue|read|unlock|access|see)|to continue reading|"
    r"this (?:article|story|content|piece) is (?:available to|for) subscribers|"
    r"create a (?:free )?account to (?:continue|read)|become a member to (?:read|continue)|"
    r"register to (?:continue|read)|(?:reading|access) (?:is )?limited to subscribers)", re.I)
#: 登录/订阅 CTA（弱信号，只与"半句截断"合用时判截断）
CTA = re.compile(r"(sign in|log\s?in|subscribe|register|become a member|unlock)", re.I)
#: 句末标点（正文应以此收尾）
TERMINAL = re.compile(r"[.!?\u3002\uff01\uff1f\u201d\u2019\"'\)\]]\s*$")
#: 扫墙时跳过：推荐位/页脚/导航里常有 "Subscribe" 推广，**不是墙**（防误判免费全文）
SKIP = frozenset({"script", "style", "noscript", "aside", "footer", "nav", "form"})


def _article_regions(dom):
    return select_all(dom, "article") or select_all(dom, "main") or [dom]


def _wall_element(dom) -> str:
    stack = list(_article_regions(dom))
    while stack:
        n = stack.pop()
        if n.tag in SKIP:
            continue
        for k in ("class", "id", "data-paywall", "data-truncated"):
            v = attr(n, k)
            if v and (WALL_ATTR.search(v) or (k == "data-truncated" and v.lower() not in ("", "false", "0"))):
                return f"{n.tag}[{k}={v.strip()[:40]}]"
        stack.extend(n.children)
    return ""


def judge_access(html: str, body: str = "") -> tuple[bool, list[str], dict]:
    """返回 (可入库?, reasons, signals)。`可入库=False` ⇒ 页面内容不全（未登录/付费墙/截断）。"""
    if not html:
        return True, [], {"access": "unknown"}
    dom = parse(html)
    sig: dict = {}
    locked = False

    # ① 结构化信号（全页，最硬）
    for n in select_all(dom, "meta"):
        key = (attr(n, "property") or attr(n, "name")).lower()
        val = attr(n, "content").strip().lower()
        if key.endswith("content_tier") or key.endswith("content-tier"):
            sig["content_tier"] = val
            if val in ("locked", "paid", "premium", "subscriber"):
                locked = True
        if "isaccessibleforfree" in key:
            sig["isAccessibleForFree"] = val
            if val.startswith("false"):
                locked = True
    if re.search(r'"isAccessibleForFree"\s*:\s*(?:false|"false")', html, re.I):
        sig["jsonld_locked"] = True
        locked = True

    # ② 文章区内的墙：元素 ≥ 文案
    el = _wall_element(dom)
    if el:
        sig["wall_element"] = el
        locked = True
    art_txt = " ".join(_text(a, skip=SKIP) for a in _article_regions(dom))
    m = WALL_TEXT.search(art_txt)
    if m:
        sig["wall_text"] = m.group(0)[:60]
        locked = True

    # ③ 截断形态：正文末尾是半句 + 页面有 CTA
    if not locked and body:
        tail = body.strip()
        if len(tail) > 120 and not TERMINAL.search(tail):
            sig["ends_mid_sentence"] = True
            if CTA.search(art_txt):
                sig["cta"] = CTA.search(art_txt).group(0)[:30]
                return False, ["maybe_truncated"], sig

    if locked:
        return False, ["login_required"], sig
    return True, [], sig
