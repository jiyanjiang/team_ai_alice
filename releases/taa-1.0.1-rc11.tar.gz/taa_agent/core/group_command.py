"""Cross-owner command contract.

Same owner: immediate.
Different owner: target owner gets a 10-second immediate/reject override;
without a choice the command defaults to idle and runs when the target agent is
free (the actual dispatcher wiring lives in group_ingress).
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone

from . import owner_identity, presence

CONSENT_SECONDS = 10
STATES = {
    "offline_owner", "offline_agent", "ownership_invalid",
    "pending_consent", "rejected", "immediate", "idle",
    "queued", "running", "done", "failed",
}


class CommandError(ValueError):
    pass


def ensure(conn) -> None:
    conn.execute("""
      CREATE TABLE IF NOT EXISTS group_command (
        id                 TEXT PRIMARY KEY,
        group_id           TEXT,
        room_id            TEXT NOT NULL,
        local_message_id   INTEGER NOT NULL,
        center_message_id  TEXT,
        peer_message_id    TEXT,
        source_owner_id    TEXT NOT NULL,
        target_owner_id    TEXT NOT NULL,
        target_agent_id    TEXT NOT NULL,
        state              TEXT NOT NULL,
        mode               TEXT NOT NULL DEFAULT 'idle',
        consent_deadline   TEXT,
        decided_by         TEXT,
        decided_at         TEXT,
        task_id            TEXT,
        last_error         TEXT,
        created_at         TEXT DEFAULT (datetime('now','localtime')),
        updated_at         TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(room_id, local_message_id, target_agent_id)
      )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS ux_group_command_pending "
                 "ON group_command(target_owner_id, state, consent_deadline)")
    conn.commit()


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def _now() -> str:
    return _iso(datetime.now(timezone.utc))


def _row(conn, cid: str) -> dict | None:
    row = conn.execute("SELECT * FROM group_command WHERE id=?", (cid,)).fetchone()
    return dict(row) if row else None


def get(conn, cid: str) -> dict | None:
    ensure(conn)
    return _row(conn, cid)


def create(conn, *, room_id: str, local_message_id: int,
           source_owner_id: str, target_agent_id: str,
           group_id: str = "", center_message_id: str = "",
           peer_message_id: str = "", owner_online: bool | None = None,
           agent_online: bool | None = None) -> dict:
    """Create (or return the existing) command for one message+agent."""
    ensure(conn)
    source_owner_id = str(source_owner_id or "").strip()
    target_agent_id = str(target_agent_id or "").strip()
    if not source_owner_id or not target_agent_id:
        raise CommandError("source_owner_id and target_agent_id required")
    existing = conn.execute(
        "SELECT * FROM group_command WHERE room_id=? AND local_message_id=? "
        "AND target_agent_id=?", (room_id, int(local_message_id), target_agent_id)).fetchone()
    if existing:
        return {**dict(existing), "duplicate": True}

    try:
        target = owner_identity.require_agent_owner(conn, target_agent_id)
    except owner_identity.OwnerIdentityError as exc:
        raise CommandError(str(exc)) from exc
    target_owner_id = target.owner_id
    if source_owner_id == target_owner_id:
        mode = "immediate"
        owner_ok = True
    else:
        mode = "idle"
        owner_ok = bool(owner_online) if owner_online is not None \
            else presence.is_online(conn, target_owner_id, "owner")
    agent_ok = bool(agent_online) if agent_online is not None \
        else presence.is_online(conn, target_agent_id, "agent")

    now = datetime.now(timezone.utc)
    if not owner_ok and source_owner_id != target_owner_id:
        state, deadline = "offline_owner", None
    elif not agent_ok:
        state, deadline = "offline_agent", None
    elif source_owner_id == target_owner_id:
        state, deadline = "immediate", None
    else:
        state, deadline = "pending_consent", _iso(now + timedelta(seconds=CONSENT_SECONDS))

    cid = "gc-" + uuid.uuid4().hex[:12]
    conn.execute(
        "INSERT INTO group_command(id,group_id,room_id,local_message_id,center_message_id,"
        "peer_message_id,source_owner_id,target_owner_id,target_agent_id,state,mode,"
        "consent_deadline,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'),datetime('now','localtime'))",
        (cid, group_id[:80] or None, room_id, int(local_message_id),
         center_message_id or None, peer_message_id or None, source_owner_id,
         target_owner_id, target_agent_id, state, mode, deadline))
    conn.commit()
    return _row(conn, cid) or {}


def expire_due(conn) -> int:
    """Turn timed-out pending commands into the default idle state."""
    ensure(conn)
    cur = conn.execute(
        "UPDATE group_command SET state='idle',mode='idle',updated_at=datetime('now','localtime') "
        "WHERE state='pending_consent' AND consent_deadline IS NOT NULL "
        "AND consent_deadline<=?", (_now(),))
    conn.commit()
    return int(cur.rowcount or 0)


def decide(conn, cid: str, owner_id: str, decision: str) -> dict:
    """Target owner chooses immediate or reject inside the consent window."""
    ensure(conn)
    decision = str(decision or "").lower()
    if decision not in ("immediate", "reject"):
        raise CommandError("decision must be immediate|reject")
    row = get(conn, cid)
    if not row:
        raise CommandError("command_not_found")
    if str(row["target_owner_id"]) != str(owner_id or ""):
        raise CommandError("not_target_owner")
    if row["state"] != "pending_consent":
        raise CommandError(f"command_not_pending:{row['state']}")
    state = "immediate" if decision == "immediate" else "rejected"
    cur = conn.execute(
        "UPDATE group_command SET state=?,mode=?,decided_by=?,decided_at=?,"
        "updated_at=datetime('now','localtime') "
        "WHERE id=? AND state='pending_consent' AND target_owner_id=?",
        (state, decision, owner_id, _now(), cid, owner_id))
    conn.commit()
    if not cur.rowcount:
        raise CommandError("command_race")
    return get(conn, cid) or {}


def list_pending(conn, owner_id: str) -> list[dict]:
    ensure(conn)
    expire_due(conn)
    rows = conn.execute(
        "SELECT * FROM group_command WHERE target_owner_id=? "
        "AND state='pending_consent' ORDER BY consent_deadline",
        (owner_id,)).fetchall()
    return [dict(r) for r in rows]


def sync_task_state(conn, task_id: str, status: str) -> None:
    """Project task lifecycle back onto the command row.

    A task can be submitted/reviewed while the command remained `queued`;
    group_health then reports a phantom missing inbox and shows a false red.
    """
    if not task_id:
        return
    if status in ("claimed", "in_progress"):
        state = "running"
    elif status in ("review", "done"):
        state = "done"
    elif status in ("blocked", "cancelled"):
        state = "failed"
    else:
        return
    conn.execute("UPDATE group_command SET state=?,updated_at=datetime('now','localtime') "
                 "WHERE task_id=? AND state IN ('queued','running','immediate','idle')",
                 (state, task_id))
    conn.commit()


def set_task(conn, cid: str, task_id: str, state: str = "queued") -> dict:
    ensure(conn)
    if state not in STATES:
        raise CommandError("bad_state")
    conn.execute(
        "UPDATE group_command SET task_id=?,state=?,updated_at=datetime('now','localtime') "
        "WHERE id=?", (task_id, state, cid))
    conn.commit()
    return get(conn, cid) or {}


def as_json(row: dict | None) -> str:
    return json.dumps(row or {}, ensure_ascii=False)
