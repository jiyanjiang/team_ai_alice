"""persona_gen —— 名字驱动的**确定性**人格生成（纯规则，不依赖网络）。

设计（2026-11-01，术语与生成流程重整的一部分）：

    名字 → 性别 → 模板池 → N 选 1 → 填 id/name → 可落盘的 persona 骨架

三条原则：

1. **确定性**：同 `(name, seed)` 必得同一结果（随机数由 sha256 播种，不用 Python 内建 hash）。
   这样才能回归测试，也能把"当时抽中了哪套模板"写进 evolution 留痕。
2. **可降级**：`enrich()` 是**可选**的 LLM 增强（bio/appearance 措辞），网络或解析失败
   一律静默回退到规则结果——生成流程绝不能因为 API 挂了就产出不了 agent。
3. **不写死设备**：产物只描述 agent 自身（body / wardrobe / voice），不含任何设备标识，
   网络位置由运行时注入（见 `docs/术语表.md` §4）。

与既有模块的分工：
  · `core.persona`：真相源与读写（load/save/expand_wardrobe），本模块**只生成不落盘**；
  · `core.agent_names`：名字池与唯一化；
  · 本模块：把"名字 → 人格"这一步补上，供 bootstrap / init-agent 调用。
"""
from __future__ import annotations

import copy
import hashlib
import json
import random
from datetime import date

from . import persona as P
from . import persona_pool as POOL

# ---------------------------------------------------------------- 名字 → 性别

#: 高置信女性用字（刻意避开「华 / 春 / 云 / 霞 / 玉」等两性都常见的字）
_FEMALE_CHARS = set("芳丽娜静敏艳娟兰燕慧红梅琳雪瑶晶婷欣怡思雨梦晴薇璐玲莉萍洁颖倩"
                    "媛姝妍妮娅蕾蕊淑惠巧玉珍秀美凤琴婉柔婵媛婕")
#: 高置信男性用字
_MALE_CHARS = set("伟强磊刚军洋勇杰涛超峰辉鹏亮斌波轩浩凯健龙飞虎生才发富贵荣"
                  "建国志宏鹏程昊晨皓然森鑫")

_FEMALE_NAMES = {"alice", "carol", "emma", "olivia", "sophia", "lily", "grace", "zoe", "mia",
                 "ella", "chloe", "victoria", "diana", "anna", "luna", "iris", "nina"}
_MALE_NAMES = {"bob", "darwin", "jack", "james", "john", "michael", "david", "daniel", "william",
               "henry", "leo", "max", "ryan", "ethan", "noah", "liam", "adam", "tony"}

GENDERS = ("female", "male")


def detect_gender(name: str) -> str | None:
    """从名字推测性别；推测不出返回 None（**不猜**，交给调用方或随机）。"""
    n = (name or "").strip()
    if not n:
        return None
    low = n.lower()
    if low in _FEMALE_NAMES:
        return "female"
    if low in _MALE_NAMES:
        return "male"
    cn = "".join(ch for ch in n if "\u4e00" <= ch <= "\u9fff")
    for ch in reversed(cn):                 # 中文名取末字优先（"张伟"的"伟"）
        if ch in _FEMALE_CHARS and ch not in _MALE_CHARS:
            return "female"
        if ch in _MALE_CHARS and ch not in _FEMALE_CHARS:
            return "male"
    return None


# ---------------------------------------------------------------- 模板池

def template_pool(gender: str) -> list[str]:
    """按性别过滤可用模板（`agents/_templates/<name>.yaml`，以文件名前缀区分性别）。"""
    g = (gender or "").strip().lower()
    pool = [t for t in P.list_templates() if t.lower().startswith(g)] if g in GENDERS else []
    return pool or [t for t in P.list_templates()
                    if "female" not in t.lower() and "male" not in t.lower()] or P.list_templates()


def _rng(name: str, seed: str | None) -> random.Random:
    key = f"{name.strip()}|{seed or ''}".encode("utf-8")
    return random.Random(int(hashlib.sha256(key).hexdigest()[:16], 16))


# ---------------------------------------------------------------- 生成

def roll(name: str, *, gender: str | None = None, seed: str | None = None,
         template: str | None = None, vary_body: bool = True) -> dict:
    """按名字生成一份 persona 骨架（**不落盘**，调用方决定 save_persona 与否）。

    参数：
      name      展示名；同时决定性别（显式 gender 优先）
      gender    `female` / `male`；非法或空则回退到名字推测，再回退到随机（确定性）
      seed      确定性种子；同一 (name, seed) 结果恒定。留空按名字本身定
      template  指定模板（须属于该性别池）；非法则从池中抽
      vary_body 是否在模板基准上做 ±2 岁 / ±4cm 的微扰（仍是确定性的）
    """
    n = (name or "").strip()
    if not n:
        raise ValueError("name is required")

    g = (gender or "").strip().lower()
    if g not in GENDERS:
        g = detect_gender(n) or ("female", "male")[0]
    rng = _rng(n, seed)

    pool = template_pool(g)
    tpl = template if (template in pool) else rng.choice(pool)

    p = copy.deepcopy(P.load_template(tpl))       # 绝不改模板文件本体
    p["id"] = p.get("id") or ""
    p["name"] = n
    p["_template"] = tpl
    ident = p.setdefault("identity", {})
    ident["gender"] = g
    ident.setdefault("pronouns", "她/她的" if g == "female" else "他/他的")

    body = p.setdefault("body", {})
    if vary_body and isinstance(body.get("age"), int):
        body["age"] = max(22, min(40, body["age"] + rng.randint(-2, 2)))
    if vary_body and isinstance(body.get("height_cm"), int):
        body["height_cm"] = max(150, min(196, body["height_cm"] + rng.randint(-4, 4)))

    # 衣柜 starter 与性别对齐（starter 决定展开哪套 18 件单品）
    wardrobe = p.setdefault("wardrobe", {})
    wardrobe["starter"] = g
    wardrobe.setdefault("version", 1)

    # 外形与自述改由**特征池抽样合成**（2026-11-01）：
    # 池子按领域分层、只存抽象特征；三人分工 = 主干/补位/反差。
    # 这一步是纯规则的、确定性的；LLM 只在 enrich() 里做措辞增强。
    basis = POOL.pick(g, n, seed)
    if basis:
        prof = POOL.rule_profile(basis)
        if prof.get("appearance"):
            body["appearance"] = prof["appearance"]
        if prof.get("bio"):
            ident["bio"] = prof["bio"]
        # 语气也取自池子（补位的「说话节奏」），模板只保留性格基线：
        # 否则两个人抽到同一模板，语气与口癖会一模一样。
        temper = POOL.voice_of(basis)
        if temper:
            voice = p.setdefault("voice", {})
            voice["style"] = temper + "。"
            voice["tone"] = temper.split("、")[0].removeprefix("说话").strip()
            voice["temper_source"] = str((basis[1] if len(basis) > 1 else basis[0]).get("id") or "")
        # 口癖同样取自池子（按主干领域），不继承模板的 catchphrases
        ph = POOL.phrases_of(basis, seed)
        if ph:
            voice = p.setdefault("voice", {})
            voice["catchphrases"] = ph
            voice["phrases_source"] = str(basis[0].get("id") or "")
        p["_basis"] = POOL.describe(basis)

    evo = p.setdefault(P.EVOLUTION_KEY, [])
    if isinstance(evo, list):
        evo.append({"at": date.today().isoformat(), "by": "persona_gen",
                    "event": "generated", "template": tpl, "gender": g,
                    "seed": seed or "", "vary_body": bool(vary_body)})
    return p


def summary(p: dict) -> dict:
    """生成结果的一行摘要（给 CLI / 日志用，不含任何私密正文）。"""
    b = p.get("body") or {}
    return {"name": p.get("name"), "gender": (p.get("identity") or {}).get("gender"),
            "template": p.get("_template"), "age": b.get("age"), "height_cm": b.get("height_cm"),
            "wardrobe_starter": (p.get("wardrobe") or {}).get("starter")}


# ---------------------------------------------------------------- 可选：LLM 措辞增强

ENRICH_PROMPT = """你在为一个 AI agent 写「外形与自我介绍」两段文字，只输出 JSON。

【已知】名字：{name}；性别：{gender}；年龄：{age}；身高：{height}cm；性格模板：{template}
【设定】{hint}

要求：
- `appearance`：60 字以内，写具体可感的细节（发型/穿着/小动作），不要形容词堆砌；
- `bio`：50 字以内，第一人称，写这个人怎么做事、在意什么，不写履历；
- 不要提任何机器、设备、型号、地点；不要写名字。
- 输出严格为一个 JSON 对象：{{"appearance": "...", "bio": "..."}}"""


def enrich(p: dict, hint: str = "", *, model: str = "deepseek-v4-flash",
           timeout: int = 120) -> dict:
    """用 LLM 把 `appearance` / `bio` 写得更像人话；**失败一律返回原对象**。

    这是加分项不是依赖：任何异常（无 key、网络、JSON 解析）都静默回退，
    调用方不需要 try。
    """
    try:
        from . import config, research
        b = p.get("body") or {}
        gender = (p.get("identity") or {}).get("gender") or ""
        cards = POOL.by_ids(gender, ((p.get("_basis") or {}).get("ids") or []))
        if cards:
            prompt = POOL.build_prompt(cards, p.get("name") or "", gender,
                                       b.get("age"), b.get("height_cm"), hint)
        else:
            prompt = ENRICH_PROMPT.format(
                name=p.get("name"), gender=gender,
                age=b.get("age"), height=b.get("height_cm"), template=p.get("_template"),
                hint=(hint or "见模板"))
        payload = {"model": model, "messages": [{"role": "user", "content": prompt}],
                   "temperature": 0.7, "max_tokens": 1200, "stream": False,
                   "response_format": {"type": "json_object"}}
        data = research._post_chat(research.DEEPSEEK_CHAT_URL, config.deepseek_key(),
                                   payload, timeout)
        txt = (data["choices"][0]["message"].get("content") or "").strip()
        d = json.loads(txt[txt.index("{"):txt.rindex("}") + 1])
        out = copy.deepcopy(p)
        if d.get("appearance"):
            out.setdefault("body", {})["appearance"] = str(d["appearance"])[:200]
        if d.get("bio"):
            out.setdefault("identity", {})["bio"] = str(d["bio"])[:200]
        evo = out.setdefault(P.EVOLUTION_KEY, [])
        if isinstance(evo, list):
            evo.append({"at": date.today().isoformat(), "by": "persona_gen.enrich",
                        "event": "enriched", "model": model})
        return out
    except Exception:      # noqa: BLE001 —— 增强失败绝不阻断生成
        return p
