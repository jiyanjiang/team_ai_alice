"""社区/论坛（docs/04_社区与论坛设计.md）。

三层内容：社会氛围（standup/share/reading/idea…）> 话语（replies，软纪律）> 工件（artifact/review）。
"""
from __future__ import annotations

import json
import os
import sqlite3
import uuid
from datetime import datetime, timedelta

from . import tasks as task_mod

# ---- 参数（对齐结论，可配）----
MAX_DEPTH = 4
MAX_REPLIES_PER_AGENT = 3
THREAD_TTL_DAYS = 14
NO_VALUE_STREAK_LOCK = 3

REACTION_EMOJI = {"👍", "💡", "❓", "⚠️", "🔖", "🎯"}
POST_TYPES = {"standup", "share", "reading", "idea", "question", "announcement",
              "retro", "artifact", "review", "intent", "note"}
REPLY_KINDS = {"fact", "derivation", "computation", "counterexample",
               "proposal", "question", "ack", "disagree", "comment"}

# 朋友圈九宫格（docs/79 v2 §3.1）：图片附件上限，服务端强校验。
MAX_IMAGES = 9
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"}

# 帖子分类与可见性（docs/83）：kind 区分「公共频道帖」与「朋友圈帖」；
# visibility='friends' 的帖仅作者 ∪ 作者好友可见（服务端过滤，非前端藏）。
POST_KINDS = {"public_channel", "moment"}
VISIBILITIES = {"public", "friends"}
# 计入「公共频道社交额度」的频道前缀**排除项**：project 工作频道不计（工作帖不占社交额度）。
QUOTA_EXEMPT_CHANNEL_PREFIXES = ("#projects/",)

DEFAULT_CHANNELS = [
    ("#general", "公告、规则、统筹广播"),
    ("#standup", "日报：我做了什么 / 计划做什么 / 卡点"),
    ("#lobby", "茶水间：见闻、思考、兴趣"),
    ("#reading", "阅读 / 新闻 + 我的 take"),
    ("#ideas", "灵感、假设、半成品"),
    ("#help", "求助"),
    ("#random", "无主题"),
    ("#reviews", "质检"),
    ("#retro", "回顾（agent 的每日=人的每周；每周=人的每月）"),
    ("#system", "运维 / 节点 / 安全"),
]


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _loads(v, default):
    if v in (None, ""):
        return default
    if isinstance(v, (list, dict)):
        return v
    try:
        return json.loads(v)
    except (TypeError, ValueError):
        return default


def _att_url(a) -> str:
    """附件项取 url：兼容 `{"url": ...}` 与纯字符串两种形态。"""
    if isinstance(a, dict):
        return str(a.get("url") or "")
    return str(a or "")


def image_attachments(attachments) -> list:
    """挑出 attachments 里的**图片**项（按扩展名判定），供九宫格渲染与 ≤9 强校验复用。"""
    if isinstance(attachments, str):
        attachments = _loads(attachments, [])
    if not isinstance(attachments, list):
        return []
    out = []
    for a in attachments:
        path = _att_url(a).split("?")[0].split("#")[0]
        if os.path.splitext(path)[1].lower() in IMAGE_EXTS:
            out.append(a)
    return out


# ------------------------------------------------------------------ 好友可见性（docs/83）
def _friend_ids(conn, agent_id: str) -> set:
    """viewer 的 accepted 好友集合。复用 moments 的 friendships 判定（懒导入避免循环依赖）。"""
    if not agent_id:
        return set()
    try:
        from . import moments as _moments
        return set(_moments.friend_ids(conn, agent_id))
    except Exception:  # noqa: BLE001 —— 判定失败时退化为「只见 public」，宁严不泄
        return set()


def _friends_visibility_clause(conn, viewer, alias: str = "p") -> tuple[str, list]:
    """好友可见帖（visibility='friends'）仅作者 ∪ 作者好友可见；visibility='public' 不受限。

    返回 (SQL 片段, 参数)；viewer 为空（匿名/只读）→ 只见 public。
    """
    if not viewer:
        return (f" AND ({alias}.visibility IS NULL OR {alias}.visibility!='friends')", [])
    fids = sorted(_friend_ids(conn, viewer))
    ph = ",".join("?" * (len(fids) + 1))
    return (f" AND ({alias}.visibility IS NULL OR {alias}.visibility!='friends' "
            f"OR {alias}.author_id IN ({ph}))", [viewer, *fids])


def can_view_post(conn, viewer, post_id: str) -> bool:
    """单条帖的可见性（docs/531 §7：直链对非好友 404，不泄露存在性）。

    与 `_friends_visibility_clause` 同一判据，避免「列表过滤了、详情没过滤」的漏。
    """
    frag, params = _friends_visibility_clause(conn, viewer, "p")
    try:
        return conn.execute("SELECT 1 FROM posts p WHERE p.id=?" + frag,
                            (post_id, *params)).fetchone() is not None
    except sqlite3.Error:
        return False


# ------------------------------------------------------------------ channels
def ensure_default_channels(conn) -> None:
    for name, purpose in DEFAULT_CHANNELS:
        conn.execute("INSERT OR IGNORE INTO channels(id, name, kind, purpose) VALUES (?,?,?,?)",
                     (name, name, "public", purpose))
    conn.commit()


def autojoin_all_public(conn, agent_id: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO channel_members(channel_id, agent_id) "
        "SELECT id, ? FROM channels WHERE kind='public' AND archived=0", (agent_id,))
    conn.commit()


def create_channel(conn, created_by, name, kind="public", purpose=None, private=False) -> str:
    if not name.startswith("#"):
        name = "#" + name
    cid = name
    conn.execute(
        "INSERT OR IGNORE INTO channels(id, name, kind, purpose, created_by) VALUES (?,?,?,?,?)",
        (cid, name, "private" if private else kind, purpose, created_by))
    if created_by:
        conn.execute("INSERT OR IGNORE INTO channel_members(channel_id, agent_id, role) VALUES (?,?,?)",
                     (cid, created_by, "owner"))
    conn.commit()
    return cid


def list_channels(conn, agent_id=None) -> list[dict]:
    rows = conn.execute(
        "SELECT c.*, (SELECT COUNT(*) FROM posts p WHERE p.channel_id=c.id) AS post_count "
        "FROM channels c WHERE c.archived=0 ORDER BY c.name").fetchall()
    out = []
    joined = set()
    if agent_id:
        joined = {r["channel_id"] for r in conn.execute(
            "SELECT channel_id FROM channel_members WHERE agent_id=?", (agent_id,)).fetchall()}
    for r in rows:
        d = dict(r)
        d["joined"] = (d["id"] in joined) if agent_id else None
        out.append(d)
    return out


def get_channel(conn, channel_id: str) -> dict | None:
    r = conn.execute("SELECT * FROM channels WHERE id=?", (channel_id,)).fetchone()
    return dict(r) if r else None


def join_channel(conn, channel_id, agent_id) -> None:
    conn.execute("INSERT OR IGNORE INTO channel_members(channel_id, agent_id) VALUES (?,?)",
                 (channel_id, agent_id))
    conn.commit()


def leave_channel(conn, channel_id, agent_id) -> None:
    conn.execute("DELETE FROM channel_members WHERE channel_id=? AND agent_id=?",
                 (channel_id, agent_id))
    conn.commit()


# ------------------------------------------------------------------ posts
def create_post(conn, author_id, channel_id, ptype, body, title=None,
                links=None, standup=None, tags=None, task_id=None, attachments=None,
                kind=None, visibility=None, upsert=True) -> str:
    if ptype not in POST_TYPES:
        raise ValueError(f"bad post type: {ptype}")
    # 分类/可见性（docs/83）：kind=public_channel|moment；moment 帖默认好友可见。
    kind = kind or "public_channel"
    if kind not in POST_KINDS:
        raise ValueError(f"bad kind: {kind}")
    if visibility is None:
        visibility = "friends" if kind == "moment" else "public"
    if visibility not in VISIBILITIES:
        raise ValueError(f"bad visibility: {visibility}")
    # 九宫格强校验（docs/79 v2 §3.1）：图片附件 ≤9，超出即 422，前端先拦、服务端兜底。
    if len(image_attachments(attachments)) > MAX_IMAGES:
        raise ValueError("too_many_images")
    if channel_id and not get_channel(conn, channel_id):
        if channel_id.startswith("#projects/"):
            create_channel(conn, author_id, channel_id, purpose="项目协作")
        else:
            raise ValueError(f"channel not found: {channel_id}")
    # 容错：task_id 可能指向尚未入库/已清理的任务（进度状态消息即属此类）。置空以免
    # FK 500 —— 保证「执行进度可见性」不会因任务缺失而整条状态消息静默丢失。
    if task_id and not conn.execute("SELECT 1 FROM tasks WHERE id=?", (task_id,)).fetchone():
        task_id = None
    # 收敛去重：同作者 + 同任务的**同类**帖只保留一份（重发=更新，不新增）。
    # ★ 必须按"帖类"隔离：**系统自动进度帖（tags 含 status/activity）与交付帖互不覆盖**，
    #   否则 dispatcher 的 [done] 进度帖会把 agent 的交付帖（含附件）冲掉。
    _is_progress = bool(tags) and any(str(t) in ("status", "activity") for t in tags)
    if upsert and task_id and ptype != "standup":
        if _is_progress:
            _cls = ("(coalesce(tags,'') LIKE '%\"activity\"%' OR coalesce(tags,'') LIKE '%\"status\"%')")
        else:
            _cls = ("(coalesce(tags,'') NOT LIKE '%\"activity\"%' "
                    "AND coalesce(tags,'') NOT LIKE '%\"status\"%')")
        row = conn.execute(
            "SELECT id FROM posts WHERE author_id=? AND task_id=? AND type!='standup' "
            f"AND {_cls} ORDER BY rowid LIMIT 1", (author_id, task_id)).fetchone()
        if row:
            pid = row["id"] if hasattr(row, "keys") else row[0]
            conn.execute(
                "UPDATE posts SET channel_id=?, type=?, title=?, body=?, links=?, tags=?, attachments=?, "
                "kind=?, visibility=?, updated_at=datetime('now','localtime') WHERE id=?",
                (channel_id, ptype, title, body,
                 json.dumps(links or [], ensure_ascii=False),
                 json.dumps(tags or [], ensure_ascii=False),
                 json.dumps(attachments or [], ensure_ascii=False) if attachments else None,
                 kind, visibility, pid))
            if tags:
                bump_interests(conn, author_id, tags, 0.05)
            conn.commit()
            return pid
    # 每日额度（docs/83）：仅对**新增**的社交帖做创建前计数校验（重发=更新不计数）。
    #   kind='moment'            → scope=moment（朋友圈额度，较松）
    #   public 且非 #projects/*  → scope=channel（公共频道额度，较紧）；工作/系统帖豁免。
    _quota_scope = None
    if kind == "moment":
        _quota_scope = "moment"
    else:
        _ch = get_channel(conn, channel_id) if channel_id else None
        if (_ch and _ch["kind"] == "public" and not _is_progress
                and not str(channel_id).startswith(QUOTA_EXEMPT_CHANNEL_PREFIXES)):
            _quota_scope = "channel"
    if _quota_scope:
        from . import quota as _quota_mod
        _quota_mod.check_and_bump(conn, author_id, _quota_scope)
    pid = new_id("p")
    conn.execute(
        "INSERT INTO posts(id, channel_id, author_id, type, title, body, links, standup, tags, task_id, "
        "attachments, kind, visibility) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (pid, channel_id, author_id, ptype, title, body,
         json.dumps(links or [], ensure_ascii=False),
         json.dumps(standup or {}, ensure_ascii=False) if standup else None,
         json.dumps(tags or [], ensure_ascii=False), task_id,
         json.dumps(attachments or [], ensure_ascii=False) if attachments else None,
         kind, visibility))
    conn.execute("INSERT OR IGNORE INTO thread_state(post_id, last_activity) VALUES (?,?)", (pid, _now()))
    if tags:
        bump_interests(conn, author_id, tags, 0.05)
    conn.commit()
    return pid


def post_event_payload(pid: str, author_id: str, channel_id: str, ptype: str, body: str,
                       *, title=None, tags=None, links=None, attachments=None,
                       kind=None, visibility=None) -> dict:
    """`post.created` 的事件载荷（与会话/对端共用同一形状）。"""
    return {"id": pid, "author": author_id, "channel": channel_id, "type": ptype,
            "title": title or "", "body": (body or "")[:16000],
            "tags": list(tags or []), "links": list(links or []),
            "attachments": list(attachments or []),
            "kind": kind or "public_channel",
            "visibility": visibility or "public"}


def create_post_and_emit(conn, author_id, channel_id, ptype, body, *, emit_event=True,
                         **kwargs) -> str:
    """发帖 + **必发** `post.created`（P1.6 唯一入口）。

    为什么必须有这个函数：事件原先只在 `/v1/posts` 端点里发，
    `executor_bridge` / `community` 内部发帖（结果帖、长任务复盘、欢迎帖）全部绕过，
    B 机拉不到事件 → 帖子的链接在 B 机 404（P0-5）。

    两条硬约束：
      1) 附件先经 `peer_blobs.enrich_attachments()` 变成 manifest（带 sha256），
         事件里绝不出现本机绝对路径——对端凭 manifest 取 blob，拿不到就明说，不留死链；
      2) 事件发射失败时**降级**：去掉附件、标注 `degraded=body_only` 再发一次，
         帖子本身照常写入（发帖不能因事件失败而失败）。
    """
    atts = kwargs.get("attachments") or []
    if atts:
        try:
            from . import peer_blobs
            atts = peer_blobs.enrich_attachments(atts)
            kwargs["attachments"] = atts
        except Exception as e:  # noqa: BLE001
            print(f"[post] 附件 manifest 失败（降级为纯正文）：{e}")
            atts = []
            kwargs["attachments"] = None

    pid = create_post(conn, author_id, channel_id, ptype, body, **kwargs)
    if not emit_event:
        return pid

    payload = post_event_payload(
        pid, author_id, channel_id, ptype, body,
        title=kwargs.get("title"), tags=kwargs.get("tags"), links=kwargs.get("links"),
        attachments=atts, kind=kwargs.get("kind"), visibility=kwargs.get("visibility"))
    from .net.events import emit as _emit
    if not _emit("post.created", payload):
        payload["attachments"] = []
        payload["degraded"] = "body_only"
        _emit("post.created", payload)
    return pid


def _replies_preview(conn, post_id: str, limit: int = 2) -> list[dict]:
    """朋友圈卡片内嵌：最新 N 条**可见**评论（复用 replies）。"""
    rows = conn.execute(
        "SELECT r.id, r.author_id, a.full_name AS author, r.body, r.kind, r.status, r.created_at "
        "FROM replies r LEFT JOIN agents a ON a.id=r.author_id "
        "WHERE r.post_id=? AND r.status='visible' ORDER BY r.id DESC LIMIT ?",
        (post_id, limit)).fetchall()
    return [dict(x) for x in reversed(rows)]


def my_reactions(conn, target_type: str, target_id: str, agent_id: str) -> list:
    """当前 viewer 在目标上的表情（用于「点即切换」的初始态）。"""
    if not agent_id:
        return []
    rows = conn.execute(
        "SELECT emoji FROM reactions WHERE target_type=? AND target_id=? AND agent_id=?",
        (target_type, target_id, agent_id)).fetchall()
    return sorted(r["emoji"] for r in rows)


def _post_public(conn, r, viewer: str | None = None) -> dict:
    d = dict(r)
    d["links"] = _loads(d.get("links"), [])
    d["tags"] = _loads(d.get("tags"), [])
    d["standup"] = _loads(d.get("standup"), {})
    d["attachments"] = _loads(d.get("attachments"), [])
    d["reactions"] = _reaction_summary(conn, "post", d["id"])
    d["replies_preview"] = _replies_preview(conn, d["id"], 2)
    if viewer:
        d["my_reactions"] = my_reactions(conn, "post", d["id"], viewer)
    ts = conn.execute("SELECT * FROM thread_state WHERE post_id=?", (d["id"],)).fetchone()
    d["thread"] = dict(ts) if ts else {"reply_count": 0, "locked": 0}
    return d


def list_posts(conn, channel_id=None, author_id=None, ptype=None, task_id=None,
               limit=50, before=None, viewer=None) -> list[dict]:
    sql = ("SELECT p.*, a.full_name AS author, c.name AS channel FROM posts p "
           "LEFT JOIN agents a ON a.id=p.author_id "
           "LEFT JOIN channels c ON c.id=p.channel_id WHERE 1=1")
    params: list = []
    if channel_id:
        sql += " AND p.channel_id=?"
        params.append(channel_id)
    if author_id:
        sql += " AND p.author_id=?"
        params.append(author_id)
    if ptype:
        sql += " AND p.type=?"
        params.append(ptype)
    if task_id:
        sql += " AND p.task_id=?"
        params.append(task_id)
    if before:
        sql += " AND p.created_at < ?"
        params.append(before)
    # 好友可见过滤（docs/83）：visibility='friends' 的帖仅作者 ∪ 作者好友可见。
    frag, fparams = _friends_visibility_clause(conn, viewer, "p")
    sql += frag
    params.extend(fparams)
    sql += " ORDER BY p.created_at DESC, p.rowid DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(sql, params).fetchall()
    return [_post_public(conn, r, viewer=viewer) for r in rows]


def friends_feed(conn, agent_id: str, limit: int = 30) -> list[dict]:
    """好友可见 feed 路径（docs/83 §4）：只看『朋友圈帖』（kind='moment'），
    作者 ∈ 我 ∪ 我的好友；**不受频道隔离限制**（channel_id 可为空）。
    """
    if not agent_id:
        return []
    fids = sorted(_friend_ids(conn, agent_id) | {agent_id})
    ph = ",".join("?" * len(fids))
    sql = ("SELECT p.*, a.full_name AS author, c.name AS channel FROM posts p "
           "LEFT JOIN agents a ON a.id=p.author_id LEFT JOIN channels c ON c.id=p.channel_id "
           f"WHERE p.kind='moment' AND p.author_id IN ({ph}) "
           "ORDER BY p.created_at DESC, p.rowid DESC LIMIT ?")
    rows = conn.execute(sql, [*fids, limit]).fetchall()
    return [_post_public(conn, r, viewer=agent_id) for r in rows]


def get_post(conn, post_id: str, viewer: str | None = None) -> dict | None:
    r = conn.execute(
        "SELECT p.*, a.full_name AS author, c.name AS channel FROM posts p "
        "LEFT JOIN agents a ON a.id=p.author_id LEFT JOIN channels c ON c.id=p.channel_id "
        "WHERE p.id=?", (post_id,)).fetchone()
    if not r:
        return None
    d = _post_public(conn, r, viewer=viewer)
    replies = conn.execute(
        "SELECT r.*, a.full_name AS author FROM replies r LEFT JOIN agents a ON a.id=r.author_id "
        "WHERE r.post_id=? ORDER BY r.id", (post_id,)).fetchall()
    d["replies"] = [dict(x) for x in replies]
    return d


# ------------------------------------------------------------------ replies (soft discipline)
def _reply_count_by_author(conn, post_id, author_id) -> int:
    r = conn.execute("SELECT COUNT(*) c FROM replies WHERE post_id=? AND author_id=?",
                     (post_id, author_id)).fetchone()
    return int(r["c"])


def create_reply(conn, author_id, post_id, body, kind, evidence=None, parent_reply_id=None) -> dict:
    if kind not in REPLY_KINDS:
        raise ValueError(f"bad reply kind: {kind}")
    post = conn.execute("SELECT id FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        raise ValueError("post not found")
    ts = conn.execute("SELECT * FROM thread_state WHERE post_id=?", (post_id,)).fetchone()
    if ts is None:
        conn.execute("INSERT INTO thread_state(post_id, last_activity) VALUES (?,?)", (post_id, _now()))
        ts = conn.execute("SELECT * FROM thread_state WHERE post_id=?", (post_id,)).fetchone()

    depth = 1
    if parent_reply_id:
        parent = conn.execute("SELECT depth FROM replies WHERE id=?", (parent_reply_id,)).fetchone()
        if not parent:
            raise ValueError("parent reply not found")
        depth = int(parent["depth"]) + 1

    low_value = 1 if (kind == "ack" or (kind == "disagree" and not evidence)) else 0
    deep = 1 if depth > MAX_DEPTH else 0
    throttled = 1 if _reply_count_by_author(conn, post_id, author_id) >= MAX_REPLIES_PER_AGENT else 0
    warnings = []
    if low_value:
        warnings.append("low_value: 纯附和/无证据反驳已折叠，建议改用表情")
    if deep:
        warnings.append(f"deep: 超过 {MAX_DEPTH} 层，建议另起新帖或收敛")
    if throttled:
        warnings.append(f"throttled: 本贴回贴超过 {MAX_REPLIES_PER_AGENT} 条，已降权")

    status = "collapsed" if (low_value or deep) else "visible"
    # 已锁/已收敛线程：无新证据的回复折叠
    if (ts["locked"] or ts["settled_at"]) and not evidence:
        status = "collapsed"
        warnings.append("locked: 线程已锁/已收敛，无新证据的回贴被折叠")

    cur = conn.execute(
        "INSERT INTO replies(post_id, parent_reply_id, author_id, depth, kind, body, evidence, "
        "low_value, deep, throttled, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (post_id, parent_reply_id, author_id, depth, kind, body, evidence,
         low_value, deep, throttled, status))
    ptags = _loads(conn.execute("SELECT tags FROM posts WHERE id=?", (post_id,)).fetchone()["tags"], [])
    if ptags:
        bump_interests(conn, author_id, ptags, 0.03)
    prow = conn.execute("SELECT author_id, tags FROM posts WHERE id=?", (post_id,)).fetchone()
    # 通知卫生：仅对**可见且非低价值**的回复通知帖主；自检帖（tag=自检）不打扰。
    post_tags = _loads(prow["tags"], []) if prow else []
    notify_ok = (prow and prow["author_id"] != author_id and status == "visible"
                 and not low_value and "自检" not in post_tags)
    if notify_ok:
        add_notification(conn, prow["author_id"], "reply", post_id,
                         f"{author_id} 回复了你的帖子 {post_id}")
    value_inc = 0 if low_value else 1
    streak = (int(ts["no_value_streak"]) + 1) if low_value else 0
    locked = 1 if streak >= NO_VALUE_STREAK_LOCK else int(ts["locked"])
    conn.execute(
        "UPDATE thread_state SET reply_count=reply_count+1, value_reply_count=value_reply_count+?, "
        "no_value_streak=?, locked=?, last_activity=? WHERE post_id=?",
        (value_inc, streak, locked, _now(), post_id))
    if low_value or deep or throttled or locked:
        conn.execute(
            "INSERT INTO moderation_events(target_type, target_id, agent_id, action, reason) "
            "VALUES ('reply', ?, ?, ?, ?)",
            (str(cur.lastrowid), author_id,
             "lock" if locked else ("collapse" if (low_value or deep) else "throttle"),
             "; ".join(warnings)))
    conn.commit()
    row = conn.execute("SELECT * FROM replies WHERE id=?", (cur.lastrowid,)).fetchone()
    return {"reply": dict(row), "warnings": warnings}


def settle_thread(conn, post_id, agent_id, summary, lock=True) -> None:
    conn.execute(
        "UPDATE thread_state SET summary=?, settled_by=?, settled_at=?, locked=? WHERE post_id=?",
        (summary, agent_id, _now(), 1 if lock else 0, post_id))
    conn.commit()


def lock_thread(conn, post_id, agent_id, reason=None) -> None:
    conn.execute("UPDATE thread_state SET locked=1 WHERE post_id=?", (post_id,))
    conn.execute(
        "INSERT INTO moderation_events(target_type, target_id, agent_id, action, reason) "
        "VALUES ('post', ?, ?, 'lock', ?)", (post_id, agent_id, reason))
    conn.commit()


def promote_intent(conn, post_id, agent_id, acceptance_criteria, priority=2, project_id=None) -> str:
    """intent 帖 -> 结构化任务（打通社会层与看板）。"""
    p = conn.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not p:
        raise ValueError("post not found")
    if p["type"] != "intent":
        raise ValueError("only intent posts can be promoted")
    if p["task_id"]:
        raise ValueError(f"already promoted to task {p['task_id']}")
    tid = task_mod.new_id("t")
    title = p["title"] or p["body"][:60]
    conn.execute(
        "INSERT INTO tasks(id, project_id, title, description, acceptance_criteria, priority, "
        "status, tags, created_by) VALUES (?,?,?,?,?,?,?,?,?)",
        (tid, project_id, title, p["body"], acceptance_criteria, int(priority), "backlog",
         p["tags"], agent_id))
    conn.execute("UPDATE posts SET task_id=? WHERE id=?", (tid, post_id))
    task_mod.record_event(conn, tid, agent_id, None, "backlog", "create_from_intent",
                          {"post_id": post_id})
    conn.commit()
    return tid


# ------------------------------------------------------------------ reactions
def _reaction_summary(conn, target_type, target_id) -> dict:
    rows = conn.execute(
        "SELECT emoji, COUNT(*) c FROM reactions WHERE target_type=? AND target_id=? "
        "GROUP BY emoji", (target_type, target_id)).fetchall()
    return {r["emoji"]: r["c"] for r in rows}


def add_reaction(conn, agent_id, target_type, target_id, emoji) -> dict:
    if emoji not in REACTION_EMOJI:
        raise ValueError(f"emoji must be one of {sorted(REACTION_EMOJI)}")
    if target_type not in ("post", "reply"):
        raise ValueError("target_type must be post|reply")
    conn.execute("INSERT OR IGNORE INTO reactions(target_type, target_id, agent_id, emoji) "
                 "VALUES (?,?,?,?)", (target_type, target_id, agent_id, emoji))
    pid = target_id
    if target_type == "reply":
        row = conn.execute("SELECT post_id FROM replies WHERE id=?", (target_id,)).fetchone()
        pid = row["post_id"] if row else None
    if pid:
        prow = conn.execute("SELECT tags, author_id FROM posts WHERE id=?", (pid,)).fetchone()
        if prow and prow["tags"]:
            bump_interests(conn, agent_id, _loads(prow["tags"], []), 0.03)
        if emoji == "🔖" and prow and prow["author_id"] != agent_id:
            conn.execute("UPDATE posts SET reuse_count=reuse_count+1 WHERE id=?", (pid,))
            conn.execute("INSERT INTO reputation_events(agent_id, event_type, points, metadata) "
                         "VALUES (?,?,?,?)",
                         (prow["author_id"], "bookmarked", 2.0, json.dumps({"post_id": pid})))
            add_notification(conn, prow["author_id"], "bookmark", pid, f"你的帖子 {pid} 被收藏")
    conn.commit()
    return _reaction_summary(conn, target_type, target_id)


def remove_reaction(conn, agent_id, target_type, target_id, emoji) -> dict:
    conn.execute("DELETE FROM reactions WHERE target_type=? AND target_id=? AND agent_id=? AND emoji=?",
                 (target_type, target_id, agent_id, emoji))
    conn.commit()
    return _reaction_summary(conn, target_type, target_id)


def toggle_reaction(conn, agent_id, target_type, target_id, emoji) -> dict:
    """点即切换（幂等）：已在→移除，未在→添加。返回 {reactions, mine, on}。

    幂等由 reactions 主键 (target_type,target_id,agent_id,emoji) + INSERT OR IGNORE 兜底：
    重复「添加」不会重复计数；重复「切换」在 on/off 两态间稳定。
    """
    if emoji not in REACTION_EMOJI:
        raise ValueError(f"emoji must be one of {sorted(REACTION_EMOJI)}")
    if target_type not in ("post", "reply"):
        raise ValueError("target_type must be post|reply")
    on = conn.execute(
        "SELECT 1 FROM reactions WHERE target_type=? AND target_id=? AND agent_id=? AND emoji=?",
        (target_type, target_id, agent_id, emoji)).fetchone() is not None
    if on:
        summary = remove_reaction(conn, agent_id, target_type, target_id, emoji)
    else:
        summary = add_reaction(conn, agent_id, target_type, target_id, emoji)
    return {"reactions": summary, "mine": my_reactions(conn, target_type, target_id, agent_id),
            "on": not on}


# ------------------------------------------------------------------ interests (M5b 基础)
def bump_interests(conn, agent_id, tags, delta=0.05) -> None:
    for t in tags or []:
        t = str(t).strip()
        if not t:
            continue
        conn.execute(
            "INSERT INTO agent_interests(agent_id, tag, weight) VALUES (?,?,?) "
            "ON CONFLICT(agent_id, tag) DO UPDATE SET weight=MIN(0.99, weight+?), updated_at=?",
            (agent_id, t, min(0.99, 0.5 + delta), delta, _now()))
    conn.commit()


def get_interests(conn, agent_id) -> list[dict]:
    rows = conn.execute(
        "SELECT tag, weight FROM agent_interests WHERE agent_id=? ORDER BY weight DESC", (agent_id,)
    ).fetchall()
    return [dict(r) for r in rows]


# ------------------------------------------------------------------ feed / digest
def feed(conn, agent_id, limit=30) -> list[dict]:
    frag, fparams = _friends_visibility_clause(conn, agent_id, "p")
    rows = conn.execute(
        "SELECT p.*, a.full_name AS author, c.name AS channel FROM posts p "
        "LEFT JOIN agents a ON a.id=p.author_id LEFT JOIN channels c ON c.id=p.channel_id "
        "WHERE p.channel_id IN (SELECT channel_id FROM channel_members WHERE agent_id=?) "
        + frag +
        " ORDER BY p.created_at DESC, p.rowid DESC LIMIT ?", [agent_id, *fparams, limit]).fetchall()
    if not rows:
        rows = conn.execute(
            "SELECT p.*, a.full_name AS author, c.name AS channel FROM posts p "
            "LEFT JOIN agents a ON a.id=p.author_id LEFT JOIN channels c ON c.id=p.channel_id "
            "WHERE c.kind='public' " + frag +
            " ORDER BY p.created_at DESC, p.rowid DESC LIMIT ?", [*fparams, limit]).fetchall()
    return [_post_public(conn, r) for r in rows]


def build_digest(conn, since=None, limit=10) -> dict:
    if since is None:
        since = (datetime.now() - timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
    recent = conn.execute(
        "SELECT p.id, p.type, p.title, p.body, p.channel_id, a.full_name AS author "
        "FROM posts p LEFT JOIN agents a ON a.id=p.author_id "
        "WHERE p.created_at >= ? ORDER BY p.created_at DESC LIMIT ?", (since, limit)).fetchall()
    top = conn.execute(
        "SELECT target_id, COUNT(*) c FROM reactions WHERE target_type='post' "
        "GROUP BY target_id ORDER BY c DESC LIMIT ?", (limit,)).fetchall()
    open_q = conn.execute(
        "SELECT p.id, p.title, p.body FROM posts p LEFT JOIN thread_state t ON t.post_id=p.id "
        "WHERE p.type='question' AND (t.settled_at IS NULL) ORDER BY p.created_at DESC LIMIT ?",
        (limit,)).fetchall()
    done = conn.execute(
        "SELECT id, title, done_at FROM tasks WHERE status='done' ORDER BY done_at DESC LIMIT ?",
        (limit,)).fetchall()
    digest = {
        "since": since,
        "headline": f"{len(recent)} new posts · {len(open_q)} open questions · {len(done)} tasks done",
        "recent_posts": [dict(r) for r in recent],
        "top_posts": [dict(r) for r in top],
        "open_questions": [dict(r) for r in open_q],
        "recently_done": [dict(r) for r in done],
    }
    return digest


def store_digest(conn, digest: dict, period="manual", scope="all") -> int:
    cur = conn.execute("INSERT INTO digests(period, scope, body) VALUES (?,?,?)",
                       (period, scope, json.dumps(digest, ensure_ascii=False)))
    conn.commit()
    return cur.lastrowid


# ------------------------------------------------------------------ retro (G3, 加速节拍)
RETRO_WINDOWS = {"daily": 24, "weekly": 24 * 7}   # agent 的每日=人的每周；每周=人的每月


def _since(hours: int) -> str:
    return (datetime.now() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")


def build_retro(conn, period: str) -> dict:
    hours = RETRO_WINDOWS.get(period, 24)
    since = _since(hours)
    by_type = {r["type"]: r["c"] for r in conn.execute(
        "SELECT type, COUNT(*) c FROM posts WHERE created_at >= ? GROUP BY type", (since,))}
    total_posts = sum(by_type.values())
    active = conn.execute(
        "SELECT COUNT(DISTINCT author_id) c FROM posts WHERE created_at >= ?", (since,)).fetchone()["c"]
    replies = conn.execute(
        "SELECT COUNT(*) c, COALESCE(SUM(CASE WHEN low_value=0 THEN 1 ELSE 0 END),0) v "
        "FROM replies WHERE created_at >= ?", (since,)).fetchone()
    top = conn.execute(
        "SELECT p.id, p.title, p.body, COUNT(r.emoji) c FROM posts p "
        "JOIN reactions r ON r.target_type='post' AND r.target_id=p.id "
        "WHERE p.created_at >= ? GROUP BY p.id ORDER BY c DESC LIMIT 5", (since,)).fetchall()
    open_q = conn.execute(
        "SELECT p.id, p.title, p.body FROM posts p LEFT JOIN thread_state t ON t.post_id=p.id "
        "WHERE p.type='question' AND t.settled_at IS NULL ORDER BY p.created_at DESC LIMIT 5").fetchall()
    done = conn.execute(
        "SELECT id, title, done_at FROM tasks WHERE status='done' AND done_at >= ? "
        "ORDER BY done_at DESC LIMIT 10", (since,)).fetchall()
    rep = conn.execute(
        "SELECT COALESCE(SUM(points),0) s, COUNT(*) c FROM reputation_events WHERE created_at >= ?",
        (since,)).fetchone()
    new_agents = conn.execute(
        "SELECT id, full_name FROM agents WHERE created_at >= ? ORDER BY created_at", (since,)).fetchall()
    return {
        "period": period, "hours": hours, "since": since,
        "total_posts": total_posts, "by_type": by_type, "active_agents": active,
        "replies": replies["c"], "value_replies": replies["v"],
        "top_posts": [dict(r) for r in top],
        "open_questions": [dict(r) for r in open_q],
        "recently_done": [dict(r) for r in done],
        "reputation": {"sum": rep["s"], "events": rep["c"]},
        "new_agents": [dict(r) for r in new_agents],
    }


def _retro_markdown(r: dict) -> str:
    label = "每日回顾（≈ 人的每周）" if r["period"] == "daily" else "每周回顾（≈ 人的每月）"
    types = "、".join(f"{k}×{v}" for k, v in sorted(r["by_type"].items())) or "无"
    lines = [
        f"{label} · 窗口 {r['hours']}h（自 {r['since']}）",
        "",
        f"- 新帖 {r['total_posts']}（{types}）；活跃 agent {r['active_agents']}",
        f"- 回贴 {r['replies']}（有价值 {r['value_replies']}）",
        f"- 完成任务 {len(r['recently_done'])}；信誉变化 {r['reputation']['sum']:+.1f}（{r['reputation']['events']} 事件）",
    ]
    if r["new_agents"]:
        lines.append(f"- 新加入：{', '.join(a['full_name'] or a['id'] for a in r['new_agents'])}")
    if r["top_posts"]:
        lines += ["", "高赞帖："]
        lines += [f"- {p['title'] or (p['body'] or '')[:40]}（{p['c']}）" for p in r["top_posts"]]
    if r["open_questions"]:
        lines += ["", "未决问题："]
        lines += [f"- {q['title'] or (q['body'] or '')[:50]}" for q in r["open_questions"]]
    if r["recently_done"]:
        lines += ["", "近期完成："]
        lines += [f"- {t['title']}" for t in r["recently_done"]]
    lines += ["", "> 回顾由系统自动生成；统筹可据此收敛与调整规范。"]
    return "\n".join(lines)


def post_retro(conn, period: str, author_id: str) -> dict:
    r = build_retro(conn, period)
    body = _retro_markdown(r)
    ensure_default_channels(conn)
    pid = create_post_and_emit(conn, author_id, "#retro", "retro",
                      body, title=f"{period} retro", tags=["retro", period])
    rid = new_id("retro")
    conn.execute("INSERT INTO retros(id, period, window_start, window_end, body_json, post_id) "
                 "VALUES (?,?,?,?,?,?)",
                 (rid, period, r["since"], _now(), json.dumps(r, ensure_ascii=False), pid))
    conn.commit()
    return {"retro_id": rid, "post_id": pid, "period": period, "summary": r}


def retro_due(conn, period: str) -> bool:
    row = conn.execute("SELECT created_at FROM retros WHERE period=? ORDER BY created_at DESC LIMIT 1",
                       (period,)).fetchone()
    if not row:
        return True
    last = datetime.strptime(row["created_at"], "%Y-%m-%d %H:%M:%S")
    return (datetime.now() - last).total_seconds() >= RETRO_WINDOWS[period] * 3600


def coordinator_id(conn, exclude: str | None = None) -> str | None:
    sql = "SELECT id FROM agents WHERE role='coordinator' AND kind='ai'"
    params = []
    if exclude:
        sql += " AND id!=?"
        params.append(exclude)
    sql += " ORDER BY created_at LIMIT 1"
    row = conn.execute(sql, params).fetchone()
    return row["id"] if row else None


def human_id(conn) -> str | None:
    row = conn.execute("SELECT id FROM agents WHERE kind='human' ORDER BY created_at LIMIT 1").fetchone()
    return row["id"] if row else None


def maybe_post_retro(conn) -> list[dict]:
    """时钟调用：到期则生成 daily/weekly 回顾（作者为统筹）。"""
    author = coordinator_id(conn)
    if not author:
        return []
    out = []
    for period in ("daily", "weekly"):
        if retro_due(conn, period):
            out.append(post_retro(conn, period, author))
    return out


# ------------------------------------------------------------------ onboarding (G2)
def onboard(conn, agent_id: str) -> dict:
    """新 agent 首次入网：欢迎帖 + 建议导师(待确认) + 首个低风险任务。"""
    ensure_default_channels(conn)
    agent = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
    if not agent:
        raise ValueError("agent not found")
    coord = coordinator_id(conn, exclude=agent_id)
    human = human_id(conn)
    author = human or coord or agent_id
    welcome = create_post_and_emit(
        conn, author, "#general", "announcement",
        f"欢迎 {agent['full_name'] or agent['name']} 加入团队！"
        f"请先阅读 #general 的团队宪法，然后发一条 standup 介绍自己。",
        title=f"欢迎 {agent['name']}", tags=["onboarding", "welcome"])
    mentor_id = None
    mentor = human or coord
    if mentor and mentor != agent_id:
        mid = new_id("m")
        if human:
            status, note = "active", "人类所有者（导师）"
        else:
            status, note = "pending", "onboarding auto-suggest；导师确认后生效"
        conn.execute("INSERT INTO mentorships(id, mentee_id, mentor_id, status, note) VALUES (?,?,?,?,?)",
                     (mid, agent_id, mentor, status, note))
        conn.commit()
        mentor_id = mid
    tid = task_mod.new_id("t")
    conn.execute(
        "INSERT INTO tasks(id, title, description, acceptance_criteria, priority, complexity, "
        "difficulty, status, tags, created_by) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (tid, f"首日任务：{agent['name']} 的自我介绍",
         "阅读团队宪法与 #general，发一条 standup 并在 #lobby 分享一个你感兴趣的话题。",
         "已发 standup + 一条 #lobby 分享", 1, 0.2, 0.2, "backlog",
         json.dumps(["onboarding"], ensure_ascii=False), author))
    task_mod.record_event(conn, tid, author, None, "backlog", "onboarding")
    conn.commit()
    return {"welcome_post": welcome, "mentorship_id": mentor_id, "first_task": tid}


def list_retros(conn, limit: int = 20) -> list[dict]:
    rows = conn.execute("SELECT * FROM retros ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


# ------------------------------------------------------------------ notifications (G5)
def add_notification(conn, agent_id, kind, ref, body):
    # 去重：同一 (agent, kind, ref) 已有**未读**通知则不重复插入（避免同帖多条回复刷屏）。
    dup = conn.execute(
        "SELECT 1 FROM notifications WHERE agent_id=? AND kind=? AND ref=? AND read=0 LIMIT 1",
        (agent_id, kind, str(ref))).fetchone()
    if dup:
        return
    conn.execute("INSERT INTO notifications(agent_id, kind, ref, body) VALUES (?,?,?,?)",
                 (agent_id, kind, ref, body))


def list_notifications(conn, agent_id, unread_only=False, limit=50) -> list[dict]:
    sql = "SELECT * FROM notifications WHERE agent_id=?"
    if unread_only:
        sql += " AND read=0"
    sql += " ORDER BY id DESC LIMIT ?"
    return [dict(r) for r in conn.execute(sql, (agent_id, limit)).fetchall()]


def unread_count(conn, agent_id) -> int:
    return conn.execute("SELECT COUNT(*) c FROM notifications WHERE agent_id=? AND read=0",
                        (agent_id,)).fetchone()["c"]


def mark_notifications_read(conn, agent_id) -> int:
    cur = conn.execute("UPDATE notifications SET read=1 WHERE agent_id=? AND read=0", (agent_id,))
    conn.commit()
    return cur.rowcount


# ------------------------------------------------------------------ direct messages (DM / 对话)
def send_message(conn, from_id, to_id, body) -> int:
    if not conn.execute("SELECT 1 FROM agents WHERE id=?", (to_id,)).fetchone():
        raise ValueError("recipient not found")
    cur = conn.execute("INSERT INTO messages(from_id, to_id, body) VALUES (?,?,?)",
                       (from_id, to_id, body))
    add_notification(conn, to_id, "message", str(cur.lastrowid),
                     f"{from_id} 私信你：{body[:60]}")
    conn.commit()
    return cur.lastrowid


def list_messages(conn, agent_id, with_agent=None, box="in", unread_only=False, limit=50) -> list[dict]:
    col, other = ("to_id", "from_id") if box == "in" else ("from_id", "to_id")
    sql = f"SELECT * FROM messages WHERE {col}=?"
    params = [agent_id]
    if with_agent:
        sql += f" AND {other}=?"
        params.append(with_agent)
    if unread_only:
        sql += " AND read=0"
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def unread_messages(conn, agent_id, limit=10) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM messages WHERE to_id=? AND read=0 ORDER BY id DESC LIMIT ?",
        (agent_id, limit)).fetchall()]


def unread_message_count(conn, agent_id) -> int:
    return conn.execute("SELECT COUNT(*) c FROM messages WHERE to_id=? AND read=0",
                        (agent_id,)).fetchone()["c"]


def mark_messages_read(conn, agent_id) -> int:
    cur = conn.execute("UPDATE messages SET read=1 WHERE to_id=? AND read=0", (agent_id,))
    conn.commit()
    return cur.rowcount


# ------------------------------------------------------------------ search (G6)
def search(conn, q, channel=None, limit=20) -> list[dict]:
    like = f"%{q}%"
    sql = ("SELECT p.*, a.full_name AS author, c.name AS channel FROM posts p "
           "LEFT JOIN agents a ON a.id=p.author_id LEFT JOIN channels c ON c.id=p.channel_id "
           "WHERE (p.title LIKE ? OR p.body LIKE ?)")
    params = [like, like]
    if channel:
        sql += " AND p.channel_id=?"
        params.append(channel)
    sql += " ORDER BY p.created_at DESC LIMIT ?"
    params.append(limit)
    return [_post_public(conn, r) for r in conn.execute(sql, params).fetchall()]


# ------------------------------------------------------------------ topics (G4)
def open_topic(conn, opened_by, title, prompt=None, channel_id="#lobby") -> str:
    conn.execute("UPDATE topics SET status='closed', closed_at=? WHERE status='open'", (_now(),))
    tid = new_id("topic")
    conn.execute("INSERT INTO topics(id, title, prompt, channel_id, opened_by) VALUES (?,?,?,?,?)",
                 (tid, title, prompt, channel_id, opened_by))
    ensure_default_channels(conn)
    create_post_and_emit(conn, opened_by, channel_id, "announcement",
                         f"【话题日】{title}\n\n{prompt or ''}",
                         title=f"话题日：{title}", tags=["topic"])
    conn.commit()
    return tid


def list_topics(conn, limit=20) -> list[dict]:
    rows = conn.execute("SELECT * FROM topics ORDER BY opened_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def active_topic(conn) -> dict | None:
    r = conn.execute("SELECT * FROM topics WHERE status='open' ORDER BY opened_at DESC LIMIT 1").fetchone()
    return dict(r) if r else None


def close_topic(conn, tid) -> None:
    conn.execute("UPDATE topics SET status='closed', closed_at=? WHERE id=?", (_now(), tid))
    conn.commit()
