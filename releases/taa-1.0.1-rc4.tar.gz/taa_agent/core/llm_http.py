"""纯文本判断类 LLM 调用（HTTP 直连，不走 coding agent）。

为什么单列一个模块（docs/529 §1.2）：
  · coding agent（opencode 等）是**执行器**，会被提示词里的文件名/目录触发 Glob，
    工具日志混进输出、结构化内容被截断——实测 4 次调用失败 2 次；
  · 题材判定、风格提取、审稿这类**纯文本判断**不需要工具能力，走 HTTP 直连
    5 秒稳定返回，且 `temperature=0` 可复现。

凡"要一句判断/一份摘要"的地方都用这里；凡"要动手改文件"的地方才用执行器。
取不到 key 返回空串，由调用方决定是否回落 CLI。
"""
from __future__ import annotations

import json
import os

DEFAULT_MODEL = os.environ.get("TEAMAI_HTTP_MODEL", "deepseek-chat")


def available() -> bool:
    try:
        from . import config as _cfg
        return bool(_cfg.deepseek_key())
    except Exception:  # noqa: BLE001
        return False


def ask(prompt: str, *, model: str | None = None, temperature: float = 0.0,
        max_tokens: int = 2400, timeout: int = 120,
        url: str | None = None) -> str:
    """一次问答，返回纯文本；任何失败返回空串（不抛）。"""
    try:
        from . import config as _cfg
        key = _cfg.deepseek_key()
    except Exception:  # noqa: BLE001
        key = ""
    if not key:
        return ""
    url = url or os.environ.get("TEAMAI_HTTP_URL") or "https://api.deepseek.com/v1/chat/completions"
    body = json.dumps({
        "model": model or DEFAULT_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }).encode()
    try:
        import urllib.request
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {key}")
        try:
            from .net_retry import urlopen_retry
            ctx = urlopen_retry(req, timeout=max(5, min(timeout, 180)),
                                 attempts=2, backoff=(1,))
        except ImportError:
            ctx = urllib.request.urlopen(req, timeout=max(5, min(timeout, 180)))
        with ctx as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        return str((d.get("choices") or [{}])[0].get("message", {}).get("content") or "")
    except Exception as e:  # noqa: BLE001
        print(f"[llm_http] 调用失败：{type(e).__name__}: {e}")
        return ""
