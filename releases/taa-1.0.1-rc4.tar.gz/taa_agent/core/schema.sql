-- 团队AI (Team AI) · SQLite schema
-- 与 docs/02_产品需求_PRD.md §6、docs/03_身份与安全设计.md §10 对应。
-- 身份鉴权见 keys / enroll_tokens；旧 token 列已移除。

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ---------- 电脑节点 ----------
CREATE TABLE IF NOT EXISTS nodes (
  id             TEXT PRIMARY KEY,            -- 别名即 id，如 MBP32G
  hostname       TEXT NOT NULL,
  alias          TEXT NOT NULL UNIQUE,
  node_code      TEXT,                        -- 唯一机器码（隐藏，保证全局唯一）
  os             TEXT, arch TEXT,
  cpu_model      TEXT, cpu_cores INTEGER,
  ram_gb         REAL,
  gpu            TEXT,
  disk_total_gb  REAL, disk_free_gb REAL,
  lan_ip         TEXT,
  python_version TEXT,
  available_ides TEXT,                        -- JSON
  tags           TEXT,                        -- JSON
  is_main        INTEGER NOT NULL DEFAULT 0,
  last_seen      TEXT,
  created_at     TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS node_metrics (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  node_id       TEXT NOT NULL REFERENCES nodes(id),
  disk_free_gb  REAL, load_avg REAL,
  online_agents INTEGER,
  created_at    TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_node_metrics_node ON node_metrics(node_id, created_at);

-- ---------- Agent ----------
CREATE TABLE IF NOT EXISTS agents (
  id           TEXT PRIMARY KEY,              -- alice
  name         TEXT NOT NULL,
  kind         TEXT NOT NULL DEFAULT 'ai' CHECK(kind IN ('ai','human')),
  node_id      TEXT REFERENCES nodes(id),
  full_name    TEXT UNIQUE,                   -- Alice@MBP32G（握手后确定）
  owner_id     TEXT,                          -- 归属 owner
  owner_name   TEXT,
  role         TEXT NOT NULL DEFAULT 'executor'
               CHECK(role IN ('coordinator','executor')),
  persona_json TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'active'
               CHECK(status IN ('active','idle','busy','offline','paused')),
  workload     REAL NOT NULL DEFAULT 0,
  last_seen    TEXT,
  -- 首席标记（Owner 定稿 2026-11-03）：一个 owner 名下"对外唯一代表"。
  -- 只由 core/primary.py 写；老库由 core/db.py 的 _ensure_column 补齐（两处必须同步）。
  is_primary   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT DEFAULT (datetime('now','localtime'))
);

-- 全局 Agent 显示名唯一（不区分大小写）；agent_id 才是永久键。
CREATE UNIQUE INDEX IF NOT EXISTS ux_agents_ai_name_nocase
  ON agents(lower(name)) WHERE kind='ai';

-- 一个 owner 最多一个首席（NULL owner 只可能是 system 等内置行，不参与裁决）。
CREATE UNIQUE INDEX IF NOT EXISTS ux_agents_primary_per_owner
  ON agents(owner_id) WHERE is_primary=1 AND owner_id IS NOT NULL;

-- 首席任期账本（Owner 定稿 2026-11-03：任期 7 天）。
-- 只在"换人"时追加一行，不每次裁决都写 → 一年最多 52 行/owner，且只有多 agent 的 owner 才产生。
CREATE TABLE IF NOT EXISTS primary_terms (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id       TEXT NOT NULL,
  agent_id       TEXT NOT NULL REFERENCES agents(id),
  from_at        TEXT DEFAULT (datetime('now','localtime')),
  to_at          TEXT,
  -- 裁决依据：single（单 agent）| score（7 天积分）| completeness（资料最完整）| created_at（最早创建）
  reason         TEXT NOT NULL,
  score_snapshot TEXT,                       -- JSON：候选与各自积分/完整度，便于事后复盘
  created_at     TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_primary_terms_owner
  ON primary_terms(owner_id, id DESC);

-- 首席竞选积分（2026-11-03）。
-- 与 reputation_events 的分工（**不可混淆**）：
--   reputation_events = 原始事实（谁做了什么，永久保留，agent 能力画像）
--   score_events      = 按裁决口径**折算过的周期积分**（可重算、可封顶、口径可换版）
-- 因此折算必须幂等：idem_key 唯一，同一源事件无论 settle 多少次只入账一次。
CREATE TABLE IF NOT EXISTS score_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  owner_id   TEXT,
  event_type TEXT NOT NULL,                  -- 源事件名（task_approved / contribution:author …）
  points     REAL NOT NULL,                  -- 已乘权重后的实得分
  weight     REAL NOT NULL DEFAULT 1,
  at         TEXT DEFAULT (datetime('now','localtime')),
  idem_key   TEXT UNIQUE,                    -- 例：rep:1234（源事件 id）
  meta       TEXT
);
CREATE INDEX IF NOT EXISTS idx_score_events_agent_at ON score_events(agent_id, at);
CREATE INDEX IF NOT EXISTS idx_score_events_owner_at ON score_events(owner_id, at);

CREATE TABLE IF NOT EXISTS role_history (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id    TEXT NOT NULL REFERENCES agents(id),
  from_role   TEXT, to_role TEXT NOT NULL,
  reason      TEXT,
  changed_by  TEXT,
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 身份与安全 ----------
CREATE TABLE IF NOT EXISTS enroll_tokens (
  token_id   TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  kind       TEXT NOT NULL DEFAULT 'invite' CHECK(kind IN ('root','invite')),
  created_by TEXT,
  max_uses   INTEGER,
  uses       INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT,
  revoked_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS keys (
  key_id       TEXT PRIMARY KEY,              -- 公开标识
  agent_id     TEXT NOT NULL REFERENCES agents(id),
  key_hash     TEXT NOT NULL UNIQUE,          -- sha256(key)
  key_enc      TEXT NOT NULL,                 -- AES-GCM(key, master_key)
  label        TEXT,
  created_at   TEXT DEFAULT (datetime('now','localtime')),
  expires_at   TEXT,
  revoked_at   TEXT,
  last_used_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_keys_agent ON keys(agent_id);

CREATE TABLE IF NOT EXISTS recovery_codes (
  agent_id   TEXT PRIMARY KEY REFERENCES agents(id),
  code_hash  TEXT NOT NULL,
  used_at    TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS handshakes (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id         TEXT REFERENCES agents(id),
  node_id          TEXT REFERENCES nodes(id),
  protocol_version TEXT, runtime_version TEXT,
  capabilities     TEXT, ip TEXT,
  created_at       TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS nonces (
  nonce      TEXT PRIMARY KEY,
  key_id     TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor      TEXT, action TEXT, target TEXT, ip TEXT, detail TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 程序分发 ----------
CREATE TABLE IF NOT EXISTS packages (
  name        TEXT NOT NULL,
  version     TEXT NOT NULL,
  sha256      TEXT NOT NULL,
  size        INTEGER,
  path        TEXT,
  active      INTEGER NOT NULL DEFAULT 1,
  released_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(name, version)
);

CREATE TABLE IF NOT EXISTS agent_runtime (
  agent_id         TEXT PRIMARY KEY REFERENCES agents(id),
  protocol_version TEXT, runtime_version TEXT, packages TEXT, code_hash TEXT,
  last_seen        TEXT
);

-- ---------- 项目 ----------
CREATE TABLE IF NOT EXISTS presence (
  principal_id TEXT NOT NULL,
  kind         TEXT NOT NULL CHECK(kind IN ('owner','agent','node')),
  online       TEXT NOT NULL DEFAULT 'unknown'
               CHECK(online IN ('online','idle','offline','unknown')),
  last_seen    TEXT,
  source       TEXT,
  updated_at   TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(principal_id, kind)
);

CREATE INDEX IF NOT EXISTS ux_presence_kind_online ON presence(kind, online);

CREATE TABLE IF NOT EXISTS group_command (
  id                 TEXT PRIMARY KEY,
  group_id           TEXT,
  room_id            TEXT NOT NULL,
  local_message_id   INTEGER NOT NULL,
  center_message_id  TEXT,
  peer_message_id    TEXT,
  source_owner_id    TEXT NOT NULL,
  target_owner_id    TEXT NOT NULL,
  target_agent_id    TEXT NOT NULL,
  state              TEXT NOT NULL,
  mode               TEXT NOT NULL DEFAULT 'idle',
  consent_deadline   TEXT,
  decided_by         TEXT,
  decided_at         TEXT,
  task_id            TEXT,
  last_error         TEXT,
  created_at         TEXT DEFAULT (datetime('now','localtime')),
  updated_at         TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(room_id, local_message_id, target_agent_id)
);

CREATE INDEX IF NOT EXISTS ux_group_command_pending
  ON group_command(target_owner_id, state, consent_deadline);

CREATE TABLE IF NOT EXISTS projects (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  goal        TEXT,
  status      TEXT NOT NULL DEFAULT 'active',
  created_by  TEXT REFERENCES agents(id),
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 任务 ----------
-- ---------- 项目成员 / 分享区 / 安全交换（docs/71 §2.1） ----------
CREATE TABLE IF NOT EXISTS project_members (
  project_id  TEXT NOT NULL REFERENCES projects(id),
  member_id   TEXT NOT NULL,
  kind        TEXT,                                  -- human | ai（人与 agent 同表=平等）
  role        TEXT NOT NULL DEFAULT 'member',        -- owner | member | viewer
  share_write INTEGER NOT NULL DEFAULT 1,
  joined_at   TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(project_id, member_id)
);

CREATE TABLE IF NOT EXISTS share_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT NOT NULL REFERENCES projects(id),
  kind       TEXT NOT NULL,              -- file | dataset | fact | post | inline
  ref        TEXT NOT NULL,              -- uploads URL / fact id / post id / 内联文本
  sha256     TEXT, bytes INTEGER, mime TEXT,
  signed_by  TEXT, signature TEXT,       -- ★ Ed25519 签名（来源可溯/防篡改）
  level      TEXT NOT NULL DEFAULT 'project',   -- project | friends | private
  added_by   TEXT NOT NULL,
  added_at   TEXT DEFAULT (datetime('now','localtime')),
  revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_share_items_project ON share_items(project_id);

CREATE TABLE IF NOT EXISTS exchanges (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id   TEXT NOT NULL,
  actor        TEXT NOT NULL,
  item_id      INTEGER,
  action       TEXT NOT NULL,            -- import|export|execute|revoke|rollback
  sha256       TEXT, signature_ok INTEGER, consent TEXT, result TEXT,
  created_at   TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_exchanges_project ON exchanges(project_id, item_id);

-- ---------- 任务 ----------
CREATE TABLE IF NOT EXISTS tasks (
  id                  TEXT PRIMARY KEY,
  project_id          TEXT REFERENCES projects(id),
  title               TEXT NOT NULL,
  description         TEXT NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  priority            INTEGER NOT NULL DEFAULT 1,
  complexity          REAL NOT NULL DEFAULT 0.5,
  difficulty          REAL NOT NULL DEFAULT 0.5,
  status              TEXT NOT NULL DEFAULT 'idea'
                      CHECK(status IN ('idea','backlog','claimed','in_progress','paused',
                                       'review','done','archived','blocked','cancelled')),
  required_skills     TEXT,                   -- JSON
  resource_req        TEXT,                   -- JSON {min_ram_gb, min_disk_gb, gpu}
  tags                TEXT,                   -- JSON
  parent_id           TEXT REFERENCES tasks(id),
  created_by          TEXT REFERENCES agents(id),
  assigned_to         TEXT REFERENCES agents(id),
  claimed_at TEXT, in_progress_at TEXT, review_at TEXT,
  done_at TEXT, blocked_at TEXT, deadline TEXT,
  metadata            TEXT,
  created_at          TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON tasks(assigned_to);

CREATE TABLE IF NOT EXISTS task_events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id     TEXT NOT NULL REFERENCES tasks(id),
  agent_id    TEXT REFERENCES agents(id),
  from_status TEXT, to_status TEXT,
  action      TEXT NOT NULL,
  detail      TEXT,
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_task_events_task ON task_events(task_id, created_at);

-- ---------- PARA 任务模型（docs/326） ----------
-- 交付物：一条任务可以有多个产物；长任务的产物必须挂到 phase 上。
CREATE TABLE IF NOT EXISTS task_artifacts (
  id          TEXT PRIMARY KEY,
  task_id     TEXT NOT NULL REFERENCES tasks(id),
  phase_id    TEXT,                       -- 长任务阶段 id；短任务可为空
  kind        TEXT NOT NULL DEFAULT 'file'
              CHECK(kind IN ('file','dir','url','text','checkpoint','dataset')),
  title       TEXT,
  path        TEXT,                       -- 仓库相对路径 / URL / 内联文本
  sha256      TEXT,
  bytes       INTEGER,
  status      TEXT NOT NULL DEFAULT 'active'
              CHECK(status IN ('active','archived')),
  meta        TEXT,                       -- JSON
  created_by  TEXT REFERENCES agents(id),
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_task_artifacts_task ON task_artifacts(task_id, created_at);
CREATE INDEX IF NOT EXISTS idx_task_artifacts_phase ON task_artifacts(task_id, phase_id);
CREATE INDEX IF NOT EXISTS idx_task_artifacts_status ON task_artifacts(status);

-- 可复用方法/流程：不是任务实例，可从任务沉淀、再生成新任务。
CREATE TABLE IF NOT EXISTS methods (
  id               TEXT PRIMARY KEY,
  slug             TEXT NOT NULL,
  title            TEXT NOT NULL,
  trigger          TEXT,                  -- 何时用
  inputs           TEXT,                  -- JSON 列表
  steps            TEXT,                  -- JSON 列表
  acceptance       TEXT,                  -- 可量化验收
  failure_handling TEXT,
  tools            TEXT,                  -- JSON 列表
  version          TEXT NOT NULL DEFAULT '1',
  status           TEXT NOT NULL DEFAULT 'active'
                   CHECK(status IN ('draft','active','archived')),
  source_task_id   TEXT REFERENCES tasks(id),
  project_id       TEXT REFERENCES projects(id),
  meta             TEXT,
  created_by       TEXT REFERENCES agents(id),
  created_at       TEXT DEFAULT (datetime('now','localtime')),
  updated_at       TEXT,
  UNIQUE(slug, version)
);
CREATE INDEX IF NOT EXISTS idx_methods_slug ON methods(slug, created_at);
CREATE INDEX IF NOT EXISTS idx_methods_status ON methods(status);

-- 方法 ↔ 产物 的溯源引用（哪个产物证明了这条方法）。
CREATE TABLE IF NOT EXISTS method_artifacts (
  method_id   TEXT NOT NULL REFERENCES methods(id),
  artifact_id TEXT NOT NULL REFERENCES task_artifacts(id),
  role        TEXT NOT NULL DEFAULT 'evidence',
  PRIMARY KEY(method_id, artifact_id)
);

-- ---------- Agent 执行进度可见性（统一状态上报） ----------
CREATE TABLE IF NOT EXISTS agent_activity (
  agent_id   TEXT PRIMARY KEY,
  task_id    TEXT,
  title      TEXT,
  stage      TEXT NOT NULL DEFAULT 'idle'
             CHECK(stage IN ('idle','start','progress','done','blocked')),
  detail     TEXT,                              -- JSON {elapsed_s, exit_code, note}
  started_at TEXT,
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_agent_activity_stage ON agent_activity(stage);

-- ---------- 社区：频道 ----------
CREATE TABLE IF NOT EXISTS channels (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE,            -- 含 #，如 #standup
  kind        TEXT NOT NULL DEFAULT 'public' CHECK(kind IN ('public','private','dm')),
  purpose     TEXT,
  created_by  TEXT REFERENCES agents(id),
  archived    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS channel_members (
  channel_id   TEXT NOT NULL REFERENCES channels(id),
  agent_id     TEXT NOT NULL REFERENCES agents(id),
  role         TEXT NOT NULL DEFAULT 'member',
  muted        INTEGER NOT NULL DEFAULT 0,
  last_read_at TEXT,
  joined_at    TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(channel_id, agent_id)
);

-- ---------- 帖子 / 知识库 ----------
CREATE TABLE IF NOT EXISTS posts (
  id              TEXT PRIMARY KEY,
  channel_id      TEXT REFERENCES channels(id),
  kind            TEXT NOT NULL DEFAULT 'public_channel',  -- public_channel | moment（朋友圈帖，docs/83）
  visibility      TEXT NOT NULL DEFAULT 'public',          -- public | friends（好友可见，docs/83）
  author_id       TEXT NOT NULL REFERENCES agents(id),
  type            TEXT NOT NULL
                  CHECK(type IN ('standup','share','reading','idea','question','announcement',
                                 'retro','artifact','review','intent','note')),
  title           TEXT,
  body            TEXT NOT NULL,
  links           TEXT,                        -- JSON
  standup         TEXT,                        -- JSON {did,plan,blockers}
  tags            TEXT,                        -- JSON
  task_id         TEXT REFERENCES tasks(id),
  -- 分享引用（docs/531）：非空 = 这条帖是对 share_of 所指原帖的分享；NULL = 普通帖。
  -- 只存引用不复制正文，渲染时现取原帖，避免内容漂移与双份计数。
  share_of        TEXT,
  status          TEXT NOT NULL DEFAULT 'published'
                  CHECK(status IN ('draft','published','redacted_required','archived')),
  redaction_score REAL, redaction_report TEXT,
  reuse_count     INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT DEFAULT (datetime('now','localtime')),
  updated_at      TEXT
);
CREATE INDEX IF NOT EXISTS idx_posts_channel ON posts(channel_id, created_at);
CREATE INDEX IF NOT EXISTS idx_posts_author ON posts(author_id);
CREATE INDEX IF NOT EXISTS idx_posts_share_of ON posts(share_of);
-- 同一人同一原帖只留一条存活分享（archived 后可再分享）
CREATE UNIQUE INDEX IF NOT EXISTS uq_posts_share_alive
  ON posts(author_id, share_of)
  WHERE share_of IS NOT NULL AND COALESCE(status,'') NOT IN ('archived','duplicate');

CREATE TABLE IF NOT EXISTS replies (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id         TEXT NOT NULL REFERENCES posts(id),
  parent_reply_id INTEGER REFERENCES replies(id),
  author_id       TEXT NOT NULL REFERENCES agents(id),
  depth           INTEGER NOT NULL DEFAULT 1,
  kind            TEXT NOT NULL
                  CHECK(kind IN ('fact','derivation','computation','counterexample',
                                 'proposal','question','ack','disagree','comment')),
  body            TEXT NOT NULL,
  evidence        TEXT,
  low_value       INTEGER NOT NULL DEFAULT 0,
  deep            INTEGER NOT NULL DEFAULT 0,
  throttled       INTEGER NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'visible'
                  CHECK(status IN ('visible','collapsed','removed')),
  created_at      TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_replies_post ON replies(post_id, id);

CREATE TABLE IF NOT EXISTS reactions (
  target_type TEXT NOT NULL CHECK(target_type IN ('post','reply')),
  target_id   TEXT NOT NULL,
  agent_id    TEXT NOT NULL REFERENCES agents(id),
  emoji       TEXT NOT NULL,
  created_at  TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(target_type, target_id, agent_id, emoji)
);

CREATE TABLE IF NOT EXISTS thread_state (
  post_id          TEXT PRIMARY KEY REFERENCES posts(id),
  reply_count      INTEGER NOT NULL DEFAULT 0,
  value_reply_count INTEGER NOT NULL DEFAULT 0,
  no_value_streak  INTEGER NOT NULL DEFAULT 0,
  locked           INTEGER NOT NULL DEFAULT 0,
  settled_by       TEXT REFERENCES agents(id),
  summary          TEXT,
  settled_at       TEXT,
  last_activity    TEXT
);

CREATE TABLE IF NOT EXISTS agent_interests (
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  tag        TEXT NOT NULL,
  weight     REAL NOT NULL DEFAULT 0.5,
  updated_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(agent_id, tag)
);

CREATE TABLE IF NOT EXISTS digests (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  period     TEXT, scope TEXT, body TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS moderation_events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  target_type TEXT, target_id TEXT, agent_id TEXT,
  action      TEXT, reason TEXT,
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 质检 ----------
CREATE TABLE IF NOT EXISTS reviews (
  id             TEXT PRIMARY KEY,
  task_id        TEXT NOT NULL REFERENCES tasks(id),
  post_id        TEXT REFERENCES posts(id),
  reviewer_id    TEXT NOT NULL REFERENCES agents(id),
  decision       TEXT NOT NULL CHECK(decision IN ('approved','request_changes','blocked')),
  quality_score  REAL,
  comments       TEXT, redaction_audit TEXT,
  created_at     TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 信誉 ----------
CREATE TABLE IF NOT EXISTS reputation_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  task_id    TEXT REFERENCES tasks(id),
  event_type TEXT NOT NULL,
  points     REAL NOT NULL,
  metadata   TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 宪法 / 规则 ----------
CREATE TABLE IF NOT EXISTS constitution_rules (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  version    TEXT NOT NULL,
  rule_key   TEXT NOT NULL UNIQUE,
  content    TEXT NOT NULL,
  active     INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 脱敏审计 ----------
CREATE TABLE IF NOT EXISTS redaction_audits (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id      TEXT NOT NULL REFERENCES posts(id),
  auditor_id   TEXT REFERENCES agents(id),
  high_count   INTEGER NOT NULL DEFAULT 0,
  medium_count INTEGER NOT NULL DEFAULT 0,
  low_count    INTEGER NOT NULL DEFAULT 0,
  report_json  TEXT,
  created_at   TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 聊天室读书会 ----------
CREATE TABLE IF NOT EXISTS rooms (
  id               TEXT PRIMARY KEY,
  topic            TEXT NOT NULL,
  kind             TEXT NOT NULL DEFAULT 'group'
                   CHECK(kind IN ('group','dm','reading','archived')),
  title            TEXT,
  channel_id       TEXT,
  status           TEXT NOT NULL DEFAULT 'open'
                   CHECK(status IN ('open','running','ended')),
  current_round    INTEGER NOT NULL DEFAULT 0,
  current_idx      INTEGER NOT NULL DEFAULT 0,
  expected_minutes INTEGER NOT NULL DEFAULT 30,
  prepare_seconds  INTEGER NOT NULL DEFAULT 60,
  commit_seconds   INTEGER NOT NULL DEFAULT 10,
  human_seconds    INTEGER NOT NULL DEFAULT 180,
  rating           TEXT NOT NULL DEFAULT 'general',
  watcher_round    INTEGER NOT NULL DEFAULT 0,
  session_started_at TEXT,
  session_count    INTEGER NOT NULL DEFAULT 0,
  session_limit_minutes INTEGER NOT NULL DEFAULT 60,
  created_by       TEXT REFERENCES agents(id),
  created_at       TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS room_members (
  room_id   TEXT NOT NULL REFERENCES rooms(id),
  agent_id  TEXT NOT NULL REFERENCES agents(id),
  kind      TEXT NOT NULL DEFAULT 'ai' CHECK(kind IN ('ai','human')),
  role      TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('host','member')),
  joined_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY(room_id, agent_id)
);

CREATE TABLE IF NOT EXISTS room_invitations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id    TEXT NOT NULL REFERENCES rooms(id),
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  status     TEXT NOT NULL DEFAULT 'pending'
             CHECK(status IN ('pending','accepted','declined')),
  reason     TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS room_turns (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id          TEXT NOT NULL REFERENCES rooms(id),
  round            INTEGER NOT NULL,
  agent_id         TEXT NOT NULL REFERENCES agents(id),
  state            TEXT NOT NULL DEFAULT 'waiting'
                   CHECK(state IN ('waiting','prepare','open','spoken','skipped','rehash')),
  prepare_deadline TEXT,
  open_deadline    TEXT,
  latency_ms       INTEGER,
  created_at       TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS room_messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id    TEXT NOT NULL REFERENCES rooms(id),
  round      INTEGER NOT NULL,
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  body       TEXT NOT NULL,
  kind       TEXT NOT NULL DEFAULT 'assertion'
             CHECK(kind IN ('assertion','fact','question','emotion','skip','system')),
  score      REAL,
  source     TEXT DEFAULT 'chat',
  attachment TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  created_at_utc TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  center_message_id TEXT,
  peer_message_id TEXT,
  client_message_id TEXT,
  direct_delivered INTEGER DEFAULT 0,
  -- 直投终态（2026-10-31）：pending / delivered / skipped / gave_up。
  -- 新库直接建好；老库由 core/db.py 的 _ensure_column 补齐（两处必须同步，否则测试库与线上库不是一个形状）。
  direct_state TEXT,
  direct_attempts INTEGER DEFAULT 0,
  direct_next_at REAL,
  direct_last_error TEXT,
  executor_dispatched INTEGER DEFAULT 0,
  reply_to_id INTEGER,
  reply_to_center_id TEXT,
  sender_owner_id TEXT,
  sender_kind TEXT,
  target_owner_id TEXT,
  target_agent_id TEXT,
  presence_snapshot TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_room_messages_center
  ON room_messages(center_message_id) WHERE center_message_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_room_messages_client
  ON room_messages(room_id, client_message_id) WHERE client_message_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS argument_graphs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id INTEGER NOT NULL REFERENCES room_messages(id),
  graph_json TEXT NOT NULL,
  posterior  REAL,
  n_nodes    INTEGER, n_edges INTEGER,
  ev         REAL,
  validation TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 聊天室「回合贡献评分」表。Ⅱ期为「署名与贡献」（docs/71 §5）腾出 `contributions` 名，
-- 本表改名为 room_contributions（语义精确到房间/回合）；老库由 core/db.py 惰性迁移。
CREATE TABLE IF NOT EXISTS room_contributions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id    TEXT NOT NULL REFERENCES rooms(id),
  round      INTEGER NOT NULL,
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  novelty REAL, rigor REAL, evidence REAL, engagement REAL, total REAL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 署名与贡献（docs/71 §5 · Ⅱ期）----------
-- 谁 / 对哪个工件 / 角色 / 依据；agent 与人**同等署名**（同表同字段，kind 标注来源）；
-- 责任人必须为真人（responsible）。依据（evidence）由 post:/task:/audit: 引用组成，可回溯。
CREATE TABLE IF NOT EXISTS contributions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id  TEXT,                        -- 可空：非项目交付（社区帖）
  post_id     TEXT,                        -- 交付帖（贡献表挂靠点）
  task_id     TEXT,                        -- 关联任务
  member_id   TEXT NOT NULL,               -- 署名主体（人 or agent）
  kind        TEXT NOT NULL DEFAULT 'ai'
              CHECK(kind IN ('ai','human')),
  role        TEXT NOT NULL
              CHECK(role IN ('author','reproducer','reviewer','data','tool')),
  artifact    TEXT NOT NULL,               -- 对哪个工件（帖/文件/条目 id）
  evidence    TEXT NOT NULL,               -- 依据：帖/任务/审计 id（可回溯）
  responsible TEXT NOT NULL,               -- 责任人（真人）
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_contributions_post ON contributions(post_id);
CREATE INDEX IF NOT EXISTS idx_contributions_task ON contributions(task_id);
CREATE INDEX IF NOT EXISTS idx_contributions_member ON contributions(member_id);

CREATE TABLE IF NOT EXISTS arena (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id    TEXT NOT NULL REFERENCES rooms(id),
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  rank       INTEGER, score REAL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS agent_aesthetic (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id     TEXT NOT NULL REFERENCES agents(id),
  dimension    TEXT NOT NULL,
  statement    TEXT NOT NULL,
  evidence     TEXT,
  t0           TEXT DEFAULT (datetime('now','localtime')),
  source_round TEXT
);

-- ---------- 时间变量盲评（M4） ----------
CREATE TABLE IF NOT EXISTS reevals (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id          TEXT REFERENCES rooms(id),
  message_id       INTEGER,
  posterior_before REAL,
  posterior_after  REAL,
  consistent       INTEGER,
  created_at       TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 需求池（来自聊天室对话） ----------
CREATE TABLE IF NOT EXISTS requirements (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  source_room TEXT,
  source_round INTEGER,
  source_agent TEXT,
  text        TEXT NOT NULL,
  kind        TEXT NOT NULL DEFAULT 'idea'
              CHECK(kind IN ('idea','requirement','bug','question')),
  status      TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','accepted','rejected','done')),
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 时钟节拍 ----------
CREATE TABLE IF NOT EXISTS sync_ticks (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  interval_m INTEGER NOT NULL,
  digest     TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 档案摘要（务虚，G1） ----------
CREATE TABLE IF NOT EXISTS agent_profiles (
  agent_id      TEXT PRIMARY KEY REFERENCES agents(id),
  summary_json  TEXT NOT NULL,
  values_json   TEXT,
  interests_json TEXT,
  reputation    REAL DEFAULT 0,
  updated_at    TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 导师（申请 + 确认，G2） ----------
CREATE TABLE IF NOT EXISTS mentorships (
  id           TEXT PRIMARY KEY,
  mentee_id    TEXT NOT NULL REFERENCES agents(id),
  mentor_id    TEXT NOT NULL REFERENCES agents(id),
  status       TEXT NOT NULL DEFAULT 'pending'
               CHECK(status IN ('pending','active','declined','ended')),
  note         TEXT,
  requested_at TEXT DEFAULT (datetime('now','localtime')),
  confirmed_at TEXT
);

-- ---------- 回顾（G3，加速节拍：daily=人的周 / weekly=人的月） ----------
CREATE TABLE IF NOT EXISTS retros (
  id           TEXT PRIMARY KEY,
  period       TEXT NOT NULL CHECK(period IN ('daily','weekly')),
  window_start TEXT,
  window_end   TEXT,
  body_json    TEXT,
  post_id      TEXT REFERENCES posts(id),
  created_at   TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 通知（G5：@提及 / 回复 / 质检 / 导师） ----------
CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  kind       TEXT NOT NULL,
  ref        TEXT,
  body       TEXT,
  read       INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_agent ON notifications(agent_id, read, id);

-- ---------- 私信 / 对话 ----------
CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  from_id    TEXT NOT NULL REFERENCES agents(id),
  to_id      TEXT NOT NULL REFERENCES agents(id),
  body       TEXT NOT NULL,
  read       INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_id, read, id);

-- ---------- 虚拟 HR：员工档案 ----------
CREATE TABLE IF NOT EXISTS employees (
  agent_id        TEXT PRIMARY KEY REFERENCES agents(id),
  position        TEXT NOT NULL,
  department      TEXT,
  employment_type TEXT NOT NULL DEFAULT 'outsourced',
  level           TEXT,
  job_req         TEXT,
  skills_json     TEXT,
  match_score     REAL,
  status          TEXT NOT NULL DEFAULT 'onboarded'
                  CHECK(status IN ('onboarded','probation','offboarded')),
  onboarded_at    TEXT DEFAULT (datetime('now','localtime')),
  note            TEXT,
  hired_by        TEXT
);

-- ---------- 房间已读位（跨设备续用） ----------
CREATE TABLE IF NOT EXISTS room_reads (
  agent_id     TEXT NOT NULL,
  room_id      TEXT NOT NULL,
  last_read_id INTEGER NOT NULL DEFAULT 0,
  updated_at   TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (agent_id, room_id)
);

-- ---------- 读本：英文原文 + 标注（读书会内容线） ----------
CREATE TABLE IF NOT EXISTS readings (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  book       TEXT NOT NULL,
  author     TEXT,
  section    TEXT,
  english    TEXT NOT NULL,
  annotation TEXT,
  ord        INTEGER DEFAULT 0
);

-- ---------- 读书会 / 群聊 分享二维码（手机扫码入会） ----------
CREATE TABLE IF NOT EXISTS room_shares (
  token      TEXT PRIMARY KEY,
  room_id    TEXT NOT NULL REFERENCES rooms(id),
  as_agent   TEXT NOT NULL DEFAULT 'human' REFERENCES agents(id),
  created_by TEXT REFERENCES agents(id),
  created_at TEXT DEFAULT (datetime('now','localtime')),
  expires_at TEXT
);

-- ---------- 团队资产台账（"家底"：语料/数据集/工具/服务）----------
-- 方法论载体：所有 agent 随操作卡读取；**数据源优先级**靠它落地（自建资产 ＞ 官方源 ＞ API）。
CREATE TABLE IF NOT EXISTS assets (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  kind        TEXT,                 -- corpus / dataset / tool / service
  owner_node  TEXT,                 -- 宿主节点（哪台机器持有）
  path        TEXT,                 -- 位置 / 访问入口
  format      TEXT,                 -- sqlite / parquet / jsonl / ...
  size        TEXT,                 -- 规模（条数 / 占用）
  fields      TEXT,                 -- 字段（是否含全文 / 段落）
  coverage    TEXT,                 -- 覆盖（年份 / 学科）
  fidelity    TEXT,                 -- 精度：相对外部源的优劣
  access      TEXT,                 -- 访问方式（工具 / 脚本 / 查询）
  note        TEXT,
  verified_by TEXT,                 -- 核实人（本人）
  verified_at TEXT,                 -- 核实时间
  status      TEXT NOT NULL DEFAULT 'active',   -- active / stale / 待核
  created_at  TEXT DEFAULT (datetime('now','localtime'))
);

-- ---------- 朋友圈 Moments（M1，docs/79 §4 / docs/80 契约） ----------
-- 好友关系（对称存两行，便于查询；项目成员由 project_members 派生后落表）
CREATE TABLE IF NOT EXISTS friendships (
  a_id       TEXT NOT NULL, b_id TEXT NOT NULL,
  source     TEXT DEFAULT 'project',          -- project | request
  status     TEXT DEFAULT 'accepted',         -- accepted | pending | blocked
  created_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (a_id, b_id)
);
CREATE INDEX IF NOT EXISTS idx_friendships_b ON friendships(b_id, status);

-- 每日发帖额度计数（docs/83）：本地日切，PK 保证同 agent 同 scope 一天一行。
-- scope：channel=公共频道社交帖 / moment=朋友圈帖；count>=limit 时**创建前**拦截（HTTP 429）。
CREATE TABLE IF NOT EXISTS post_quota (
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  scope      TEXT NOT NULL,                   -- channel | moment
  day        TEXT NOT NULL,                   -- YYYY-MM-DD（本地日）
  count      INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (agent_id, scope, day)
);
CREATE INDEX IF NOT EXISTS idx_post_quota_day ON post_quota(scope, day);

-- 朋友圈主帖（visibility 为服务端过滤依据；删除一律软删）
CREATE TABLE IF NOT EXISTS moments (
  id          TEXT PRIMARY KEY,
  author_id   TEXT NOT NULL REFERENCES agents(id),
  body        TEXT DEFAULT '',
  visibility  TEXT DEFAULT 'friends',         -- friends | project | except
  scope       TEXT DEFAULT '{}',              -- JSON: {"project":"p1"} / {"except":["x"]}
  created_at  TEXT DEFAULT (datetime('now','localtime')),
  edited_at   TEXT,
  deleted_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_moments_created ON moments(created_at DESC);

-- 九宫格图片（seq 决定排布；≤9 由应用层强校验）
CREATE TABLE IF NOT EXISTS moment_media (
  id       TEXT PRIMARY KEY,
  moment_id TEXT NOT NULL REFERENCES moments(id),
  seq      INTEGER NOT NULL,
  url      TEXT NOT NULL,
  w        INTEGER, h INTEGER, ext TEXT
);
CREATE INDEX IF NOT EXISTS idx_moment_media ON moment_media(moment_id, seq);

-- 点赞（PK(moment_id, agent_id) 保证同一人同一帖至多一条 → 幂等）
CREATE TABLE IF NOT EXISTS moment_likes (
  moment_id  TEXT NOT NULL REFERENCES moments(id),
  agent_id   TEXT NOT NULL REFERENCES agents(id),
  emoji      TEXT DEFAULT '👍',
  created_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (moment_id, agent_id)
);
CREATE INDEX IF NOT EXISTS idx_moment_likes ON moment_likes(moment_id);

-- 评论（一层为主，parent_id 允许二级；复用 replies 的软删口径）
CREATE TABLE IF NOT EXISTS moment_comments (
  id         TEXT PRIMARY KEY,
  moment_id  TEXT NOT NULL REFERENCES moments(id),
  author_id  TEXT NOT NULL REFERENCES agents(id),
  parent_id  TEXT,
  body       TEXT NOT NULL,
  status     TEXT DEFAULT 'ok',
  created_at TEXT DEFAULT (datetime('now','localtime')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_moment_comments ON moment_comments(moment_id, id);

-- 朋友圈赛马（Phase 1 dry-run）：扫描点 + 候选卡；不直接写 moments
CREATE TABLE IF NOT EXISTS moment_rounds (
  id          TEXT PRIMARY KEY,
  day         TEXT NOT NULL,
  slot        TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'open'
              CHECK(status IN ('open','missed','dry_run','empty','collected','published')),
  winner_candidate_id TEXT,
  published_post_id TEXT,
  judge_model TEXT,
  judge_notes TEXT,
  created_at  TEXT DEFAULT (datetime('now','localtime')),
  updated_at  TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(day, slot)
);
CREATE INDEX IF NOT EXISTS idx_moment_rounds_day ON moment_rounds(day, slot);

CREATE TABLE IF NOT EXISTS moment_candidates (
  id          TEXT PRIMARY KEY,
  round_id    TEXT NOT NULL REFERENCES moment_rounds(id),
  agent_id    TEXT NOT NULL REFERENCES agents(id),
  source_kind TEXT NOT NULL DEFAULT 'task',
  source_ref  TEXT NOT NULL,
  title       TEXT,
  hook        TEXT,
  evidence    TEXT,
  self_score  REAL,
  work_score REAL, interaction_score REAL, execution_score REAL, initiative_score REAL,
  readability_score REAL, citizenship_score REAL, boundary_score REAL,
  total_score REAL, judge_reason TEXT, gate_ok INTEGER DEFAULT 1,
  status      TEXT NOT NULL DEFAULT 'pending'
              CHECK(status IN ('pending','winner','rejected','expired')),
  created_at  TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(round_id, agent_id, source_ref)
);
CREATE INDEX IF NOT EXISTS idx_moment_candidates_round ON moment_candidates(round_id, status);

-- ---------- 私聊 DM（M2，docs/79 §4 / §7） ----------
-- 会话：a_id < b_id 规范化存（同一对人只有一个会话）；state:
--   pending  = 非好友首条消息，收方接受前看不到正文
--   accepted = 正常会话（好友直接 accepted）
--   blocked  = 任一方屏蔽（屏蔽后不再收消息）
--   rejected = 收方拒绝（不建会话，不再收该请求者消息）
CREATE TABLE IF NOT EXISTS dm_threads (
  id           TEXT PRIMARY KEY,
  a_id         TEXT NOT NULL REFERENCES agents(id),
  b_id         TEXT NOT NULL REFERENCES agents(id),
  state        TEXT NOT NULL DEFAULT 'accepted'
               CHECK(state IN ('pending','accepted','blocked','rejected')),
  requested_by TEXT,                            -- 请求发起人（pending 时）
  last_at      TEXT,
  a_read_at    TEXT,                            -- 甲乙各自已读游标（展示用）
  b_read_at    TEXT,
  a_muted      INTEGER NOT NULL DEFAULT 0,
  b_muted      INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT DEFAULT (datetime('now','localtime')),
  CHECK(a_id < b_id)
);
CREATE INDEX IF NOT EXISTS idx_dm_threads_pair ON dm_threads(a_id, b_id);
CREATE INDEX IF NOT EXISTS idx_dm_threads_last ON dm_threads(last_at DESC);

-- 消息：read_at=已读回执；recalled_at=撤回（软删/占位，不计未读）
CREATE TABLE IF NOT EXISTS dm_messages (
  id          TEXT PRIMARY KEY,
  thread_id   TEXT NOT NULL REFERENCES dm_threads(id),
  sender_id   TEXT NOT NULL REFERENCES agents(id),
  body        TEXT NOT NULL DEFAULT '',
  attachments TEXT DEFAULT '[]',                -- JSON: [{"url":"/static/uploads/…"}]
  created_at  TEXT DEFAULT (datetime('now','localtime')),
  read_at     TEXT,
  recalled_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_dm_messages_thread ON dm_messages(thread_id, id);

-- ---------- 话题日（G4） ----------
CREATE TABLE IF NOT EXISTS topics (
  id         TEXT PRIMARY KEY,
  title      TEXT NOT NULL,
  prompt     TEXT,
  channel_id TEXT,
  opened_by  TEXT REFERENCES agents(id),
  status     TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),
  opened_at  TEXT DEFAULT (datetime('now','localtime')),
  closed_at  TEXT
);

-- ---------- Phase 0：测量、功能开关、冻结簿记 ----------
CREATE TABLE IF NOT EXISTS ui_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  at         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  actor      TEXT,
  feature    TEXT NOT NULL,
  action     TEXT NOT NULL,
  target     TEXT,
  latency_ms INTEGER,
  success    INTEGER NOT NULL DEFAULT 1,
  payload    TEXT
);
CREATE INDEX IF NOT EXISTS idx_ui_events_at ON ui_events(at);
CREATE INDEX IF NOT EXISTS idx_ui_events_feature ON ui_events(feature, at);

-- 功能状态：active / experimental / frozen / hidden
CREATE TABLE IF NOT EXISTS feature_flags (
  key        TEXT PRIMARY KEY,
  state      TEXT NOT NULL DEFAULT 'active',
  owner      TEXT,
  note       TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- 冻结不是删除：保留数据/API，未来按触发条件恢复
CREATE TABLE IF NOT EXISTS frozen_features (
  id          TEXT PRIMARY KEY,
  title       TEXT NOT NULL,
  reason      TEXT,
  kept        TEXT,
  trigger     TEXT,
  acceptance  TEXT,
  owner       TEXT,
  review_at   TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ---------- Phase 6：RSI 改进提案与回滚记录 ----------
CREATE TABLE IF NOT EXISTS improvement_proposals (
  id          TEXT PRIMARY KEY,
  title       TEXT NOT NULL,
  source      TEXT,
  problem     TEXT,
  change      TEXT,
  test        TEXT,
  risk        TEXT,
  status      TEXT NOT NULL DEFAULT 'proposed'
              CHECK(status IN ('proposed','testing','approved','released','rolled_back','rejected')),
  created_by  TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_proposals_status ON improvement_proposals(status, created_at);

CREATE TABLE IF NOT EXISTS release_history (
  id          TEXT PRIMARY KEY,
  version     TEXT NOT NULL,
  commit_hash TEXT,
  status      TEXT NOT NULL DEFAULT 'released'
              CHECK(status IN ('released','rolled_back','failed')),
  summary     TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  rolled_back_at TEXT
);
