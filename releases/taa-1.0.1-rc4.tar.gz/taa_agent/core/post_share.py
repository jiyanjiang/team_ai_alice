"""帖子「分享到朋友圈」（docs/531·B 案）。

设计要点（与立项文档一一对应）：
  * 分享 = `posts` 里的一条**引用型帖子**：`kind='moment'`、`tags='朋友圈,lobby'`、
    `share_of=<原帖 id>`、`visibility` 默认 `friends`。不新建表、不复制正文。
  * 去重靠部分唯一索引 `uq_posts_share_alive`：同一人同一原帖只有一条存活分享。
  * 「移除」= `status='archived'`（软删留痕），对外不说"撤回"。
  * **可见性 ≤ 原帖**：分享的可见面取 `min(分享, 原帖)`，不放大原帖。

这里只放数据与权限判定，HTML 渲染留在 `core/app_ui.py`（避免循环 import）。
"""

from __future__ import annotations

import hashlib
import sqlite3
import time

MOMENT_TAGS = "朋友圈,lobby"


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _row_get(row, key, default=None):
    """兼容 sqlite3.Row 与 dict。"""
    try:
        return row[key]
    except (IndexError, KeyError, TypeError):
        return default


def friend_set(conn, viewer: str) -> set[str] | None:
    """好友集合；判定不可用（库异常/只读连接）返回 None。

    返回 None 时调用方必须**保持原行为**（不做收紧）：这些行在补 visibility
    之前本来就是可见的，不能让一次查询失败把整页内容藏掉。
    """
    base = _local_friend_ids(conn, viewer)
    if base is None:
        # 本机派生判定不可用 → 不放宽也不收紧（docs/532：宁可少给，不给错）。
        return None
    try:
        from . import friend_sync
        base = set(base) | friend_sync.friend_agents(conn, viewer)
    except Exception:                                            # noqa: BLE001
        pass
    return base


def _local_friend_ids(conn, viewer: str) -> set[str] | None:
    """本机 friendships（project/team 派生 + 显式请求）里的好友集合。"""
    try:
        from .moments import friend_ids
        return friend_ids(conn, viewer)
    except Exception:                                            # noqa: BLE001
        pass
    # app_ui 的 db() 是 mode=ro：friend_ids 内部的派生同步（INSERT）写不进去会整段抛错。
    # 此时退回一个写连接再算一次，否则「好友可见」在真机上等于没接（静默放行）。
    try:
        from .db import connect
        from .moments import friend_ids
        c2 = connect()
        try:
            return friend_ids(c2, viewer)
        finally:
            c2.close()
    except Exception:                                            # noqa: BLE001
        return None


def can_view(viewer: str, row, friends: set[str] | None = None,
             conn=None) -> bool:
    """本条帖子对 viewer 是否可见。

    规则：public → 是；friends → 作者本人或好友；其它未知值 → 按 public（向后兼容）。
    `friends` 可预计算以批量判定；不给则用 conn 现取；判定不可用 → 放行（不回归）。
    """
    if row is None:
        return False
    if viewer and _row_get(row, "author_id") == viewer:
        return True
    vis = str(_row_get(row, "visibility") or "public").lower()
    if vis != "friends":
        return True
    if friends is None:
        if conn is None:
            return False
        friends = friend_set(conn, viewer)
    if friends is None:
        return True
    # friends = **viewer 的好友集合**；要判的是「作者是不是我的好友」，
    # 不是「我在自己的好友集合里」（那样恒 False，好友可见等于没接）。
    return bool(viewer) and _row_get(row, "author_id") in friends


def visible_rows(conn, viewer: str, rows) -> list:
    """批量过滤（feed / moments 用）。好友集合只算一次；判定不可用则原样返回。"""
    rows = list(rows or [])
    if not rows:
        return []
    friends = friend_set(conn, viewer)
    if friends is None:
        return rows
    return [r for r in rows if can_view(viewer, r, friends)]


def share_of_row(conn, post_id: str):
    """取原帖（含 share_of 列）；不存在/已归档 → None（分享侧据此降级）。"""
    if not post_id:
        return None
    try:
        return conn.execute(
            "select * from posts where id=? and coalesce(status,'') "
            "not in ('duplicate','archived')", (post_id,)).fetchone()
    except sqlite3.Error:
        return None


def my_share(conn, viewer: str, post_id: str):
    """viewer 对该帖的存活分享（没有则 None）。"""
    try:
        return conn.execute(
            "select * from posts where share_of=? and author_id=? "
            "and coalesce(status,'') NOT IN ('archived','duplicate') limit 1",
            (post_id, viewer)).fetchone()
    except sqlite3.Error:
        return None


def share_post(conn, actor: str, post_id: str, note: str = "",
               visibility: str = "friends") -> dict:
    """分享一条帖子到自己的朋友圈（幂等：已有存活分享则更新转发语）。

    返回 {ok, share_id, post_id, created} 或 {ok: False, error}。
    """
    src = share_of_row(conn, post_id)
    if src is None:
        return {"ok": False, "error": "not_found"}
    if _row_get(src, "share_of"):
        # 不允许分享"分享帖"，否则引用会套娃；请直接分享原帖。
        return {"ok": False, "error": "share_of_share"}
    if not can_view(actor, src, conn=conn):
        return {"ok": False, "error": "forbidden"}

    # 可见性不放大原帖：friends 分享只能更严
    vis = str(visibility or "friends").lower()
    if vis not in ("friends", "public"):
        vis = "friends"
    src_vis = str(_row_get(src, "visibility") or "public").lower()
    if src_vis == "friends":
        vis = "friends"

    note = (note or "").strip()[:2000]
    row = my_share(conn, actor, post_id)
    if row is not None:
        conn.execute("update posts set body=?, updated_at=? where id=?",
                     (note, _now(), _row_get(row, "id")))
        conn.commit()
        return {"ok": True, "share_id": _row_get(row, "id"), "post_id": post_id,
                "created": False}

    sid = "p-" + hashlib.sha1(f"share|{actor}|{post_id}|{time.time()}".encode()).hexdigest()[:8]
    conn.execute(
        "insert into posts(id,channel_id,kind,visibility,author_id,type,title,body,"
        "links,tags,task_id,share_of,status,reuse_count,created_at,updated_at) "
        "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (sid, "#lobby", "moment", vis, actor, "share", None, note, None,
         MOMENT_TAGS, None, post_id, "published", 0, _now(), _now()))
    conn.commit()
    return {"ok": True, "share_id": sid, "post_id": post_id, "created": True}


def unshare_post(conn, actor: str, share_id: str) -> dict:
    """移除自己的分享（软删：status='archived'）。"""
    try:
        row = conn.execute("select * from posts where id=?", (share_id,)).fetchone()
    except sqlite3.Error:
        row = None
    if row is None:
        return {"ok": False, "error": "not_found"}
    if _row_get(row, "author_id") != actor:
        return {"ok": False, "error": "forbidden"}
    conn.execute("update posts set status='archived', updated_at=? where id=?",
                 (_now(), share_id))
    conn.commit()
    return {"ok": True, "share_id": share_id}
