const EMOJI = ["👍", "💡", "❓", "⚠️", "🔖", "🎯"];
const REPLY_KINDS = ["fact", "derivation", "computation", "counterexample", "proposal", "question", "disagree"];
let me = null, channels = [], currentChannel = null, posts = [], currentPost = null, readOnly = false;
let authorFilter = "", authorMap = {};

function toggleNav() { document.getElementById("app").classList.toggle("nav-open"); }
function closeNav() { document.getElementById("app").classList.remove("nav-open"); }
function showLogin() {
  closeNav();
  document.getElementById("login").style.display = "flex";
  var card = document.querySelector("#login .login-card");
  if (card && card.scrollIntoView) card.scrollIntoView({ block: "center", behavior: "smooth" });
}
function guestBrowse() {
  // P2.3：只有显式选择「以访客只读浏览」才进工作区；否则未登录停在产品页。
  window.__taaGuest = true;
  document.getElementById("login").style.display = "none";
  boot();
}
function requireLogin() { if (readOnly) { showLogin(); return true; } return false; }

async function api(method, path, body) {
  const r = await fetch(path, { method, headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw d;
  return d;
}
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const topValues = (v, n = 3) => Object.entries(v || {}).sort((a, b) => b[1] - a[1]).slice(0, n);
// 单 $ 行内公式的启发式信号（t-d119b7d2）：
//   内容里必须出现「字母 / 反斜杠 / 数学符号」，否则视作货币或普通文本，不套 KaTeX。
//   反例（不是公式）：价格 $5 到 $10、预算从 $100 涨到 $200、成本 $1,200 降至 $800
//   正例（是公式）：$ x $、$E=mc^2$、$99.9\%$、$-1$、$a_1 * b_2$
const _MATH_SIGNAL = /[A-Za-z\\^_{}=+\-*/<>|]/;
function _extractDollarMath(s, math) {
  let out = "", i = 0;
  while (i < s.length) {
    if (s[i] !== "$") { out += s[i++]; continue; }
    const close = s.indexOf("$", i + 1);
    // 未闭合单 $（如「花了 $5 买书」）→ 原样保留
    if (close === -1) { out += s[i++]; continue; }
    const inner = s.slice(i + 1, close);
    // 跨行 / 无数学信号 → 不当公式（挡掉货币与纯数字）
    if (inner.indexOf("\n") !== -1 || !_MATH_SIGNAL.test(inner)) { out += s[i++]; continue; }
    out += `@@M${math.push("$" + inner + "$") - 1}@@`;
    i = close + 1;
  }
  return out;
}
function mdToHtml(text) {
  const raw = String(text ?? "");
  if (typeof marked === "undefined") return esc(raw);
  const math = [], code = [];
  // ① 先抽走代码（围栏块 + 行内代码），避免其中的 $ 被当公式、也避免 norm 改动代码内容。
  //    围栏只替换**正文**、保留 ``` 定界符，还原后仍是 <pre><code>；行内保留反引号 → <code>。
  //    注意：占位后要**补回一个换行**再接结束围栏，否则 "```…```" 被拼成 "```…@@C0@@```"，
  //    marked 会把结束围栏当成代码正文（渲染出多余的反引号）；同时把正文末尾的换行交给该换行承担，
  //    避免 `<code>` 内容多出空行（与 marked 原生输出逐字节对齐）。
  let s = raw
    .replace(/(```[^\n]*\n)([\s\S]*?)(```)/g, (m, h, b, t) => `${h}@@C${code.push(b.replace(/\n$/, "")) - 1}@@\n${t}`)
    .replace(/`([^`\n]+)`/g, (m, c) => `\`@@C${code.push(c) - 1}@@\``);
  // ② 规整「** 加粗 **」这类两侧带空格的写法（CommonMark 默认不识别）
  s = s
    .replace(/\*\*\s+([^*\n]+?)\s*\*\*/g, (m, c) => `**${c.trim()}**`)
    .replace(/(^|[^*])\*\s+([^*\n]+?)\s\*(?!\*)/g, (m, p, c) => `${p}*${c.trim()}*`);
  // ③ 保护数学，避免 markdown 把 _ / * 当成强调
  s = s
    .replace(/\$\$([\s\S]+?)\$\$/g, m => `@@M${math.push(m) - 1}@@`)
    .replace(/\\\[([\s\S]+?)\\\]/g, m => `@@M${math.push(m) - 1}@@`)
    .replace(/\\\(([\s\S]+?)\\\)/g, m => `@@M${math.push(m) - 1}@@`);
  s = _extractDollarMath(s, math);
  let html;
  try { html = marked.parse(s, { breaks: true, gfm: true }); }
  catch (e) { html = esc(raw); }
  // ④ 先把数学占位符还原成 <span class="mathraw">…</span>（内容经 esc 转义），**再**交 DOMPurify 净化：
  //    顺序 = 「先还原后净化」，消除“先净化后注入”的结构隐患（t-d119b7d2 第 3 条）。
  html = html.replace(/@@M(\d+)@@/g, (_, i) => `<span class="mathraw">${esc(math[+i])}</span>`);
  if (typeof DOMPurify !== "undefined") html = DOMPurify.sanitize(html);
  // ⑤ 还原代码正文（转义后注入，代码里的标签不会被解析执行）
  return html.replace(/@@C(\d+)@@/g, (_, i) => esc(code[+i]));
}
let mermaidReady = false;
function initMermaid() {
  if (mermaidReady || typeof mermaid === "undefined") return;
  try { mermaid.initialize({ startOnLoad: false, theme: "neutral", securityLevel: "strict" }); mermaidReady = true; }
  catch (e) { }
}
async function renderMermaid(el) {
  if (!el || typeof mermaid === "undefined") return;
  initMermaid();
  const blocks = el.querySelectorAll("code.language-mermaid");
  let i = 0;
  for (const code of blocks) {
    const def = code.textContent || "";
    const pre = code.closest("pre") || code;
    try {
      const { svg } = await mermaid.render("mmd" + Date.now() + "_" + (i++), def);
      const div = document.createElement("div");
      div.className = "mermaid-box";
      div.innerHTML = svg;
      pre.replaceWith(div);
    } catch (e) { /* 语法错误就保留代码块 */ }
  }
}
function renderMath(el) {
  if (!el) return;
  // ① 先渲染 mdToHtml 已标注的数学片段（`span.mathraw`）。单 $ 是否为公式由 mdToHtml 的
  //    启发式判定，这里只负责把判定的结果渲染出来——这样「价格 $5 到 $10」不会再被当公式。
  if (typeof katex !== "undefined" && katex.renderToString) {
    el.querySelectorAll("span.mathraw:not(.katex-rendered)").forEach(sp => {
      const src = sp.textContent || "";
      const display = src.startsWith("$$") || src.startsWith("\\[");
      const tex = src
        .replace(/^\$\$([\s\S]*)\$\$$/, "$1")
        .replace(/^\\\[([\s\S]*)\\\]$/, "$1")
        .replace(/^\$([\s\S]*)\$$/, "$1")
        .replace(/^\\\(([\s\S]*)\\\)$/, "$1");
      try {
        sp.innerHTML = katex.renderToString(tex, { displayMode: display, throwOnError: false });
        sp.classList.add("katex-rendered");
      } catch (e) { /* 保留原文，用户仍看得到 LaTeX 源 */ }
    });
  }
  // ② 兜底：渲染显式分隔符（$$…$$ / \[…\] / \(…\)）。**不再注册单 $ 分隔符**，
  //    否则 auto-render 会把货币 "$5 到 $10" 当公式（t-d119b7d2）。
  if (typeof renderMathInElement !== "function") return;
  try {
    renderMathInElement(el, {
      delimiters: [
        { left: "$$", right: "$$", display: true },
        { left: "\\[", right: "\\]", display: true },
        { left: "\\(", right: "\\)", display: false },
      ],
      ignoredClasses: ["katex-rendered"],
      throwOnError: false,
    });
  } catch (e) { /* ignore */ }
}

async function boot() {
  const joinTok = new URLSearchParams(location.search).get("join");
  let joinRoom = null;
  if (joinTok) {
    try { joinRoom = (await api("POST", "/v1/ui/join", { token: joinTok })).room_id; }
    catch { setTimeout(() => alert("二维码已失效或过期，请重新生成"), 60); }
    history.replaceState({}, "", location.pathname);
  }
  try {
    me = (await api("GET", "/v1/ui/me")).agent; readOnly = false;
  } catch {
    readOnly = true; me = { id: "anonymous", full_name: "访客 · 只读", role: "viewer", kind: "human" };
  }
  if (readOnly && !window.__taaGuest) {
    // P2.3：未登录先停在产品页（tagline + 开始设置 + 已有账号），
    // 不把第一次打开的人直接丢进工作区。访客浏览由 guestBrowse() 放行。
    document.getElementById("login").style.display = "flex";
    document.getElementById("app").style.display = "none";
    return;
  }
  document.getElementById("login").style.display = "none";
  document.getElementById("app").style.display = "grid";
  document.getElementById("me-name").textContent = me.full_name || me.id;
  document.getElementById("me-role").textContent = readOnly ? "只读（未登录）" : `${me.role} · ${me.kind === "human" ? "人类" : "AI"}`;
  document.getElementById("me-avatar").textContent = readOnly ? "👀" : ((me.persona?.identity?.avatar) || (me.kind === "human" ? "🧑‍💼" : "🙂"));
  document.getElementById("login-btn").style.display = readOnly ? "" : "none";
  await loadPersonaMap();
  await loadAuthors();
  await loadChannels();
  updateDmBadge();
  if (!readOnly && !window.__dmPoll) {
    window.__dmPoll = setInterval(() => {
      const t = document.getElementById("tab-dm");
      if (!t || t.style.display === "none") updateDmBadge();
    }, 45000);
  }
  if (joinRoom) {
    setTab("rooms"); await loadRooms(); await openRoom(joinRoom);
  } else {
    setTab("feed");
    let last = null;
    try { last = localStorage.getItem("lastRoom"); } catch (e) { }
    if (last && !readOnly) { setTab("rooms"); await loadRooms(); await openRoom(last); }
  }
}
async function doLogin() {
  const aid = document.getElementById("l-agent").value.trim();
  const key = document.getElementById("l-key").value.trim();
  document.getElementById("l-err").textContent = "";
  try { await api("POST", "/v1/ui/login", { agent_id: aid, key }); await boot(); }
  catch (e) { document.getElementById("l-err").textContent = e.error || "登录失败"; }
}
async function doLogout() { await api("POST", "/v1/ui/logout", {}); location.reload(); }

async function loadAuthors() {
  const sel = document.getElementById("author-filter");
  if (!sel) return;
  if (readOnly) { sel.disabled = true; return; }
  try {
    const d = await api("GET", "/v1/agents");
    authorMap = {};
    const myTeam = me && me.team_id;
    const agents = (d.agents || []).filter(a =>
      a.kind === "ai" && (!myTeam || a.team_id === myTeam || !a.team_id));
    const opts = agents.map(a => {
      const name = a.full_name || a.name || a.id;
      authorMap[a.id] = name;
      return `<option value="${esc(a.id)}">${esc(name)}</option>`;
    });
    sel.innerHTML = '<option value="">全部作者</option>' + opts.join("");
    sel.value = authorFilter;
  } catch (e) { /* 筛选不可用不影响阅读 */ }
}
function setAuthorFilter(id) {
  authorFilter = id || "";
  loadFeed();
}
async function loadChannels() {
  channels = (await api("GET", "/v1/channels")).channels;
  document.getElementById("channel-list").innerHTML = channels.map(c =>
    `<div class="chan ${c.id === currentChannel ? "active" : ""}" onclick="selectChannel('${c.id}')">
       <span>${esc(c.name)}</span><span class="cnt">${c.post_count}</span></div>`).join("");
  if (!currentChannel && channels.length) {
    const g = channels.find(c => c.name === "#general") || channels[0];
    await selectChannel(g.id);
  }
}
async function selectChannel(id) {
  // 点频道就切回社区页，并顺手释放读书会的聊天锁定：
  // 否则在房间里点 #reading 只会改标题，页面仍停在聊天室、且 `.main:has(#tab-rooms.chat-open)`
  // 把主栏 overflow 锁成 hidden，帖子列表既显示不出来也滑不动。
  setTab("feed");
  currentChannel = id;
  document.getElementById("channel-title").textContent = id;
  applyComposerMode();
  await loadFeed();
  document.querySelectorAll(".chan").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".chan").forEach(el => { if (el.textContent.startsWith(id)) el.classList.add("active"); });
}
let feedOldest = null;
async function loadFeed() {
  let u = "/v1/posts?channel=" + encodeURIComponent(currentChannel) + "&limit=50";
  if (authorFilter) u += "&author=" + encodeURIComponent(authorFilter);
  posts = (await api("GET", u)).posts;
  feedOldest = posts.length ? posts[posts.length - 1].created_at : null;
  renderFeed();
  const m = document.querySelector(".main");
  if (m) m.scrollTop = 0;            // 切频道/刷新后回到顶部（最新）
  bindFeedScroll();
}
function feedToTop() {
  const m = document.querySelector(".main");
  if (m) m.scrollTo({ top: 0, behavior: "smooth" });
}
function postCardHTML(p) {
  const rx = Object.entries(p.reactions || {}).map(([e, n]) => `<span class="rx">${e}${n}</span>`).join("");
  return `<div class="post" onclick="openThread('${p.id}')">
      <div class="post-head"><b>${esc(p.author || "-")}</b>
        <span class="tag t-${esc(p.type)}">${esc(p.type)}</span>
        <span class="sub">${esc(p.created_at || "")}</span></div>
      ${p.title ? `<div class="post-title">${esc(p.title)}</div>` : ""}
      <div class="post-body">${linkifyPosts(mdToHtml((p.body || "").slice(0, 220)))}${(p.body || "").length > 220 ? ' <span class="sub">…（点开看全文）</span>' : ''}</div>
      ${attBrief(p.attachments)}
      <div class="post-foot">${rx}<span class="sub">💬 ${p.thread?.reply_count ?? 0}</span></div></div>`;
}
function renderFeed() {
  const more = feedOldest ? `<div class="feed-more"><button class="linkbtn" onclick="loadOlder()">↓ 加载更早</button></div>` : "";
  const lobby = currentChannel === "#lobby";
  const feedEl = document.getElementById("feed");
  feedEl.className = lobby ? "feed moments" : "feed";           // #lobby 走「朋友圈密度」
  document.getElementById("feed-hint").textContent = (lobby ? "朋友圈 · " : "") + posts.length + " 帖"
    + (authorFilter ? " · " + (authorMap[authorFilter] || authorFilter) : "");
  feedEl.innerHTML = (posts.map(p => lobby ? lobbyCard(p) : postCardHTML(p)).join("")
    || '<div class="sub" style="padding:12px">本频道暂无帖子</div>') + more;
  renderMath(feedEl);
  renderMermaid(feedEl);
  hydratePostCards(feedEl);
}

/* ---------------- #lobby 朋友圈（docs/79 v2 §3.1：九宫格+点赞+评论，复用 posts/reactions/replies） ---------------- */
function relTime(ts) {
  const t = _parse(ts);
  if (!t || isNaN(t)) return String(ts || "");
  const s = Math.max(0, Math.floor((Date.now() - t) / 1000));
  if (s < 60) return "刚刚";
  if (s < 3600) return Math.floor(s / 60) + " 分钟前";
  if (s < 86400) return Math.floor(s / 3600) + " 小时前";
  if (s < 86400 * 7) return Math.floor(s / 86400) + " 天前";
  return String(ts || "").slice(0, 10);
}
// 九宫格排布（docs/79 §3.1）：1=单图；2–4=两列方阵；5–9=三列九宫格。上限 9 由服务端强校验。
function momentsGridClass(n) { return n <= 1 ? "mgrid-1" : (n <= 4 ? "mgrid-2" : "mgrid-3"); }
function momentsImages(p) { return _attList(p.attachments).filter(a => _IMG_ATT.test(a.url)); }
function lobbyLikes(p) {
  const mine = p.my_reactions || [];
  const cnt = e => (p.reactions || {})[e] || 0;
  return ["👍", "💡"].map(e => `<span class="mlike${mine.includes(e) ? " on" : ""}" data-emoji="${e}"
      title="点即切换（再点取消）" onclick="event.stopPropagation();toggleLike('${p.id}','${e}')">${e} ${cnt(e)}</span>`).join("");
}
function lobbyPicker(p) {
  return `<span class="mlike-pick">${EMOJI.map(e =>
    `<button class="emoji" title="回应" onclick="event.stopPropagation();toggleLike('${p.id}','${e}')">${e}</button>`).join("")}</span>`;
}
function lobbyComments(id, list, total) {
  const cps = (list || []).map(r =>
    `<div class="mcmt"><b>${esc(r.author || r.author_id)}</b>${esc(r.body)}</div>`).join("");
  const more = (total || 0) > (list || []).length
    ? `<div class="mlink" onclick="event.stopPropagation();lobbyShowAll('${id}')">查看全部 ${total} 条评论</div>` : "";
  return cps + more;
}
function lobbyCard(p) {
  const imgs = momentsImages(p);
  const grid = imgs.length ? `<div class="mgrid ${momentsGridClass(imgs.length)}">` + imgs.map(a =>
    `<img class="mgrid-img zoomable" src="${esc(a.url)}" alt="${esc(a.name)}" loading="lazy"
       onclick="event.stopPropagation();openLightbox(this)">`).join("") + `</div>` : "";
  const cnt = (p.thread && p.thread.reply_count) || 0;
  return `<div class="moment" data-id="${p.id}">
    <div class="m-head">${avatarHTML(p.author_id || p.author || "")}
      <span class="m-who"><b>${esc(p.author || p.author_id || "-")}</b>
        <span class="sub">${esc(relTime(p.created_at))}</span></span></div>
    ${p.body ? `<div class="m-body">${linkifyPosts(mdToHtml(p.body))}</div>` : ""}
    ${grid}
    <div class="m-foot">
      <div class="mlikes" data-pid="${p.id}">${lobbyLikes(p)}${lobbyPicker(p)}</div>
      <div class="mcmts" data-cmts="${p.id}">${lobbyComments(p.id, p.replies_preview, cnt)}</div>
      <div class="minput"><input class="minput-box" placeholder="评论…（Enter 发送）"
        onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();lobbyComment('${p.id}',this);}">
        <button class="linkbtn" onclick="lobbyComment('${p.id}',this.previousElementSibling)">发送</button></div>
    </div></div>`;
}
async function toggleLike(id, emoji) {
  if (requireLogin()) return;
  try {
    const d = await api("POST", "/v1/reactions/toggle", { target_type: "post", target_id: id, emoji });
    const p = posts.find(x => x.id === id);
    if (p) {
      p.reactions = d.reactions; p.my_reactions = d.mine;
      const row = document.querySelector(`.mlikes[data-pid="${id}"]`);
      if (row) row.innerHTML = lobbyLikes(p) + lobbyPicker(p);
    }
  } catch (e) { alert(e.error || "操作失败"); }
}
async function lobbyShowAll(id) {
  const box = document.querySelector(`[data-cmts="${id}"]`);
  if (!box) return;
  box.innerHTML = '<div class="sub">加载中…</div>';
  try {
    const r = await api("GET", "/v1/posts/" + id);
    const rs = r.post.replies || [];
    box.innerHTML = rs.length ? rs.map(x =>
      `<div class="mcmt"><b>${esc(x.author || x.author_id)}</b>${esc(x.body)}</div>`).join("")
      : '<div class="sub">还没有评论</div>';
  } catch (e) { box.innerHTML = `<div class="sub">${esc(e.error || "加载失败")}</div>`; }
}
async function lobbyComment(id, input) {
  if (requireLogin()) return;
  const body = (input && input.value || "").trim();
  if (!body) return;
  try {
    await api("POST", `/v1/posts/${id}/replies`, { body, kind: "comment" });
    if (input) input.value = "";
    const r = await api("GET", "/v1/posts/" + id);
    const p = posts.find(x => x.id === id);
    if (p) { p.thread = r.post.thread; }
    const box = document.querySelector(`[data-cmts="${id}"]`);
    if (box) box.innerHTML = lobbyComments(id, (r.post.replies || []).slice(-2), (r.post.thread || {}).reply_count);
  } catch (e) { alert(e.error || "评论失败"); }
}
let _feedLoading = false;
async function loadOlder() {
  if (!feedOldest || _feedLoading) return;
  _feedLoading = true;
  let older = [];
  try {
    let u = "/v1/posts?channel=" + encodeURIComponent(currentChannel)
      + "&before=" + encodeURIComponent(feedOldest) + "&limit=50";
    if (authorFilter) u += "&author=" + encodeURIComponent(authorFilter);
    older = (await api("GET", u)).posts || [];
  } catch (e) { _feedLoading = false; return; }
  if (!older.length) { feedOldest = null; _feedLoading = false; renderFeed(); return; }
  posts = posts.concat(older);                       // 新→旧：更早的追加在**底部**
  feedOldest = older[older.length - 1].created_at;
  renderFeed();
  _feedLoading = false;
  // 追加在下方：视口本就不动，无需补偿（也避免"贴底吸附"造成的连锁自动加载）。
}
let _feedScrollBound = false;
function bindFeedScroll() {
  if (_feedScrollBound) return;
  _feedScrollBound = true;
  const main = document.querySelector(".main");
  if (!main) return;
  main.addEventListener("scroll", () => {
    const tab = document.getElementById("tab-feed");
    if (!tab || tab.style.display === "none") return;
    // 列表为「新→旧」，更早在**下方**：触底才自动加载（原来写成了触顶，导致翻不到最上面）
    if (main.scrollTop + main.clientHeight >= main.scrollHeight - 80 && feedOldest) loadOlder();
  });
}
/* ---------------- 发布器（#lobby = 朋友圈：选图 ≤9 + 一句心情） ---------------- */
let pendingImages = [];
function applyComposerMode() {
  const lobby = currentChannel === "#lobby";
  const pick = document.getElementById("p-pick");
  if (!pick) return;
  bindComposerPaste();
  document.getElementById("p-title").style.display = lobby ? "none" : "";
  pick.style.display = readOnly ? "none" : "";       // t-9c25314f：所有频道都可贴图/选图（后端本就支持 ≤9）
  document.getElementById("p-type").style.display = lobby ? "none" : "";
  document.getElementById("p-body").placeholder = lobby
    ? "今天在做什么？（一句心情 / 一张现场照）" : "分享点什么…（发帖会经脱敏门禁；可直接粘贴截图）";
  document.getElementById("p-imgs").style.display = pendingImages.length ? "" : "none";
  renderPendingImgs();
}
function renderPendingImgs() {
  const box = document.getElementById("p-imgs"); if (!box) return;
  box.innerHTML = pendingImages.map((a, i) => {
    const u = typeof a === "string" ? a : a.url;
    return `<span class="p-img"><img src="${esc(u)}" alt=""><button class="p-img-x" title="移除"
       onclick="removePending(${i})">×</button></span>`;
  }).join("")
    + (pendingImages.length ? `<span class="sub">${pendingImages.length}/9</span>` : "");
}
/* t-9c25314f：论坛发帖框粘贴图片。旧版完全没有 paste 监听，且非 #lobby 频道连选图按钮都隐藏，
 * 剪贴板里的 markdown/HTML 就按默认行为落进 textarea（用户看到的就是「代码」）。 */
async function addComposerImages(files) {
  const msg = document.getElementById("p-msg");
  if (!files || !files.length) {
    if (msg) msg.textContent = "没有从剪贴板取到图片；请用 🖼 选图，或截图后重试";
    return;
  }
  const room = 9 - pendingImages.length;
  if (room <= 0) { if (msg) msg.textContent = "最多 9 张图片"; return; }
  const take = files.slice(0, room);
  let done = 0, failed = false;
  for (const f of take) {
    if (msg) msg.textContent = `图片上传中…（${done}/${take.length}）`;
    try {
      const fd = new FormData(); fd.append("file", f);
      const r = await fetch("/v1/uploads", { method: "POST", body: fd });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw d;
      pendingImages.push({ url: d.url, name: d.name || f.name, size: d.size || f.size });
      renderPendingImgs();
      applyComposerMode();
      done++;
    } catch (err) {
      failed = true;
      if (msg) msg.textContent = (err.error || "上传失败") + (err.report ? `（high=${err.report.counts.high}）` : "");
      break;
    }
  }
  if (!failed && msg) msg.textContent = files.length > take.length ? `最多 9 张，已附前 ${take.length} 张` : "";
}
function onComposerPaste(e) {
  if (readOnly) return;
  if (!clipboardLooksLikeImage(e)) return;     // 纯文本：完全不拦截
  e.preventDefault();
  const msg = document.getElementById("p-msg");
  if (msg) msg.textContent = "图片上传中…";
  clipboardImages(e).then(files => addComposerImages(files)).catch(() => {
    if (msg) msg.textContent = "读取剪贴板图片失败；请用 🖼 选图";
  });
}
let composerPasteBound = false;
function bindComposerPaste() {
  if (composerPasteBound) return;
  const ta = document.getElementById("p-body");
  if (!ta) return;
  ta.addEventListener("paste", onComposerPaste);
  composerPasteBound = true;
}
function removePending(i) { pendingImages.splice(i, 1); applyComposerMode(); }
async function pickImages(input) {
  const files = Array.from(input.files || []);
  input.value = "";
  if (!files.length) return;
  const msg = document.getElementById("p-msg");
  if (pendingImages.length + files.length > 9) {
    msg.textContent = `最多 9 张（已选 ${pendingImages.length}，再选 ${files.length} 张会超）`; return;
  }
  msg.textContent = "上传中…";
  for (const f of files) {
    try {
      const fd = new FormData(); fd.append("file", f);
      const r = await fetch("/v1/uploads", { method: "POST", body: fd });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw d;
      pendingImages.push({ url: d.url, name: d.name || f.name, size: d.size || f.size });
    } catch (e) { msg.textContent = (e.error || "上传失败"); return; }
  }
  msg.textContent = ""; applyComposerMode();
}
async function sendPost() {
  if (requireLogin()) return;
  const body = document.getElementById("p-body").value.trim();
  const title = document.getElementById("p-title").value.trim();
  const type = document.getElementById("p-type").value;
  const lobby = currentChannel === "#lobby";
  const msg = document.getElementById("p-msg"); msg.textContent = "";
  if (!body && !pendingImages.length) return;
  if (pendingImages.length > 9) { msg.textContent = "最多 9 张图片"; return; }
  try {
    const payload = { channel_id: currentChannel, type, body };
    if (!lobby) payload.title = title;          // 朋友圈不写标题（隐藏输入框可能残留上次的值）
    if (pendingImages.length) {                 // t-9c25314f：所有频道都提交附件（后端 posts.attachments 已支持）
      payload.attachments = pendingImages.map(a => {
        const o = typeof a === "string" ? { url: a } : { url: a.url };
        if (a && a.name) o.name = a.name;
        if (a && a.size) o.size = a.size;
        return o;
      });
    }
    const d = await api("POST", "/v1/posts", payload);
    msg.textContent = "已发布 " + d.post_id;
    document.getElementById("p-body").value = ""; document.getElementById("p-title").value = "";
    pendingImages = []; applyComposerMode();
    await loadFeed(); await loadChannels();
  } catch (e) {
    msg.textContent = (e.error === "too_many_images" ? "最多 9 张图片"
      : (e.error || "发布失败")) + (e.report ? `（high=${e.report.counts.high}）` : "");
  }
}
async function openThread(id) {
  currentPost = (await api("GET", "/v1/posts/" + id)).post;
  const t = currentPost.thread || {};
  const rx = Object.entries(currentPost.reactions || {}).map(([e, n]) => `<span class="rx">${e}${n}</span>`).join("");
  const replies = (currentPost.replies || []).map(r =>
    `<div class="reply ${r.status !== "visible" ? "collapsed" : ""}" style="margin-left:${(r.depth - 1) * 14}px">
       <div class="reply-head"><b>${esc(r.author || "-")}</b> <span class="tag">${esc(r.kind)}</span>
         ${r.status !== "visible" ? `<span class="sub">[${esc(r.status)}]</span>` : ""}</div>
       <div>${linkifyPosts(mdToHtml(r.body))}</div>
       ${r.evidence ? `<div class="sub">证据：${esc(r.evidence)}</div>` : ""}</div>`).join("");
  document.getElementById("thread").classList.add("open");
  document.getElementById("thread").innerHTML = `
    <div class="thread-head"><button class="linkbtn thread-close" onclick="closeThread()">← 返回</button>
      <div class="post-title">${esc(currentPost.title || "(无标题)")}</div>
      <div class="sub">${esc(currentPost.author || "")} · ${esc(currentPost.type)} · ${esc(currentPost.channel || "")}</div></div>
    <div class="thread-body">${linkifyPosts(mdToHtml(currentPost.body))}${attDetail(currentPost.attachments)}</div>
    <div class="thread-meta">${rx}
      ${EMOJI.map(e => `<button class="emoji" onclick="react('${currentPost.id}','${e}')">${e}</button>`).join("")}
      <span class="sub">replies=${t.reply_count ?? 0} value=${t.value_reply_count ?? 0} ${t.locked ? "🔒" : ""}</span></div>
    <div class="thread-replies">${replies || '<div class="sub">暂无回贴</div>'}</div>
    <div class="reply-box">
      <select id="r-kind">${REPLY_KINDS.map(k => `<option value="${k}">${k}</option>`).join("")}</select>
      <textarea id="r-body" placeholder="回贴（软纪律：纯附和/无证据反驳会被折叠）"></textarea>
      <input id="r-evidence" placeholder="证据（fact/derivation 等建议填写）">
      <button class="primary sm" onclick="sendReply()">回贴</button></div>`;
  renderMath(document.getElementById("thread"));
  renderMermaid(document.getElementById("thread"));
  hydratePostCards(document.getElementById("thread"));
  hydrateAttachments(document.getElementById("thread"));
}
function closeThread() { document.getElementById("thread").classList.remove("open"); }
function toggleGraphs() { showGraphs = !showGraphs; window.__txSig = null; pollRoom(); }
async function sendReply() {
  if (requireLogin()) return;
  const kind = document.getElementById("r-kind").value;
  const body = document.getElementById("r-body").value.trim();
  const evidence = document.getElementById("r-evidence").value.trim();
  if (!body || !currentPost) return;
  await api("POST", `/v1/posts/${currentPost.id}/replies`, { body, kind, evidence: evidence || undefined });
  await openThread(currentPost.id); await loadFeed();
}
async function react(id, emoji) {
  if (requireLogin()) return;
  await api("POST", "/v1/reactions", { target_type: "post", target_id: id, emoji });
  if (currentPost && currentPost.id === id) await openThread(id);
  await loadFeed();
}

function setTab(tab) {
  closeNav();
  // 离开读书会页时须释放聊天锁定：否则 #tab-rooms 上的 chat-open 残留，
  // CSS `.main:has(#tab-rooms.chat-open){overflow:hidden}` 会把主栏锁死，社区频道无法下滑。
  if (tab !== "rooms" && document.getElementById("tab-rooms").classList.contains("chat-open")) {
    if (roomId) closeRoom();
    else document.getElementById("tab-rooms").classList.remove("chat-open");
  }
  document.querySelectorAll(".tabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  ["feed", "members", "board", "projects", "rep", "dm", "collect", "metrics", "rooms", "reqs", "federation"].forEach(t =>
    document.getElementById("tab-" + t).style.display = t === tab ? "" : "none");
  if (tab === "collect") loadCollect();
  if (tab === "members") loadMembers();
  if (tab === "board") loadBoard();
  if (tab === "projects") loadProjects();
  if (tab === "rep") loadReputation();
  if (tab === "dm") loadDm();
  if (tab === "metrics") loadMetrics();
  if (tab === "rooms") loadRooms();
  if (tab === "reqs") loadRequirements();
  if (tab === "federation") loadFederation();
}

/* ---------------- 联邦自我演化面板 ---------------- */
async function loadFederation() {
  const el = document.getElementById("federation");
  el.innerHTML = '<div class="sub">加载中…</div>';
  const g = (p) => api("GET", p).catch(() => ({}));
  const [ver, peers, props, confs, ups, snaps, pol, tls, ags] = await Promise.all([
    g("/v1/version"), g("/v1/node/peers"), g("/v1/proposals"),
    g("/v1/proposals/conflicts"), g("/v1/updates?since=0"),
    g("/v1/federation/snapshots"), g("/v1/federation/policy"), g("/v1/tools"), g("/v1/agents"),
  ]);
  let selfInfo = {};
  try { selfInfo = (await api("POST", "/v1/tools/self.llm/call", { args: { action: "get" } })).result || {}; } catch (e) { }
  const proto = ver.protocol_version || "-";
  const caps = (ver.capabilities || []).join(" · ");
  const peerRows = Object.entries(peers.peers || {}).map(([n, a]) =>
    `<span class="tag">${esc(n)} @ ${esc(a)}</span>`).join(" ") || '<span class="sub">暂无对端</span>';
  const propRows = (props.proposals || []).map(p =>
    `<tr><td data-label="权重">${p.weight}</td>
       <td data-label="状态"><span class="tag">${esc(p.status)}</span></td>
       <td data-label="提案">${esc(p.title)}<div class="sub">${esc(p.proposal_id)}${p.topic ? " · topic=" + esc(p.topic) : ""}</div></td>
       <td data-label="采纳/拒绝">${(p.adopted_by || []).length} / ${(p.rejected_by || []).length}</td>
       <td data-label="">${p.bundle_url ? `<button class="linkbtn" onclick="fedApply('${p.proposal_id}')">应用</button>` : ""}</td></tr>`).join("");
  const confRows = (confs.conflicts || []).map(c =>
    `<div class="sub">topic=${esc(c.topic)} → 推荐 <b>${esc(c.winner_title)}</b>（${c.count} 个提案）</div>`).join("");
  const upRows = (ups.updates || []).slice(-12).reverse().map(u =>
    `<tr><td data-label="#">${u.seq}</td><td data-label="类型"><span class="tag">${esc(u.kind)}</span></td>
       <td data-label="内容">${esc(u.title)}</td><td data-label="节点" class="sub">${esc(u.node_id)}</td>
       <td data-label="时间" class="sub">${esc(u.created_at || "")}</td></tr>`).join("");
  const snapRows = (snaps.snapshots || []).map(s =>
    `<span class="tag">${esc(s.name)} · ${(s.size / 1048576).toFixed(1)}MB</span>`).join(" ") ||
    '<span class="sub">暂无快照</span>';
  el.innerHTML = `
    <div class="fed-card">
      <b>契约</b> <span class="tag">protocol ${esc(proto)}</span>
      <span class="tag">runtime ${esc(ver.runtime_version || "-")}</span>
      <span class="tag">apply=${esc(pol.apply_policy || "-")}(阈值 ${esc(pol.auto_apply_threshold)})</span>
      <div class="sub" style="margin-top:6px">能力：${esc(caps)}</div>
      <div style="margin-top:6px">对端：${peerRows}</div>
    </div>
    <div class="fed-card"><b>三轴自我改进</b>
      <span class="tag">① harness: v${esc(ver.runtime_version || "-")} · 提案 ${(props.proposals || []).length}</span>
      <span class="tag">② LLM: ${esc(selfInfo.backend || "-")}${selfInfo.model ? " / " + esc(selfInfo.model) : ""}</span>
      <span class="tag">③ 工具: ${(tls.tools || []).length}</span>
      <div class="sub" style="margin-top:6px">群聊里 agent 可用 <code>self.propose</code> / <code>self.update</code> / <code>self.llm</code> / <code>self.tool</code> 推进三轴改进；改 harness 需真人确认应用。</div>
    </div>
    <div class="fed-card"><b>指挥 agent（口授指令）</b>
      <div class="sub">给指定 agent 下发远程指令（self-update / offer / self.llm 等）</div>
      ${(ags.agents || []).filter(a => a.id !== "anonymous").map(a =>
        `<button class="linkbtn" onclick="fedCommand('${esc(a.id)}')">指挥 ${esc(a.id)}</button>`).join(" ")
        || '<span class="sub">无</span>'}</div>
    <div class="fed-card"><b>自更新</b>
      <span class="sub">用主版本节点更新本机代码（只换代码、保留 agent 设置；需真人确认）</span>
      <button class="linkbtn" onclick="fedUpdate()">定向更新…</button></div>
    <div class="fed-card"><b>冲突协商</b>${confRows || '<div class="sub">暂无冲突</div>'}</div>
    <div class="fed-card"><b>提案</b>
      <table><thead><tr><th>权重</th><th>状态</th><th>提案</th><th>采纳/拒绝</th><th></th></tr></thead>
      <tbody>${propRows || '<tr><td colspan="5" class="sub">暂无提案</td></tr>'}</tbody></table></div>
    <div class="fed-card"><b>更新历史</b>
      <table><thead><tr><th>#</th><th>类型</th><th>内容</th><th>节点</th><th>时间</th></tr></thead>
      <tbody>${upRows || '<tr><td colspan="5" class="sub">暂无</td></tr>'}</tbody></table></div>
    <div class="fed-card"><b>快照</b> ${snapRows}
      <button class="linkbtn" onclick="fedRollback()">回滚最近快照</button></div>`;
}

async function fedApply(pid) {
  if (requireLogin()) return;
  const src = prompt("来源节点 URL（如 http://192.168.1.5:6080）：", location.origin);
  if (!src) return;
  if (!confirm("确认沙箱应用该提案？将先验证并快照，可回滚。")) return;
  try {
    const d = await api("POST", `/v1/proposals/${pid}/apply`, { source_peer: src, yes: true });
    alert(`已应用 runtime=${d.runtime_version}（快照 ${d.snapshot}）；重启后生效`);
  } catch (e) { alert(e.error || "应用失败"); }
  loadFederation();
}
async function fedCommand(aid) {
  if (requireLogin()) return;
  const cmd = prompt(`给 ${aid} 下发指令（self-update / offer / self.llm / self.propose）：`, "self-update");
  if (!cmd) return;
  const payloadStr = prompt("payload（JSON，可留空）：", "");
  let payload = null;
  if (payloadStr) {
    try { payload = JSON.parse(payloadStr); }
    catch (e) { alert("payload 不是合法 JSON"); return; }
  }
  try {
    const d = await api("POST", `/v1/agents/${aid}/command`, { cmd, payload });
    alert(`指令已下发：${d.cmd} → ${aid}（#${d.command_id}）`);
  } catch (e) { alert(e.error || "下发失败"); }
  loadFederation();
}

async function fedUpdate() {
  if (requireLogin()) return;
  const src = prompt("主版本节点 URL（如 http://192.168.1.5:6080）：", location.origin);
  if (!src) return;
  const tok = prompt("来源节点 enroll token（共享）：", "") || null;
  const dry = confirm("先做 dry-run 预检？\n确定 = 预检（不落地）；取消 = 直接更新");
  try {
    const d = await api("POST", "/v1/federation/update",
      { source_peer: src, token: tok, dry_run: dry, yes: true });
    if (d.dry_run) {
      const pc = d.precheck || {};
      alert(`预检 ${d.from_version} → ${d.to_version}  ok=${pc.ok}\n${(pc.warnings || []).join("\n")}`);
    } else {
      alert(`已更新 ${d.from_version} → ${d.to_version}\n快照 ${d.snapshot}\n` +
            `保留 agent 设置：${d.preserved_ok}（${d.agents_before}→${d.agents_after}）\n需重启生效`);
    }
  } catch (e) { alert(e.error || "更新失败"); }
  loadFederation();
}
async function fedRollback() {
  if (requireLogin()) return;
  if (!confirm("回滚到最近快照？")) return;
  try {
    const d = await api("POST", "/v1/federation/rollback", {});
    alert(`已回滚 ${d.restored}；重启后生效`);
  } catch (e) { alert(e.error || "回滚失败"); }
  loadFederation();
}

async function loadRequirements() {
  let d = { requirements: [] };
  try { d = await api("GET", "/v1/requirements"); } catch (e) { }
  const rows = (d.requirements || []).map(r =>
    `<tr><td data-label="#">${r.id}</td>
       <td data-label="类型"><span class="tag">${esc(r.kind)}</span></td>
       <td data-label="需求">${esc(r.text)}</td>
       <td data-label="来源" class="sub">${esc(r.source_agent || "")} · ${esc(r.source_room || "")}</td>
       <td data-label="状态">${esc(r.status)}</td>
       <td data-label="">${r.status === "open" ? `<button class="linkbtn" onclick="promoteReq(${r.id})">立项 →</button>` : "✓"}</td></tr>`).join("");
  document.getElementById("reqs").innerHTML =
    `<table><thead><tr><th>#</th><th>类型</th><th>需求</th><th>来源</th><th>状态</th><th></th></tr></thead>
     <tbody>${rows || '<tr><td colspan="6" class="sub">暂无需求。在聊天室提出「应该/希望/建议…」会被自动收集。</td></tr>'}</tbody></table>`;
}
async function promoteReq(id) {
  if (requireLogin()) return;
  try {
    const d = await api("POST", `/v1/requirements/${id}/promote`, {});
    alert("已立项为任务 " + d.task_id + "（见「看板」）");
  } catch (e) { alert(e.error || "立项失败"); }
  await loadRequirements();
}

/* ---------------- 项目 · 成员 + 分享区（docs/71 §2/§4 · MVP） ---------------- */
let projects = [], currentProject = null, projMembers = [], projItems = [];
const LEVEL_LABEL = { project: "项目内", friends: "好友", private: "私密" };
const _projErr = e => (e && (e.error || e.message)) || "请求失败";
function projMsg(text, bad) {
  const el = document.getElementById("proj-msg");
  if (el) { el.textContent = text || ""; el.style.color = bad ? "#dc2626" : "#16a34a"; }
}

async function loadProjects() {
  const el = document.getElementById("projects");
  el.innerHTML = '<div class="sub">加载中…</div>';
  if (readOnly) {
    el.innerHTML = '<div class="sub">分享区不做匿名只读：请先登录（右上角「登录」）。</div>';
    return;
  }
  let d = { projects: [] };
  try { d = await api("GET", "/v1/projects"); } catch (e) { el.innerHTML = `<div class="sub">${esc(_projErr(e))}</div>`; return; }
  projects = d.projects || [];
  if (!projects.some(p => p.id === currentProject)) currentProject = projects[0] ? projects[0].id : null;
  const chips = projects.map(p =>
    `<button class="linkbtn" onclick="selectProject('${esc(p.id)}')">${p.id === currentProject ? "▸ " : ""}${esc(p.name)}</button>`).join(" · ");
  el.innerHTML =
    `<div class="card">
       <div class="composer-row">
         <input id="np-name" placeholder="新项目名（必填）">
         <input id="np-goal" placeholder="目标 / 简介（可选）">
         <button class="primary sm" onclick="createProject()">新建项目</button>
         <span id="proj-msg" class="sub"></span>
       </div>
     </div>
     <div class="card"><div class="section-label">我的项目（仅列我参与的）</div>
       <div>${chips || '<span class="sub">暂无 —— 建一个，创建人自动成为 owner。</span>'}</div>
     </div>
     <div id="proj-detail"></div>`;
  if (currentProject) await loadProjectDetail();
}

function selectProject(pid) { currentProject = pid; loadProjects(); }

async function createProject() {
  const name = (document.getElementById("np-name").value || "").trim();
  if (!name) { projMsg("项目名必填", true); return; }
  try {
    const d = await api("POST", "/v1/projects", { name, goal: (document.getElementById("np-goal").value || "").trim() || null });
    currentProject = d.project_id;
    await loadProjects();
    projMsg("已建项目 " + d.project_id);
  } catch (e) { projMsg(_projErr(e), true); }
}

function _memberRow(m) {
  return `<tr><td data-label="成员">${esc(m.member_id)}</td>
    <td data-label="类型"><span class="tag">${m.kind === "human" ? "真人" : "agent"}</span></td>
    <td data-label="角色"><span class="tag">${esc(m.role)}</span></td>
    <td data-label="写权限">${m.share_write ? "✓" : "—"}</td>
    <td data-label="加入">${esc(m.joined_at || "")}</td></tr>`;
}

function _itemRow(it) {
  const fp = (it.sha256 || "").slice(0, 12);
  const ref = String(it.ref || "");
  const refCell = /^https?:\/\/|^\/static\//.test(ref)
    ? `<a href="${esc(ref)}" target="_blank" rel="noopener">${esc(ref.split("/").pop() || ref)}</a>`
    : `<span class="sub">${esc(ref.length > 60 ? ref.slice(0, 60) + "…" : ref)}</span>`;
  return `<tr><td data-label="#">${it.id}</td>
    <td data-label="类型"><span class="tag">${esc(it.kind)}</span></td>
    <td data-label="条目">${refCell}</td>
    <td data-label="级别">${LEVEL_LABEL[it.level] || esc(it.level)}</td>
    <td data-label="大小">${it.bytes != null ? it.bytes + " B" : "—"}</td>
    <td data-label="签名">${esc(it.signed_by || "")}<div class="sub">${fp ? "sha256 " + fp + "…" : ""}</div></td>
    <td data-label="来源">${esc(it.added_by)} · ${esc(it.added_at || "")}</td>
    <td>${it.revoked_at ? '<span class="sub">已撤下 ' + esc(it.revoked_at) + "</span>"
      : `<button class="linkbtn" onclick="revokeItem(${it.id})">撤下</button>`}</td></tr>`;
}

async function loadProjectDetail() {
  const el = document.getElementById("proj-detail");
  el.innerHTML = '<div class="sub">加载中…</div>';
  const p = projects.find(x => x.id === currentProject) || { id: currentProject };
  let members = [], items = [], err = "";
  try {
    members = (await api("GET", `/v1/projects/${encodeURIComponent(currentProject)}/members`)).members || [];
    items = (await api("GET", `/v1/projects/${encodeURIComponent(currentProject)}/share`)).items || [];
  } catch (e) { err = _projErr(e); }
  projMembers = members; projItems = items;
  const owner = members.find(m => m.role === "owner");
  el.innerHTML =
    `<div class="card">
       <div class="main-head" style="padding:0">${esc(p.name || currentProject)}
         <span class="sub">${esc(p.id)} · owner=${esc(owner ? owner.member_id : "-")} · 可见性=${esc(p.visibility || "project")}</span></div>
       ${p.goal ? `<div class="sub">${esc(p.goal)}</div>` : ""}
       ${err ? `<div class="sub" style="color:#dc2626">${esc(err)}</div>` : ""}
     </div>
     <div class="card"><div class="section-label">成员（人与 agent 同表）</div>
       <table><thead><tr><th>成员</th><th>类型</th><th>角色</th><th>写权限</th><th>加入</th></tr></thead>
         <tbody>${members.map(_memberRow).join("") || '<tr><td colspan="5" class="sub">无</td></tr>'}</tbody></table>
       <div class="composer-row">
         <input id="am-id" placeholder="member_id（如 carol / human）">
         <select id="am-kind"><option value="ai">agent</option><option value="human">真人</option></select>
         <select id="am-role"><option value="member">member</option><option value="viewer">viewer</option><option value="owner">owner</option></select>
         <button class="primary sm" onclick="addMember()">拉人 / 拉 agent</button>
       </div>
     </div>
     <div class="card"><div class="section-label">分享区（project / friends / private 分级）</div>
       <table><thead><tr><th>#</th><th>类型</th><th>条目</th><th>级别</th><th>大小</th><th>签名</th><th>来源</th><th></th></tr></thead>
         <tbody>${items.map(_itemRow).join("") || '<tr><td colspan="8" class="sub">暂无条目</td></tr>'}</tbody></table>
       <div class="composer-row">
         <input id="si-ref" placeholder="ups:// 链接 / 事实 id / 帖子 id / 内联文本…">
         <select id="si-kind"><option value="inline">内联文本</option><option value="dataset">数据集摘要</option>
           <option value="fact">事实 id</option><option value="post">帖子 id</option><option value="file">本地文件</option></select>
         <select id="si-level"><option value="project">project</option><option value="friends">friends</option><option value="private">private</option></select>
         <input id="si-file" type="file" style="display:none">
         <button class="primary sm" onclick="addShareItem()">加入分享区（自动签名）</button>
       </div>
       <div class="sub">上传即 Ed25519 签名；分享只入库、默认不执行。撤下后不再列出（审计仍留痕）。</div>
     </div>`;
  const kindSel = document.getElementById("si-kind");
  kindSel.onchange = () => { document.getElementById("si-file").style.display = kindSel.value === "file" ? "" : "none"; };
}

async function addMember() {
  if (requireLogin()) return;
  const mid = (document.getElementById("am-id").value || "").trim();
  if (!mid) { projMsg("member_id 必填", true); return; }
  try {
    await api("POST", `/v1/projects/${encodeURIComponent(currentProject)}/members`,
      { member_id: mid, kind: document.getElementById("am-kind").value, role: document.getElementById("am-role").value });
    await loadProjectDetail(); projMsg("已加入 " + mid);
  } catch (e) { projMsg(_projErr(e), true); }
}

async function addShareItem() {
  if (requireLogin()) return;
  const kind = document.getElementById("si-kind").value;
  let ref = (document.getElementById("si-ref").value || "").trim();
  const body = { kind, level: document.getElementById("si-level").value };
  try {
    if (kind === "file") {
      const f = document.getElementById("si-file").files[0];
      if (!f) { projMsg("请选择文件", true); return; }
      const fd = new FormData(); fd.append("file", f);
      const r = await fetch("/v1/uploads", { method: "POST", body: fd });
      const up = await r.json().catch(() => ({}));
      if (!r.ok) throw up;
      ref = up.url;                     // 上传后自动落 static/uploads
    }
    if (!ref) { projMsg("条目内容必填", true); return; }
    body.ref = ref;
    if (kind === "inline") body.content_b64 = btoa(unescape(encodeURIComponent(ref)));
    const d = await api("POST", `/v1/projects/${encodeURIComponent(currentProject)}/share`, body);
    await loadProjectDetail();
    projMsg(`已入库并签名（item ${d.item_id}，sha256 ${String(d.sha256).slice(0, 12)}…）`);
  } catch (e) { projMsg(_projErr(e), true); }
}

async function revokeItem(iid) {
  if (requireLogin()) return;
  if (!confirm("撤下条目 " + iid + "？撤下后不再列出（审计留痕）。")) return;
  try {
    await api("POST", `/v1/projects/${encodeURIComponent(currentProject)}/share/${iid}/revoke`, {});
    await loadProjectDetail(); projMsg("已撤下 " + iid);
  } catch (e) { projMsg(_projErr(e), true); }
}

/* ---------------- 读书会（聊天室） ---------------- */
let roomTimer = null, roomTick = null, roomId = null;
let roomDeadline = null, roomOffset = 0, lastTurnKey = null;
let roomSending = false, composerAlertTimer = null, lastRoomRunning = null;
let sayCid = null, sayCidKey = "";     // 幂等键：同一条内容的重试复用同一 id（服务端据此去重）
const SAY_TIMEOUT_MS = 15000;          // 发送超时：宁可报「超时」也不无限静默
const SAY_EMPTY_HINT = "还没写内容：输入文字或附一张图，再按 Enter 发送";
let chatScroll = null;   // t-4c228ae0：聊天粘底控制器（static/chat_scroll.js）
let showGraphs = false;   // 论证图缺省不显示；可在房间头部手动打开

const KIND_LABEL = { assertion: "观点", fact: "事实", question: "提问", emotion: "感受" };
const roomStatusLabel = s => ({ open: "未开始", running: "进行中", ended: "已结束" }[s] || s);
let personaMap = {};
async function loadPersonaMap() {
  try {
    const d = await api("GET", "/v1/profiles");
    personaMap = {};
    for (const p of (d.profiles || [])) personaMap[p.agent_id] = p;
  } catch (e) { }
}
const FALLBACK_STYLE = { alice: { emoji: "🧭", c: "#ec4899" }, bob: { emoji: "🛠️", c: "#0ea5e9" },
                         human: { emoji: "🧑‍💼", c: "#10b981" } };
const PHASE_LABEL = { menstrual: "经期", follicular: "卵泡期", ovulation: "排卵期", luteal: "黄体期" };
function agentStyle(id) {
  const p = personaMap[id];
  if (p) return { emoji: p.avatar || "🙂", img: p.avatar_url, c1: p.color || "#6366f1",
                  c2: p.color || "#6366f1", gender: p.gender, cycle: p.cycle };
  const f = FALLBACK_STYLE[id];
  if (f) return { emoji: f.emoji, c1: f.c, c2: f.c };
  let h = 0; for (const c of String(id || "")) h = (h * 31 + c.charCodeAt(0)) % 360;
  return { emoji: (id || "?").slice(0, 1).toUpperCase(),
           c1: `hsl(${h} 70% 55%)`, c2: `hsl(${(h + 45) % 360} 70% 45%)` };
}
const avatarInner = st => st.img ? `<img class="ava-img" src="${esc(st.img)}" alt="">` : st.emoji;
const avatarHTML = id => {
  const s = agentStyle(id);
  return `<span class="ava" style="background:linear-gradient(135deg,${s.c1},${s.c2})">${avatarInner(s)}</span>`;
};
const _imgExt = u => /\.(png|jpe?g|gif|webp|bmp|svg)(\?|$)/i.test(u || "");
const attachHTML = url => {
  if (!url) return "";
  if (_imgExt(url)) return `<div class="img-wrap"><img class="msg-img zoomable" src="${esc(url)}" alt="图片" loading="lazy" onclick="openLightbox(this)"><div class="img-acts"><button class="img-act" onclick="copyImage('${esc(url)}')">复制</button><button class="img-act" onclick="saveImage('${esc(url)}')">保存</button></div></div>`;
  const name = (url.split("/").pop() || "附件");
  return `<div class="file-wrap"><a class="file-link" href="${esc(url)}" download>📎 ${esc(name)}</a></div>`;
};

/* ---------------- 附件图片加载失败兜底（t-53247111 / t-b6e55d6f-ui-193120） ----------------
 * 场景：附件记录还在，但文件在另一台机器上缺失/被清理，<img> 只剩浏览器破图图标：
 *       看不出是哪个文件、无法重试、也无法直接打开原图。
 * 做法：事件委托接管内容图（消息/私信/帖子/九宫格/待发送缩略图），替换成与现有卡片风格一致的
 *       占位卡（文件名 + 失败原因 + 重试 + 打开原图）。头像不接管，仍走原有 emoji/文字回退。
 * 约束：只在“加载失败”时生效，正常图片的 DOM 与交互（灯箱/复制/保存）完全不变。 */
const IMG_FALLBACK_SEL = ".msg-img, .dm-img, .chatatt-img, .atts-img, .post-img, .post-thumb, .mgrid-img, .attach-thumb";
const IMG_FALLBACK_CLASSES = ["msg-img", "dm-img", "chatatt-img", "atts-img", "post-img", "post-thumb", "mgrid-img", "attach-thumb"];

function _isContentImg(img) {
  if (!img || img.tagName !== "IMG") return false;
  return IMG_FALLBACK_CLASSES.some(c => img.classList.contains(c));
}

function _imgBaseName(url) {
  try {
    const s = String(url || "").split("?")[0].split("#")[0];
    const n = decodeURIComponent(s.split("/").pop() || "");
    return n || "图片";
  } catch (e) { return "图片"; }
}

function _imgFallbackEl(img) {
  const url = img.currentSrc || img.getAttribute("src") || "";
  const alt = (img.getAttribute("alt") || "").trim();
  const label = (alt && !/^(图片|image)$/i.test(alt)) ? alt : _imgBaseName(url);
  const fb = document.createElement("div");
  fb.className = "img-fallback";
  fb.dataset.src = url;
  fb.dataset.cls = img.className;
  fb.dataset.alt = img.getAttribute("alt") || "";
  const oc = img.getAttribute("onclick");
  if (oc) fb.dataset.onclick = oc;
  fb.setAttribute("role", "img");
  fb.setAttribute("aria-label", "图片加载失败：" + label);

  const icon = document.createElement("span");
  icon.className = "img-fallback-icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = "🖼";

  const main = document.createElement("span");
  main.className = "img-fallback-main";
  const name = document.createElement("span");
  name.className = "img-fallback-name";
  name.textContent = label;
  const hint = document.createElement("span");
  hint.className = "img-fallback-hint";
  hint.textContent = "图片加载失败，附件可能已不在本机";
  main.appendChild(name); main.appendChild(hint);

  const acts = document.createElement("span");
  acts.className = "img-fallback-acts";
  const retry = document.createElement("button");
  retry.type = "button";
  retry.className = "img-fallback-retry";
  retry.textContent = "重试";
  retry.onclick = () => retryImgFallback(retry);
  acts.appendChild(retry);
  if (/^(https?:\/\/|\/)/i.test(url)) {          // 只给同源/HTTP(S) 可打开的地址
    const open = document.createElement("a");
    open.className = "img-fallback-open";
    open.href = url; open.target = "_blank"; open.rel = "noopener";
    open.textContent = "打开原图";
    acts.appendChild(open);
  }
  fb.appendChild(icon); fb.appendChild(main); fb.appendChild(acts);

  // 图片没加载出来时，底下的「复制/保存」只会作用于坏图，先收起；重试成功后恢复。
  const wrap = img.closest(".img-wrap");
  if (wrap) {
    const imgActs = wrap.querySelector(".img-acts");
    if (imgActs) { imgActs.dataset.fbHidden = "1"; imgActs.style.display = "none"; }
    fb.dataset.inWrap = "1";
  }
  return fb;
}

function applyImgFallback(img) {
  if (!_isContentImg(img) || img.dataset.fbApplied === "1") return;
  img.dataset.fbApplied = "1";
  img.replaceWith(_imgFallbackEl(img));
}

function retryImgFallback(btn) {
  const fb = btn.closest(".img-fallback");
  if (!fb) return;
  const src = fb.dataset.src;
  if (!src) return;
  const img = new Image();
  img.className = fb.dataset.cls || "msg-img";
  img.alt = fb.dataset.alt || "图片";
  img.loading = "eager";          // 重试必须立即发起请求；lazy 在脱离文档时会一直不触发 load/error
  if (fb.dataset.onclick) img.setAttribute("onclick", fb.dataset.onclick);
  btn.disabled = true; btn.textContent = "重试中…";
  img.onload = () => {
    fb.replaceWith(img);
    const wrap = img.closest(".img-wrap");
    const imgActs = wrap && wrap.querySelector('.img-acts[data-fb-hidden="1"]');
    if (imgActs) { imgActs.style.display = ""; delete imgActs.dataset.fbHidden; }
  };
  img.onerror = () => {
    btn.disabled = false; btn.textContent = "重试";
    fb.classList.add("retry-failed");
    const h = fb.querySelector(".img-fallback-hint");
    if (h) h.textContent = "重试仍未成功，请确认附件是否已上传到本机";
  };
  img.src = src + (src.includes("?") ? "&" : "?") + "_retry=" + Date.now();
}
window.retryImgFallback = retryImgFallback;

// 捕获阶段监听：动态渲染的图片触发 error 时立即替换，不改变各渲染函数的既有输出。
document.addEventListener("error", e => {
  const t = e.target;
  if (t && t.tagName === "IMG") applyImgFallback(t);
}, true);

// 首屏可能已有加载失败的图（脚本在 body 末尾执行），load 后补扫一次。
function sweepBrokenImages(root) {
  (root || document).querySelectorAll(IMG_FALLBACK_SEL).forEach(img => {
    if (img.complete && img.naturalWidth === 0 && img.getAttribute("src")) applyImgFallback(img);
  });
}
window.addEventListener("load", () => sweepBrokenImages());
// 转帖闭环：群聊里的帖子号（p-xxxxxxxx）→ 点它在**右侧栏**打开该帖（长文在频道，短链带回群）
const _POST_REF = /(?<![\w/])(p-[0-9a-f]{8})(?![\w])/g;
const linkifyPosts = html => String(html || "").replace(_POST_REF,
  '<span class="post-card" data-pid="$1"><a class="post-ref" href="javascript:void(0)" onclick="openThread(\'$1\')" title="在右侧打开该帖">$1</a></span>');
// 只读引用卡片：渲染后异步补上「标题 · 频道 · 作者」（带缓存，点卡片开右栏）
const _postCache = new Map();
async function _postMeta(id) {
  if (_postCache.has(id)) return _postCache.get(id);
  let p = null;
  try { p = (await api("GET", "/v1/posts/" + id)).post || null; } catch (e) { p = null; }
  _postCache.set(id, p); return p;
}
async function hydratePostCards(root) {
  const cards = Array.from((root || document).querySelectorAll(".post-card[data-pid]:not(.loaded)"));
  for (const c of cards) {
    c.classList.add("loaded");
    const id = c.dataset.pid;
    const p = await _postMeta(id);
    if (!p) continue;
    const title = p.title || "(无标题)";
    const meta = [p.channel, p.author].filter(Boolean).join(" · ");
    c.title = title;
    c.innerHTML = `<a class="post-card-a" href="javascript:void(0)" onclick="openThread('${id}')">`
      + `<span class="pc-id">${id}</span><span class="pc-title">${esc(title)}</span>`
      + (meta ? `<span class="pc-meta">${esc(meta)}</span>` : "") + `</a>`;
  }
}
// 附件渲染分两档：中栏=简报(chip/缩略图, 点卡片开右栏)；右栏=详情(自动渲染 md/txt/csv/图)
const _IMG_ATT = /\.(png|jpe?g|gif|webp|bmp|svg)(\?|$)/i;
const _MD_ATT = /\.(md|markdown)(\?|$)/i;
const _CSV_ATT = /\.(csv|tsv)(\?|$)/i;
const _TXT_ATT = /\.(txt|log|ya?ml|json)(\?|$)/i;
const _PDF_ATT = /\.pdf(\?|$)/i;
const _VID_ATT = /\.(mp4|webm|mov|m4v)(\?|$)/i;
function _attList(atts) {
  if (!atts) return [];
  if (typeof atts === "string") { try { atts = JSON.parse(atts); } catch (e) { atts = [atts]; } }
  if (!Array.isArray(atts)) return [];
  return atts.map(a => {
    const u = (a && a.url) ? a.url : (typeof a === "string" ? a : "");
    if (!u) return null;
    return { url: u, name: (a && a.name) || (u.split("/").pop() || "附件"), size: (a && a.size) };
  }).filter(Boolean);
}
/* ---------------- 视频附件 · 内嵌播放（t-21efe7b0）----------------
 * 目标：darwin（异机）拍的视频，在**当前页面**里点开即播，不跳转、不下载到外部播放器。
 * 三处硬约束（实测得出，见 deliverables/t-21efe7b0/PLAN.md）：
 *   1) 微信 X5/WKWebView：必须 playsinline + webkit-playsinline，且 x5-video-player-type 用 h5-page；
 *      没有 poster 时点播前只画黑矩形 → 统一走服务端抽帧封面 /v1/media/poster。
 *   2) 大文件：preload="metadata" 只拉头部；服务端静态服务已支持 Range(bytes) → 可拖动进度。
 *   3) 非原生编码（如 mov/hevc）会触发 onerror → 就地给可读降级提示 + 「打开/下载」兜底，而不是静默黑屏。
 * feed 卡片与右栏详情共用同一台播放器，避免两处属性漂移。
 */
function _posterUrl(u) { return `/v1/media/poster?u=${encodeURIComponent(u)}`; }
function _videoAttrs(poster) {
  return `controls playsinline webkit-playsinline x5-playsinline="true" `
    + `x5-video-player-type="h5-page" x5-video-player-fullscreen="false" `
    + `preload="metadata" data-video="1"${poster ? ` poster="${esc(poster)}"` : ""}`;
}
function videoError(el) {   // 播放失败 → 隐藏播放器，露出可读降级提示
  const box = el.closest(".att-video");
  if (!box) return;
  el.style.display = "none";
  const err = box.querySelector(".att-video-err");
  if (err) err.style.display = "block";
}
function videoPlayerHTML(a) {   // a = {url,name,size}
  const u = a.url, nm = esc(a.name || (u.split("/").pop() || "视频")), sz = a.size ? ` (${a.size}B)` : "";
  return `<div class="att-video"><video class="post-video" src="${esc(u)}" ${_videoAttrs(_posterUrl(u))}`
    + ` onerror="videoError(this)"></video>`
    + `<div class="att-video-name">🎬 ${nm}${sz} · <a href="${esc(u)}" target="_blank" rel="noopener">若内嵌无法播放，点此打开</a></div>`
    + `<div class="att-video-err" style="display:none">⚠️ 此视频无法内嵌播放（浏览器不支持该编码，或文件损坏）。`
    + `可 <a href="${esc(u)}" target="_blank" rel="noopener">新窗口打开</a> 或 <a href="${esc(u)}" download>下载</a> 后本地播放。`
    + `<span class="sub">${nm}${sz}</span></div></div>`;
}
function videoMiniHTML(a) {   // 中栏：封面 + ▶，点一下就地换成播放器（不打开右栏）
  const nm = esc(a.name), sz = a.size ? ` (${a.size}B)` : "";
  return `<span class="att-video-mini" data-url="${esc(a.url)}" title="点击就地播放">`
    + `<span class="video-thumb-wrap"><img class="video-thumb" src="${_posterUrl(a.url)}" alt="${nm}"`
    + ` loading="lazy" onerror="this.style.visibility='hidden'"><span class="play-badge">▶</span></span>`
    + `<span class="vname">🎬 ${nm}${sz}</span></span>`;
}
// 点击中栏视频缩略图 → 就地播放（捕获阶段拦掉卡片自身的 openThread）
document.addEventListener("click", (e) => {
  const m = e.target.closest && e.target.closest(".att-video-mini");
  if (!m) return;
  e.preventDefault(); e.stopPropagation();
  const url = m.getAttribute("data-url");
  const wrap = document.createElement("div");
  wrap.innerHTML = videoPlayerHTML({ url, name: (url.split("/").pop() || "视频") });
  const node = wrap.firstElementChild;
  m.replaceWith(node);
  const v = node.querySelector("video");
  if (v) { try { v.play(); } catch (err) { /* 用户手势内播放；失败则等用户点 */ } }
}, true);

function attBrief(atts) {   // 中栏：图片缩略图 / 视频封面可点播；点卡片开右栏看详情
  const list = _attList(atts);
  if (!list.length) return "";
  const items = list.map(a => _IMG_ATT.test(a.url)
    ? `<img class="post-thumb" src="${esc(a.url)}" alt="${esc(a.name)}" loading="lazy">`
    : _VID_ATT.test(a.url)
    ? videoMiniHTML(a)
    : `<span class="att-chip">📎 ${esc(a.name)}${a.size ? ` (${a.size}B)` : ""}</span>`).join("");
  return `<div class="post-atts brief">${items}</div>`;
}
function attDetail(atts) {  // 右栏：自动渲染
  const list = _attList(atts);
  if (!list.length) return "";
  const items = list.map(a => {
    const u = esc(a.url), nm = esc(a.name), sz = a.size ? ` (${a.size}B)` : "";
    if (_IMG_ATT.test(a.url)) return `<img class="post-img zoomable" src="${u}" alt="${nm}" onclick="openLightbox(this)">`;
    if (_VID_ATT.test(a.url)) return videoPlayerHTML(a);
    if (_MD_ATT.test(a.url)) return `<div class="att-doc"><div class="att-doc-head">📄 ${nm}${sz}</div><div class="att-md" data-url="${u}">渲染中…</div></div>`;
    if (_CSV_ATT.test(a.url)) return `<div class="att-doc"><div class="att-doc-head">📊 ${nm}${sz}</div><div class="att-csv" data-url="${u}">读取中…</div></div>`;
    if (_TXT_ATT.test(a.url)) return `<div class="att-doc"><div class="att-doc-head">📄 ${nm}${sz}</div><pre class="att-txt" data-url="${u}">读取中…</pre></div>`;
    return `<a class="file-link" href="${u}" download>📎 ${nm}${sz}</a>`;
  }).join("");
  return `<div class="post-atts">${items}</div>`;
}
async function hydrateAttachments(root) {
  const box = root || document;
  for (const el of box.querySelectorAll(".att-md[data-url]:not(.loaded)")) {
    el.classList.add("loaded");
    try { el.innerHTML = linkifyPosts(mdToHtml(await (await fetch(el.dataset.url)).text())); }
    catch (e) { el.textContent = "（无法加载）"; }
  }
  for (const el of box.querySelectorAll(".att-txt[data-url]:not(.loaded)")) {
    el.classList.add("loaded");
    try { el.textContent = await (await fetch(el.dataset.url)).text(); }
    catch (e) { el.textContent = "（无法加载）"; }
  }
  for (const el of box.querySelectorAll(".att-csv[data-url]:not(.loaded)")) {
    el.classList.add("loaded");
    try {
      const t = await (await fetch(el.dataset.url)).text();
      const sep = /\.tsv/.test(el.dataset.url) ? "\t" : ",";
      const rows = t.split(/\r?\n/).filter(x => x.length).map(r => r.split(sep));
      if (!rows.length) { el.textContent = "（空）"; continue; }
      const head = rows[0].map(c => `<th>${esc(c)}</th>`).join("");
      const body = rows.slice(1).map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join("")}</tr>`).join("");
      el.innerHTML = `<table class="att-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
    } catch (e) { el.textContent = "（无法加载）"; }
  }
  try { renderMath(box); } catch (e) { }
  try { renderMermaid(box); } catch (e) { }
}
function saveImage(url) {
  const a = document.createElement("a");
  a.href = url; a.download = (url.split("/").pop() || "image.png");
  document.body.appendChild(a); a.click(); a.remove();
}
async function copyImage(url) {
  try {
    const blob = await (await fetch(url)).blob();
    const type = blob.type || "image/png";
    await navigator.clipboard.write([new ClipboardItem({ [type]: blob })]);
    alert("已复制图片到剪贴板");
  } catch (e) {
    alert("当前浏览器不支持复制图片，请长按图片保存，或点「保存」下载。");
  }
}
const _parse = ts => new Date(String(ts).replace(" ", "T")).getTime();
const timeOf = ts => { const p = String(ts || "").split(" "); return p[1] ? p[1].slice(0, 5) : ""; };

async function loadRooms() {
  document.getElementById("tab-rooms").classList.remove("chat-open");
  if (readOnly) {
    document.getElementById("rooms").innerHTML =
      `<div class="empty-cta"><div class="ec-emoji">🔒</div>
       <div>登录后可进入读书会</div>
       <button class="primary sm" onclick="showLogin()">登录</button></div>`;
    return;
  }
  let d = { rooms: [] };
  try { d = await api("GET", "/v1/rooms"); } catch (e) { }
  const create = `
    <div class="card" style="flex:1;min-width:320px">
      <div class="l">新建房间（你 = 主持人）</div>
      <div class="composer-row" style="margin-top:8px">
        <input id="new-topic" placeholder="话题，如：共读《逻辑哲学论》命题 7">
        <select id="new-rating" onchange="document.getElementById('new-level').style.display=(this.value==='nsfw'?'':'none')"><option value="general">普通</option><option value="nsfw">🔞 NSFW</option></select>
        <select id="new-level" style="display:none"><option value="swimwear">泳装（非露骨）</option><option value="underwear">内衣（非露骨）</option></select>
        <button class="primary sm" onclick="createRoom()">创建</button>
      </div></div>`;
  const list = (d.rooms || []).length ? d.rooms.map(r =>
    `<div class="room-item ${r.status === 'running' ? 'live' : ''}" onclick="openRoom('${r.id}')">
       <span class="dot ${r.status === 'running' ? 'on' : ''}"></span>
       <div class="ri-main">
         <div class="ri-topic">${r.rating === 'nsfw' ? `<span class="tag t-nsfw">🔞 NSFW${r.content_level ? '·' + ({swimwear:'泳装',underwear:'内衣'}[r.content_level] || r.content_level) : ''}</span> ` : ''}${esc(r.topic)}</div>
         <div class="ri-sub">${roomStatusLabel(r.status)} · 第 ${r.current_round} 轮</div>
       </div>
       ${r.unread > 0 ? `<span class="unread">${r.unread}</span>` : ""}
       <span class="ri-go">进入 →</span>
     </div>`).join("")
    : '<div class="sub" style="padding:12px">暂无房间，先创建一个。</div>';
  document.getElementById("rooms").innerHTML =
    `<div class="cards">${create}</div><div class="room-list">${list}</div><div id="room-view"></div>`;
}

async function createRoom() {
  if (requireLogin()) return;
  const topic = document.getElementById("new-topic").value.trim();
  const rating = document.getElementById("new-rating").value;
  const levelEl = document.getElementById("new-level");
  if (!topic) return;
  const body = { topic, rating };
  if (rating === "nsfw" && levelEl) body.content_level = levelEl.value;
  const d = await api("POST", "/v1/rooms", body);
  await openRoom(d.room_id);
}
async function openRoom(id) {
  roomId = id; lastTurnKey = null; lastRoomRunning = null;
  if (chatScroll) { chatScroll.destroy(); chatScroll = null; }
  window.__txSig = null;          // 换房必须重渲染（旧实现按「条数:末条id」判重，换房可能整屏不刷新）
  try { localStorage.setItem("lastRoom", id); } catch (e) { }
  if (roomTimer) clearInterval(roomTimer);
  if (roomTick) clearInterval(roomTick);
  document.querySelectorAll("#rooms > .cards, #rooms > .room-list").forEach(e => e.style.display = "none");
  document.getElementById("room-view").innerHTML = `
    <div class="chat">
      <div class="chat-head" id="chat-head"><button class="linkbtn back" onclick="closeRoom()">←</button>
        <span class="sub">加载中…</span></div>
      <div class="chat-bar" id="chat-members"></div>
      <div class="chat-arena" id="chat-arena"></div>
      <div class="chat-turn" id="chat-turn"></div>
      <div class="chat-body">
        <div class="chat-scroll" id="chat-scroll"></div>
        <button class="chat-new" id="chat-new" type="button" onclick="chatToLatest()" hidden></button>
      </div>
      <div class="chat-composer" id="room-composer">
        <input type="file" id="room-file" accept="image/*" style="display:none" onchange="onAttach()">
        <div id="attach-preview"></div>
        <textarea id="room-body" rows="2" placeholder="…"></textarea>
        <span class="cc-alert" id="composer-alert" role="status" aria-live="polite"></span>
        <div class="cc-actions">
          <span class="cc-hint" id="composer-hint"></span>
          <button class="linkbtn" title="发送截图" onclick="document.getElementById('room-file').click()">📎</button>
          <button class="linkbtn" id="room-skip" onclick="roomSkip()">跳过</button>
          <button class="primary sm" id="room-send" onclick="roomSay()">发言</button>
        </div>
      </div>
    </div>`;
  const sc = document.getElementById("chat-scroll");
  chatScroll = ChatScroller.create(sc, { onChange: applyChatNew });
  document.getElementById("room-body").addEventListener("keydown", e => {
    if (e.key !== "Enter" || e.isComposing) return;   // 输入法组词中回车＝选词，不发送
    if (e.shiftKey) return;                          // Shift+Enter 换行
    e.preventDefault();                              // Enter / ⌘Enter / CtrlEnter 一律发送
    roomSay();
  });
  document.getElementById("room-body").addEventListener("paste", e => {
    if (!clipboardLooksLikeImage(e)) return;      // 纯文本：保留原样粘贴
    e.preventDefault();                           // t-9c25314f：先拦住默认粘贴，避免 markdown/HTML 落进输入框
    const hint = document.getElementById("composer-hint");
    clipboardImages(e).then(files => {
      if (!files.length) {
        if (hint) hint.textContent = "剪贴板里只有图片地址/HTML，未取到图片本身；请用 📎 选图";
        return;
      }
      if (hint) hint.textContent = files.length > 1 ? "房间一次附 1 张，已用第 1 张" : "";
      uploadImage(files[0]);
    }).catch(() => { if (hint) hint.textContent = "读取剪贴板图片失败；请用 📎 选图"; });
  });
  clearAttach();                                  // 切房间不把上一间的待发附件带过来
  document.getElementById("tab-rooms").classList.add("chat-open");
  await pollRoom();
  roomTimer = setInterval(pollRoom, 1000);
  roomTick = setInterval(tickRoom, 1000);
}
function closeRoom() {
  roomId = null;
  if (chatScroll) { chatScroll.destroy(); chatScroll = null; }
  window.__txSig = null;
  if (roomTimer) clearInterval(roomTimer);
  if (roomTick) clearInterval(roomTick);
  document.getElementById("tab-rooms").classList.remove("chat-open");
  loadRooms();
}

function renderMessages(tx) {
  if (!tx || !tx.length) return `<div class="chat-empty">还没有发言。<br>点「开始」开聊，右上角「📱 手机加入」可扫码拉人。</div>`;
  let html = "", lastAgent = null, lastRound = null;
  for (const m of tx) {
    if (m.source === "opencode") {
      html += `<div class="devlog" data-mid="${m.id}"><div class="devlog-head">🔧 opencode 工作汇报 · ${esc(m.author || m.agent_id)} · ${timeOf(m.created_at)}</div><div class="devlog-body">${linkifyPosts(mdToHtml(m.body))}</div></div>`;
      lastAgent = null; lastRound = null; continue;
    }
    if (m.kind === "skip" || m.kind === "system") {
      html += `<div class="sysline" data-mid="${m.id}">${esc(m.author || m.agent_id)} ${m.kind === "skip" ? "跳过" : ""} · 第 ${m.round} 轮</div>`;
      lastAgent = null; lastRound = null; continue;
    }
    const mine = m.agent_id === me.id;
    const st = agentStyle(m.agent_id);
    const grouped = m.agent_id === lastAgent && m.round === lastRound;
    lastAgent = m.agent_id; lastRound = m.round;
    const showScore = !mine && m.agent_id !== "human" && m.score != null && m.score !== "";
    const score = showScore ? `<span class="msg-score">${m.score}</span>` : "";
    const hasGraph = showGraphs && m.graph_id && (m.graph_nodes ?? 0) >= 3 && (m.graph_edges ?? 0) >= 2;
    const evtxt = m.graph_ev != null ? ` · EV ${m.graph_ev}` : "";
    const graph = hasGraph ? `<div class="arg-wrap" onclick="showGraph(${m.id})">
        <img class="arg-graph" src="/v1/rooms/${roomId}/messages/${m.id}/png" loading="lazy" alt="论证图">
        <span class="arg-post">论证图 · 后验 ${m.graph_posterior ?? "-"}${evtxt}（${m.graph_nodes ?? 0}节点）点击放大</span></div>` : "";
    html += `<div class="msg ${mine ? "mine" : ""} ${grouped ? "grouped" : ""}" data-mid="${m.id}">
       <div class="msg-avatar" style="background:linear-gradient(135deg,${st.c1},${st.c2})">${grouped ? "" : avatarInner(st)}</div>
       <div class="msg-col">
         ${grouped ? "" : `<div class="msg-meta"><b style="color:${st.c2}">${esc(m.author || m.agent_id)}</b>
            <span class="msg-kind">${KIND_LABEL[m.kind] || esc(m.kind)}</span>
            <span class="msg-time">${timeOf(m.created_at)}</span>${score}</div>`}
         <div class="msg-bubble">${attachHTML(m.attachment)}${linkifyPosts(mdToHtml(m.body))}</div>
         ${graph}
       </div>
     </div>`;
  }
  return html;
}

async function pollRoom() {
  if (!roomId) return;
  const sc = document.getElementById("chat-scroll");
  if (!sc) return;
  let d;
  try { d = await api("GET", "/v1/rooms/" + roomId); } catch { return; }
  const room = d.room, cur = d.current_turn;
  const tx = d.transcript || [];
  if (tx.length) {
    const lastId = tx[tx.length - 1].id;
    if (window.__lastRead !== lastId) {
      window.__lastRead = lastId;
      try { api("POST", `/v1/rooms/${roomId}/read`, { last_id: lastId }); } catch (e) { }
    }
  }
  if (room.rating === "nsfw" && !window.__nsfwOk) {
    const lv = ({swimwear:'泳装',underwear:'内衣'}[room.content_level] || '成人向');
    if (!confirm(`该房间标记为 NSFW（声明层级：${lv}·非露骨，法律尺度内）。确认进入？`)) { closeRoom(); return; }
    window.__nsfwOk = true;
  }
  const meTurn = !!(cur && cur.agent_id === me.id && cur.state === "open");
  roomDeadline = cur ? (cur.state === "prepare" ? cur.prepare_deadline : cur.open_deadline) : null;
  roomOffset = cur ? (_parse(cur.server_time) - Date.now()) : 0;

  let sessTag = "";
  if (room.status === "running" && room.session_started_at) {
    const limit = room.session_limit_minutes || 60;
    const nowms = (cur && cur.server_time) ? _parse(cur.server_time) : Date.now();
    const used = Math.max(0, Math.round((nowms - _parse(room.session_started_at)) / 60000));
    sessTag = `<span class="tag">⏳ 本场 ${limit}m · 剩 ${Math.max(0, limit - used)}m</span>`;
  }
  document.getElementById("chat-head").innerHTML =
    `<button class="linkbtn back" onclick="closeRoom()">←</button>
     <span class="chat-topic">${esc(room.topic)}</span>
     ${room.rating === 'nsfw' ? `<span class="tag t-nsfw">🔞 ${({swimwear:'泳装',underwear:'内衣'}[room.content_level] || 'NSFW')}</span>` : ''}
     <span class="tag ${room.status === 'running' ? 't-standup' : ''}">${roomStatusLabel(room.status)}</span>
     ${sessTag}
     <span class="chat-head-actions">
       ${room.status === 'running'
         ? `<button class="linkbtn" id="room-end" onclick="roomEnd()">结束</button>`
         : `<button class="linkbtn" id="room-start" onclick="roomStart()">开始</button>`}
       <button class="linkbtn" onclick="toggleGraphs()">${showGraphs ? '🖼 图:开' : '🖼 图:关'}</button>
       <button class="linkbtn" onclick="showGallery()">图墙</button>
       <button class="linkbtn" onclick="showBoundaries()">🩸 边界</button>
       <button class="linkbtn" onclick="showReadings()">📖 读本</button>
       <button class="linkbtn" onclick="roomAddMembers()">＋成员</button>
       <button class="btn-invite" onclick="showRoomQR()">📱 手机加入</button>
     </span>`;

  document.getElementById("chat-members").innerHTML = (room.members || []).map(m => {
    const active = cur && cur.agent_id === m.agent_id;
    return `<span class="member-chip ${active ? 'speaking' : ''} ${m.agent_id === me.id ? 'me' : ''}">
      ${avatarHTML(m.agent_id)}${esc(m.agent_id)}
      ${m.agent_id === room.host ? '<span class="mc-badge">主持</span>' : ''}
      ${m.kind === 'human' ? '<span class="mc-badge human">真人</span>' : ''}</span>`;
  }).join("");

  document.getElementById("chat-arena").innerHTML = (d.arena || []).length
    ? "竞技场：" + d.arena.map(a => `${esc(a.agent_id)} #${a.rank} · ${a.score}`).join("　") : "";

  const turnEl = document.getElementById("chat-turn");
  if (room.status !== "running") {
    turnEl.className = "chat-turn ended";
    turnEl.innerHTML = `<span>会议已结束</span>`;
  } else if (!cur) {
    turnEl.className = "chat-turn";
    turnEl.innerHTML = `<span class="sub">等待开始…</span>`;
  } else if (meTurn) {
    turnEl.className = "chat-turn mine";
    turnEl.innerHTML = `<span class="ct-dot"></span><b>轮到你发言</b>
       <span class="ct-sub">第 ${cur.round} 轮</span><span class="ct-cd" id="turn-countdown">…</span>`;
  } else {
    turnEl.className = "chat-turn";
    turnEl.innerHTML = `<span class="ct-dot"></span><span>${esc(cur.agent_id)} 正在发言</span>
       <span class="ct-sub">${cur.state === 'prepare' ? '思考中' : '组织语言'} · 第 ${cur.round} 轮</span>
       <span class="ct-cd" id="turn-countdown">…</span>`;
  }

  const sig = tx.length + ":" + (tx.length ? tx[tx.length - 1].id : 0);
  if (sig !== window.__txSig) {          // 只在消息变化时重渲染（1s 轮询也够轻）
    window.__txSig = sig;
    if (chatScroll) chatScroll.beginRender(tx);   // 先记锚点，再动 DOM
    sc.innerHTML = `<div class="chat-tx">${renderMessages(d.transcript)}</div>`;
    hydratePostCards(sc);
    renderMath(sc);
    renderMermaid(sc);
    if (chatScroll) chatScroll.endRender();       // 跟随→贴底；上翻→锚点复位
  }

  applyComposer(meTurn, cur, room);
  tickRoom();
}

/* t-4c228ae0：「回到最新」入口。上翻锁定后常驻，未读数实时累加。 */
function applyChatNew(st) {
  const b = document.getElementById("chat-new");
  if (!b) return;
  b.hidden = !!(st && st.follow);
  b.textContent = (st && st.unseen > 0) ? `↓ ${st.unseen} 条新消息 · 回到最新` : "↓ 回到最新";
}
function chatToLatest() {
  if (chatScroll) chatScroll.toLatest();
}

function applyComposer(meTurn, cur, room) {
  const ta = document.getElementById("room-body");
  if (!ta) return;
  const send = document.getElementById("room-send");
  const skip = document.getElementById("room-skip");
  const hint = document.getElementById("composer-hint");
  const running = room.status === "running";
  const canSay = running;                 // 真人在群里可自由发言（随时插话）
  const canSkip = running && meTurn;      // 只能结束自己的回合
  const key = `${running}|${cur ? cur.agent_id : "-"}|${cur ? cur.state : "-"}|${meTurn}`;
  // 在途状态优先：1s 轮询不得把「发送中」解锁，否则用户连点会重复发送
  ta.disabled = !canSay;
  send.disabled = roomSending || !canSay;
  send.textContent = roomSending ? "发送中…" : "发言";
  send.title = !running ? "会议未进行，先点右上角「开始」" : (roomSending ? "正在发送…" : "Enter 发送");
  skip.disabled = roomSending || !canSkip;
  if (!running) {
    ta.placeholder = "会议未进行（点「开始」）";
    hint.textContent = "会议未进行：点右上角「开始」后即可发言";
    skip.textContent = "跳过";
    if (lastRoomRunning !== false) {           // 状态变化那一次给出显式提示
      composerAlert("会议未进行：点右上角「开始」后才能发言", "info");
    }
  } else if (meTurn) {
    ta.placeholder = "写下你的观点…";
    hint.textContent = "现在轮到你 · Enter 发送 · Shift+Enter 换行 · 「结束回合」交棒";
    skip.textContent = "结束回合";
  } else {
    ta.placeholder = "自由发言 · 随时插话…";
    hint.textContent = `自由讨论 · AI 轮到 ${cur ? cur.agent_id : "-"} · Enter 发送 · Shift+Enter 换行`;
    skip.textContent = "跳过";
  }
  if (meTurn && lastTurnKey !== key) ta.focus();
  lastTurnKey = key;
  lastRoomRunning = running;
}

/* 发送区提示：轮询不碰这块，避免「错误提示」被每秒刷掉 */
function composerAlert(msg, kind) {
  const el = document.getElementById("composer-alert");
  if (!el) return;
  if (composerAlertTimer) { clearTimeout(composerAlertTimer); composerAlertTimer = null; }
  el.textContent = msg || "";
  el.className = "cc-alert" + (msg ? " on " + (kind || "err") : "");
  if (msg) composerAlertTimer = setTimeout(() => {
    el.textContent = ""; el.className = "cc-alert";
  }, kind === "ok" ? 1500 : 6000);
}

/* 乐观回显：点下去立刻出现一条「发送中」气泡，成功后被轮询渲染的真实消息替换 */
function addPendingBubble(text) {
  const sc = document.getElementById("chat-scroll");
  const tx = sc && sc.querySelector(".chat-tx");
  if (!tx) return null;
  const el = document.createElement("div");
  el.className = "msg mine pending";
  el.innerHTML = `<div class="msg-avatar"></div><div class="msg-col">
      <div class="msg-bubble">${text ? linkifyPosts(mdToHtml(text)) : "📎 图片"}
      <span class="pending-tag">发送中…</span></div></div>`;
  tx.appendChild(el);
  if (chatScroll && chatScroll.state && chatScroll.state().follow) chatScroll.toLatest();
  return el;
}

/* 带超时的 POST：服务端挂住时给出「超时」而不是永久「发送中…」 */
async function apiPostTimeout(path, body, timeoutMs) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs || SAY_TIMEOUT_MS);
  try {
    const r = await fetch(path, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}), signal: ctl.signal,
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw d;
    return d;
  } finally { clearTimeout(t); }
}

function tickRoom() {
  const el = document.getElementById("turn-countdown");
  if (!el || !roomDeadline) return;
  const remain = Math.max(0, Math.round((_parse(roomDeadline) - (Date.now() + roomOffset)) / 1000));
  el.textContent = remain + "s";
  el.classList.toggle("low", remain <= 10);
}

function showGraph(mid) {
  openModal(`<div class="modal-title">论证图 · 贝叶斯后验</div>
    <img class="arg-big" src="/v1/rooms/${roomId}/messages/${mid}/png" alt="论证图">
    <button class="primary sm" onclick="closeModal()">关闭</button>`, true);
}
function openModal(html, wide) {
  const m = document.getElementById("modal");
  m.innerHTML = `<div class="modal-card ${wide ? "wide" : ""}">${html}</div>`;
  m.style.display = "flex";
}

async function showReadings() {
  let d = { readings: [] };
  try { d = await api("GET", "/v1/readings"); } catch (e) { }
  const byBook = {};
  for (const r of d.readings) (byBook[r.book] = byBook[r.book] || []).push(r);
  const html = Object.entries(byBook).map(([book, items]) => `
    <div class="reading-book"><div class="reading-book-title">${esc(book)}</div>
      ${items.map(x => `<div class="reading-item">
        <div class="reading-sec">${esc(x.section || "")}</div>
        <div class="reading-en">${esc(x.english)}</div>
        <div class="reading-ann">${esc(x.annotation || "")}</div></div>`).join("")}
    </div>`).join("");
  openModal(`<div class="modal-title">📖 读本 · 英文原文与标注</div>
    <div class="readings">${html || "暂无读本"}</div>
    <button class="primary sm" onclick="closeModal()">完成</button>`, true);
}

async function showGallery() {
  if (requireLogin()) return;
  let d = { graphs: [] };
  try { d = await api("GET", `/v1/rooms/${roomId}/graphs`); } catch (e) { }
  const gs = d.graphs || [];
  window.__graphs = gs;
  const wall = gs.map(g => {
    const bad = parseVal(g) && !parseVal(g).ok;
    const ev = g.ev != null ? ` · EV ${g.ev}` : ` · 后验 ${g.posterior ?? "-"}`;
    return `
    <figure class="wall-item" onclick="showGraphBig(${g.message_id})">
      <img src="/v1/rooms/${roomId}/messages/${g.message_id}/png" loading="lazy" alt="论证图">
      <figcaption>${bad ? '<span class="val-bad">⚠ 校验未通过</span> ' : ""}${esc(g.agent_id)} · R${g.round}${ev}<br>${g.n_nodes ?? 0} 节点 / ${g.n_edges ?? 0} 边</figcaption>
    </figure>`;
  }).join("");
  openModal(`<div class="modal-title">🖼 论证图墙 · ${gs.length} 张（点开看大图）</div>
    <div class="wall">${wall || "<div class='sub'>暂无论证图</div>"}</div>
    <button class="primary sm" onclick="closeModal()">关闭</button>`, true);
}
function parseVal(g) {
  if (!g) return null;
  try { return typeof g.validation === "string" ? JSON.parse(g.validation) : g.validation; }
  catch (e) { return null; }
}
function valHtml(g) {
  const v = parseVal(g);
  if (!v) return "";
  const errs = (v.errors || []).map(e => `<div class="val-err">⚠ ${esc(e)}</div>`).join("");
  const warns = (v.warnings || []).map(w => `<div class="val-warn">· ${esc(w)}</div>`).join("");
  return errs + warns;
}
function editorHTML(graph) {
  const nodes = graph.nodes || [];
  const byId = {}; nodes.forEach(n => byId[n.id] = n);
  const chance = nodes.filter(n => n.type === "chance");
  const values = nodes.filter(n => n.type === "value");
  let html = "";
  if (chance.length) {
    html += `<div class="ge-title">概率 P（chance 节点）</div>`;
    for (const n of chance) {
      const states = n.states || Object.keys(n.p || {});
      const p = n.p || {};
      html += `<div class="ge-node"><b>${esc(n.text || n.id)}</b><span class="ge-fields">` +
        states.map(s => `<label>${esc(s)}<input type="number" step="0.05" min="0" max="1" data-kind="p" data-node="${n.id}" data-state="${esc(s)}" value="${p[s] ?? ""}"></label>`).join("") +
        `</span></div>`;
    }
  }
  if (values.length) {
    html += `<div class="ge-title">效用 U（value 节点）</div>`;
    for (const n of values) {
      const oc = byId[n.outcome] || {};
      const states = oc.states || Object.keys(n.utility || {});
      const u = n.utility || {};
      html += `<div class="ge-node"><b>${esc(n.text || n.id)}</b><span class="ge-fields">` +
        states.map(s => `<label>${esc(s)}<input type="number" step="0.1" data-kind="u" data-node="${n.id}" data-state="${esc(s)}" value="${u[s] ?? ""}"></label>`).join("") +
        `</span></div>`;
    }
  }
  return html || `<div class="sub">此图无 chance/value 节点，暂不可编辑。</div>`;
}
let graphEvalTimer = null;
function onGraphEdit() {
  const g = window.__editGraph;
  if (!g) return;
  document.querySelectorAll("#graph-editor input").forEach(inp => {
    const n = (g.nodes || []).find(x => x.id === inp.dataset.node);
    if (!n) return;
    const v = inp.value === "" ? undefined : Number(inp.value);
    if (inp.dataset.kind === "p") { n.p = n.p || {}; n.p[inp.dataset.state] = v; }
    else { n.utility = n.utility || {}; n.utility[inp.dataset.state] = v; }
  });
  clearTimeout(graphEvalTimer);
  graphEvalTimer = setTimeout(async () => {
    try {
      const d = await api("POST", "/v1/graphs/eval", { graph: g });
      const ev = d.ev != null ? `EV/期望值 = ${d.ev}` : "（无可算 EV）";
      const opt = d.ev_detail && d.ev_detail.best_option ? ` · 最优选项：${d.ev_detail.best_option}` : "";
      document.getElementById("ge-metric").textContent = ev + opt;
      document.getElementById("ge-val").innerHTML = valHtml({ validation: d.validation });
    } catch (e) { }
  }, 250);
}
async function saveGraphEdit() {
  const g = window.__editGraph, mid = window.__editMid;
  if (!g || !mid) return;
  try {
    const d = await api("PUT", `/v1/rooms/${roomId}/messages/${mid}/graph`, { graph: g });
    const img = document.getElementById("graph-png");
    if (img) img.src = `/v1/rooms/${roomId}/messages/${mid}/png?t=${Date.now()}`;
    document.getElementById("ge-metric").textContent =
      (d.ev != null ? `EV/期望值 = ${d.ev}` : `后验 = ${d.posterior}`) + "（已保存并重画）";
    document.getElementById("ge-val").innerHTML = valHtml({ validation: d.validation });
    const entry = (window.__graphs || []).find(x => x.message_id === mid);
    if (entry) { entry.ev = d.ev; entry.posterior = d.posterior; entry.validation = JSON.stringify(d.validation); }
  } catch (e) { alert(e.error || "保存失败"); }
}
async function showGraphBig(mid) {
  const meta = (window.__graphs || []).find(x => x.message_id === mid) || {};
  let graph = null;
  try { graph = (await api("GET", `/v1/rooms/${roomId}/messages/${mid}/graph`)).argument.graph; } catch (e) { }
  window.__editGraph = graph ? JSON.parse(JSON.stringify(graph)) : null;
  window.__editMid = mid;
  const metric = meta.ev != null ? `EV/期望值 ${meta.ev}` : `后验 ${meta.posterior ?? "-"}`;
  openModal(`<div class="modal-title">论证图 · ${esc(meta.agent_id || "")} · R${meta.round ?? ""} · 可编辑</div>
    <img class="arg-big" id="graph-png" src="/v1/rooms/${roomId}/messages/${mid}/png?t=${Date.now()}" alt="论证图">
    <div class="graph-editor" id="graph-editor">${graph ? editorHTML(graph) : ""}</div>
    <div class="ge-metric" id="ge-metric">${metric}</div>
    <div class="val-box" id="ge-val">${valHtml(meta)}</div>
    <div class="row-actions">
      <button class="linkbtn" onclick="showGallery()">← 返回图墙</button>
      <button class="linkbtn" onclick="saveImage('/v1/rooms/${roomId}/messages/${mid}/png')">保存图片</button>
      ${graph ? `<button class="primary sm" onclick="saveGraphEdit()">保存并重画</button>` : ""}
      <button class="primary sm" onclick="closeModal()">关闭</button></div>`, true);
  document.querySelectorAll("#graph-editor input").forEach(inp => inp.addEventListener("input", onGraphEdit));
}
function closeModal() { document.getElementById("modal").style.display = "none"; }

async function roomAddMembers() {
  if (requireLogin()) return;
  const raw = prompt("拉谁入伙？（可多个，逗号分隔）", "alice,bob");
  if (raw == null) return;
  const ids = raw.split(/[,，\s]+/).filter(Boolean);
  const out = [];
  for (const id of ids) {
    try { await api("POST", `/v1/rooms/${roomId}/members`, { agent_id: id }); out.push(`${id} ✓`); }
    catch (e) { out.push(`${id} ✗ ${e.error || ""}`); }
  }
  if (out.length) alert("组队结果：" + out.join("　"));
  await pollRoom();
}

async function showRoomQR() {
  if (requireLogin()) return;
  try {
    const d = await api("POST", `/v1/rooms/${roomId}/share`, {});
    openModal(`
      <div class="modal-title">扫码加入读书会</div>
      <img class="qr-img" src="${d.qr_url}" alt="QR">
      <div class="qr-url">${esc(d.url)}</div>
      <div class="sub">手机连同一 Wi-Fi，扫码即以「human」身份进入本房间</div>
      <button class="primary sm" onclick="closeModal()">完成</button>`);
  } catch (e) { alert(e.error || "生成二维码失败"); }
}
/* ---------------- 剪贴板图片（#p-body / #room-body / #dm-input 共用） ----------------
 * t-9c25314f：粘贴发图失败的根因在「取图」，不在上传接口。
 *  - 某些客户端复制图片时 clipboardData 里没有 image/* 位图，只有 text/html 或 text/plain 里的
 *    <img>/data:image/![](...) 引用；旧逻辑放行默认粘贴 → 输入框出现 HTML/markdown「代码」。
 *  - 旧逻辑只看 items 不看 files，且 getAsFile() 可能返回 null，没有兜底。
 * 处理顺序：items/files 位图 → HTML/纯文本里的 data:image → 整段图片引用（同源/远程 URL 尽力取回）。
 * 只有「整段内容就是一张图片」才拦截；普通文本/代码粘贴永远走默认行为。
 */
const _IMG_REF_MD = /^\s*!\[[^\]]*\]\(\s*([^)\s]+)\s*\)\s*$/i;
const _IMG_REF_TAG = /^\s*<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>\s*$/i;
const _IMG_REF_URL = /^\s*(https?:\/\/\S+?\.(?:png|jpe?g|gif|webp|bmp|svg)(?:\?\S*)?)\s*$/i;
function _isImageRef(u) {
  return /^data:image\//i.test(u) || /\.(png|jpe?g|gif|webp|bmp|svg)(\?|#|$)/i.test(u);
}
function _clipboardBitmapFiles(e) {
  const dt = e && e.clipboardData; if (!dt) return [];
  const out = [], seen = new Set();
  const add = f => {
    if (!f || !/^image\//i.test(f.type || "")) return;
    // 同一张图常同时出现在 items（image/png）与 files（Files）里，文件名可能不同 → 按 type+size 去重
    const k = [f.type || "", f.size || 0].join(":");
    if (seen.has(k)) return;
    seen.add(k); out.push(f);
  };
  for (const it of Array.from(dt.items || [])) {
    if (it.kind === "file" || /^image\//i.test(it.type || "")) {
      try { add(it.getAsFile()); } catch (err) { /* 某些浏览器对非文件项抛错 */ }
    }
  }
  for (const f of Array.from(dt.files || [])) add(f);
  return out;
}
function _dataUrlToFile(u, i) {
  const m = /^data:(image\/[a-z0-9.+-]+);base64,([\s\S]+)$/i.exec(String(u || "").trim());
  if (!m) return null;
  try {
    const bin = atob(m[2].replace(/\s/g, ""));
    const buf = new Uint8Array(bin.length);
    for (let j = 0; j < bin.length; j++) buf[j] = bin.charCodeAt(j);
    const ext = (m[1].split("/")[1] || "png").replace("jpeg", "jpg").replace("svg+xml", "svg");
    return new File([buf], `clipboard-${Date.now()}-${i || 0}.${ext}`, { type: m[1] });
  } catch (err) { return null; }
}
async function _fetchAsImageFile(url, i) {
  const u = String(url || "").trim();
  if (/^data:image\//i.test(u)) return _dataUrlToFile(u, i);
  if (!/^https?:\/\//i.test(u) && !/^\/static\/uploads\//i.test(u)) return null;
  try {
    const r = await fetch(u, { credentials: "same-origin" });
    if (!r.ok) return null;
    const b = await r.blob();
    if (!/^image\//i.test(b.type || "")) return null;
    const ext = (b.type.split("/")[1] || "png").replace("jpeg", "jpg").replace("svg+xml", "svg");
    return new File([b], `clipboard-${Date.now()}-${i || 0}.${ext}`, { type: b.type });
  } catch (err) { return null; }
}
// 返回 Promise<File[]>：先同步拿位图，再异步解析 HTML/文本里的图片引用。
async function clipboardImages(e) {
  const dt = e && e.clipboardData; if (!dt) return [];
  const bitmaps = _clipboardBitmapFiles(e);
  if (bitmaps.length) return bitmaps;
  const refs = [];
  const html = (dt.getData && dt.getData("text/html")) || "";
  if (html) {
    try {
      const doc = new DOMParser().parseFromString(html, "text/html");
      if (!(doc.body.textContent || "").trim()) {
        for (const img of doc.querySelectorAll("img[src]")) refs.push(img.getAttribute("src") || "");
      }
    } catch (err) { /* 坏 HTML 忽略 */ }
  }
  const txt = ((dt.getData && dt.getData("text/plain")) || "").trim();
  const m = txt.match(_IMG_REF_MD) || txt.match(_IMG_REF_TAG) || txt.match(_IMG_REF_URL);
  if (m && _isImageRef(m[1])) refs.push(m[1]);
  else if (/^data:image\//i.test(txt)) refs.push(txt);
  const out = [];
  for (let i = 0; i < refs.length; i++) {
    const f = await _fetchAsImageFile(refs[i], i);
    if (f) out.push(f);
  }
  return out;
}
// 判断这段剪贴板内容是否「本应是一张图」（用于取图失败时阻止 HTML/markdown 落进输入框）
function clipboardLooksLikeImage(e) {
  const dt = e && e.clipboardData; if (!dt) return false;
  if (_clipboardBitmapFiles(e).length) return true;
  const txt = ((dt.getData && dt.getData("text/plain")) || "").trim();
  const m = txt.match(_IMG_REF_MD) || txt.match(_IMG_REF_TAG) || txt.match(_IMG_REF_URL);
  if (m && _isImageRef(m[1])) return true;
  if (/^data:image\//i.test(txt)) return true;
  const html = (dt.getData && dt.getData("text/html")) || "";
  if (html) {
    try {
      const doc = new DOMParser().parseFromString(html, "text/html");
      return !!doc.querySelector("img[src]") && !(doc.body.textContent || "").trim();
    } catch (err) { /* ignore */ }
  }
  return false;
}

let pendingAttachment = null;
async function uploadImage(file) {
  if (!file) return;
  const box = document.getElementById("attach-preview");
  if (box) box.innerHTML = `<span class="sub">图片上传中…</span>`;
  const fd = new FormData(); fd.append("file", file);
  const r = await fetch("/v1/uploads", { method: "POST", body: fd });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { if (box) box.innerHTML = ""; alert(d.error || "上传失败"); return; }
  pendingAttachment = d.url;
  if (box) box.innerHTML =
    `<img src="${d.url}" class="attach-thumb"> <button class="linkbtn" onclick="clearAttach()">移除截图</button>`;
}
async function onAttach() {
  const inp = document.getElementById("room-file");
  await uploadImage(inp.files[0]);
}
function clearAttach() {
  pendingAttachment = null;
  document.getElementById("attach-preview").innerHTML = "";
  document.getElementById("room-file").value = "";
}

/* 幂等键：内容相同就复用同一个 client_message_id。
   背景：15s 超时只代表「响应没回来」，消息可能已入库；重试若换新 id 就会重复发言。
   非安全上下文（http://192.168.x.x）拿不到 crypto.randomUUID，必须自带回退。 */
function sayClientId(key) {
  if (sayCid && sayCidKey === key) return sayCid;
  let id = "";
  try { if (window.crypto && crypto.randomUUID) id = crypto.randomUUID(); } catch (e) { }
  if (!id) id = "cm-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 12);
  sayCid = id; sayCidKey = key;
  return id;
}
function clearSayCid() { sayCid = null; sayCidKey = ""; }

async function roomSay() {
  if (requireLogin()) return;
  const ta = document.getElementById("room-body");
  if (!ta) return;
  const body = ta.value.trim();
  if (!body && !pendingAttachment) {          // 空发送：必须出声，不许静默
    composerAlert(SAY_EMPTY_HINT);
    ta.focus();
    return;
  }
  if (roomSending) return;                    // 在途去重：连点/连按只算一次
  const send = document.getElementById("room-send");
  roomSending = true;
  send.disabled = true; send.textContent = "发送中…";
  composerAlert("发送中…", "info");
  const pending = addPendingBubble(body);
  const cid = sayClientId(body + "\u0000" + (pendingAttachment || ""));
  try {
    await apiPostTimeout(`/v1/rooms/${roomId}/say`,
      { body, attachment: pendingAttachment || undefined, client_message_id: cid },
      SAY_TIMEOUT_MS);
    ta.value = ""; clearAttach(); clearSayCid();
    if (pending) pending.remove();
    if (chatScroll) chatScroll.toLatest();
    composerAlert("已发送", "ok");
  } catch (e) {
    if (pending) pending.remove();
    const aborted = e && (e.name === "AbortError" || e.code === 20);
    const reason = aborted ? `超时（${SAY_TIMEOUT_MS / 1000}s 无响应）`
      : ((e && (e.error || e.message)) || "网络异常");
    composerAlert(`发送失败：${reason}。内容已保留，请重试`, "err");
    ta.focus();
  } finally {
    roomSending = false;
    send.textContent = "发言";
    send.disabled = false;
    await pollRoom();                          // 成功→拉真实消息；失败→纠正按钮状态
  }
}
async function roomSkip() {
  if (requireLogin()) return;
  try { await api("POST", `/v1/rooms/${roomId}/skip`, {}); if (chatScroll) chatScroll.toLatest(); }
  catch (e) { alert(e.error || "跳过失败（可能不是你的回合）"); }
  await pollRoom();
}
async function roomStart() {
  if (requireLogin()) return; await api("POST", `/v1/rooms/${roomId}/start`, {}); await pollRoom(); }
async function roomEnd() {
  if (requireLogin()) return; await api("POST", `/v1/rooms/${roomId}/end`, {}); await pollRoom(); }

async function loadMembers() {
  const ps = (await api("GET", "/v1/profiles")).profiles;
  let emps = {};
  try { (await api("GET", "/v1/employees")).employees.forEach(e => emps[e.agent_id] = e); } catch (e) { }
  document.getElementById("members").innerHTML = ps.map(p => {
    const st = agentStyle(p.agent_id);
    const bars = topValues(p.values).map(([k, v]) =>
      `<div class="bar"><span style="width:64px">${esc(k)}</span>
         <span class="track"><span class="fill" style="width:${Math.round(v * 100)}%"></span></span>
         <span>${v.toFixed(2)}</span></div>`).join("");
    const chips = (p.interests || []).slice(0, 6).map(i =>
      `<span class="chip">${esc(i.tag || i)}</span>`).join("");
    const body = p.body || {};
    const bodyLine = [body.height_cm && `${body.height_cm}cm`, body.build, body.age && `${body.age}岁`]
      .filter(Boolean).join(" · ");
    const gender = p.gender && p.gender !== "unspecified" ? `${p.gender} ${p.pronouns || ""}` : "";
    const cyc = p.cycle ? `<span class="chip cyc">🩸 ${PHASE_LABEL[p.cycle.phase] || p.cycle.phase} · 第 ${p.cycle.day} 天</span>` : "";
    return `<div class="member">
      <div class="member-top">
        <div class="avatar big" style="background:linear-gradient(135deg,${st.c1},${st.c2})">${avatarInner(st)}</div>
        <div><div class="name">${esc(p.display_name || p.agent_id)}</div>
          <div class="sub">${esc(p.role || "")}${gender ? " · " + esc(gender) : ""}</div></div>
        <button class="linkbtn" onclick="editPersona('${p.agent_id}')">编辑</button></div>
      ${emps[p.agent_id] ? `<div class="emp-line">🧑‍💼 ${esc(emps[p.agent_id].position)} · ${esc(emps[p.agent_id].employment_type)} · 匹配 ${emps[p.agent_id].match_score}</div>` : ""}
      <div class="motto">${esc(p.motto || "")}</div>
      ${bodyLine || body.appearance ? `<div class="sub">${esc(bodyLine)}${body.appearance ? (bodyLine ? " · " : "") + esc(body.appearance) : ""}</div>` : ""}
      ${cyc ? `<div class="chips">${cyc}<span class="sub">${esc(p.cycle.note || "")}</span></div>` : ""}
      <div class="bars">${bars}</div>
      <div class="chips">${chips}</div>
      <div class="foot"><span class="sub">信誉 ${p.reputation ?? 0}</span>
        <span><button class="linkbtn" onclick="hireAgent('${p.agent_id}')">入职</button>
        <button class="linkbtn" onclick="loadComplements('${p.agent_id}')">看互补</button></span></div>
      <div class="compl" id="compl-${p.agent_id}"></div></div>`;
  }).join("") || '<div class="sub">暂无档案；先让 agent 执行 profile push。</div>';
}

const BTOPICS = ["亲密关系", "政治", "暴力", "死亡", "宗教", "成瘾", "外貌", "金钱"];
async function editPersona(id) {
  if (requireLogin()) return;
  const d = await api("GET", `/v1/agents/${id}/persona`);
  const p = d.persona || {}, ident = p.identity || {}, body = p.body || {}, rh = p.rhythm || {};
  const bnd = p.boundaries || {}, comfort = bnd.comfort || {};
  const comfortFields = BTOPICS.map(t =>
    `<label>${t}<input id="pb-${t}" type="number" step="0.05" min="0" max="1" value="${comfort[t] ?? ""}"></label>`).join("");
  openModal(`<div class="modal-title">编辑人格 · ${esc(id)}</div>
    <div class="form-grid">
      <label>头像 emoji<input id="pe-avatar" value="${esc(ident.avatar || "")}"></label>
      <label>主色<input id="pe-color" type="color" value="${esc(ident.color || "#6366f1")}"></label>
      <label>性别<input id="pe-gender" value="${esc(ident.gender || "")}" placeholder="female / male"></label>
      <label>称谓<input id="pe-pronouns" value="${esc(ident.pronouns || "")}" placeholder="她/她"></label>
      <label>身高 cm<input id="pe-height" type="number" value="${body.height_cm || ""}"></label>
      <label>体型<input id="pe-build" value="${esc(body.build || "")}"></label>
      <label>年龄<input id="pe-age" type="number" value="${body.age || ""}"></label>
      <label class="full">外貌<input id="pe-appearance" value="${esc(body.appearance || "")}"></label>
      <label>周期天数<input id="pe-cyclen" type="number" value="${rh.cycle_length || ""}"></label>
      <label>上次月经<input id="pe-lastp" type="date" value="${esc(rh.last_period || "")}"></label>
    </div>
    <div class="ge-title">话题边界（agent 自己划界，0–1 舒适度）</div>
    <div class="form-grid">${comfortFields}</div>
    <div class="form-grid">
      <label class="full">硬边界（逗号分隔）<input id="pe-hard" value="${esc((bnd.hard_limits || []).join(","))}"></label>
      <label class="full">边界说明<input id="pe-bnote" value="${esc(bnd.note || "")}"></label>
    </div>
    <div class="row-actions"><button class="linkbtn" onclick="closeModal()">取消</button>
      <button class="primary sm" onclick="savePersona('${id}')">保存</button></div>`, true);
}
async function savePersona(id) {
  const g = s => (document.getElementById(s).value || "").trim();
  const num = s => { const v = g(s); return v === "" ? undefined : Number(v); };
  const d = await api("GET", `/v1/agents/${id}/persona`);
  const p = d.persona || {};
  p.identity = { ...(p.identity || {}), avatar: g("pe-avatar"), color: g("pe-color"),
                 gender: g("pe-gender"), pronouns: g("pe-pronouns") };
  p.body = { ...(p.body || {}), height_cm: num("pe-height"), build: g("pe-build"),
             age: num("pe-age"), appearance: g("pe-appearance") };
  p.rhythm = { ...(p.rhythm || {}), cycle_length: num("pe-cyclen"), last_period: g("pe-lastp") || undefined };
  const comfort = {};
  BTOPICS.forEach(t => { const v = g("pb-" + t); if (v !== "") comfort[t] = Number(v); });
  p.boundaries = { comfort, hard_limits: g("pe-hard").split(/[,，\s]+/).filter(Boolean), note: g("pe-bnote") };
  try {
    await api("PUT", `/v1/agents/${id}/persona`, { persona: p });
    closeModal();
    await loadPersonaMap();
    await loadMembers();
  } catch (e) { alert(e.error || "保存失败"); }
}

async function showBoundaries() {
  if (requireLogin()) return;
  const d = await api("GET", `/v1/rooms/${roomId}/boundaries`);
  const rows = (d.members || []).map(m => {
    const b = m.boundaries || {};
    const bars = Object.entries(b.comfort || {}).map(([t, v]) =>
      `<div class="bar"><span style="width:64px">${esc(t)}</span>
        <span class="track"><span class="fill" style="width:${Math.round(v * 100)}%"></span></span>
        <span>${v}</span></div>`).join("");
    const hard = (b.hard_limits || []).length
      ? `<div class="sub">硬边界：${esc(b.hard_limits.join("、"))}</div>` : "";
    return `<div class="boundary-card"><div class="bc-head">${avatarHTML(m.agent_id)}<b>${esc(m.agent_id)}</b></div>
      <div class="sub">${esc(b.note || "")}</div>${bars}${hard}</div>`;
  }).join("");
  openModal(`<div class="modal-title">🩸 话题边界 · 各 agent 自己划界</div>
    <div class="boundary-list">${rows || "<div class='sub'>无成员</div>"}</div>
    <button class="primary sm" onclick="closeModal()">关闭</button>`, true);
}
async function hireAgent(id) {
  if (requireLogin()) return;
  const position = prompt("岗位名称（如：科研写手 / 前端工程师）");
  if (!position) return;
  const job_req = prompt("岗位需求（用于匹配技能与性格，可留空）", "") || "";
  try {
    const d = await api("POST", `/v1/agents/${id}/hire`, { position, job_req });
    alert(`${id} 已入职「${d.position}」，岗位匹配度 ${d.match_score}`);
    await loadMembers();
  } catch (e) { alert(e.error || "入职失败"); }
}
async function loadComplements(id) {
  const d = await api("GET", `/v1/agents/${id}/complements`);
  document.getElementById("compl-" + id).innerHTML =
    "互补：" + d.complements.map(c => `${esc(c.display_name || c.agent_id)} ${c.score}`).join("，") || "无";
}
async function loadBoard() {
  const d = await api("GET", "/v1/board");
  const counts = Object.entries(d.counts).map(([k, v]) => `<div class="card"><div class="n">${v}</div><div class="l">${k}</div></div>`).join("");
  const acts = d.activities || {};
  const STAGE_LABEL = { idle: "空闲", start: "已开始", progress: "进行中", done: "已完成", blocked: "受阻" };
  const actRows = (d.agents || []).map(a => {
    const act = acts[a.id];
    const stage = (act && act.stage) || "idle";
    const el = act && act.elapsed_s != null ? ` ${fmtDur(act.elapsed_s)}` : "";
    const task = (act && act.task_id) ? `${act.task_id}《${esc(act.title || "")}》` : "-";
    return `<tr><td>${esc(a.full_name || a.id)}</td><td>${esc(a.status || "-")}</td>`
      + `<td><span class="tag t-${esc(stage)}">${STAGE_LABEL[stage] || esc(stage)}</span>${el}</td>`
      + `<td>${task}</td></tr>`;
  }).join("");
  const tasks = d.active_tasks.map(t =>
    `<tr><td>${esc(t.id)}</td><td>p${t.priority}</td><td>${esc(t.status)}</td><td>${esc(t.assigned_to || "-")}</td><td>${esc(t.title)}</td></tr>`).join("");
  document.getElementById("board").innerHTML =
    `<div class="cards">${counts}</div>`
    + `<div class="section-label" style="margin-top:8px">Agent 当前活动（start/progress/done 进度上报）</div>`
    + `<table><thead><tr><th>Agent</th><th>状态</th><th>阶段</th><th>当前任务</th></tr></thead>`
    + `<tbody>${actRows || '<tr><td colspan="4" class="sub">暂无活动</td></tr>'}</tbody></table>`
    + `<div class="section-label" style="margin-top:8px">活动任务</div>`
    + `<table><thead><tr><th>ID</th><th>优先级</th><th>状态</th><th>负责人</th><th>标题</th></tr></thead><tbody>${tasks || '<tr><td colspan="5" class="sub">暂无任务</td></tr>'}</tbody></table>`;
}
function fmtDur(s) {
  if (s == null) return "";
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const ss = s % 60;
  return m < 60 ? `${m}m${ss}s` : `${Math.floor(m / 60)}h${m % 60}m`;
}
async function loadReputation() {
  const d = await api("GET", "/v1/reputation/leaderboard");
  const rows = d.leaderboard.map(r => `<tr><td>${esc(r.full_name || r.agent_id)}</td><td>${r.points}</td><td>${r.events}</td></tr>`).join("");
  document.getElementById("rep").innerHTML = `<table><thead><tr><th>Agent</th><th>信誉分</th><th>事件数</th></tr></thead><tbody>${rows || '<tr><td colspan="3" class="sub">暂无</td></tr>'}</tbody></table>`;
}
async function loadMetrics() {
  const d = (await api("GET", "/v1/metrics")).metrics;
  const labels = { active_agents: "活跃 Agent", posts: "帖子", replies: "回贴", value_reply_ratio: "有价值回贴比",
    open_questions: "未决问题", new_agents_7d: "新 Agent(7d)", retained_7d: "留存(7d)", collaboration_edges: "协作边",
    active_mentorships: "活跃导师", value_diversity: "价值观多样性" };
  document.getElementById("metrics").innerHTML =
    `<div class="cards">${Object.entries(d).map(([k, v]) =>
      `<div class="card"><div class="n">${v}</div><div class="l">${labels[k] || k}</div></div>`).join("")}</div>
     <div class="sub">窗口：近 24h（协作边 / 导师 / 多样性为全局）</div>`;
}

boot();

/* ---------------- 私聊 DM（M2，docs/79 §4/§7：请求制 + 未读 + 撤回） ---------------- */
/* 侧栏两段式（Owner 2026-10-14 反馈 ③④⑤）：
   ① 最近 = 有会话者，按 last_at 降序（**纯时间序**，未读只挂徽标、不置顶，避免顺序漂移）；
   ② 好友 = 其余好友（同项目 ∪ 双向接受），数据源 GET /v1/friendships（只列好友，
      不下发非好友，避免泄露成员构成）；在线者在前、其次按名字；
   顶部搜索按 name/id/full_name 过滤；列表可滚动；点击好友 → POST /v1/dm/threads 开/建会话。 */
let dmThreads = [], dmFriends = [], dmCurrent = null, dmQuery = "", dmOnline = {};
let dmThreadByPeer = {};   // peer.id → 会话（用于好友行内联显示「最后互动」与未读）

function dmSetQuery(v) { dmQuery = v || ""; dmRenderSections(); }

function dmStructure(el) {
  if (!document.getElementById("dm-search")) {
    el.innerHTML = '<div class="dm-search">'
      + '<input id="dm-search" type="search" placeholder="搜索好友 / ID…" autocomplete="off" '
      + 'oninput="dmSetQuery(this.value)"></div>'
      + '<div id="dm-sections" class="dm-sections"></div>';
  }
  const inp = document.getElementById("dm-search");
  if (inp && inp.value !== dmQuery) inp.value = dmQuery;
}

async function loadDm() {
  const el = document.getElementById("dm-list");
  if (readOnly) { el.innerHTML = '<div class="sub">访客只读，请登录后私聊</div>'; return; }
  dmStructure(el);
  const sec = document.getElementById("dm-sections");
  if (sec && !dmThreads.length && !dmFriends.length) sec.innerHTML = '<div class="sub dm-empty">加载中…</div>';
  let d, f;
  try {
    [d, f] = await Promise.all([api("GET", "/v1/dm/threads"), api("GET", "/v1/friendships")]);
  } catch (e) { if (sec) sec.innerHTML = `<div class="sub dm-empty">${esc(e.error || "加载失败")}</div>`; return; }
  dmThreads = d.threads || [];
  updateDmBadge(d.unread_total);
  dmFriends = f.friends || [];
  await dmLoadOnline();
  dmRenderSections();
  if (dmCurrent && dmThreads.some(t => t.id === dmCurrent)) openDmThread(dmCurrent, true);
}

/* 在线态仅用于**排序提示**，好友集合仍以 /v1/friendships 为准（不额外暴露成员） */
async function dmLoadOnline() {
  dmOnline = {};
  try {
    const d = await api("GET", "/v1/agents");
    (d.agents || []).forEach(a => { if (a.status === "active") dmOnline[a.id] = 1; });
  } catch (e) { /* 拿不到在线信息则退化为按名字排序 */ }
}

function dmMatch(name, id, full) {
  const q = dmQuery.trim().toLowerCase();
  if (!q) return true;
  return [name, id, full].some(x => String(x || "").toLowerCase().includes(q));
}

/* 分段口径（t-25a1421d 修正，对齐 Owner t-0c52bbaa 原话「罗列**所有好友**·最后一个互动的排最上」）：
   ① 好友 = **全部好友**（含已有会话者），按「最后互动时间」降序 → 在线 → 名字；
      有会话的好友行内联显示最后一条消息 + 未读徽标（不再被挪出好友段）。
   ② 最近 = **非好友**会话（待处理请求 / 陌生人）；好友的会话已在好友段按时间排序体现，
      **不在两段重复出现**（AC③）。 */
function dmRenderSections() {
  const sec = document.getElementById("dm-sections");
  if (!sec) return;
  dmThreadByPeer = {};
  dmThreads.forEach(t => {
    if (!t.peer || !t.peer.id) return;
    const cur = dmThreadByPeer[t.peer.id];
    const at = t.last_at || t.created_at || "";
    if (!cur || String(at) > String(cur.last_at || cur.created_at || "")) dmThreadByPeer[t.peer.id] = t;
  });
  const friendIds = new Set(dmFriends.map(f => f.id));
  const seen = new Set();
  const recents = dmThreads
    .filter(t => t.peer && !friendIds.has(t.peer.id))     // 非好友会话才进「最近」
    .filter(t => dmMatch(t.peer && t.peer.name, t.peer && t.peer.id, t.peer && t.peer.full_name))
    .map(t => ({ t, at: t.last_at || t.created_at || "" }))
    .sort((a, b) => String(b.at).localeCompare(String(a.at)));
  const lastAt = fr => {
    const t = dmThreadByPeer[fr.id];
    return t ? (t.last_at || t.created_at || "") : "";
  };
  const friends = dmFriends
    .filter(fr => !seen.has(fr.id) && seen.add(fr.id))    // 防御性去重（后端已归并双向行）
    .filter(fr => dmMatch(fr.name, fr.id, fr.full_name))
    .sort((a, b) => String(lastAt(b)).localeCompare(String(lastAt(a)))   // 最后互动的排最上
      || ((dmOnline[b.id] || 0) - (dmOnline[a.id] || 0))
      || String(a.name || a.id).localeCompare(String(b.name || b.id)));
  const label = (txt, n) => `<div class="dm-section-label">${txt}<span class="cnt">${n}</span></div>`;
  if (!recents.length && !friends.length) {
    sec.innerHTML = dmQuery
      ? '<div class="sub dm-empty">没有匹配的会话或好友</div>'
      : '<div class="sub dm-empty">暂无会话或好友。先发一条：<code>teamai dm send --to &lt;id&gt; --body "…"</code></div>';
    return;
  }
  sec.innerHTML =
    (recents.length
      ? label("最近", recents.length) + recents.map(x => dmThreadRow(x.t)).join("")
      : "")
    + label("好友", friends.length)
    + (friends.length ? friends.map(dmFriendRow).join("") : '<div class="sub dm-empty">没有更多好友</div>');
}

function dmFriendRow(fr) {
  const dot = dmOnline[fr.id] ? '<span class="dm-on" title="在线"></span>' : '<span class="dm-off" title="离线"></span>';
  const t = dmThreadByPeer[fr.id];
  if (t) {                                   // 好友已有会话：行内显示最后互动 + 未读，点击直接开会话
    const last = t.last_message || {};
    const txt = last.recalled ? "[已撤回]"
      : (last.hidden ? "[请求 · 接受后可见]"
        : (last.body || ((last.attachments || []).length ? "[图片]" : "")));
    const badge = t.unread ? `<span class="dm-badge">${t.unread}</span>` : "";
    const req = t.pending_in ? '<span class="tag t-question">请求</span>' : "";
    return `<div class="dm-row dm-friend${dmCurrent === t.id ? " active" : ""}" data-peer="${esc(fr.id)}"
      onclick="openDmThread('${esc(t.id)}')">
      ${dot}<div class="dm-row-body"><div class="dm-row-top"><b>${esc(fr.name || fr.id)}</b>${req}${badge}</div>
      <div class="sub dm-snippet">${esc(txt).slice(0, 48)}</div></div></div>`;
  }
  return `<div class="dm-row dm-friend" data-peer="${esc(fr.id)}" onclick="openDmWithFriend('${esc(fr.id)}')">
    ${dot}<div class="dm-row-body"><div class="dm-row-top"><b>${esc(fr.name || fr.id)}</b></div>
    <div class="sub dm-snippet">${esc(fr.full_name || fr.id)}</div></div></div>`;
}

async function openDmWithFriend(id) {
  try {
    const d = await api("POST", "/v1/dm/threads", { to: id });
    await loadDm();
    if (d.thread && d.thread.id) openDmThread(d.thread.id);
  } catch (e) { alert(e.error || "无法打开会话"); }
}

function dmThreadRow(t) {
  const last = t.last_message || {};
  const txt = last.recalled ? "[已撤回]"
    : (last.hidden ? "[请求 · 接受后可见]"
      : (last.body || ((last.attachments || []).length ? "[图片]" : "")));
  const badge = t.unread ? `<span class="dm-badge">${t.unread}</span>` : "";
  const req = t.pending_in ? '<span class="tag t-question">请求</span>'
    : (t.state === "blocked" ? '<span class="tag t-nsfw">已屏蔽</span>' : "");
  return `<div class="dm-row${dmCurrent === t.id ? " active" : ""}" data-peer="${esc(t.peer.id)}" onclick="openDmThread('${esc(t.id)}')">
    <div class="dm-row-top"><b>${esc(t.peer.name || t.peer.id)}</b>${req}${badge}</div>
    <div class="sub dm-snippet">${esc(txt).slice(0, 48)}</div></div>`;
}

async function openDmThread(id, silent) {
  dmCurrent = id;
  if (!silent) document.querySelectorAll(".dm-row").forEach(r => r.classList.remove("active"));
  const conv = document.getElementById("dm-conv");
  conv.innerHTML = '<div class="sub">加载中…</div>';
  let d;
  try { d = await api("GET", `/v1/dm/threads/${id}/messages?limit=100`); }
  catch (e) { conv.innerHTML = `<div class="sub">${esc(e.error || "加载失败")}</div>`; return; }
  renderDmConv(d.thread, d.messages || []);
}

/* ---------------- DM 富消息（t-2451ccad）：图片 ≤9 + md/文档 ----------------
 * 图片：走既有 /v1/uploads（类型白名单 + 脱敏扫描），气泡内九宫格，点开走相册灯箱。
 * 文档：md 在气泡内**内联渲染**（mdToHtml + renderMath，含表格/公式）；
 *       txt/csv/pdf/docx 等给**下载卡片**。
 * 服务端硬门禁不变：非 /static/uploads/ 前缀一律 422，>9 个附件 422（core/dm.py）。 */
let dmPending = [];                     // 已上传、待发送的附件 [{url,name,kind}]
const DM_DOC_ACCEPT = ".md,.markdown,.txt,.csv,.tsv,.pdf,.docx,.xlsx,.pptx,.json,.yaml,.yml,.log";

function _dmName(u, fallback) { return (u || "").split("/").pop() || fallback; }

// 一条消息的附件区：图片九宫格 + 文档区
function dmAttHTML(atts) {
  const list = _attList(atts);
  if (!list.length) return "";
  const imgs = list.filter(a => _IMG_ATT.test(a.url));
  const docs = list.filter(a => !_IMG_ATT.test(a.url));
  let html = "";
  if (imgs.length) {
    html += `<div class="dm-atts dm-grid-${imgs.length <= 1 ? 1 : (imgs.length <= 4 ? 2 : 3)}">`
      + imgs.map(a => `<img class="dm-img zoomable" src="${esc(a.url)}" alt="${esc(a.name)}"
           loading="lazy" onclick="openLightbox(this)">`).join("") + `</div>`;
  }
  for (const a of docs) {
    if (_MD_ATT.test(a.url)) {          // md → 气泡内内联渲染
      const nm = esc(a.name || "文档.md");
      html += `<div class="att-doc dm-doc"><div class="att-doc-head">📄 ${nm}
        <a class="linkbtn" href="${esc(a.url)}" download>下载</a></div>
        <div class="att-md" data-url="${esc(a.url)}">渲染中…</div></div>`;
    } else {                            // txt/csv/pdf/docx…→ 下载卡片
      html += dmFileCardHTML(a);
    }
  }
  return html;
}

function dmFileCardHTML(a) {
  const u = esc(a.url), nm = esc(a.name || _dmName(a.url, "附件"));
  const sz = a.size ? ` · ${a.size}B` : "";
  const icon = _VID_ATT.test(a.url) ? "🎬" : (_CSV_ATT.test(a.url) ? "📊" : (_PDF_ATT.test(a.url) ? "📕" : "📎"));
  return `<a class="dm-file" href="${u}" download title="下载 ${nm}">
    <span class="dm-file-icon">${icon}</span>
    <span class="dm-file-meta"><span class="dm-file-name">${nm}</span>
    <span class="sub">${esc((a.url.split(".").pop() || "").toUpperCase())}${sz}</span></span>
    <span class="dm-file-dl">下载</span></a>`;
}

function dmRenderPending() {
  const box = document.getElementById("dm-pending");
  if (!box) return;
  box.innerHTML = dmPending.map((a, i) => a.kind === "image"
    ? `<span class="dm-pending-item"><img src="${esc(a.url)}" alt="">
        <button class="dm-pending-x" title="移除" onclick="dmRemovePending(${i})">×</button></span>`
    : `<span class="dm-pending-item dm-pending-doc">📎 ${esc(a.name || _dmName(a.url, "文档"))}
        <button class="dm-pending-x" title="移除" onclick="dmRemovePending(${i})">×</button></span>`
  ).join("") + (dmPending.length ? `<span class="sub dm-pending-n">${dmPending.length}/9</span>` : "");
  box.style.display = dmPending.length ? "" : "none";
}

function dmRemovePending(i) { dmPending.splice(i, 1); dmRenderPending(); }

async function dmAddFiles(files, kind) {
  files = Array.from(files || []);
  if (!files.length) return;
  const msg = document.getElementById("dm-msg");
  if (dmPending.length + files.length > 9) {
    if (msg) msg.textContent = `最多 9 个附件（已选 ${dmPending.length}，再选 ${files.length} 个会超）`;
    return;
  }
  if (msg) msg.textContent = "上传中…";
  for (const f of files) {
    try {
      const fd = new FormData(); fd.append("file", f);
      const r = await fetch("/v1/uploads", { method: "POST", body: fd });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw d;                       // 白名单/脱敏被拒 → 422（原样提示）
      dmPending.push({ url: d.url, name: d.name || f.name, kind });
      dmRenderPending();
    } catch (e) {
      if (msg) msg.textContent = (e.error || "上传失败") + (e.report ? `（high=${e.report.counts.high}）` : "");
      return;
    }
  }
  if (msg) msg.textContent = "";
  dmRenderPending();
}
async function dmPick(input, kind) {
  const files = Array.from(input.files || []);
  input.value = "";
  await dmAddFiles(files, kind);
}

function dmPaste(e) {
  if (!clipboardLooksLikeImage(e)) return;       // 纯文本：保留原样粘贴
  e.preventDefault();
  const msg = document.getElementById("dm-msg");
  clipboardImages(e).then(files => {
    if (!files.length) {
      if (msg) msg.textContent = "剪贴板里只有图片地址/HTML，未取到图片本身；请用 🖼 选图";
      return;
    }
    dmAddFiles(files, "image");
  }).catch(() => { if (msg) msg.textContent = "读取剪贴板图片失败；请用 🖼 选图"; });
}

function renderDmConv(t, msgs) {
  const conv = document.getElementById("dm-conv");
  const acts = [];
  if (t.state === "pending" && t.pending_in) {
    acts.push('<button class="primary sm" onclick="dmAct(\'accept\')">接受</button>');
    acts.push('<button class="ghost sm" onclick="dmAct(\'reject\')">拒绝</button>');
  } else if (t.state === "accepted") {
    acts.push('<button class="ghost sm" onclick="dmAct(\'block\')">屏蔽</button>');
  }
  const head = `<div class="dm-conv-head"><b>${esc(t.peer.name || t.peer.id)}</b>
    <span class="sub">${esc(t.peer.full_name || "")}</span>
    <span class="tag">${esc(t.state)}</span><span style="flex:1"></span>${acts.join("")}</div>`;
  const bubbles = msgs.map(m => {
    const mine = m.from_me ? " me" : "";
    let inner;
    if (m.recalled) inner = '<span class="dm-recalled">这条消息已撤回</span>';
    else if (m.hidden) inner = '<span class="dm-recalled">请求：接受后可查看正文</span>';
    else {
      // 正文走 md（含 LaTeX/表格/链接），附件走 dmAttHTML（图片→相册，md→内联，其它→下载卡）
      inner = (m.body ? `<div class="dm-text">${linkifyPosts(mdToHtml(m.body))}</div>` : "")
        + dmAttHTML(m.attachments);
    }
    const del = (m.from_me && !m.recalled)
      ? `<button class="linkbtn dm-del" onclick="dmRecall('${esc(m.id)}')">撤回</button>` : "";
    return `<div class="dm-bubble${mine}">${inner}
      <div class="dm-meta">${esc(m.created_at)}${(m.read_at && mine) ? " · 已读" : ""} ${del}</div></div>`;
  }).join("");
  const canSend = t.state === "accepted" || (t.state === "pending" && t.is_requester);
  const composer = canSend
    ? `<div class="dm-composer">
         <input type="file" id="dm-file" accept="image/*" multiple style="display:none"
           onchange="dmPick(this,'image')">
         <input type="file" id="dm-doc" accept="${DM_DOC_ACCEPT}" multiple style="display:none"
           onchange="dmPick(this,'doc')">
         <div id="dm-pending" class="dm-pending" style="display:none"></div>
         <div class="dm-input-row">
           <textarea id="dm-input" placeholder="输入消息…（Enter 发送；可粘贴图片）"
             onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();dmSend();}"></textarea>
           <div class="dm-actions">
             <button class="linkbtn" title="发图片（≤9）" onclick="document.getElementById('dm-file').click()">🖼</button>
             <button class="linkbtn" title="发文档 md/txt/csv/pdf/docx" onclick="document.getElementById('dm-doc').click()">📎</button>
             <button class="primary sm" onclick="dmSend()">发送</button>
           </div>
         </div>
         <div id="dm-msg" class="sub dm-msg"></div>
       </div>`
    : `<div class="sub" style="padding:10px 14px">${t.state === "pending"
      ? "等待对方接受请求…" : "该会话不可发送（已屏蔽 / 已拒绝）"}</div>`;
  conv.innerHTML = head + `<div class="dm-msgs">${bubbles || '<div class="sub">还没有消息</div>'}</div>` + composer;
  const box = conv.querySelector(".dm-msgs");
  if (box) box.scrollTop = box.scrollHeight;
  const ta = document.getElementById("dm-input");
  if (ta) { ta.addEventListener("paste", dmPaste); ta.focus(); }
  dmRenderPending();
  renderMath(conv);
  hydrateAttachments(conv);     // md 附件内联渲染（内部会再跑 renderMath/renderMermaid）
  hydratePostCards(conv);
  if (t.state === "accepted" && t.unread) dmMarkRead(t.id);
}

async function dmSend() {
  const el = document.getElementById("dm-input");
  const body = (el && el.value || "").trim();
  if ((!body && !dmPending.length) || !dmCurrent) return;
  const btn = document.querySelector(".dm-composer .dm-actions .primary");
  if (btn) { btn.disabled = true; btn.textContent = "发送中…"; }
  try {
    await api("POST", `/v1/dm/threads/${dmCurrent}/messages`,
      { body, attachments: dmPending.map(a => ({ url: a.url, name: a.name, size: a.size })) });
    if (el) el.value = "";
    dmPending = [];
    await loadDm();
  } catch (e) {
    alert(e.error || "发送失败");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "发送"; }
  }
}
async function dmMarkRead(id) { try { await api("POST", `/v1/dm/threads/${id}/read`, {}); } catch (e) { } }
async function dmAct(act) {
  if (!dmCurrent) return;
  try { await api("POST", `/v1/dm/threads/${dmCurrent}/${act}`, {}); await loadDm(); }
  catch (e) { alert(e.error || "操作失败"); }
}
async function dmRecall(mid) {
  try { await api("POST", `/v1/dm/messages/${mid}/recall`, {}); await openDmThread(dmCurrent, true); }
  catch (e) { alert(e.error || "撤回失败"); }
}
async function updateDmBadge(n) {
  const btn = document.querySelector('.tabs button[data-tab="dm"]');
  if (!btn) return;
  if (n == null) { try { n = (await api("GET", "/v1/dm/threads")).unread_total; } catch (e) { return; } }
  btn.textContent = n ? `私聊 (${n})` : "私聊";
}


/* ---------------- 信源台（docs/83 + Owner 口径 2026-10-14）：**真人用**的两个页面 ----------------
   页面 A「信息收集」：**逐条文章详情页链接**（未采/已采）——真人一条一条点开去读（登录态），
                       点开即被采集；源只作筛选；栏目页/首页**只用于发现链接，本身不采集**。
   页面 B「汇总」：已采素材（时间倒序）+ **页内加工**（立即阅读 + 自动转发频道）。
   ------------------------------------------------------------------------- */
let collectFilter = "";

function collectStatusChip(l) {
  // 库里只有"看过的全文"：因此只有两种状态——已看（有全文）/ 还没看
  if (l.status === "captured" || l.cap_status === "raw") return '<span class="ok">已看·有全文</span>';
  return '<span class="sub">还没看</span>';
}

async function loadCollect() {
  const mid = document.getElementById("collect-body");
  const side = document.getElementById("thread");
  mid.innerHTML = '<div class="sub">加载中…</div>';
  let links, caps;
  try {
    const q = collectFilter ? ("?source=" + encodeURIComponent(collectFilter)) : "";
    links = await api("GET", "/v1/captures/links" + q);
    caps = await api("GET", "/v1/captures?limit=100" + (collectFilter ? ("&source=" + encodeURIComponent(collectFilter)) : ""));
  } catch (e) { mid.innerHTML = '<div class="sub">加载失败：' + esc(e.error || e) + '</div>'; return; }
  const srcs = links.sources || [], L = links.links || [], C = caps.captures || [];
  const TODO = L.filter(l => !(l.status === "captured" || l.cap_status === "raw"));

  // 中栏：文章链接清单（标题就是链接 → 点开去读原文；顺手自动保存，读完刷新这里就有 md）
  const srcs_bar = '<span class="collect-srcs">'
    + ['<a class="src' + (collectFilter ? "" : " on") + '" href="javascript:collectFilterSrc(\'\')">全部</a>']
      .concat(srcs.map(s => '<a class="src' + (collectFilter === s.id ? " on" : "") + '" href="javascript:collectFilterSrc(\''
        + esc(s.id) + '\')">' + esc(s.name || s.domain) + '</a>')).join("") + '</span>';
  const todo = TODO.map(l => '<div class="collect-row">'
    + '<a class="t" href="' + esc(l.url) + '" target="_blank" rel="noopener"'
    + ' onclick="collectFetch(' + l.id + ', \'' + esc(l.url) + '\')">' + esc(l.title || l.url) + '</a>'
    + '<span class="sub">' + esc((l.published_at || l.found_at || "").slice(0, 16)) + '</span></div>'
  ).join("") || '<div class="collect-empty">都读过了。</div>';
  mid.innerHTML = '<div class="collect-bar"><span class="collect-h">信息源文章 · ' + TODO.length + '</span>'
    + '<span class="grow"></span>' + srcs_bar + '</div><div class="collect-pane">' + todo + '</div>';

  // 最右栏：已保存的 md（读）＋ 原文（核查）＋ 解读（转写）
  const saved = C.length ? C.map(c => '<div class="collect-row">'
    + '<span class="t">' + esc(c.title || c.canonical_url) + '</span>'
    + '<span class="sub">' + (c.body_chars || 0) + ' 字</span>'
    + '<a class="linkbtn" href="' + esc(c.url || "") + '" target="_blank" rel="noopener" title="原站：与 md 比对核查">原文</a>'
    + '<a class="linkbtn" href="javascript:collectRead(' + c.id + ')" title="读保存在本机的内容">md</a>'
    + '<a class="linkbtn" href="javascript:collectProcess(' + c.id + ')">解读</a></div>').join("")
    : '<div class="collect-empty">还没有。读完一篇，刷新这里就有。</div>';
  side.innerHTML = '<div class="collect-bar"><span class="collect-h">已保存 · ' + C.length + ' 篇</span></div>'
    + '<div id="collect-reader" class="collect-reader" style="display:none"></div>'
    + '<div class="collect-hint" id="collect-hint">点［md］读本机内容；点［原文］与原站比对核查</div>'
    + '<div class="collect-pane">' + saved + '</div>';
}
function collectHint() {                       // ★ 收起：本轮重写 loadCollect 时被误删，导致「收起」失灵
  const el = document.getElementById("collect-reader");
  const hint = document.getElementById("collect-hint");
  if (el) { el.style.display = "none"; el.innerHTML = ""; }
  if (hint) hint.style.display = "block";
}
function collectFilterSrc(id) { collectFilter = id || ""; loadCollect(); }
async function collectFetch(linkId, url) {
  const box = document.getElementById("collect-body");
  if (box) box.dataset.busy = "1";
  try {
    const r = await api("POST", "/v1/captures/fetch", { url, link_id: linkId });
    if (r.saved) { alert("✅ 页面加载完整 → 已保存\n" + (r.path || "") +
      (r.metrics ? ("\n（正文 " + r.metrics.body_chars + " 字 / 源站公布 " + (r.metrics.reference_chars || "—") + " 字）") : "")); }
    else { alert("⛔ 判为不完整，未保存\n" + ((r.reasons || []).join("、") || r.error || "")); }
    loadCollect();
  } catch (e) { alert("失败：" + (e.error || e)); }
}
async function collectRead(id) {              // 点标题 → 右栏就地渲染 md（标题只出现一次）
  const el = document.getElementById("collect-reader");
  const hint = document.getElementById("collect-hint");
  if (el) { el.style.display = "block"; el.innerHTML = '<span class="sub">读取中…</span>'; }
  if (hint) hint.style.display = "none";
  try {
    const r = await fetch("/v1/captures/" + id + "/markdown");
    let text = (await r.text()).replace(/^---[\s\S]*?---\s*/, "");
    const line = (text.split("\n").find(x => x.trim().startsWith("# ")) || "").trim();
    const head = line.replace(/^#\s*/, "");
    text = text.replace(/^#\s.*$/m, "").replace(/^\s+/, "");   // ★ 正文里不再重复标题
    if (el) el.innerHTML = '<div class="collect-reader-h"><span class="rh-t">' + esc(head) + '</span>'
      + '<a class="linkbtn" href="javascript:collectHint()">收起</a></div>' + linkifyPosts(mdToHtml(text));
  } catch (e) { if (el) el.innerHTML = '<span class="bad">读不到这篇</span>'; }
}
async function collectShowInterpret(id) {   // 把四步产物逐块显示（立意/事实/成稿/三核查）
  const el = document.getElementById("collect-reader");
  const hint = document.getElementById("collect-hint");
  if (hint) hint.style.display = "none";
  if (el) { el.style.display = "block"; el.innerHTML = '<span class="sub">读取解读产物…</span>'; }
  try {
    const d = await api("GET", "/v1/captures/" + id + "/interpret");
    if (!d.intent && !d.draft) { if (el) el.innerHTML = '<span class="sub">还没有解读产物</span>'; return; }
    const mark = (ok, warn) => ok ? ' <span class="ok">通过</span>' : (warn ? ' <span class="sub">见缺口</span>' : ' <span class="bad">缺口</span>');
    const has = (s, ...ks) => ks.every(k => (s || "").includes(k));
    const factsN = (d.facts || "").split("\n").filter(l => l.trim().startsWith("-")).length;
    const fm = d.frontmatter || {};
    const hero = fm.hero_image
      ? '<img src="' + esc(fm.hero_largest || fm.hero_image) + '" alt="" style="width:100%;border-radius:8px;margin:4px 0 8px">'
      : "";
    const _by = (fm.byline || "").replace(/[\[\]"]/g, "").trim();
    // ★ 源站对赞助/合作内容会写 "No Author"——那不是作者，不该显示成作者名
    const by = (/^(no author|staff|editor|admin)$/i.test(_by) || !_by) ? "" : _by;
    const meta = [fm.published_at, by || (fm.published_at ? '<span title="源站未提供署名（常见于赞助/合作内容）">无署名</span>' : ""),
                  fm.url ? ("<a href='" + esc(fm.url) + "' target='_blank' rel='noopener'>原文</a>") : ""]
      .filter(Boolean).join(" · ");
    // ★ 成稿排最前（读者是来读文章的），其后才是流水线产物
    const blocks = [
      ["③ 成稿" + mark((d.draft || "").length > 300 && has(d.draft, "来源："), false),
        (meta ? '<div class="sub" style="margin-bottom:4px">' + meta + '</div>' : "") + hero + (d.draft || "")],
      ["① 立意" + mark(has(d.intent, "主论断", "子论断"), false), d.intent],
      ["② 事实编纂" + mark(factsN >= 6 && has(d.facts, "来源："), false), d.facts],
      ["④ 三核查" + mark(has(d.check, "PASS"), true), d.check],
    ].filter(x => x[1]).map((x, i) => '<div class="rh-block"' + (i === 0 ? ' style="border-top:0"' : "") + '>'
      + '<div class="rh-h">' + x[0] + '</div>' + linkifyPosts(mdToHtml(x[1])) + '</div>').join("");
    if (el) el.innerHTML = '<div class="collect-reader-h"><span class="rh-t">解读 · ' + id + '</span>'
      + '<a class="linkbtn" href="javascript:collectHint()">收起</a></div>' + blocks;
  } catch (e) { if (el) el.innerHTML = '<span class="bad">读不到解读产物</span>'; }
}
async function collectProcess(id) {
  const el = document.getElementById("collect-reader");
  const hint = document.getElementById("collect-hint");      // ★ 此前丢了定义 → 一点就 ReferenceError
  if (!id) { alert("该条目还没有入库"); return; }
  // ★ 已有产物 → 直接显示，**不重新生成**（Owner：钱多没地方花了吗）
  try {
    const d = await api("GET", "/v1/captures/" + id + "/interpret");
    const bad = s => !s || s.includes("[llm]") || s.includes("未找到命令") || s.length < 200;
    if (d && (d.draft || d.intent) && !bad(d.draft) && !bad(d.intent)) {
      collectShowInterpret(id); return;      // 有效产物 → 直接显示
    }
    if (el) { el.style.display = "block"; el.innerHTML = '<span class="sub">还没有解读产物 → 开始生成（①②③④，1–3 分钟）</span>'; }
  } catch (e) { /* 取不到就当没有，走生成 */ }
  if (hint) hint.style.display = "none";
  try {
    const r = await api("POST", "/v1/captures/process", { ids: [Number(id)] });
    if (!r.ok) { if (el) el.innerHTML = '<span class="bad">起不来：' + esc(r.error || "") + '</span>'; return; }
  } catch (e) { if (el) el.innerHTML = '<span class="bad">失败：' + esc(e.error || e) + '</span>'; return; }
  for (let i = 0; i < 40; i++) {                       // 最多轮询 ~3 分钟
    await new Promise(res => setTimeout(res, 5000));
    let j = {};
    try { j = await api("GET", "/v1/captures/" + id + "/job"); } catch (e) { continue; }
    if (j.status === "ok") {
      if (j.post_id) { if (el) el.innerHTML = '<span class="ok">✅ 已出稿</span> 帖子 ' + esc(j.post_id)
        + ' <span class="sub">去 #reading 看</span>'; }
      collectShowInterpret(id); return;
    }
    if (j.status && j.status !== "ok") {        // 失败态：先看有没有产物，有就照样显示
      try { const art = await api("GET", "/v1/captures/" + id + "/interpret");
            if (art && (art.draft || art.intent)) { collectShowInterpret(id); return; } } catch (e) {}
      if (el) el.innerHTML = '<span class="bad">解读失败：' + esc(j.detail || j.status) + '</span> '
        + '<a class="linkbtn" href="javascript:collectProcess(' + id + ')">重试</a>'; return;
    }
    try {                                        // 兜底：产物先出来就先显示
      const art = await api("GET", "/v1/captures/" + id + "/interpret");
      if (art && art.draft) { collectShowInterpret(id); return; }
    } catch (e) { /* 继续轮询 */ }
  }
  collectShowInterpret(id);
}
