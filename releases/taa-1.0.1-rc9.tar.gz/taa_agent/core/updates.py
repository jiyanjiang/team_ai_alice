"""Local TAA update checker / downloader / detached installer.

Design defaults:
  mode=download
  check_at=10:07,20:07 local time
  no more than 2 automatic checks/day and 1 automatic apply/day

The updater never copies data itself; it invokes ``taa_upgrade.py`` which owns
the protected-data/atomic-swap/rollback contract.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import random
import re
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HOME = Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")).expanduser()
STATE = HOME / "update.json"
UPDATES = HOME / "updates"
LATEST_API = "https://api.github.com/repos/jiyanjiang/team_ai_alice/contents/releases/latest.json?ref=main"
LATEST_RAW = "https://raw.githubusercontent.com/jiyanjiang/team_ai_alice/main/releases/latest.json"
DEFAULT_URL = os.environ.get("TAA_UPDATE_URL", LATEST_API)
LOCK = threading.Lock()
_scheduler_started = False

DEFAULT = {
    "enabled": True,
    "mode": "download",          # notify | download | auto
    "channel": "beta",
    "check_at": ["10:07", "20:07"],
    "jitter_seconds": 600,
    "last_check_at": "",
    "last_check_day": "",
    "checks_today": 0,
    "checked_slots": [],
    "last_apply_at": "",
    "last_apply_day": "",
    "applies_today": 0,
    "latest": None,
    "downloaded": None,
    "last_error": "",
    "last_result": "",
    # 自动安装次数上限（检测固定 2 次/天，见 _due）。做成参数而不是硬编码：
    # rc 阶段一天装两次 = 一天可能回滚两次，收益低风险高（2026-11-06 定）。
    "max_auto_apply_per_day": 1,
    # 当日是否已补检过：错过 slot 窗口时兜住「每天至少检查一次」。
    "catch_up_day": "",
    # 正在安装中的版本：apply() 起的是后台子进程，结局要回头结算。
    "pending_version": "",
    # {ver: {count, last_phase, at, error}}：装失败（回滚）过的版本，
    # 命中即不再自动重试——否则每天 applies_today 归零就重装一次，形成日循环。
    "failed_versions": {},
}


def _load() -> dict:
    data = dict(DEFAULT)
    try:
        raw = json.loads(STATE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            data.update(raw)
    except Exception:
        pass
    today = date.today().isoformat()
    if data.get("last_check_day") != today:
        data["last_check_day"] = today
        data["checks_today"] = 0
        data["checked_slots"] = []
    if data.get("last_apply_day") != today:
        data["last_apply_day"] = today
        data["applies_today"] = 0
    return data


def _save(data: dict) -> None:
    HOME.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    os.replace(tmp, STATE)


def current_version() -> str:
    for p in (ROOT / "VERSION", ROOT / "dist" / "VERSION"):
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            continue
    return "0.0.0"


def _ver(v: str) -> tuple:
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?", str(v or ""))
    if not m:
        return (0, 0, 0, 0, ())
    pre = tuple(int(x) if x.isdigit() else x for x in (m.group(4) or "").split(".") if x)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)),
            0 if pre else 1, pre)


def version_gt(a: str, b: str) -> bool:
    return _ver(a) > _ver(b)


def _fetch(url: str, timeout: int = 15) -> dict:
    req = urllib.request.Request(url, headers={
        "user-agent": "TAA-Updater/1.0",
        "accept": "application/vnd.github+json, application/json",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read(2_000_000)
    data = json.loads(raw.decode("utf-8"))
    if isinstance(data, dict) and data.get("content") and data.get("encoding") == "base64":
        data = json.loads(base64.b64decode(data["content"]).decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("latest.json is not an object")
    return data


def _fetch_any() -> dict:
    """Try the Contents API first, then the plain raw manifest.

    The API hostname can fail DNS independently of raw.githubusercontent.com;
    a manual check must not be stuck on one hostname.
    """
    errors = []
    urls = [LATEST_RAW] if "api.github.com" in DEFAULT_URL else [DEFAULT_URL]
    if LATEST_RAW not in urls:
        urls.append(LATEST_RAW)
    urls.append(DEFAULT_URL)
    seen = set()
    for url in urls:
        if url in seen:
            continue
        seen.add(url)
        try:
            return _fetch(url, timeout=4)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{url}: {type(exc).__name__}")
    raise RuntimeError("; ".join(errors) or "manifest unavailable")


def _safe_download(url: str, dest: Path, sha: str, size: int = 0) -> None:
    UPDATES.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    h = hashlib.sha256()
    total = 0
    req = urllib.request.Request(url, headers={"user-agent": "TAA-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=60) as resp, part.open("wb") as out:
        while True:
            chunk = resp.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if size and total > size:
                raise ValueError("package larger than manifest")
            h.update(chunk)
            out.write(chunk)
    if sha and h.hexdigest() != sha:
        part.unlink(missing_ok=True)
        raise ValueError("package sha256 mismatch")
    if size and total != size:
        part.unlink(missing_ok=True)
        raise ValueError("package size mismatch")
    os.replace(part, dest)


def _upgrade_phase() -> str:
    """读升级日志里的 phase。

    apply() 起的是后台子进程，它失败回滚后只把结论写在这里，
    没有回写 update.json —— 所以 update.json 的 last_result 会永远停在
    "applying"（2026-11-06 实况：已 ROLLED_BACK，界面一直显示「安装中」）。
    """
    try:
        raw = json.loads((HOME / "upgrade.state.json").read_text(encoding="utf-8"))
        return str(raw.get("phase") or "").upper()
    except Exception:  # noqa: BLE001
        return ""


_ROLLBACK_PHASES = ("ROLLED_BACK", "ROLLBACK", "FAILED")
_COMMITTED_PHASE = "COMMITTED"


def _journal() -> dict:
    try:
        return json.loads((HOME / "upgrade.state.json").read_text(encoding="utf-8")) or {}
    except Exception:  # noqa: BLE001
        return {}


def _blocked_versions(s: dict) -> dict[str, dict]:
    data = s.get("failed_versions")
    return data if isinstance(data, dict) else {}


def _is_blocked(s: dict, ver: str) -> bool:
    """这个版本是否已被熔断（装过一次、回滚了，就不再自动重试）。"""
    return bool(ver) and ver in _blocked_versions(s)


def _settle_pending(s: dict) -> bool:
    """把上一次 apply 的结局落账：成功清账，失败记一次并熔断该版本。

    为什么必须做（2026-11-06 复盘）：apply() 起的是后台子进程，它失败回滚后
    只写 `upgrade.state.json`，从不回写 update.json。于是第二天 applies_today
    归零，同一个坏包又被装一次、又回滚一次——"每天自动回滚一次"的日循环。
    这里回读 journal 结算，并清掉本地坏包。
    """
    ver = str(s.get("pending_version") or "")
    if not ver:
        return False
    j = _journal()
    phase = str(j.get("phase") or "").upper()
    src = str(j.get("source") or "")
    # journal 只保留最后一次升级；用 source 里的 extract-<ver> 认领归属。
    same = (ver in src) or (not src)
    if not same:
        return False
    if phase in _ROLLBACK_PHASES:
        got = dict(_blocked_versions(s))
        rec = dict(got.get(ver) or {})
        rec["count"] = int(rec.get("count") or 0) + 1
        rec["last_phase"] = str(j.get("failed_phase") or phase)
        rec["at"] = datetime.now().isoformat(timespec="seconds")
        rec["error"] = str(j.get("error") or "")[:200]
        got[ver] = rec
        s["failed_versions"] = got
        s["pending_version"] = ""
        s["downloaded"] = None          # 坏包不留，免得下次直接复用
        s["last_result"] = "rolled_back"
        s["last_error"] = (f"{ver} 安装失败（{rec['last_phase']}），已回滚到原版本并暂停该版本"
                           f"自动重试；可手动重试或等下一版")
        return True
    if phase == _COMMITTED_PHASE:
        got = dict(_blocked_versions(s))
        got.pop(ver, None)                  # 手动重试成功后解除熔断
        s["failed_versions"] = got
        s["pending_version"] = ""
        s["downloaded"] = None
        s["last_result"] = "committed"
        s["last_error"] = ""
        return True
    return False


def _state(s: dict) -> str:
    """Single UI/API state machine for the update card.

    unchecked -> available -> downloaded -> applying -> current
                         \\-> failed
    """
    current = current_version()
    latest = s.get("latest") or {}
    downloaded = s.get("downloaded") or {}
    latest_v = str(latest.get("version") or "")
    downloaded_v = str(downloaded.get("version") or "")
    available = bool(latest_v and version_gt(latest_v, current))
    if latest_v and not available:
        return "current"
    if s.get("last_error"):
        return "failed"
    if str(s.get("last_result") or "") == "applying":
        if downloaded_v and not version_gt(downloaded_v, current):
            return "current"
        if _upgrade_phase() in _ROLLBACK_PHASES:
            return "failed"
        return "applying"
    if downloaded_v and version_gt(downloaded_v, current):
        return "downloaded"
    if available:
        return "available"
    if latest_v:
        return "current"
    return "unchecked"


def status() -> dict:
    s = _load()
    if _settle_pending(s):
        _save(s)
    latest = s.get("latest") or {}
    downloaded = s.get("downloaded") or {}
    current = current_version()
    latest_v = str(latest.get("version") or "")
    downloaded_v = str(downloaded.get("version") or "")
    state = _state(s)
    last_error = s.get("last_error", "")
    if not last_error and state == "failed" and _upgrade_phase() in _ROLLBACK_PHASES:
        last_error = "上次安装未成功，已回滚到原版本（日志：~/.taa/updates/updater.log）"
    last_result = str(s.get("last_result") or "")
    if state == "current" and last_result == "applying":
        # 升级成功后后台进程同样不回写；版本已相等即可判完成，避免字段永远停在 applying
        last_result = "committed"
    return {
        "current": current,
        "latest": latest_v,
        "available": bool(latest_v and version_gt(latest_v, current)),
        "state": state,
        "mode": s.get("mode", "download"),
        "check_at": s.get("check_at", []),
        "last_check_at": s.get("last_check_at", ""),
        "last_error": last_error,
        "downloaded": downloaded.get("path", ""),
        "downloaded_version": downloaded_v,
        "last_result": last_result,
        "notes_url": latest.get("notes_url", ""),
        "bytes": latest.get("bytes", 0),
        "pending_version": s.get("pending_version", ""),
        "blocked": _is_blocked(s, latest_v),
        "blocked_versions": sorted(_blocked_versions(s)),
        "max_auto_apply_per_day": int(s.get("max_auto_apply_per_day") or 1),
    }


def check(force: bool = False, manual: bool = False) -> dict:
    with LOCK:
        s = _load()
        if _settle_pending(s):
            _save(s)
        if not s.get("enabled", True) and not force:
            return {"ok": False, "error": "updates disabled", **status()}
        try:
            latest = _fetch_any()
            if str(latest.get("product") or "TAA") != "TAA":
                raise ValueError("not a TAA manifest")
            s["latest"] = latest
            s["last_error"] = ""
            s["last_result"] = "checked"
            s["last_check_at"] = datetime.now().isoformat(timespec="seconds")
            s["last_check_day"] = date.today().isoformat()
            s["catch_up_day"] = date.today().isoformat()
            if not manual:
                s["checks_today"] = int(s.get("checks_today") or 0) + 1
                slot = f"{date.today().isoformat()}T{datetime.now().strftime('%H:%M')}"
                slots = list(s.get("checked_slots") or [])
                if slot not in slots:
                    slots.append(slot)
                s["checked_slots"] = slots[-6:]
            else:
                s["manual_checks_total"] = int(s.get("manual_checks_total") or 0) + 1
            _save(s)
            available = bool(latest.get("version") and version_gt(str(latest["version"]), current_version()))
            if available and _is_blocked(s, str(latest.get("version") or "")):
                # 熔断：这个版本装过并回滚过，不再自动下载/重试，等下一版。
                s = _load()
                s["last_result"] = "blocked"
                s["downloaded"] = None
                _save(s)
                return {**status(), "ok": True, "blocked": True}
            if available and s.get("mode") in ("download", "auto"):
                try:
                    download()
                except Exception as exc:  # noqa: BLE001
                    s = _load()
                    s["last_error"] = str(exc)
                    _save(s)
            return {"ok": True, **status()}
        except Exception as exc:  # noqa: BLE001
            s = _load()
            raw = str(exc)
            if "nodename nor servname" in raw or "Name or service" in raw or "Temporary failure" in raw:
                s["last_error"] = "网络暂不可用（DNS 解析失败）；已保留上次检查结果"
            elif "timed out" in raw.lower() or "TimeoutError" in raw or "timeout" in raw.lower():
                s["last_error"] = "网络暂不可用（连接超时）；已保留上次检查结果"
            else:
                s["last_error"] = raw
            s["last_check_at"] = datetime.now().isoformat(timespec="seconds")
            _save(s)
            return {"ok": False, "error": s["last_error"], **status()}


def start_check(*, manual: bool = True) -> dict:
    """Start a check without blocking an HTTP page on DNS/network latency."""
    threading.Thread(target=lambda: check(force=True, manual=manual),
                     name="taa-update-manual-check", daemon=True).start()
    return {"ok": True, "checking": True, **status()}


def download(force: bool = False) -> dict:
    s = _load()
    latest = s.get("latest") or {}
    ver = str(latest.get("version") or "")
    if not ver:
        return {"ok": False, "error": "no latest version"}
    if not version_gt(ver, current_version()):
        return {"ok": False, "error": "not newer"}
    if _is_blocked(s, ver):
        return {"ok": False, "blocked": True,
                "error": f"{ver} 安装失败过，已暂停自动重试（可手动重试）"}
    url = str(latest.get("url") or "")
    if not url.startswith("https://"):
        return {"ok": False, "error": "unsafe update URL"}
    UPDATES.mkdir(parents=True, exist_ok=True)
    dest = UPDATES / f"taa-{ver}.tar.gz"
    try:
        _safe_download(url, dest, str(latest.get("sha256") or ""), int(latest.get("bytes") or 0))
        s["downloaded"] = {"version": ver, "path": str(dest),
                           "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()}
        s["last_error"] = ""
        s["last_result"] = "downloaded"
        _save(s)
        _notify(
            "TAA update downloaded",
            f"v{ver} 已下载，可在版本页安装并重启。",
            f"p-{ver}",
        )
        return {"ok": True, **status()}
    except Exception as exc:  # noqa: BLE001
        s["last_error"] = str(exc)
        _save(s)
        return {"ok": False, "error": str(exc), **status()}


def _notify(title: str, body: str, ref: str) -> None:
    """Best-effort local inbox notification for every local AI agent."""
    try:
        from core import db, community
        conn = db.connect()
        try:
            for row in conn.execute("SELECT id FROM agents WHERE kind='ai'"):
                try:
                    community.add_notification(conn, row["id"], "update", ref, f"{title}：{body}")
                except Exception:
                    pass
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def _is_idle() -> bool:
    try:
        from core import db
        conn = db.connect()
        try:
            busy = conn.execute(
                "SELECT 1 FROM tasks WHERE status IN ('claimed','in_progress','review') LIMIT 1"
            ).fetchone()
            room = conn.execute("SELECT 1 FROM rooms WHERE status='running' LIMIT 1").fetchone()
            return not busy and not room
        finally:
            conn.close()
    except Exception:
        return False


def apply(manual: bool = False) -> dict:
    s = _load()
    if _settle_pending(s):
        _save(s)
    limit = int(s.get("max_auto_apply_per_day") or 1)
    if not manual and s.get("mode") == "auto" and int(s.get("applies_today") or 0) >= limit:
        return {"ok": True, "deferred": True, "reason": "daily auto-apply limit", **status()}
    d = s.get("downloaded") or {}
    ver = str(d.get("version") or "")
    pkg = Path(str(d.get("path") or ""))
    if not ver or not pkg.exists():
        return {"ok": False, "error": "no downloaded package"}
    if not version_gt(ver, current_version()):
        return {"ok": False, "error": "not newer"}
    if not manual and _is_blocked(s, ver):
        # 注意顺序：status() 也带 blocked 字段，必须让它先展开再覆盖，否则会被冲掉。
        return {**status(), "ok": False, "blocked": True,
                "error": f"{ver} 安装失败过，已暂停自动重试（可手动重试）"}
    if not manual and s.get("mode") == "auto" and not _is_idle():
        s["last_result"] = "deferred_busy"
        _save(s)
        return {"ok": True, "deferred": True, **status()}
    extract = UPDATES / f"extract-{ver}"
    try:
        if extract.exists():
            import shutil
            shutil.rmtree(extract)
        extract.mkdir(parents=True)
        with tarfile.open(pkg, "r:gz") as tf:
            try:
                tf.extractall(extract, filter="data")  # Python 3.12+
            except TypeError:
                tf.extractall(extract)
        src = extract / "taa_agent"
        updater = ROOT / "taa_upgrade.py"
        if not updater.exists():
            updater = ROOT / "scripts" / "taa_upgrade.py"
        if not updater.exists():
            return {"ok": False, "error": "taa_upgrade.py missing"}
        env = dict(os.environ, TAA_HOME=str(HOME), TAA_HTTP_PORT=os.environ.get("TAA_HTTP_PORT", "6080"))
        log_path = UPDATES / "updater.log"
        UPDATES.mkdir(parents=True, exist_ok=True)
        with log_path.open("ab") as log_fp:
            log_fp.write(f"\n=== {datetime.now().isoformat(timespec='seconds')} apply {ver} ===\n".encode())
            log_fp.flush()
            subprocess.Popen(
                [sys.executable, str(updater), "--source", str(src), "--home", str(HOME),
                 "--port", os.environ.get("TAA_HTTP_PORT", "6080"),
                 "--python", sys.executable, "--no-open"],
                env=env, cwd=str(HOME / "app"), stdin=subprocess.DEVNULL,
                stdout=log_fp, stderr=log_fp, start_new_session=True,
            )
        s["last_apply_at"] = datetime.now().isoformat(timespec="seconds")
        s["last_apply_day"] = date.today().isoformat()
        s["pending_version"] = ver          # 后台进程的结局要靠 _settle_pending 回读
        if manual:
            s["manual_applies_total"] = int(s.get("manual_applies_total") or 0) + 1
        else:
            s["applies_today"] = int(s.get("applies_today") or 0) + 1
        s["last_result"] = "applying"
        s["last_error"] = ""
        _save(s)
        return {"ok": True, "started": True, **status()}
    except Exception as exc:  # noqa: BLE001
        s["last_error"] = str(exc)
        _save(s)
        return {"ok": False, "error": str(exc), **status()}


def _slot_targets(check_at, now: datetime) -> list[datetime]:
    out: list[datetime] = []
    for hm in check_at or []:
        try:
            h, m = [int(x) for x in str(hm).split(":")]
        except Exception:
            continue
        out.append(now.replace(hour=h, minute=m, second=0, microsecond=0))
    return sorted(out)


def _due() -> bool:
    s = _load()
    if not s.get("enabled", True):
        return False
    if int(s.get("checks_today") or 0) >= 2:
        return False
    now = datetime.now()
    today = date.today().isoformat()
    try:
        last = datetime.fromisoformat(str(s.get("last_check_at") or ""))
        if last.date() == now.date() and abs((now - last).total_seconds()) < 30 * 60:
            return False
    except Exception:
        pass
    jitter = timedelta(seconds=min(600, int(s.get("jitter_seconds") or 0)))
    slots = set(s.get("checked_slots") or [])
    targets = _slot_targets(s.get("check_at"), now)
    for target in targets:
        if f"{today}T{target.strftime('%H:%M')}" in slots:
            continue
        due = target + jitter
        if due <= now < due + timedelta(minutes=30):
            return True
    # 补检（catch-up）：机器在窗口期关机就永远打不上卡，会一整天零检查。
    # 「每天至少检查一次」靠这里兜住：当天最后一个 slot 的窗口已彻底错过、
    # 今天还一次没查、且今天没补过 → 补一次（总上限仍是 2 次/天）。
    if (targets and int(s.get("checks_today") or 0) == 0
            and str(s.get("catch_up_day") or "") != today
            and now >= targets[-1] + jitter + timedelta(minutes=30)):
        return True
    return False


def _loop() -> None:
    while True:
        try:
            if _due():
                check()
                s = _load()
                if s.get("mode") == "auto" and s.get("downloaded"):
                    apply()
        except Exception:
            pass
        time.sleep(45)


def start_scheduler() -> None:
    global _scheduler_started
    if _scheduler_started or os.environ.get("TAA_UPDATE_DISABLE") == "1":
        return
    _scheduler_started = True
    threading.Thread(target=_loop, name="taa-update-check", daemon=True).start()
