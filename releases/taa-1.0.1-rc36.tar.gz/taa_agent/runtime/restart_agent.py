#!/usr/bin/env python3
"""restart_agent —— 更新后自动收敛为单套 agent 进程。

由 self-update / restart-executor 命令调用；不依赖人工在 B 机敲 kill/启动命令。

行为：
  1. 单实例锁，避免两个 updater 互相打架；
  2. 找到同一 agent 的旧 supervisor/loop/dispatcher/chatroom_agent；
  3. 先停 supervisor，再停子进程；清掉旧锁；
  4. 用当前解释器启动**一个**新 supervisor；
  5. 状态写入 runtime/.restart.<agent>.json。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

try:                       # 脚本直跑（sys.path 含 runtime/）或 dist/ 平铺
    from procutil import pid_alive
except ImportError:        # 被 `from runtime import x` 当包导入时（门禁测试就这么导）
    from core.procutil import pid_alive

ROOT = Path.cwd()
# 2026-11-14 B 端 G5：Windows 路径是反斜杠，原来只认 `/`，
# `C:\...\app\runtime\supervisor.py` 一条都匹配不上 → 收敛永远落空。
AGENT_RE = re.compile(r"(?:[\\/]|^)(?:runtime|dist)[\\/]"
                      r"(?:supervisor|loop|dispatcher|chatroom_agent)\.py\b")
START_ORDER = ("supervisor", "loop", "dispatcher", "chatroom_agent")


def _alive(pid: int) -> bool:
    return pid_alive(pid)


def _lock(agent: str) -> bool:
    p = ROOT / "runtime" / f".restart.{agent}.lock"
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        try:
            old = int(p.read_text(encoding="utf-8").strip() or "0")
            if _alive(old):
                print(f"[restart] 已有 updater 在跑 pid={old}，退出")
                return False
        except Exception:  # noqa: BLE001
            pass
        p.write_text(str(os.getpid()), encoding="utf-8")
    return True


def _ps_output() -> str:
    """`pid command` 一行一条。Windows 上没有 `ps`。

    2026-11-14 B 端 G5 实证：原来无条件 `check_output(["ps", ...])`，Windows 报
    `[WinError 2] 系统找不到指定的文件` → found 0 → 旧套一个都没停 → 又起一套，
    同机出现两套 supervisor。这里改走 CIM，顺便才能拿到带反斜杠的 Windows 路径。
    """
    if os.name != "nt":
        return subprocess.check_output(["ps", "-axo", "pid=,command="], text=True,
                                       timeout=20)
    script = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine } | "
              "ForEach-Object { \"$($_.ProcessId) $($_.CommandLine)\" }")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                       capture_output=True, text=True, errors="replace", timeout=40)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or "").strip()[:200] or f"powershell rc={r.returncode}")
    return r.stdout or ""


def _procs(agent: str) -> list[tuple[int, str, str]]:
    """返回 [(pid, kind, command)]，只匹配同一 agent。"""
    try:
        out = _ps_output()
    except Exception as e:  # noqa: BLE001
        print(f"[restart] ps failed: {e}")
        return []
    found: list[tuple[int, str, str]] = []
    for line in out.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            pid_s, cmd = line.split(None, 1)
            pid = int(pid_s)
        except ValueError:
            continue
        if str(pid) == str(os.getpid()) or not AGENT_RE.search(cmd):
            continue
        # 只匹配 --as <agent>，避免误杀同机其他 agent
        if not re.search(r"(?:^|\s)--as\s+" + re.escape(agent) + r"(?:\s|$)", cmd):
            continue
        kind = "unknown"
        for k in START_ORDER:
            if f"{k}.py" in cmd:
                kind = k
                break
        found.append((pid, kind, cmd))
    # supervisor 优先停，避免它继续拉起子进程
    found.sort(key=lambda x: START_ORDER.index(x[1]) if x[1] in START_ORDER else 99)
    return found


def _stop(procs: list[tuple[int, str, str]]) -> None:
    for pid, kind, _cmd in procs:
        if not _alive(pid):
            continue
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"[restart] SIGTERM {kind} pid={pid}")
        except Exception:  # noqa: BLE001
            pass
    deadline = time.time() + 8
    while time.time() < deadline and any(_alive(p[0]) for p in procs):
        time.sleep(0.2)
    for pid, kind, _cmd in procs:
        if _alive(pid):
            try:
                os.kill(pid, signal.SIGKILL)
                print(f"[restart] SIGKILL {kind} pid={pid}")
            except Exception:  # noqa: BLE001
                pass


def _clean_locks(agent: str) -> None:
    for name in (f".supervisor.{agent}.lock", f".chatroom.{agent}.lock",
                 f".dispatcher.{agent}.lock"):
        p = ROOT / "runtime" / name
        try:
            p.unlink()
            print(f"[restart] removed stale lock {name}")
        except FileNotFoundError:
            pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--as", dest="agent", required=True)
    ap.add_argument("--url", required=True)
    ap.add_argument("--role", choices=["executor", "coordinator"], default="executor")
    ap.add_argument("--interval", type=int, default=5)
    a = ap.parse_args()
    if not _lock(a.agent):
        return 0

    old = _procs(a.agent)
    print(f"[restart] found {len(old)} old process(es) for {a.agent}")
    _stop(old)
    _clean_locks(a.agent)

    log = ROOT / "runtime" / f"{a.agent}-supervisor.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    out = open(log, "ab")
    env = dict(os.environ)
    env["TEAMAI_URL"] = a.url
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    cmd = [sys.executable, "-u", str(ROOT / "runtime" / "supervisor.py"),
           "--as", a.agent, "--role", a.role, "--interval", str(a.interval),
           "--url", a.url]
    try:
        proc = subprocess.Popen(cmd, cwd=str(ROOT), env=env,
                                stdin=subprocess.DEVNULL, stdout=out, stderr=out,
                                start_new_session=True)
    except Exception as e:  # noqa: BLE001
        status = {"ok": False, "error": str(e), "at": time.strftime("%Y-%m-%d %H:%M:%S")}
        (ROOT / "runtime" / f".restart.{a.agent}.json").write_text(
            json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[restart] start failed: {e}")
        return 1

    status = {"ok": True, "pid": proc.pid, "agent": a.agent, "url": a.url,
              "stopped": [p[0] for p in old],
              "at": time.strftime("%Y-%m-%d %H:%M:%S")}
    (ROOT / "runtime" / f".restart.{a.agent}.json").write_text(
        json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[restart] started supervisor pid={proc.pid}")
    try:
        (ROOT / "runtime" / f".restart.{a.agent}.lock").unlink()
    except FileNotFoundError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
