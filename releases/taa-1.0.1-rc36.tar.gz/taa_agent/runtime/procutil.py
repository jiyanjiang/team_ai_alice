"""进程存活探测（runtime 副本：sys.path 里没有仓库根，不能 import core）。

**为什么必须集中到这一个函数**（2026-11-11 B 端事故）：
Windows 上 `os.kill(pid, 0)` 不是"探活"，而是
`TerminateProcess(handle, 0)` —— 探一下就真把目标进程杀掉（退出码 0）。
于是 `try: os.kill(pid,0); return True` 这种写法在 Windows 上变成
「判定存活的同时把对方干掉」，表现为：
  - supervisor 每被 chatroom 探一次就消失一次（`no live supervisor` 反复出现）；
  - launcher 那套 supervisor(interval 30) 与 chatroom 自愈拉起的 supervisor(interval 5) 并存；
  - dispatcher / loop 莫名退出，任务停在 in_progress。
POSIX 上 `os.kill(pid, 0)` 才是合法的探活方式（只发空信号）。

`runtime/procutil.py` 是本文件的同源副本（runtime 脚本的 sys.path 不含仓库根，
不能 `import core`）。**两边改动必须同步**。
"""
from __future__ import annotations

import errno
import os


def pid_alive(pid: int) -> bool:
    """进程是否还活着。绝不产生副作用（Windows 上不会误杀）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        # 非法值：os.kill(0, ...) 在 POSIX 会波及整个进程组，必须拒绝
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        return _pid_alive_windows(pid)
    try:
        os.kill(pid, 0)
        return True
    except OSError as exc:
        return getattr(exc, "errno", None) == errno.EPERM
    except Exception:                                              # noqa: BLE001
        return False


def _pid_alive_windows(pid: int) -> bool:
    import ctypes
    from ctypes import wintypes

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)          # type: ignore[attr-defined]
    k32.OpenProcess.restype = wintypes.HANDLE
    k32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    handle = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
    if not handle:
        # 打不开句柄（进程不存在 / 权限不足）一律按"不在"处理：宁可少判活，不可误杀。
        return False
    try:
        code = wintypes.DWORD()
        if not k32.GetExitCodeProcess(handle, ctypes.byref(code)):
            return False
        return code.value == STILL_ACTIVE
    finally:
        k32.CloseHandle(handle)
