"""Gate 3: connect local node identity to the center claim flow."""
from __future__ import annotations

import pathlib
from typing import Any

from .center import CenterClient, CenterError
from .identity import IdentityState, install_ref, load_state, now_iso, save_state
from . import product_version


def _summary(state: IdentityState) -> dict[str, Any]:
    return {
        "owner_id": state.center.owner_id,
        "owner_username": state.center.username,
        "node_id": state.node.node_id,
        "node_alias": state.node.alias,
        "node_status": state.node.status,
        "center": {
            "base": state.center.base,
            "owner_id": state.center.owner_id,
            "claimed_at": state.center.claimed_at,
        },
        "agents": [
            {"agent_id": agent.agent_id, "name": agent.display_name, "status": agent.status}
            for agent in state.agents
        ],
    }


def _staged(exc: CenterError, stage: str, path: str) -> CenterError:
    """给中心异常补上"哪一步 / 哪个接口"，供 `_center_error()` 渲染可读提示。

    为什么要这个（docs/547 §6）：失败信息必须指向"第几步、哪个接口、返回什么"，
    否则用户只看到 `center HTTP 403: {}`，排障只能靠翻日志。
    """
    body = exc.body if isinstance(exc.body, dict) else {"error": str(exc.body)[:200]}
    return CenterError(exc.status, {**body, "stage": stage, "path": path, "step": 2})


def _call(stage: str, path: str, fn, **kwargs: Any) -> dict[str, Any]:
    try:
        return fn(**kwargs)
    except CenterError as exc:
        raise _staged(exc, stage, path) from exc


def connect(
    home: pathlib.Path,
    *,
    base: str,
    username: str,
    password: str,
    create_owner: bool = False,
    email: str = "",
    register_agents: bool = True,
    ref: str = "",
) -> dict[str, Any]:
    home = pathlib.Path(home).expanduser()
    state = load_state(home)
    client = CenterClient(base)
    # 安装器 `--ref` 落盘的推荐码：注册时带上，中心据此直接建好友（免批准）。
    ref = ref or install_ref(home)

    claim_token: str | None = None
    node_owner_id: str | None = None
    try:
        registered = _call(
            "register_node", "/v05/node/register", client.register_node,
            node_id=state.node.node_id,
            node_key=state.node.node_key,
            alias=state.node.alias,
            fingerprint_hash=state.node.fingerprint_hash,
            version=product_version(home),
            enc_pubkey=state.node.enc_pubkey,
        )
        claim_token = registered.get("claim_token")
    except CenterError as exc:
        if exc.status != 409:
            raise
        current = client.node_me(node_key=state.node.node_key)
        node = current.get("node") or {}
        node_owner_id = node.get("owner_id") or None
        if node.get("status") == "pending_owner":
            refreshed = client.refresh_claim(node_key=state.node.node_key)
            claim_token = refreshed.get("claim_token")
            node_owner_id = None
        elif node.get("status") != "active":
            raise

    if create_owner:
        owner = _call("owner_register", "/v05/owner/register", client.owner_register,
                      username=username, password=password, email=email, ref=ref)
    else:
        owner = _call("owner_login", "/v05/owner/login", client.owner_login,
                      username=username, password=password)
    owner_token = owner.get("owner_token") or ""
    center_owner = owner.get("owner") or {}
    center_owner_id = str(center_owner.get("owner_id") or "")
    if not owner_token or not center_owner_id:
        raise RuntimeError("center did not return owner session")

    if node_owner_id and node_owner_id != center_owner_id:
        raise RuntimeError("node belongs to a different owner")
    if claim_token:
        _call("claim_node", "/v05/node/claim", client.claim_node,
              owner_token=owner_token, claim_token=claim_token)
    else:
        # Already active; verify owner identity from center.
        current = client.node_me(node_key=state.node.node_key)
        node = current.get("node") or {}
        if node.get("status") != "active" or node.get("owner_id") != center_owner_id:
            raise RuntimeError("node is not active for this owner")

    if register_agents:
        for agent in state.agents:
            try:
                result = client.register_agent(
                    node_key=state.node.node_key,
                    agent_id=agent.agent_id,
                    agent_key=agent.agent_key,
                    display_name=agent.display_name,
                )
                assigned = str((result.get("agent") or {}).get("display_name") or "")
                if assigned:
                    agent.display_name = assigned
            except CenterError as exc:
                # A retry after a partial registration is safe only for 409;
                # other failures remain visible to the caller.
                if exc.status != 409:
                    raise
                try:
                    me = client.agent_me(agent_key=agent.agent_key)
                    assigned = str((me.get("agent") or {}).get("display_name") or "")
                    if assigned:
                        agent.display_name = assigned
                except Exception:  # noqa: BLE001
                    pass

    state.node.status = "active"
    # P1（docs/548 §5.3）：留痕"这个身份曾经是本机模式"，便于以后排查老机器；
    # 新流程只写 "center"，不再产生 "local"。
    state.center.mode = "center"
    state.center.base = base.rstrip("/")
    state.center.owner_id = center_owner_id
    state.center.username = str(center_owner.get("username") or state.center.username or "")
    state.center.email = str(center_owner.get("email") or state.center.email or "")
    state.center.claimed_at = state.center.claimed_at or now_iso()
    save_state(home, state)
    return {"ok": True, **_summary(state), "ref": owner.get("ref") or {}}


def reset_owner_password(home: pathlib.Path, *, base: str, password: str) -> dict[str, Any]:
    state = load_state(home)
    client = CenterClient(base)
    result = client.reset_owner_password(
        node_id=state.node.node_id,
        node_key=state.node.node_key,
        password=password,
    )
    return {"ok": True, **result, "local_password_updated": False,
            "note": "password is owned by the center; no local password is stored"}
