#!/usr/bin/env python3
"""安装底座 —— 六个动作共用的 install 类逻辑（唯一真相源）。

本模块只回答一件事：**怎样把一份运行时铺到本机并跑起来**。
它不含产品语义，也不做任何「删」的动作：

  - 环境探测：解释器（含 uv 兜底）、pip 源测速
  - 布局：复制运行时 + 数据目录链接 + 人设模板种子
  - venv：检测 / 备份 / 重建 / 复检
  - 依赖：core（+ 可选 image）
  - 起停：launcher start
  - 收尾：install_report 自检 + install-timings.json

**不在本模块**：
  - 包完整性判断（`check_package()` 只回答「缺什么」，不含策略）
  - 升级的原子替换 / 回滚（那是 `taa_upgrade.py` 的事，本模块只保证它跑在可用 venv 上）
  - 数据清理（reset 等动作自己的语义；本模块绝不删用户数据）

设计约束（延续 2026-11-08 Win 冷装事故后的原则）：
1. 不依赖 bash / powershell，只用标准库；
2. 不写死 venv 路径，一律走 `taa_plat.venv_python()`；
3. uv 优先，没有则标准库 venv + pip；
4. 校验不靠 shell 工具（hashlib，不用 sha256sum）；
5. 每段计时写 `install-timings.json` —— 慢就是缺陷，不是「网络问题」。

调用方约定：本模块只返回结构化结果与退出码，**不做 sys.exit**。
"""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import taa_plat as plat  # noqa: E402

# 2026-11-09 Owner 定：**禁用清华**。
# 教育网镜像（TUNA）只对校园网内快，普通家宽/移动网络跨网访问常掉到几十 KB/s，
# 把它当「国内加速源」是普遍错误。实测同一 4.85MB wheel：阿里 10.5–15.1MB/s、
# 腾讯 8.4–19.7MB/s、官方 5.6–6.1MB/s。顺序 = 阿里首选、腾讯次选、官方兜底，
# 运行时再按实际测速在可用源里挑最快的（见 pick_index）。
INDEX_CANDIDATES = (
    "https://mirrors.aliyun.com/pypi/simple",
    "https://mirrors.cloud.tencent.com/pypi/simple",
    "https://pypi.org/simple",
)
DEFAULT_INDEX = INDEX_CANDIDATES[0]


# ---------------------------------------------------------------- 日志与计时

class Timer:
    def __init__(self) -> None:
        self.t0 = time.time()
        self.marks: dict[str, float] = {}

    def mark(self, name: str) -> float:
        now = time.time()
        self.marks[name] = round(now - self.t0, 2)
        return self.marks[name]

    def since(self, name: str, start: float) -> float:
        d = round(time.time() - start, 2)
        self.marks[name] = d
        return d


def log(msg: str) -> None:
    print(msg, flush=True)


def err(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def write_timings(home: Path, t: Timer, extra: dict | None = None) -> None:
    data = {"schema": 1, "platform": sys.platform, "arch": platform.machine(),
            "python": platform.python_version(), "total_s": t.mark("total"),
            "marks": t.marks}
    if extra:
        data.update(extra)
    try:
        home.mkdir(parents=True, exist_ok=True)
        (home / "install-timings.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass
    log("TIMINGS=" + json.dumps(t.marks, ensure_ascii=False))


# ---------------------------------------------------------------- pip 源

def probe_index(url: str, timeout: float = 2.5) -> float | None:
    """测一次索引往返（读前 2KB 就断开）；返回秒数，失败返回 None。

    DNS 解析卡住时 urllib 的 timeout 不生效，所以放到线程里 join 限时。
    """
    box: list[float | None] = []

    def run() -> None:
        t0 = time.time()
        try:
            req = urllib.request.Request(f"{url.rstrip('/')}/pip/",
                                         headers={"user-agent": "TAA-Installer/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                r.read(2048)
            box.append(round(time.time() - t0, 2))
        except Exception:                                        # noqa: BLE001
            box.append(None)

    th = threading.Thread(target=run, name="taa-index-probe", daemon=True)
    th.start()
    th.join(timeout + 1.5)
    return box[0] if box else None


def pick_index(explicit: str = "") -> tuple[str, list[tuple[str, float | None]]]:
    """选 pip 源：显式指定优先，否则按实测往返时间挑最快的可达源。"""
    if explicit:
        return explicit, []
    results = [(u, probe_index(u)) for u in INDEX_CANDIDATES]
    usable = [(u, t) for u, t in results if t is not None]
    best = min(usable, key=lambda x: x[1])[0] if usable else DEFAULT_INDEX
    return best, results


def short_host(url: str) -> str:
    return url.split("//")[-1].split("/")[0]


# ---------------------------------------------------------------- 解释器

def find_uv_python() -> tuple[list[str], str] | None:
    """最后手段：让 uv 自己下一份 Python（uv 存在时）。"""
    uv = plat.uv_path()
    if not uv:
        return None
    log("[deps] 未找到 Python 3.11+，尝试 uv python install 3.12")
    r = subprocess.run([uv, "python", "install", "3.12"], capture_output=True, text=True,
                       errors="replace")
    if r.returncode != 0:
        err((r.stderr or r.stdout or "").strip()[:300])
        return None
    r = subprocess.run([uv, "python", "find", "3.12"], capture_output=True, text=True,
                       errors="replace")
    if r.returncode != 0:
        return None
    path = (r.stdout or "").strip().splitlines()[-1].strip()
    ver = plat.probe_python(path) if path else None
    return ([path], ver) if ver else None


def python_hint() -> str:
    if plat.IS_WIN:
        return ("需要 Python 3.11+：\n"
                "  winget install Python.Python.3.12\n"
                "  或安装 uv（单文件，无需管理员）：winget install astral-sh.uv\n"
                "  装好后重开终端再跑；也可用 TAA_PYTHON 指定解释器路径。")
    if plat.IS_MAC:
        return ("需要 Python 3.11+：brew install python@3.12\n"
                "  或 brew install uv（uv 会自带 Python）")
    return ("需要 Python 3.11+：sudo apt install python3.12 python3.12-venv\n"
            "  或 curl -LsSf https://astral.sh/uv/install.sh | sh")


def locate_python(home: Path, *, explicit: str = "", timer: Timer | None = None
                  ) -> tuple[list[str], str] | None:
    """找可用解释器：本机探测 → uv 代下。计时记在 detect_python。"""
    st = time.time()
    found = plat.find_python(explicit=explicit or os.environ.get("TAA_PYTHON"), home=home)
    if not found:
        found = find_uv_python()
    if timer is not None:
        timer.since("detect_python", st)
    return found


def resolve_base_exe(found: tuple[list[str], str]) -> str:
    """venv 的基底解释器：优先显式路径，launcher 形式（py -3）退回自身。"""
    cmd = found[0]
    base_exe = cmd[0] if len(cmd) == 1 else sys.executable
    if not plat.probe_python(base_exe):
        base_exe = sys.executable
    return base_exe


# ---------------------------------------------------------------- 安装根目录

def check_package(src: Path) -> str | None:
    """返回缺件说明；完整则 None。只查不修。"""
    if not (src / "VERSION").exists():
        return f"包不完整：{src} 下没有 VERSION（--source 指向包根目录）"
    return None


def save_ref(home: Path, ref: str) -> str:
    """把推荐码落成 home/ref.txt，返回净化后的值（空串表示没写）。

    `--ref` 必须落盘：注册（/v05/claim 或本机 /setup/）时带上，中心据此
    直接把邀请人写成 approved 好友。只打印日志等于这个参数没用。
    这里**不能** import taa_node_v05（它依赖 cryptography，而 bootstrap 跑在
    系统解释器上、venv 还没建好），所以只写字面量文件，文件名与
    `taa_node_v05/identity.py` 的 REF_FILE 保持一致。
    """
    raw = str(ref or "").strip().lower()
    clean = "".join(ch for ch in raw if ch.isalnum() or ch in "_-")[:64]
    if not clean:
        return ""
    try:
        home.mkdir(parents=True, exist_ok=True)
        (home / "ref.txt").write_text(clean + "\n", encoding="utf-8")
        log(f"REF_SAVED={clean}（注册时自动建立好友）")
        os.environ["TAA_REF"] = clean
    except Exception as e:                                      # noqa: BLE001
        log(f"[warn] 推荐码未能落盘：{e}")
        return ""
    return clean


# ---------------------------------------------------------------- 布局

def copy_runtime(src: Path, dest: Path, home: Path) -> tuple[str, int, list[str]]:
    """复制运行时并铺数据目录/模板。返回 (复制方式, 模板数, 建链接失败的条目)。"""
    log(f"[install] 复制运行时 → {dest}")
    dest.mkdir(parents=True, exist_ok=True)
    how_copy = plat.copy_tree(src, dest, excludes=("agents", "bootstrap", "static/uploads"))
    failed = plat.ensure_data_dirs(dest, home)
    for rel in failed:
        err(f"[warn] {rel} 无法建链接（Windows 需 junction），已复制回 app 目录")
    # `agents/` 被整目录排除（防私有记忆进包），但 `_templates/*.yaml` 是**运行时必需**：
    # 缺它则在 /setup/ 建首个 agent 时 rng.choice([]) → IndexError，装完即不可用。
    n_tpl = plat.seed_templates(src, home)
    if n_tpl:
        log(f"[install] 人设模板 {n_tpl} 个 → agents/_templates")
    else:
        err("[warn] 包里没有 agents/_templates/*.yaml：装完建首个 agent 会崩")
    log(f"[install] 复制完成（{how_copy}），数据目录={'/'.join(plat.DATA_DIRS)}")
    return how_copy, n_tpl, failed


# ---------------------------------------------------------------- venv

@dataclass
class VenvOutcome:
    python: Path | None = None
    created: bool = False          # True = 本次新建（含备份重建）
    backup: Path | None = None     # 旧 venv 被移开的位置（没动过则 None）
    how: str = ""                  # uv(3.12) / venv 模块 ...
    ok: bool = True
    error: str = ""

    @property
    def reusable(self) -> bool:
        return bool(self.python) and self.ok and not self.created


def ensure_venv(home: Path, *, base_exe: str = "", timer: Timer | None = None,
                force: bool = False) -> VenvOutcome:
    """保证 home/venv 里有可跑的 Python 3.11+；不可用则备份重建。

    日志只打「错误」类，成功/复用文案留给调用方（各动作措辞不同）。
    """
    venv = home / "venv"
    vpy = plat.venv_python(venv)
    if not force and plat.probe_python(vpy):
        if timer is not None:
            timer.marks["venv"] = 0.0
        return VenvOutcome(python=vpy)

    out = VenvOutcome()
    if venv.exists():
        out.backup = plat.backup_venv(venv)
    st = time.time()
    # 有 uv 就让 uv 自己取 3.12（可代下、venv 覆盖率最好）；没有才退回本机解释器
    ok, how = plat.create_venv(venv, base_py=None if plat.uv_path() else (base_exe or sys.executable))
    if timer is not None:
        timer.since("venv", st)
    out.how = how
    if not ok:
        out.ok = False
        out.error = how
        err(f"x 建 venv 失败：{how}")
        return out

    vpy = plat.venv_python(venv)
    if not plat.probe_python(vpy):
        out.ok = False
        out.error = f"venv 建好了但解释器跑不起来：{vpy}"
        err(f"x {out.error}")
        return out
    out.python = vpy
    out.created = True
    return out


# ---------------------------------------------------------------- 依赖

def ensure_deps(dest: Path, vpy: Path, *, index_url: str = "", explicit_index: bool = False,
                skip: bool = False, timer: Timer | None = None,
                image: bool | None = None) -> tuple[bool, str, str]:
    """装 core（+ 可选 image）依赖。返回 (ok, how, 实际使用的 index_url)。

    源测速放在这里而不是更早：升级分支不该为测速多花时间。
    """
    if skip:
        log("[deps] --skip-deps：跳过依赖安装")
        return True, "skipped", index_url

    if not explicit_index:
        index_url, probes = pick_index()
        log("[deps] 源测速：" + " / ".join(
            f"{short_host(u)}={'x' if s is None else f'{s}s'}" for u, s in probes))
        log(f"[deps] 选用 index={index_url}")

    req = dest / "requirements-core.txt"
    if not req.exists():
        err(f"x 缺 {req}")
        return False, "missing-requirements", index_url

    st = time.time()
    ok, how = plat.install_deps(vpy, req, index_url=index_url)
    if timer is not None:
        timer.since("deps", st)
    if not ok:
        err(f"x 依赖安装失败（{how}）\n  可重试：\"{vpy}\" -m pip install -r \"{req}\" -i {index_url}")
        return False, how, index_url
    log(f"[deps] 核心依赖就绪（{how}，{timer.marks['deps'] if timer else '?'}s）")

    # 图片增强（Pillow 4.85MB）可选：默认不装，缩略图走 sips / 原图兜底。
    # 论证图已取消，playwright（41MB + 185MB chromium）不再安装。
    if image is None:
        image = (os.environ.get("TAA_IMAGE") or "0").strip() == "1"
    image_req = dest / "requirements-image.txt"
    if image and image_req.exists():
        st = time.time()
        iok, ihow = plat.install_deps(vpy, image_req, index_url=index_url)
        if iok:
            log(f"[deps] 图片增强就绪（{ihow}，{timer.since('image', st) if timer else '?'}s）")
        else:
            err("[deps] 图片增强未装成：缩略图走原图/系统工具兜底")
    else:
        log("[deps] 跳过图片增强（默认；TAA_IMAGE=1 可装 Pillow）")
    return True, how, index_url


# ---------------------------------------------------------------- 启动 / 自检

def launcher_path(dest: Path) -> Path | None:
    for name in ("launcher.py", "taa_launcher.py"):
        p = dest / name
        if p.exists():
            return p
    return None


def service_env(home: Path, vpy: Path, port: int) -> dict:
    env = plat.local_env()
    env.update({"TAA_HOME": str(home), "TAA_HTTP_PORT": str(port), "TAA_PYTHON": str(vpy)})
    return env


def start_service(dest: Path, home: Path, vpy: Path, port: int, *,
                  no_browser: bool = False, timer: Timer | None = None) -> int:
    """调 launcher start，返回其退出码（6 = 包里没有 launcher）。"""
    launcher = launcher_path(dest)
    env = service_env(home, vpy, port)
    st = time.time()
    if launcher is None:
        err("x 包里没有 launcher.py，无法启动（包不完整）")
        rc = 6
    else:
        cmd = [str(vpy), str(launcher), "start"] + (["--no-open"] if no_browser else [])
        rc = subprocess.run(cmd, cwd=str(dest), env=env).returncode
    if timer is not None:
        timer.since("start", st)
    return rc


def run_install_report(dest: Path, home: Path, vpy: Path, port: int, *,
                       timer: Timer | None = None) -> None:
    """装完自检报告（只读，失败不阻断）。"""
    st = time.time()
    report = dest / "scripts" / "install_report.py"
    if report.exists():
        subprocess.run([str(vpy), str(report), "--home", str(home), "--port", str(port)],
                       cwd=str(dest), env=service_env(home, vpy, port))
    if timer is not None:
        timer.since("selfcheck", st)


# ---------------------------------------------------------------- 编排：首装

def install(src: Path, home: Path, *, port: int = 6080, no_browser: bool = False,
            skip_deps: bool = False, base_exe: str = "", explicit_index: str = "",
            timer: Timer | None = None, selfcheck: bool = True) -> int:
    """首装/铺底座全流程。返回退出码（0 ok；4 venv；5 依赖；6 launcher）。

    前置：调用方已完成包完整性判断（`check_package`）与 dry-run。
    """
    t = timer or Timer()
    dest = home / "app"

    if not base_exe:
        found = locate_python(home, timer=t)
        if not found:
            err("x " + python_hint())
            return 3
        base_exe = resolve_base_exe(found)

    copy_runtime(src, dest, home)

    vout = ensure_venv(home, base_exe=base_exe, timer=t)
    if not vout.ok:
        return 4
    if vout.created:
        log(f"[deps] venv 就绪（{vout.how}）：{vout.python}")
    else:
        if vout.backup is not None:
            log(f"[deps] 现有 venv 不可用（不是 3.11+ 或已损坏），移开并重建：{vout.backup}")
        log(f"[deps] 复用已有 venv：{vout.python}")

    ok, _how, index_url = ensure_deps(dest, vout.python, index_url=explicit_index or DEFAULT_INDEX,
                                      explicit_index=bool(explicit_index), skip=skip_deps,
                                      timer=t)
    if not ok:
        return 5

    rc = start_service(dest, home, vout.python, port, no_browser=no_browser, timer=t)
    if rc != 0:
        err(f"x 启动失败（rc={rc}），日志：{home / 'run' / 'web.log'}")
        write_timings(home, t, {"mode": "install", "rc": rc})
        return rc

    if selfcheck:
        run_install_report(dest, home, vout.python, port, timer=t)

    write_timings(home, t, {"mode": "install", "rc": 0})
    return 0
