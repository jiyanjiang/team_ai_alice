"""任务生命周期状态机（PRD §5）。"""
from __future__ import annotations

import json
import uuid
from datetime import datetime

TRANSITIONS = {
    "idea": {"backlog", "cancelled"},
    "backlog": {"claimed", "cancelled"},
    "claimed": {"in_progress", "backlog", "blocked"},
    # paused 是长任务的阶段边界：释放执行位，但保留断点和 owner。
    "in_progress": {"review", "blocked", "backlog", "paused"},
    "paused": {"in_progress", "blocked", "cancelled"},
    "review": {"done", "in_progress", "blocked"},
    "done": {"archived"},
    "archived": set(),
    "blocked": {"in_progress", "claimed", "cancelled"},
    "cancelled": set(),
}

ACTIVE_STATUSES = ("claimed", "in_progress", "paused", "review")
# 并行度口径（见 wip_count 注释）：claimed=排队、review=等评审、paused=等恢复，都不占"执行位"。
WIP_STATUSES = ("in_progress",)
# claimed 是「排队位」：认领后 30 分钟还没开始执行就该放回 backlog。
# 原值 120 分钟太长——一次异常退出（或被 kill）的任务要压两小时才自动释放，
# 期间并行位被占死（2026-11-11 B 端实测：僵尸任务挡住后续跨机派活）。
DEFAULT_CLAIM_TTL_MIN = 30


class TaskError(ValueError):
    pass


def new_id(prefix: str = "t") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def get_task(conn, task_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    return dict(row) if row else None


def wip_count(conn, agent_id: str) -> int:
    """**在执行**的任务数（并行度口径）。

    ★ 2026-10-14 语义修正：原口径把 `claimed` 也算作 WIP，而 `claimed` 实际是
    "已认领、排队等执行器"（dispatcher 是串行的）。于是聊天室派单把 claimed 堆到 8–9 个后，
    loop 的 `wip < MAX_PARALLEL` 门禁让 agent **再也认领不到任何新任务**（含 P0 返工）——
    实测 A 机 alice=7、Win16G darwin=9 双双瘫痪。
    `claimed` 恢复"排队"语义，并行度只认 `in_progress`（review 是等评审，同样不占执行位）。
    """
    q = ",".join("?" * len(WIP_STATUSES))
    row = conn.execute(
        f"SELECT COUNT(*) c FROM tasks WHERE assigned_to = ? AND status IN ({q})",
        (agent_id, *WIP_STATUSES),
    ).fetchone()
    return int(row["c"])


def queue_count(conn, agent_id: str) -> int:
    """已认领但**还没开始执行**的排队数（观测用；不作为并行度门禁）。"""
    row = conn.execute(
        "SELECT COUNT(*) c FROM tasks WHERE assigned_to = ? AND status = 'claimed'",
        (agent_id,)).fetchone()
    return int(row["c"])


def lane_counts(conn, agent_id: str) -> dict[str, int]:
    """当前占用执行位的 long/short 数；paused 不计入执行位。"""
    rows = conn.execute(
        "SELECT COALESCE(json_extract(metadata, '$.lane'), 'short') lane, COUNT(*) c "
        "FROM tasks WHERE assigned_to=? AND status IN ('claimed','in_progress') "
        "GROUP BY lane", (agent_id,)).fetchall()
    out = {"long": 0, "short": 0}
    for r in rows:
        lane = "long" if str(r["lane"]) == "long" else "short"
        out[lane] += int(r["c"])
    return out


MAX_PAUSED_LONG = 2


def _lane(task: dict) -> str:
    try:
        meta = json.loads(task.get("metadata") or "{}") or {}
    except Exception:  # noqa: BLE001
        meta = {}
    return "long" if meta.get("lane") == "long" else "short"


def long_gate(conn, agent_id: str, exclude_id: str | None = None) -> dict:
    """长任务准入（docs/325/326）：每个 agent 同时只允许 1 个 long 真正占位。

    claimed 也算占位：认领后已进入执行队列，不能再接第二个长任务。
    paused 不占执行位，但最多保留 MAX_PAUSED_LONG 个断点。
    """
    active = conn.execute(
        "SELECT id, title FROM tasks WHERE assigned_to=? "
        "AND status IN ('claimed','in_progress') "
        "AND COALESCE(json_extract(metadata, '$.lane'), 'short')='long' "
        "AND id<>COALESCE(?, '')",
        (agent_id, exclude_id)).fetchall()
    paused = conn.execute(
        "SELECT COUNT(*) c FROM tasks WHERE assigned_to=? AND status='paused' "
        "AND COALESCE(json_extract(metadata, '$.lane'), 'short')='long' "
        "AND id<>COALESCE(?, '')",
        (agent_id, exclude_id)).fetchone()["c"]
    return {"ok": not active and int(paused) < MAX_PAUSED_LONG,
            "active": [dict(r) for r in active], "paused": int(paused),
            "max_paused": MAX_PAUSED_LONG}


def record_event(conn, task_id, agent_id, frm, to, action, detail=None) -> None:
    conn.execute(
        "INSERT INTO task_events(task_id, agent_id, from_status, to_status, action, detail) "
        "VALUES (?,?,?,?,?,?)",
        (task_id, agent_id, frm, to, action,
         json.dumps(detail, ensure_ascii=False) if detail is not None else None),
    )


def _check(task: dict, to: str) -> None:
    frm = task["status"]
    if to not in TRANSITIONS.get(frm, set()):
        raise TaskError(f"illegal transition {frm} -> {to}")


def claim(conn, task_id, agent_id, score_json=None, reason=None, force=False):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    frm = task["status"]
    if frm not in ("backlog", "idea"):
        raise TaskError(f"cannot claim task in status {frm}")
    # ★ 任务可"钉"给指定 agent（metadata.for_agent）：他人不得认领（force 可强制）
    try:
        meta_old = json.loads(task.get("metadata") or "{}") or {}
    except Exception:
        meta_old = {}
    pinned = meta_old.get("for_agent")
    if pinned and pinned != agent_id and not force:
        raise TaskError(f"task pinned to {pinned}")
    # ★ 长任务只有 1 个执行位（docs/325 §0：长任务只有 1 个）。
    #   认领即占位；paused 不占位，但最多保留 2 个可恢复断点。
    if _lane(task) == "long":
        gate = long_gate(conn, agent_id, exclude_id=task_id)
        if not gate["ok"]:
            if gate["active"]:
                other = gate["active"][0]["id"]
                raise TaskError(f"long lane busy: {other} 正在执行；先完成或暂停它")
            raise TaskError(f"paused long tasks >= {gate['max_paused']}；先归档/取消一个断点")
    _check(task, "claimed")
    meta_new = dict(meta_old)
    meta_new.update({"score": score_json, "reason": reason, "force": force})
    # 原子认领：并发下只有一次 UPDATE 能命中
    cur = conn.execute(
        "UPDATE tasks SET status='claimed', assigned_to=?, claimed_at=datetime('now','localtime'), "
        "metadata=? WHERE id=? AND status IN ('backlog','idea') AND assigned_to IS NULL",
        (agent_id, json.dumps(meta_new, ensure_ascii=False), task_id),
    )
    if cur.rowcount == 0:
        raise TaskError("task already claimed")
    record_event(conn, task_id, agent_id, frm, "claimed",
                 "force_claim" if force else "claim",
                 {"score": score_json, "reason": reason})
    return get_task(conn, task_id)


def release(conn, task_id, agent_id, reason=None):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    _check(task, "backlog")
    conn.execute(
        "UPDATE tasks SET status='backlog', assigned_to=NULL, claimed_at=NULL WHERE id=?",
        (task_id,),
    )
    record_event(conn, task_id, agent_id, task["status"], "backlog", "release", {"reason": reason})
    return get_task(conn, task_id)


def start(conn, task_id, agent_id):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    if task["assigned_to"] and task["assigned_to"] != agent_id:
        raise TaskError("task assigned to another agent")
    _check(task, "in_progress")
    conn.execute(
        "UPDATE tasks SET status='in_progress', assigned_to=?, "
        "in_progress_at=datetime('now','localtime') WHERE id=?",
        (agent_id, task_id),
    )
    record_event(conn, task_id, agent_id, task["status"], "in_progress", "start")
    return get_task(conn, task_id)


def checkpoint(conn, task_id, agent_id, checkpoint: dict | None = None):
    """保存阶段断点；不改变状态，供 pause/resume 或 UI 查看。"""
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    if task["assigned_to"] and task["assigned_to"] != agent_id:
        raise TaskError("task assigned to another agent")
    try:
        meta = json.loads(task.get("metadata") or "{}") or {}
    except Exception:  # noqa: BLE001
        meta = {}
    meta["checkpoint"] = checkpoint or {}
    meta["checkpoint_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("UPDATE tasks SET metadata=? WHERE id=?",
                 (json.dumps(meta, ensure_ascii=False), task_id))
    record_event(conn, task_id, agent_id, task["status"], task["status"],
                 "checkpoint", checkpoint or {})
    return get_task(conn, task_id)


def _phase_id(p) -> str:
    if isinstance(p, dict):
        return str(p.get("id") or p.get("name") or "")
    return str(p or "")


def advance_phase(conn, task_id, agent_id, checkpoint: dict | None = None):
    """同一 task 完成当前 phase，切到下一 phase 并暂停等短任务窗口。

    不新建 task，不改变 task_id；下一阶段用 resume 继续。
    """
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    if task["assigned_to"] and task["assigned_to"] != agent_id:
        raise TaskError("task assigned to another agent")
    _check(task, "paused")
    try:
        meta = json.loads(task.get("metadata") or "{}") or {}
    except Exception:  # noqa: BLE001
        meta = {}
    phases = meta.get("phases") or []
    ids = [_phase_id(p) for p in phases]
    cur = str(meta.get("phase") or (ids[0] if ids else ""))
    if cur not in ids:
        raise TaskError("task has no valid current phase")
    idx = ids.index(cur)
    if idx + 1 >= len(ids):
        raise TaskError("current phase is the last phase")
    nxt = ids[idx + 1]
    done = list(meta.get("completed") or [])
    if cur not in done:
        done.append(cur)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for p in phases:
        if not isinstance(p, dict):
            continue
        if _phase_id(p) == cur:
            p["status"] = "done"
            p["done_at"] = now
        elif _phase_id(p) == nxt and p.get("status") == "done":
            p["status"] = "pending"
    meta["completed"] = done
    meta["phase"] = nxt
    meta["phase_index"] = idx + 1
    meta["phase_status"] = "paused"
    cp = dict(meta.get("checkpoint") or {})
    if checkpoint:
        cp.update(checkpoint)
    cp.update({"phase": nxt, "completed": done, "next": nxt, "at": now})
    meta["checkpoint"] = cp
    meta["paused_at"] = now
    conn.execute("UPDATE tasks SET status='paused', metadata=? WHERE id=?",
                 (json.dumps(meta, ensure_ascii=False), task_id))
    record_event(conn, task_id, agent_id, task["status"], "paused",
                 "advance_phase", {"from": cur, "to": nxt})
    return get_task(conn, task_id)


def pause(conn, task_id, agent_id, checkpoint: dict | None = None):
    """在安全点暂停长任务：保存断点并释放执行位。"""
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    if task["assigned_to"] and task["assigned_to"] != agent_id:
        raise TaskError("task assigned to another agent")
    _check(task, "paused")
    try:
        meta = json.loads(task.get("metadata") or "{}") or {}
    except Exception:  # noqa: BLE001
        meta = {}
    if checkpoint:
        meta["checkpoint"] = checkpoint
    meta["paused_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn.execute("UPDATE tasks SET status='paused', metadata=? WHERE id=?",
                 (json.dumps(meta, ensure_ascii=False), task_id))
    record_event(conn, task_id, agent_id, task["status"], "paused", "pause",
                 {"checkpoint": meta.get("checkpoint")})
    return get_task(conn, task_id)


def resume(conn, task_id, agent_id):
    """从 paused 恢复；不重跑已完成阶段，checkpoint 留给执行器读取。"""
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    if task["assigned_to"] and task["assigned_to"] != agent_id:
        raise TaskError("task assigned to another agent")
    _check(task, "in_progress")
    conn.execute(
        "UPDATE tasks SET status='in_progress', assigned_to=?, "
        "in_progress_at=datetime('now','localtime') WHERE id=?",
        (agent_id, task_id))
    record_event(conn, task_id, agent_id, task["status"], "in_progress", "resume")
    return get_task(conn, task_id)


# —— P1.4 状态写权限白名单：只有「执行器进程已退出」这条路径能进 review ——
# 为什么需要：旧实现 submit 只校验"有交付帖"，不校验进程是否还在跑，
# agent 一边执行一边把任务推到 review（Delta 实测 19:32:07 review、19:32:34 仍 progress）。
# 允许的 writer 只有 dispatcher（必须带真实 exit_code）；人工提前提交必须显式 force。
SUBMIT_WRITERS = frozenset({"dispatcher"})


def submit(conn, task_id, agent_id, note=None, *, writer=None, exit_code=None, force=False):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    # ★ 写权限白名单（P1.4）：早于 phase gate 拒绝，避免"半成品进评审"。
    # 被拒也要留痕（只写 event，不改 status）——审计能看出谁在什么时候试图抢跑。
    def _deny(msg: str):
        record_event(conn, task_id, agent_id, task["status"], task["status"],
                     "submit_denied",
                     {"reason": msg, "writer": writer, "exit_code": exit_code})
        raise TaskError(msg)

    if not force:
        if writer not in SUBMIT_WRITERS:
            _deny("submit denied: 评审只能由执行器退出码路径推进（P1.4）；"
                  f"当前 writer={writer!r}。人工提前提交请显式 --force")
        if exit_code is None:
            _deny("submit denied: dispatcher 提交必须带 exit_code")
        try:
            _rc = int(exit_code)
        except (TypeError, ValueError):
            _deny(f"submit denied: exit_code 非法 {exit_code!r}")
        if _rc != 0:
            _deny(f"submit denied: 退出码 {_rc} ≠ 0，不得进入 review")
    # ★ 阶段契约（docs/325 §1.3）：长任务全部 phase 完成才允许提交评审。
    try:
        _meta = json.loads(task.get("metadata") or "{}") or {}
    except Exception:  # noqa: BLE001
        _meta = {}
    _phases = [p for p in (_meta.get("phases") or []) if isinstance(p, dict)]
    if _phases:
        todo = [p.get("id") for p in _phases if p.get("status") != "done"]
        if todo:
            raise TaskError(f"phase gate: 还有未完成阶段 {', '.join(str(x) for x in todo)}")
    _check(task, "review")
    conn.execute(
        "UPDATE tasks SET status='review', review_at=datetime('now','localtime') WHERE id=?",
        (task_id,),
    )
    record_event(conn, task_id, agent_id, task["status"], "review", "submit",
                 {"note": note, "writer": writer or ("manual" if force else None),
                  "exit_code": exit_code})
    return get_task(conn, task_id)


def block(conn, task_id, agent_id, reason=None):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    _check(task, "blocked")
    conn.execute(
        "UPDATE tasks SET status='blocked', blocked_at=datetime('now','localtime') WHERE id=?",
        (task_id,),
    )
    record_event(conn, task_id, agent_id, task["status"], "blocked", "block", {"reason": reason})
    return get_task(conn, task_id)


def unblock(conn, task_id, agent_id, target="in_progress"):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    if task["status"] != "blocked":
        raise TaskError("task not blocked")
    if target not in ("in_progress", "claimed"):
        raise TaskError("unblock target must be in_progress or claimed")
    conn.execute(
        "UPDATE tasks SET status=?, blocked_at=NULL WHERE id=?", (target, task_id)
    )
    record_event(conn, task_id, agent_id, "blocked", target, "unblock")
    return get_task(conn, task_id)


def review(conn, task_id, agent_id, decision, quality_score=None, comments=None):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    mapping = {"approved": "done", "request_changes": "in_progress", "blocked": "blocked"}
    if decision not in mapping:
        raise TaskError("decision must be approved|request_changes|blocked")
    to = mapping[decision]
    _check(task, to)
    conn.execute(
        "INSERT INTO reviews(id, task_id, reviewer_id, decision, quality_score, comments) "
        "VALUES (?,?,?,?,?,?)",
        (new_id("r"), task_id, agent_id, decision, quality_score,
         json.dumps(comments, ensure_ascii=False) if comments is not None else None),
    )
    if decision == "approved":
        conn.execute(
            "UPDATE tasks SET status='done', done_at=datetime('now','localtime') WHERE id=?",
            (task_id,),
        )
    elif decision == "request_changes":
        conn.execute("UPDATE tasks SET status='in_progress' WHERE id=?", (task_id,))
    else:
        conn.execute(
            "UPDATE tasks SET status='blocked', blocked_at=datetime('now','localtime') WHERE id=?",
            (task_id,),
        )
    record_event(conn, task_id, agent_id, task["status"], to, f"review:{decision}",
                 {"quality_score": quality_score, "comments": comments})
    return get_task(conn, task_id)


def deliverables(conn, task_id: str) -> list[dict]:
    """任务的交付清单：交付帖 + 附件 URL，作为归档和复现依据。"""
    out = []
    try:
        rows = conn.execute(
            "SELECT id,title,body,attachments,created_at FROM posts "
            "WHERE task_id=? ORDER BY id", (task_id,)).fetchall()
    except Exception:  # noqa: BLE001
        return out
    for r in rows:
        try:
            atts = json.loads(r["attachments"] or "[]")
        except Exception:  # noqa: BLE001
            atts = []
        out.append({"post_id": r["id"], "title": r["title"] or "",
                    "attachments": atts, "created_at": r["created_at"]})
    return out


def archive(conn, task_id, agent_id, reason=None):
    """完成后的归档：保留 task/交付物/链接，不物理删除。"""
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    _check(task, "archived")
    items = deliverables(conn, task_id)
    try:
        meta = json.loads(task.get("metadata") or "{}") or {}
    except Exception:  # noqa: BLE001
        meta = {}
    at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    meta["archived_at"] = at
    meta["archive_manifest"] = {
        "at": at,
        "by": agent_id,
        "reason": reason or "",
        "deliverables": items,
    }
    conn.execute("UPDATE tasks SET status='archived', metadata=? WHERE id=?",
                 (json.dumps(meta, ensure_ascii=False), task_id))
    record_event(conn, task_id, agent_id, task["status"], "archived", "archive",
                 {"reason": reason, "deliverables": [x["post_id"] for x in items]})
    return get_task(conn, task_id)


def cancel(conn, task_id, agent_id, reason=None):
    task = get_task(conn, task_id)
    if not task:
        raise TaskError("task not found")
    _check(task, "cancelled")
    conn.execute("UPDATE tasks SET status='cancelled' WHERE id=?", (task_id,))
    record_event(conn, task_id, agent_id, task["status"], "cancelled", "cancel", {"reason": reason})
    return get_task(conn, task_id)


def release_stale(conn, ttl_min=DEFAULT_CLAIM_TTL_MIN) -> int:
    """claimed 超时未开始 -> 释放回 backlog。返回释放条数。"""
    rows = conn.execute(
        "SELECT id FROM tasks WHERE status='claimed' "
        "AND claimed_at < datetime('now','localtime', ?)",
        (f"-{ttl_min} minutes",),
    ).fetchall()
    for r in rows:
        conn.execute(
            "UPDATE tasks SET status='backlog', assigned_to=NULL, claimed_at=NULL WHERE id=?",
            (r["id"],),
        )
        record_event(conn, r["id"], None, "claimed", "backlog", "auto_release",
                     {"ttl_min": ttl_min})
    return len(rows)
