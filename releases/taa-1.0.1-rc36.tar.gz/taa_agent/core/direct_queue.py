"""直投队列口径的单一真相源（纯标准库，可被监控/门禁脚本独立 import）。

为什么要有这个模块（2026-11-01 排查实录）：
    此前 app_ui.direct_backlog / scripts/release_gate / scripts/chatroom_monitor
    各写一份计数 SQL。口径本身是对的（都带了房间过滤），但**同一个口径存三份**，
    任何一处改漏，其余两处就会报出互相矛盾的水位。
    更常见的是：临时排查用裸 SQL 数 `coalesce(direct_delivered,0)=0`，把
    「本地私信房」「中心同步副本」「入站消息」全算成"待投"，
    334 条 NULL 状态被读成积压，而真实待投是 0。

    结论：凡是问"还有多少没投出去"，只能走本模块，不要再手写 SQL。

口径（一条本地消息"应当直投给对端"的充要条件）：
    ① center_message_id 为空   —— 非空说明是中心同步下来的副本，不回投
    ② direct_delivered != 1    —— 已送达
    ③ direct_state = pending   —— delivered/skipped/gave_up 为终态
    ④ kind != 'skip'           —— 结构性跳过
    ⑤ source 不是 center/peer/p2p  —— 入站消息不往原路回投
    ⑥ 房间有 center_group_id    —— 本地房（私信/残房）没有对端，"待投"无从谈起
"""
from __future__ import annotations

# ── 口径片段（带 m. 前缀，供 join/自查询复用）────────────────────────────────

# 范围：这些消息"理论上存在跨机投递"这回事。
SCOPE_COND = (
    "m.center_message_id is null "
    # `p2p` = 对端经 peer 通道落进来的消息（与 center/peer 同义：**入站**，不回投）。
    # 漏掉它会把对端发来的话算成"我要发给对端"，真机水位虚高（2026-11-11 实测 46 条积压里
    # 有 6 条是 source='p2p' 的入站消息）。
    "and coalesce(m.source,'') not in ('center','peer','p2p') "
)

# 完整：这些消息"现在就该由直投 worker 送出去"。
QUEUE_COND = (
    SCOPE_COND
    + "and coalesce(m.direct_delivered,0)=0 "
    "and coalesce(m.direct_state,'pending')='pending' "
    "and m.kind not in ('skip') "
)

TERMINAL_STATES = ("delivered", "skipped", "gave_up")


# ── 库结构探测（老库可能没有 direct_state 列 / 没有 rooms 表）─────────────────

def has_rooms(c) -> bool:
    return bool(c.execute(
        "select 1 from sqlite_master where type='table' and name='rooms'").fetchone())


def has_direct_state(c) -> bool:
    try:
        return "direct_state" in {str(r[1]) for r in c.execute(
            "pragma table_info(room_messages)")}
    except Exception:  # noqa: BLE001
        return False


def room_clause() -> str:
    """只有挂在中心群上的房间才存在"投给对端"这回事。"""
    return ("and m.room_id in "
            "(select id from rooms where coalesce(center_group_id,'')!='') ")


def scope_sql(c) -> str:
    """SCOPE_COND 加上房间过滤（rooms 表不存在时不追加，避免报错）。"""
    return SCOPE_COND + (room_clause() if has_rooms(c) else "")


# ── 对外接口 ─────────────────────────────────────────────────────────────────

def queued(c, rid: str = "") -> int:
    """真正待直投的条数。**这是唯一权威水位**，不要再用裸 SQL 数。"""
    if not has_direct_state(c):
        return -1                       # 老库未迁移：调用方应显示"未知"而非 0
    where = QUEUE_COND + (room_clause() if has_rooms(c) else "")
    args: list = []
    if rid:
        where += "and m.room_id=? "
        args.append(rid)
    return int(c.execute(
        f"select count(*) from room_messages m where {where}", args).fetchone()[0])


def explain(c, rid: str = "") -> dict:
    """把全部未送达消息按**原因**分桶，让"为什么不算积压"一眼可读。

    返回的 `queued` 与 queued() 完全一致；其余桶都是"看起来没投、其实不该投"。
    """
    if not has_direct_state(c):
        return {"queued": -1, "note": "direct_state 列缺失（老库未迁移）"}
    has_rm = has_rooms(c)
    local_only = ("not exists (select 1 from rooms r where r.id=m.room_id "
                  "and coalesce(r.center_group_id,'')!='')") if has_rm else "0"
    base = "from room_messages m "
    args: list = []
    if rid:
        base += "where m.room_id=? "
        args.append(rid)
    # 分支顺序必须与 QUEUE_COND 的排除顺序一致，否则会有消息落进错误桶。
    rows = c.execute(f"""
        select case
                 when m.center_message_id is not null then 'synced'
                 when coalesce(m.direct_delivered,0)=1 then 'delivered'
                 when coalesce(m.direct_state,'') in ('skipped','gave_up') then m.direct_state
                 when coalesce(m.source,'') in ('center','peer') then 'inbound'
                 when m.kind in ('skip') then 'kind_skip'
                 when {local_only} then 'local_only'
                 else 'queued'
               end bucket,
               count(*) n
        {base} group by 1""", args).fetchall()
    return {str(r[0]): int(r[1]) for r in rows}
