"""发帖后的轻量唤醒：让直连对端「立刻来拉一次」。

为什么需要
----------
P2P 是纯拉模式（`peer_pull.pull_all` 定时拉），本机发帖**不会通知**对端，
实测延迟等于对端轮询周期（80~110 秒）。朋友圈这种内容形态下，用户能明显
感到「文字到了、图还没到」。

做法：发帖（post.created / reply.created）后，向 `peer_nodes` 里
`direct_status='direct'` 的对端 POST 一个**空提示** `/peer/v1/notify`
（走 peer server 转发到对方的 Flask）。对方收到后立刻 force 拉一轮。

三条边界
--------
1. **只发提示、不带数据**：内容仍走 `/peer/v1/events`，授权与签名不变；
   收到提示的一方自己决定拉不拉，提示本身不可信、无副作用。
2. **对端没升级就静默放弃**：老版本 peer server 白名单没有 notify → 404，
   这里吞掉，绝不影响发帖、也不重试。
3. **双向节流**：全局单 worker 串行 + 每对端最小间隔，连续发帖不会刷爆对端。
"""
from __future__ import annotations

import os
import queue
import threading
import time
import urllib.error
import urllib.request

MIN_GAP = 3.0            # 同一对端两次提示的最小间隔（秒）
TIMEOUT = 2.0            # 提示请求超时：只是"拍一下肩膀"，不等人回话
_QUEUE: "queue.Queue[str]" = queue.Queue(maxsize=8)
_WORKER: threading.Thread | None = None
_LOCK = threading.Lock()
_LAST: dict[str, float] = {}
_SKIPPED: dict[str, int] = {}      # node_id -> 404/连不上的次数（排障用，不阻塞）
_FAILED: dict[str, dict] = {}      # node_id -> {at, code, hint}：最近一次失败的可解释原因


def enabled() -> bool:
    return str(os.environ.get("TAA_PEER_NOTIFY", "1")).strip().lower() not in (
        "0", "false", "no", "off")


def stats() -> dict:
    return {"enabled": enabled(), "sent": dict(_LAST), "skipped": dict(_SKIPPED),
            "failed": dict(_FAILED), "queue": _QUEUE.qsize()}


def _record_failure(nid: str, code, hint: str = "") -> None:
    """记一次唤醒失败，并把「需要人处理」的那类（503 授权未建立）落进收件箱。

    为什么必须可见（docs/561 真机）：唤醒被对端 503 拒绝时，本机没有任何信号，
    用户看到的只是「图片很慢」，于是把问题归因成「P2P 没实现」。
    503 的语义在 core/peer_pull.py 写死为「端口对了但授权没过」——这是可执行的指引，
    不该只躺在 /v1/peer/notify 的排障 JSON 里。
    """
    _SKIPPED[nid] = _SKIPPED.get(nid, 0) + 1
    _FAILED[nid] = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "code": code, "hint": hint}
    if str(code) != "503":
        return
    try:
        from . import community, db as dbmod
        conn = dbmod.connect()
        try:
            row = conn.execute(
                "select id from agents where kind='human' order by rowid limit 1").fetchone()
            who = str(row["id"]) if row else ""
            if who:
                community.add_notification(
                    conn, who, "peer_grant_blocked", nid,
                    f"跨机同步被 {nid} 拒绝（授权未建立）：对方需要批准你的节点，"
                    f"或本机 /app/peer-grants 有事项待确认")
                conn.commit()
        finally:
            conn.close()
    except Exception:                                            # noqa: BLE001
        pass


def kick(reason: str = "") -> bool:
    """入队一次唤醒；立即返回（绝不在请求线程里发网络请求）。"""
    if not enabled():
        return False
    try:
        _QUEUE.put_nowait(str(reason or ""))
    except queue.Full:
        return False
    _ensure_worker()
    return True


def _ensure_worker() -> None:
    global _WORKER
    with _LOCK:
        if _WORKER is not None and _WORKER.is_alive():
            return
        _WORKER = threading.Thread(target=_drain, name="peer-notify", daemon=True)
        _WORKER.start()


def _drain() -> None:
    while True:
        _QUEUE.get()
        try:
            notify_once()
        except Exception:                                        # noqa: BLE001
            pass


def _targets() -> list[tuple[str, str]]:
    """[(node_id, base)]：只挑已知直连、且有登记地址的对端。"""
    from . import db as dbmod
    try:
        conn = dbmod.connect()
    except Exception:                                            # noqa: BLE001
        return []
    try:
        rows = conn.execute(
            "select node_id, selected_url, direct_status from peer_nodes").fetchall()
    except Exception:                                            # noqa: BLE001
        return []
    finally:
        try:
            conn.close()
        except Exception:                                        # noqa: BLE001
            pass
    try:
        from . import peer_tokens
    except Exception:                                            # noqa: BLE001
        peer_tokens = None
    out: list[tuple[str, str]] = []
    for r in rows:
        nid = str(r["node_id"] or "")
        base = str(r["selected_url"] or "").rstrip("/")
        # 目录里的 selected_url 会被 probe_all 清空（探测一失败就降级 relay），
        # 所以再回退到本机握手时登记的同一条地址——否则提示永远发不出去，
        # 跨机消息只能等对端轮询（真机：本机侧 notify 一次都没发出过）。
        if not base.startswith("http") and peer_tokens is not None and nid:
            try:
                base = str(peer_tokens.get_base(nid) or "").rstrip("/")
            except Exception:                                    # noqa: BLE001
                base = ""
        if not nid or not base.startswith("http"):
            continue
        # `direct_status` 不再当硬门槛：它是一次性探测结论、失败即降级，
        # 而这里只是一条 2 秒超时的空提示——发不到也没有副作用。
        out.append((nid, base))
    return out


def notify_once() -> int:
    """向所有已知直连对端发一次提示，返回成功数。"""
    from . import peer_tokens
    sent = 0
    now = time.time()
    for nid, base in _targets():
        if now - float(_LAST.get(nid) or 0) < MIN_GAP:
            continue
        token = peer_tokens.get_token(nid)
        if not token:
            continue
        _LAST[nid] = now
        try:
            _post(base + "/peer/v1/notify", token)
        except urllib.error.HTTPError as e:
            # 404/405 = 对端还没升级（白名单没有 notify），静默记一次即可。
            # 503 = 端口对了但授权没过（core/peer_pull.py 的语义），必须让人看见。
            hint = "对方未授权本机（授权待建立）" if e.code == 503 else ""
            _record_failure(nid, e.code, hint)
            if e.code not in (404, 405):
                print(f"[peer-notify] {nid} HTTP {e.code}"
                      + (f"（{hint}）" if hint else ""))
        except Exception as e:                                   # noqa: BLE001
            _record_failure(nid, type(e).__name__, "连不上（地址失效或对方未运行）")
        else:
            sent += 1
    return sent


def _post(url: str, token: str) -> dict:
    body = b"{}"
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"content-type": "application/json",
                 "X-TAA-Peer-Token": token,
                 "user-agent": "TAA-Peer/0.1"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", "ignore")
    try:
        import json
        return json.loads(raw or "{}")
    except Exception:                                            # noqa: BLE001
        return {}
