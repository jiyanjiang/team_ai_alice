"""命名规范：owner 是唯一句柄（不含点），agent 是 `<短名>.<owner>`。

为什么要有这条规范
------------------
跨机事件只带 agent id，而**两台机器的 owner agent 都叫 `human`**。接收端按
id 找人时会直接撞上自己的 owner，于是对端的帖子在自己这边署了本机的名
（Delta 侧把 jiyanjiang 的帖显示成 Owner 就是这么来的）。

名字里带上 owner 句柄后就无歧义了：

* owner：`jiyanjiang`，中心 `owners.username` 唯一，且**禁止出现点号**；
* agent：`alice.jiyanjiang`，点号作分隔符，短名在 owner 内唯一；
* `system` 等系统账号不套规范，它们不属于任何 owner。

事件侧只需把这几个字段带过去（`author_name` / `author_owner` /
`author_owner_name`），接收端直接用，不再本地猜名字。
"""
from __future__ import annotations

MAX_NAME = 64
SEP = "."


def clean_owner(value: str) -> str:
    """owner 句柄：去空白，且不允许点号（点号是 agent 名的分隔符）。"""
    raw = str(value or "").strip()
    if not raw:
        return ""
    return raw.replace(SEP, "-").replace(" ", "").replace("@", "-")[:MAX_NAME]


def valid_owner(value: str) -> bool:
    raw = str(value or "").strip()
    return bool(raw) and SEP not in raw and " " not in raw and "@" not in raw


def agent_name(short: str, owner: str) -> str:
    """`<短名>.<owner>`；短名统一小写，与 `alice.jiyanjiang` 一致。"""
    s = str(short or "").strip().lower().replace(SEP, "-").replace(" ", "")
    o = clean_owner(owner)
    if not s:
        s = "agent"
    if not o:
        return s[:MAX_NAME]
    return f"{s}{SEP}{o}"[:MAX_NAME]


def split_name(name: str) -> tuple[str, str]:
    """`alice.jiyanjiang` → (`alice`, `jiyanjiang`)；没有点则 owner 为空。"""
    raw = str(name or "").strip()
    if SEP not in raw:
        return raw, ""
    short, _, owner = raw.partition(SEP)
    return short, owner


def is_qualified(name: str) -> bool:
    return SEP in str(name or "")


def has_placeholder_owner(name: str) -> bool:
    """`alice.Owner` 的 owner 段是占位符 → 这个署名不可信。"""
    return split_name(name)[1].lower() in _PLACEHOLDER_OWNERS


def is_placeholder_name(value) -> bool:
    """整名就是占位符（`Owner` / `human` / `agent.Owner`）→ 不可作为署名。"""
    text = str(value or "").strip().lower()
    return (text in _PLACEHOLDER_OWNERS
            or text.endswith((".owner", ".human", "@owner", "@human")))


# 占位句柄：老库把真人默认叫 `Owner`/`human`，绝不能当 owner 句柄用，
# 否则本机 agent 会被命名成 `alice.Owner`，全站署名都带上 Owner。
_PLACEHOLDER_OWNERS = {"owner", "human", "leader", "本机主人", "本地主人"}
# ↑ 「本机主人」是 bootstrap._owner_name() 的旧兜底串。它不在名单里时会被当成真名
#   写进 agents.name 并永久固化（docs/542 规定真人署名为 <owner>，如 jiyanjiang）。


def _usable_owner(value) -> str:
    name = clean_owner(value)
    if not name or name.lower() in _PLACEHOLDER_OWNERS:
        return ""
    return name


def _identity_username() -> str:
    """`identity.json` 的 `center.username`（中心的本地镜像）；读不到返回空串。"""
    import json
    import os
    import pathlib

    home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa")).expanduser()
    try:
        data = json.loads((home / "identity.json").read_text(encoding="utf-8"))
    except Exception:                                            # noqa: BLE001
        return ""
    name = str(((data.get("center") or {}).get("username")) or "").strip()
    if not name or name.lower() in _PLACEHOLDER_OWNERS:
        return ""
    return clean_owner(name)


def local_owner_handle(conn) -> str:
    """本机 owner 的句柄 = 本机 username（规范：裸用户名，如 `jiyanjiang`）。

    取值顺序（docs/559 §9）：**`identity.center.username`**（username 域真相在中心，
    本地镜像在 identity）→ `agents.human.owner_name` → human 行 name → 任一 human 的
    owner_name。占位名一律视为"拿不到"，不做降级猜测。

    为什么 identity 排第一：库里的 owner_name 是投影，可能滞后一轮；拿它算 agent 后缀，
    改名后会把后缀算回旧名。
    """
    ident = _identity_username()
    if ident:
        return ident
    try:
        row = conn.execute(
            "SELECT owner_name FROM agents WHERE id='human' AND kind='human'").fetchone()
        if row and _usable_owner(row["owner_name"]):
            return _usable_owner(row["owner_name"])
    except Exception:                                            # noqa: BLE001
        pass
    try:
        row = conn.execute(
            "SELECT name FROM agents WHERE id='human' AND kind='human'").fetchone()
        if row and _usable_owner(row["name"]):
            return _usable_owner(row["name"])
    except Exception:                                            # noqa: BLE001
        pass
    try:
        row = conn.execute(
            "SELECT owner_name FROM agents WHERE kind='human' AND owner_name<>'' "
            "ORDER BY (id='human') DESC LIMIT 1").fetchone()
        if row and _usable_owner(row["owner_name"]):
            return _usable_owner(row["owner_name"])
    except Exception:                                            # noqa: BLE001
        pass
    return ""


def _identity_prefixes() -> dict[str, str]:
    """`identity.json` 里本机 agent 的**前缀**（前缀的真相源，见 `ensure_local_agent_names`）。"""
    import json
    import os
    import pathlib

    home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa")).expanduser()
    try:
        data = json.loads((home / "identity.json").read_text(encoding="utf-8"))
    except Exception:                                            # noqa: BLE001
        return {}
    out: dict[str, str] = {}
    for a in (data.get("agents") or []):
        aid = str((a or {}).get("agent_id") or "").strip()
        disp = str((a or {}).get("display_name") or "").strip()
        if aid and disp:
            out[aid] = split_name(disp)[0] or disp
    return out


def ensure_local_agent_names(conn) -> list[tuple[str, str, str]]:
    """把本机 AI agent 归一到 `<前缀>.<username>`；返回 [(id, 旧名, 新名)]。

    真相源（Owner 2026-11-12 裁决，别改这个前提）
    --------------------------------------------
    * **username 全局唯一 → 中心是唯一真相**：这里只读当前句柄，不自己造名字；
    * **前缀本机去重 → 前缀的真相源是本地**：优先取 `identity.json` 的 `display_name`
      前缀，其次库里已有的前缀；**不改前缀大小写、不从中心取前缀**。

    全名的全局唯一由规则保证：「本地去重的前缀」+「全局唯一的 username」。
    因为前缀归本地管，重名必须在这里就地解决（撞名补 `-2`、`-3`）。
    远端 agent 一律不碰：它们的名字由对方那台机器按同一条规则产生。
    """
    owner = clean_owner(local_owner_handle(conn))
    if not owner:
        return []
    try:
        rows = conn.execute(
            "SELECT id, name, full_name, owner_name, kind FROM agents "
            "WHERE kind='ai' AND id NOT IN ('system')").fetchall()
    except Exception:                                            # noqa: BLE001
        return []

    prefixes = _identity_prefixes()
    local_ids = set(prefixes)
    # 先用**远端** agent 与本机 human 占住的名字，避免本机改名撞上别人。
    used: set[str] = set()
    for r in rows:
        oname = str(r["owner_name"] or "").strip()
        nm = str(r["name"] or "").strip()
        aid = str(r["id"] or "")
        if local_ids:
            is_local = aid in local_ids
        else:                       # 没有 identity 名单时退回旧判据
            is_local = not (oname and oname != owner)
        if nm and not is_local:
            used.add(nm.lower())

    changed: list[tuple[str, str, str]] = []
    for r in rows:
        aid = str(r["id"] or "")
        name = str(r["name"] or "").strip()
        old_full = str(r["full_name"] or "").strip()
        oname = str(r["owner_name"] or "").strip()
        if not aid or not name:
            continue
        # 归属判定用 identity 名单（本地域真相）；owner_name 是投影，可能滞后一轮，
        # 旧判据会把自己改名后残留的旧 owner_name 误判成"远端"而跳过。
        if local_ids:
            if aid not in local_ids:
                continue
        elif oname and oname != owner:
            continue
        prefix = (prefixes.get(aid) or split_name(name)[0] or name or "agent").strip() or "agent"
        if SEP in prefix:                     # 前缀里不能带分隔符
            prefix = prefix.replace(SEP, "-")
        new = f"{prefix}{SEP}{owner}"
        if new.lower() in used:
            n = 2
            while f"{prefix}-{n}{SEP}{owner}".lower() in used:
                n += 1
            new = f"{prefix}-{n}{SEP}{owner}"
        new = new[:MAX_NAME]
        used.add(new.lower())
        if new == name:
            continue
        # full_name 语义是 `<name>@<node>`：后缀保留，前缀跟着改名。
        suffix = ("@" + old_full.rsplit("@", 1)[1]) if "@" in old_full else "@local"
        full = (new + suffix)[:128]
        try:
            conn.execute("UPDATE agents SET name=?, full_name=? WHERE id=?",
                         (new, full, aid))
        except Exception:                                        # noqa: BLE001
            # full_name 有 UNIQUE 约束：冲突时只改 name，不阻塞其它 agent。
            try:
                conn.execute("UPDATE agents SET name=? WHERE id=?", (new, aid))
            except Exception:                                    # noqa: BLE001
                continue
        changed.append((aid, name, new))
    if changed:
        try:
            conn.commit()
        except Exception:                                        # noqa: BLE001
            pass
    return changed


def ensure_identity_agents(conn) -> list[str]:
    """把 `identity.json` 里登记的本机 agent 落进 `agents` 表（幂等）。

    为什么需要：identity 是安装/认领时写的真相源，`agents` 是业务投影。
    两者不同步时（换机、重装、库被重建），本机 agent 在业务库里根本不存在：
    它不会出现在 `room_members`，`executor_bridge._local_ais()` 返回空，
    于是群里 @ 它永远解析不到 —— 跨机派活整条链路直接断掉。
    2026-11-10 真机实测：Windows 侧 identity 里有 `Warm`，`agents` 表里没有，
    `@Warm / @alice / @bob` 全部解析为空，消息被标成"已派活"后丢弃。

    只增不改：已存在的 id 一律不碰（名字/状态由既有逻辑维护）。
    """
    import json
    import os
    import pathlib
    import time as _time

    home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
    try:
        idf = json.loads((home / "identity.json").read_text(encoding="utf-8"))
    except Exception:                                            # noqa: BLE001
        return []
    agents = idf.get("agents") or []
    if not isinstance(agents, list):
        return []
    owner_id = str((idf.get("center") or {}).get("owner_id") or "")
    node = idf.get("node") or {}
    node_id = str(node.get("node_id") or "")
    handle = local_owner_handle(conn) or clean_owner(str((idf.get("center") or {}).get("username") or ""))
    now = _time.strftime("%Y-%m-%d %H:%M:%S")
    # node_id 有外键指向 nodes(id)，而 `nodes.id` 存的是**别名**（`PC0G`），
    # identity 里是 `nod_*` —— 直接写 nod_* 必然外键失败，被 `INSERT OR IGNORE`
    # 静默吞掉（既不报错也不插入）。更麻烦的是 UI 的 agent 列表带
    # `node_id is not null`，写 NULL 等于"补了也看不见"。所以这里必须落成
    # 真实节点行：先按别名认，再退到本机唯一节点，最后才补一行 nodes。
    node_val = ""
    alias = str(node.get("alias") or "")[:64]
    try:
        if alias and conn.execute("SELECT 1 FROM nodes WHERE id=? OR alias=?",
                                  (alias, alias)).fetchone():
            node_val = alias
        if not node_val:
            row = conn.execute("SELECT id FROM nodes ORDER BY is_main DESC, created_at LIMIT 1").fetchone()
            node_val = str(row["id"])[:64] if row else ""
        if not node_val and alias:
            conn.execute("INSERT OR IGNORE INTO nodes(id,hostname,alias,is_main) VALUES(?,?,?,1)",
                         (alias, alias, alias))
            node_val = alias
    except Exception:                                            # noqa: BLE001
        node_val = ""
    added: list[str] = []
    for i, a in enumerate(agents):
        if not isinstance(a, dict):
            continue
        aid = str(a.get("agent_id") or "").strip()
        if not aid:
            continue
        try:
            if conn.execute("SELECT 1 FROM agents WHERE id=?", (aid,)).fetchone():
                continue
        except Exception:                                        # noqa: BLE001
            return added
        display = str(a.get("display_name") or a.get("name") or aid).strip() or aid
        nm = display if is_qualified(display) else agent_name(split_name(display)[0] or "agent", handle)
        full = (nm + "@" + (str(node.get("alias") or "") or "local"))[:128]
        primary = 0
        if i == 0:
            # 每个 owner 只留一个首席：已有就不抢。
            row = conn.execute(
                "SELECT 1 FROM agents WHERE kind='ai' AND is_primary=1 AND coalesce(owner_id,'')=?",
                (owner_id,)).fetchone() if owner_id else None
            primary = 0 if row else 1
        try:
            # persona_json 是 NOT NULL 且无默认值：漏了它同样会被 OR IGNORE 吞掉。
            cur = conn.execute(
                "INSERT OR IGNORE INTO agents(id,name,kind,node_id,full_name,owner_id,owner_name,"
                "persona_json,status,is_primary,created_at) "
                "VALUES(?,?, 'ai',?,?,?,?,?, 'active',?,?)",
                (aid[:64], nm[:64], node_val or None, full, owner_id or None,
                 handle or None, json.dumps({"name": nm}, ensure_ascii=False), primary, now))
            if cur.rowcount:
                added.append(aid)
        except Exception:                                        # noqa: BLE001
            continue
    if added:
        try:
            conn.commit()
        except Exception:                                        # noqa: BLE001
            pass
    return added
