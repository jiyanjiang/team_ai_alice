"""Group command -> task/inbox materialization.

Phase 4 has one execution ingress: a command is materialized into a task, and
only a claimed task gets an inbox brief for the dispatcher.  No direct
``executor_bridge.submit`` from a remote message.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading

from . import chatwork, group_command, presence, rooms, tasks
from .procutil import pid_alive


_DISPATCH_LOCK = threading.Lock()


def _dispatcher_pid(agent: str) -> int | None:
    lock = chatwork.ROOT / "runtime" / f".dispatcher.{agent}.lock"
    try:
        pid = int(lock.read_text(encoding="utf-8").strip() or "0")
        if pid > 0 and pid_alive(pid):
            return pid
    except Exception:  # noqa: BLE001
        return None
    return None


def ensure_agent_dispatcher(agent: str) -> bool:
    """Start the normal dispatcher if no live one exists for this agent.

    The task/inbox chain stays authoritative; this only prevents a claimed
    task from waiting forever after an upgrade/restart forgot the daemon.
    """
    agent = str(agent or "")
    if not agent:
        return False
    with _DISPATCH_LOCK:
        if _dispatcher_pid(agent):
            return True
        script = chatwork.ROOT / "runtime" / "dispatcher.py"
        if not script.is_file():
            return False
        log = chatwork.ROOT / "runtime" / f"dispatcher.{agent}.web.log"
        try:
            log.parent.mkdir(parents=True, exist_ok=True)
            out = log.open("ab")
            env = os.environ.copy()
            env.setdefault("TEAMAI_URL",
                           "http://127.0.0.1:" + os.environ.get("TAA_HTTP_PORT", "6080"))
            subprocess.Popen(
                [sys.executable, str(script), "--as", agent, "--interval", "5"],
                cwd=str(chatwork.ROOT), env=env,
                stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            return True
        except Exception:  # noqa: BLE001
            return False


def ensure_claimed_dispatchers(conn) -> int:
    """Wake a dispatcher for a claimed task whose room is a real center group."""
    try:
        rows = conn.execute(
            "SELECT DISTINCT t.assigned_to FROM tasks t "
            "JOIN group_command gc ON gc.task_id=t.id "
            "JOIN rooms r ON r.id=gc.room_id "
            "WHERE t.status IN ('claimed','in_progress') "
            "AND t.assigned_to IS NOT NULL AND r.center_group_id IS NOT NULL "
            "AND r.center_group_id!=''").fetchall()
    except Exception:  # noqa: BLE001
        return 0
    n = 0
    for row in rows:
        if ensure_agent_dispatcher(str(row["assigned_to"] or "")):
            n += 1
    return n


def _message_body(conn, room_id: str, mid: int) -> str:
    row = conn.execute("SELECT body FROM room_messages WHERE id=? AND room_id=?",
                       (int(mid), room_id)).fetchone()
    return str(row["body"] or "").strip() if row else ""


def _source_id(cmd: dict) -> str:
    msg = str(cmd.get("center_message_id") or cmd.get("peer_message_id") or
              f"local:{cmd.get('room_id')}:{cmd.get('local_message_id')}")
    return f"group:{cmd.get('group_id') or cmd.get('room_id')}:{msg}:{cmd.get('target_agent_id')}"


def _created_by_id(conn, source_owner: str, target: str) -> str:
    """Map an owner/command source to a legal agents.id foreign key.

    tasks.created_by points at agents.id, not owners.  A raw owner id such as
    own_f202... makes the INSERT fail with FK constraint failed; the old tick
    then looked like a silent no-op.
    """
    source_owner = str(source_owner or "")
    candidates = [source_owner]
    if source_owner:
        candidates.append("remote-human-" + source_owner)
    candidates.extend([str(target or ""), "human"])
    for candidate in candidates:
        if candidate and conn.execute("select 1 from agents where id=?", (candidate,)).fetchone():
            return candidate
    return ""


def _create_task(conn, cmd: dict) -> str:
    target = str(cmd.get("target_agent_id") or "")
    body = _message_body(conn, str(cmd.get("room_id") or ""), int(cmd.get("local_message_id") or 0))
    title = ("群聊指令 · " + (" ".join(body.split())[:68])).strip() or "群聊指令"
    description = (f"来自跨机群聊 {cmd.get('room_id')} 的指令。\n"
                   f"下达者 owner：{cmd.get('source_owner_id')}；目标 agent：{target}。\n\n{body}")
    acceptance = "完成该群聊指令，在群聊回报结论/验证/产物；需要附件时附可访问产物。"
    source_id = _source_id(cmd)
    old = conn.execute(
        "SELECT id FROM tasks WHERE json_extract(metadata,'$.source_msg_id')=? LIMIT 1",
        (source_id,)).fetchone()
    if old:
        return str(old["id"])
    tid = tasks.new_id("t")
    source_owner = str(cmd.get("source_owner_id") or "")
    created_by = _created_by_id(conn, source_owner, target)
    meta = {
        "for_agent": target,
        "source_msg_id": source_id,
        "group_command_id": cmd.get("id"),
        "source_owner_id": source_owner,
        "target_owner_id": cmd.get("target_owner_id"),
        "lane": "short",
        "kind": "short",
    }
    conn.execute(
        "INSERT INTO tasks(id,title,description,acceptance_criteria,priority,complexity,difficulty,"
        "status,required_skills,resource_req,tags,parent_id,created_by,metadata) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (tid, title[:160], description[:4000], acceptance[:1000], 2, 0.5, 0.5,
         "backlog", "[]", "{}", json.dumps(["group", "cross-owner"], ensure_ascii=False),
         None, created_by, json.dumps(meta, ensure_ascii=False)))
    conn.commit()
    return tid


def _claim_and_brief(conn, cmd: dict, task_id: str) -> bool:
    target = str(cmd.get("target_agent_id") or "")
    try:
        tasks.claim(conn, task_id, target, reason="group command")
    except Exception:  # noqa: BLE001
        return False
    title = conn.execute("SELECT title,description,acceptance_criteria,tags,priority "
                         "FROM tasks WHERE id=?", (task_id,)).fetchone()
    if not title:
        return False
    try:
        chatwork.write_inbox_brief(
            target, task_id,
            title=str(title["title"] or "群聊指令"),
            description=str(title["description"] or ""),
            acceptance_criteria=str(title["acceptance_criteria"] or ""),
            tags=json.loads(title["tags"] or "[]"),
            priority=int(title["priority"] or 2))
    except Exception:  # noqa: BLE001
        return False
    return True


def materialize(conn, cmd: dict) -> dict:
    """Create task/claim/inbox for an immediate or idle command once."""
    group_command.ensure(conn)
    cid = str(cmd.get("id") or "")
    row = group_command.get(conn, cid)
    if not row:
        return {}
    if row.get("task_id"):
        return row
    state = str(row.get("state") or "")
    if state not in ("immediate", "idle"):
        return row
    target = str(row.get("target_agent_id") or "")
    owner = str(row.get("target_owner_id") or "")
    # Re-check at materialization time; a consent window can outlive presence.
    if not presence.is_online(conn, target, "agent"):
        conn.execute("UPDATE group_command SET state='offline_agent',"
                     "last_error='agent_offline',updated_at=datetime('now','localtime') WHERE id=?",
                     (cid,))
        conn.commit()
        return group_command.get(conn, cid) or {}
    if owner and not presence.is_online(conn, owner, "owner"):
        conn.execute("UPDATE group_command SET state='offline_owner',"
                     "last_error='owner_offline',updated_at=datetime('now','localtime') WHERE id=?",
                     (cid,))
        conn.commit()
        return group_command.get(conn, cid) or {}
    # Explicitly mentioned target is online: recover the local room before the
    # task result needs a turn/report surface.
    try:
        rr = conn.execute("select status,read_only from rooms where id=?", (row.get("room_id"),)).fetchone()
        if rr and str(rr["status"] or "") != "running" and not int(rr["read_only"] or 0):
            rooms.start_room(conn, str(row.get("room_id")))
    except Exception:  # noqa: BLE001
        pass
    try:
        task_id = _create_task(conn, row)
    except Exception as exc:  # noqa: BLE001
        # Never leave an immediate command silently stuck: surface the real
        # failure in group_command.last_error for the health endpoint.
        conn.execute("UPDATE group_command SET last_error=?,"
                     "updated_at=datetime('now','localtime') WHERE id=?",
                     (f"materialize_failed:{type(exc).__name__}:{str(exc)[:180]}", cid))
        conn.commit()
        return group_command.get(conn, cid) or {}
    claimed = _claim_and_brief(conn, row, task_id)
    if not claimed:
        conn.execute("UPDATE group_command SET task_id=?,state='failed',"
                     "last_error='claim_or_inbox_failed',"
                     "updated_at=datetime('now','localtime') WHERE id=?", (task_id, cid))
        conn.commit()
        return group_command.get(conn, cid) or {}
    conn.execute("UPDATE group_command SET task_id=?,state='queued',"
                 "updated_at=datetime('now','localtime') WHERE id=?", (task_id, cid))
    conn.commit()
    rr = conn.execute("SELECT center_group_id FROM rooms WHERE id=?", (row.get("room_id"),)).fetchone()
    if claimed and rr and str(rr["center_group_id"] or ""):
        ensure_agent_dispatcher(target)
    return group_command.get(conn, cid) or {}


def tick(conn) -> int:
    """Expire consent windows, then materialize immediate/idle commands."""
    group_command.expire_due(conn)
    try:
        ensure_claimed_dispatchers(conn)
    except Exception:  # noqa: BLE001
        pass
    rows = conn.execute(
        "SELECT * FROM group_command WHERE state IN ('immediate','idle') "
        "AND task_id IS NULL ORDER BY created_at").fetchall()
    n = 0
    for r in rows:
        before = dict(r).get("task_id")
        out = materialize(conn, dict(r))
        if out.get("task_id") and not before:
            n += 1
    return n
