"""身份模型：**鉴权即身份，渲染只读不猜**（docs/559）。

为什么要有这一层（2026-11-12 实测）：
  1. `/app/*` 判"我是谁"靠 `human_id(c)` 查库里唯一 kind='human' 那行，与 cookie/session 无关；
     库里多一行或改错名，全站身份立刻串。
  2. `/v1/*` 只校验 per-agent key，**不校验机器码**，同机多 agent 没有锚。
  3. 远端真人名靠对端上报，`peer_sync` 原样信任 → warmachine 被本机写成 `jiyanjiang`，
     朋友圈四条帖全显示成本机 owner，无法区分。

本模块只做三件事，且**全部只读**：
  - `Actor`：一次请求的身份，由鉴权通道产出，不由字符串猜；
  - `resolve_*`：把"登录态 / key / 单机兜底"落成 Actor（兜底必须带 source="fallback"）；
  - `audit`：四向一致性快照（DB 名 ↔ identity.json ↔ agents/<id> 目录 ↔ .key），供自检与门禁用。

**本模块不进渲染路径**。接线顺序见 docs/559 §5（P1 只读自检 → P2 改渲染 → …）。
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

from core.agent_identity import agent_name, is_qualified, split_name

# 规范：全小写；agent = <前缀>.<owner>；真人 = <owner>（不含点）
_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")
_PREFIX_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")

REMOTE_HUMAN_PREFIX = "remote-human-"


@dataclass(frozen=True)
class Actor:
    """一次请求的身份。`name` 是**规范显示名**，落库时应作为快照保存。"""

    kind: str                  # "human" | "ai"
    id: str                    # human → owner_id；ai → agent_id
    name: str                  # 规范显示名（human=owner 名，ai=<前缀>.<owner>）
    owner_id: str = ""
    node_id: str = ""
    source: str = "key"        # "login" | "key" | "fallback"
    extra: dict = field(default_factory=dict)

    @property
    def is_fallback(self) -> bool:
        return self.source == "fallback"

    def as_dict(self) -> dict:
        return {
            "kind": self.kind, "id": self.id, "name": self.name,
            "owner_id": self.owner_id, "node_id": self.node_id,
            "source": self.source, **({"extra": self.extra} if self.extra else {}),
        }


# ---------------------------------------------------------------- 身份来源（只读）

def load_identity(home: str | os.PathLike | None = None) -> dict:
    """读 `~/.taa/identity.json`；缺失或损坏返回空 dict（不抛）。"""
    p = Path(home or os.environ.get("TAA_HOME") or (Path.home() / ".taa")) / "identity.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:                                              # noqa: BLE001
        return {}


def center_owner(ident: dict | None = None) -> tuple[str, str]:
    """(owner_id, username)。**这是真人 ID 的唯一权威来源**（中心去重）。"""
    c = (ident if ident is not None else load_identity()).get("center") or {}
    return str(c.get("owner_id") or ""), str(c.get("username") or "")


def local_node(ident: dict | None = None) -> tuple[str, str]:
    n = (ident if ident is not None else load_identity()).get("node") or {}
    return str(n.get("node_id") or ""), str(n.get("alias") or "")


def resolve_human(conn: sqlite3.Connection, ident: dict | None = None) -> Actor | None:
    """本机真人。**唯一允许的兜底**：单机单 owner，source="fallback"。

    语义（docs/559 §3.1）：有登录态时应用 login 分支（P3 接线）；此处只处理
    "本机唯一 owner" 的兜底，且必须显式标 fallback，落库时写 author_source。
    """
    ident = ident if ident is not None else load_identity()
    owner_id, username = center_owner(ident)
    node_id, _ = local_node(ident)
    if not username:
        return None
    return Actor(kind="human", id=owner_id or "human", name=username,
                 owner_id=owner_id, node_id=node_id, source="fallback")


def resolve_agent(conn: sqlite3.Connection, agent_id: str,
                  ident: dict | None = None) -> Actor | None:
    """agent 身份：名必须是 `<前缀>.<owner>`，owner 段取本机中心 username。

    名以 **数据库现状** 为准（Owner 口径：名已存在就不要捏造），
    只做规范校验与 owner 段核对，不在此处改名。
    """
    row = conn.execute("select id,name,kind,owner_id,node_id from agents where id=?",
                       (str(agent_id or ""),)).fetchone()
    if not row:
        return None
    ident = ident if ident is not None else load_identity()
    owner_id, username = center_owner(ident)
    node_id, _ = local_node(ident)
    name = str(row["name"] or "")
    try:
        db_owner = str(row["owner_id"] or "")
        db_node = str(row["node_id"] or "")
    except (IndexError, KeyError):
        db_owner = db_node = ""
    return Actor(kind="ai", id=str(row["id"]), name=name,
                 owner_id=db_owner or owner_id, node_id=db_node or node_id, source="key")


# ---------------------------------------------------------------- 一致性快照（只读）

def _agents_dir() -> Path:
    return Path(os.environ.get("TEAMAI_AGENTS_DIR")
                or Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa")) / "agents")


def audit(conn: sqlite3.Connection, ident: dict | None = None) -> dict:
    """四向一致性 + 署名唯一性快照。**只读，不改任何数据。**

    返回结构：
      {
        "owner": {"owner_id","username","node_id"},
        "violations": [{"code","level","subject","detail"}],
        "summary": {"agents": n, "violations": n, "by_code": {...}},
      }

    判据编号与 docs/559 §4 的 I3/I4/S2/S3/S4 对应，可直接被门禁断言。
    """
    ident = ident if ident is not None else load_identity()
    owner_id, username = center_owner(ident)
    node_id, alias = local_node(ident)
    adir = _agents_dir()
    violations: list[dict] = []

    def bad(code: str, subject: str, detail: str, level: str = "error") -> None:
        violations.append({"code": code, "level": level,
                           "subject": subject, "detail": detail})

    rows = conn.execute(
        "select id,name,kind,owner_id,node_id,status from agents order by kind,id"
    ).fetchall()

    # ① agent 名规范（I3）
    for r in rows:
        aid, name, kind = str(r["id"]), str(r["name"] or ""), str(r["kind"] or "")
        if aid == "system":
            # 内置账号（名="系统"）不参与命名规范判定，但它仍是 agent 行
            continue
        if kind == "ai":
            if not is_qualified(name):
                bad("I3/裸名", aid, f"ai 名 {name!r} 不含 '.'，应为 <前缀>.<owner>")
            elif name != name.lower():
                bad("I3/大写", aid, f"ai 名 {name!r} 含大写，规范要求全小写")
            else:
                prefix, suffix = split_name(name)
                if not _PREFIX_RE.match(prefix):
                    bad("I3/前缀", aid, f"前缀 {prefix!r} 不合规（只允许小写字母数字_-）")
                if username and suffix != username:
                    # 远端 agent 的 owner 段不是本机 username，属正常；只对本机 agent 判
                    if str(r["node_id"] or "") == node_id:
                        bad("I3/后缀", aid,
                            f"本机 agent 后缀 {suffix!r} ≠ 中心 username {username!r}")
        elif kind == "human":
            if is_qualified(name):
                bad("I3/真人带点", aid, f"真人名 {name!r} 含 '.'，真人不该带 owner 后缀")
            if not _NAME_RE.match(name):
                bad("I3/真人格式", aid, f"真人名 {name!r} 不合规范（小写字母数字_-）")

    # ② 显示名唯一（S2）：同名不同 id 即红
    seen: dict[str, list[str]] = {}
    for r in rows:
        seen.setdefault(str(r["name"] or ""), []).append(str(r["id"]))
    for name, ids in seen.items():
        if name and len(ids) > 1:
            bad("S2/重名", name, "同名多 id：" + ", ".join(ids))

    # ③ 远端真人不得与本机 owner 撞名（S3，warmachine→jiyanjiang 那条）
    if username:
        for r in rows:
            aid = str(r["id"])
            if str(r["kind"]) == "human" and aid.startswith(REMOTE_HUMAN_PREFIX) \
                    and str(r["name"] or "") == username:
                bad("S3/远端撞名", aid,
                    f"远端真人与本机 owner 同名 {username!r}；应按中心 username 显示（或按 owner_id 缩略）")

    # ④ identity.json ↔ DB 名一致（I4）
    id_agents = {str(a.get("agent_id")): str(a.get("display_name") or "")
                 for a in (ident.get("agents") or [])}
    for aid, disp in id_agents.items():
        row = next((r for r in rows if str(r["id"]) == aid), None)
        if row is None:
            bad("I4/缺行", aid, f"identity.json 有该 agent（display_name={disp!r}），DB 无此 id",
                level="warn")
        elif disp and str(row["name"] or "") != disp:
            bad("I4/名不一致", aid,
                f"identity={disp!r} ≠ db={str(row['name'] or '')!r}")

    # ⑤ 目录与 .key 存在性（I4）
    for r in rows:
        aid, kind, status = str(r["id"]), str(r["kind"]), str(r["status"] or "")
        if kind != "ai" or status not in ("active", ""):
            continue
        if aid in ("system",) or aid.startswith(REMOTE_HUMAN_PREFIX):
            continue
        d = adir / aid
        if not d.is_dir():
            bad("I4/无目录", aid, f"{d} 不存在（改名未迁目录或从未建目录）", level="warn")
        elif not (d / ".key").is_file():
            bad("I4/无key", aid, f"{d / '.key'} 缺失（该 agent 无法用 key 鉴权）", level="warn")

    by_code: dict[str, int] = {}
    for v in violations:
        by_code[v["code"]] = by_code.get(v["code"], 0) + 1
    return {
        "owner": {"owner_id": owner_id, "username": username,
                  "node_id": node_id, "alias": alias},
        "violations": violations,
        "summary": {"agents": len(rows), "violations": len(violations), "by_code": by_code},
    }
