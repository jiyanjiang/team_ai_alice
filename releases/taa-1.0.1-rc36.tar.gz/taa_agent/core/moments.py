"""朋友圈 Moments（M1）：九宫格(≤9 图) + 点赞 + 评论。

依据：docs/79_朋友圈与私聊DM_方案.md §3–§5、接口契约 docs/80_接口契约_M1朋友圈_v1.md。

设计红线（docs/79 §9 / docs/80 §5）：
  * **可见性一律服务端过滤**（前端藏不算实现）：非好友读不到任何帖/子资源。
  * **人格私密维度（body/wardrobe）永不进任何返回体**：作者视图是**白名单投影**，
    根本不 SELECT persona_json（比 strip_private 更硬）。
  * 删除一律**软删**（deleted_at），可审计。
  * 点赞/取消**幂等**：主键 (moment_id, agent_id) 兜底。
"""
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from datetime import datetime

from . import community

MAX_MEDIA = 9
MAX_BODY = 2000
MAX_COMMENT = 1000
UPLOAD_PREFIX = "/static/uploads/"
VISIBILITIES = {"friends", "project", "except"}
FRIEND_ACTIONS = {"request", "accept", "reject", "block"}


class MomentError(ValueError):
    """业务校验失败 → 422（code 为契约错误码）。"""

    http = 422

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class MomentNotFound(Exception):
    """帖不存在或当前 viewer 不可见 → 404（不泄露存在性）。"""


class MomentForbidden(Exception):
    """非作者执行作者专属操作 → 403。"""


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


# ------------------------------------------------------------------ 好友关系
def sync_project_friendships(conn, project_id: str | None = None) -> int:
    """把「同项目成员」派生为好友落表（source=project）。

    为什么落表而不是纯 join：docs/79 §4 明确"项目成员由 project_members 派生后落表"，
    便于统一按 friendships 判定，也便于将来 request/block 覆盖 project 关系。
    INSERT OR IGNORE 保证不覆盖已存在的 request/blocked 行。
    """
    if project_id:
        pids = [project_id]
    else:
        pids = [r["project_id"] for r in
                conn.execute("SELECT DISTINCT project_id FROM project_members").fetchall()]
    added = 0
    for pid in pids:
        members = [r["member_id"] for r in
                   conn.execute("SELECT member_id FROM project_members WHERE project_id=?",
                                (pid,)).fetchall()]
        for a in members:
            for b in members:
                if a == b:
                    continue
                cur = conn.execute(
                    "INSERT OR IGNORE INTO friendships(a_id,b_id,source,status,created_at) "
                    "VALUES (?,?,'project','accepted',?)", (a, b, _now()))
                added += cur.rowcount
    if added:
        conn.commit()
    return added


def team_member_ids(conn) -> list[str]:
    """全队成员 = `agents` 表 ∩ **在册节点**（`nodes`）。

    口径（Owner：「项目组内互为好友」，而 Team AI 本身即一个项目组）：
    凡是挂在**已登记节点**上的 AI 成员，即视为同一「Team AI 项目组」的成员。
    人类账户（node_id 为空 / 不在 nodes）**不参与**自动派生——他们保留既有显式好友与
    「非好友需请求」的请求制，用于外来者与尚未入册的新人。
    """
    rows = conn.execute(
        "SELECT DISTINCT a.id AS id FROM agents a JOIN nodes n ON n.id=a.node_id "
        "WHERE a.node_id IS NOT NULL AND a.node_id<>'' AND a.kind='ai' "
        "AND a.status<>'offline'").fetchall()
    return [r["id"] for r in rows]


def sync_team_friendships(conn) -> int:
    """把「同队成员（agents ∩ 在册节点）」派生为好友落表（`source='team'`）。

    * 与 `sync_project_friendships` 并行：一个管「某个项目组」，一个管「Team AI 全队」。
    * `ON CONFLICT ... DO UPDATE ... WHERE status='pending'`：把**请求态**升为 `team/accepted`
      ——既然已经同队，就不应再停在「请求」态；但**绝不覆盖 `blocked`**（屏蔽优先，隐私红线）。
    * 幂等：已 `accepted` 的行不动，重复调用返回 0。
    """
    members = team_member_ids(conn)
    added = 0
    for a in members:
        for b in members:
            if a == b:
                continue
            cur = conn.execute(
                "INSERT INTO friendships(a_id,b_id,source,status,created_at) "
                "VALUES (?,?,'team','accepted',?) "
                "ON CONFLICT(a_id,b_id) DO UPDATE SET source='team', status='accepted' "
                "WHERE friendships.status='pending'", (a, b, _now()))
            added += cur.rowcount
    if added:
        conn.commit()
    return added


def sync_derived_friendships(conn, project_id: str | None = None) -> int:
    """统一派生入口：项目组（project）+ 全队（team）。返回新写入/升级的行数。"""
    return sync_project_friendships(conn, project_id) + sync_team_friendships(conn)


_SYNC_TTL = float(os.environ.get("TAA_FRIEND_SYNC_TTL") or 60)
_SYNC_LOCK = threading.Lock()
_LAST_SYNC = 0.0


def _maybe_sync_derived(conn, project_id: str | None = None) -> int:
    """派生好友的**节流**入口：默认 60s 内不重复写库。

    为什么需要：`friend_ids()` 在 DM 列表、朋友圈可见性等**读路径**里被高频调用，
    原实现每次都跑 project+team 的全量 UPSERT 并 commit —— 读请求因此持有写锁，
    与后台写（风格学习、心跳）相撞就排队，表现为页面偶发十几秒卡顿与
    "database is locked"（2026-11-14 Win/本机双向证实）。
    60s 内不重算是可接受的：新增好友走显式写入点，不依赖这里的被动派生。
    """
    global _LAST_SYNC
    now = time.time()
    if _LAST_SYNC and now - _LAST_SYNC < _SYNC_TTL:
        return 0
    with _SYNC_LOCK:
        now = time.time()
        if _LAST_SYNC and now - _LAST_SYNC < _SYNC_TTL:
            return 0
        n = sync_derived_friendships(conn, project_id)
        _LAST_SYNC = time.time()
        return n


def friend_ids(conn, agent_id: str) -> set[str]:
    """返回 accepted 好友集合（排除 blocked）。blocked 关系优先于 project / team。"""
    _maybe_sync_derived(conn)
    rows = conn.execute(
        "SELECT a_id AS x, status FROM friendships WHERE b_id=? "
        "UNION SELECT b_id AS x, status FROM friendships WHERE a_id=?", (agent_id, agent_id)
    ).fetchall()
    out: set[str] = set()
    blocked: set[str] = set()
    for r in rows:
        if r["status"] == "accepted":
            out.add(r["x"])
        elif r["status"] == "blocked":
            blocked.add(r["x"])
    return out - blocked - {agent_id}


def is_friend(conn, a: str, b: str) -> bool:
    if a == b:
        return True
    return b in friend_ids(conn, a)


def list_friendships(conn, agent_id: str) -> dict:
    _maybe_sync_derived(conn)
    friends, pending_in, pending_out = [], [], []
    # 关系可能**双向各存一行**（project 派生 + request/accept 都会写两个方向），
    # 直接遍历会把同一好友列两次；按对方 id 归并，并让 accepted 覆盖 pending。
    prio = {"accepted": 3, "pending": 2, "blocked": 1}
    best: dict[str, object] = {}
    rows = conn.execute(
        "SELECT a_id, b_id, source, status, created_at FROM friendships "
        "WHERE a_id=? OR b_id=?", (agent_id, agent_id)).fetchall()
    for r in rows:
        other = r["b_id"] if r["a_id"] == agent_id else r["a_id"]
        cur = best.get(other)
        if cur is None or prio.get(r["status"], 0) > prio.get(cur["status"], 0):
            best[other] = r
    for other, r in best.items():
        if r["status"] == "blocked":
            continue                                   # blocked 一律非好友（docs/79 §3）
        item = _author_view(conn, other)
        item.update({"source": r["source"], "status": r["status"], "since": r["created_at"]})
        if r["status"] == "accepted":
            friends.append(item)
        elif r["status"] == "pending":
            (pending_out if r["a_id"] == agent_id else pending_in).append(item)
    friends.sort(key=lambda x: x["id"])
    return {"friends": friends, "pending_in": pending_in, "pending_out": pending_out}


def friendship_action(conn, agent_id: str, to: str, action: str) -> dict:
    if action not in FRIEND_ACTIONS:
        raise MomentError("bad_action")
    if not to or to == agent_id:
        raise MomentError("bad_target")
    if not conn.execute("SELECT 1 FROM agents WHERE id=?", (to,)).fetchone():
        raise MomentError("bad_target")
    if action == "block":
        conn.execute("INSERT INTO friendships(a_id,b_id,source,status,created_at) "
                     "VALUES (?,?,'request','blocked',?) "
                     "ON CONFLICT(a_id,b_id) DO UPDATE SET status='blocked'", (agent_id, to, _now()))
        conn.execute("INSERT INTO friendships(a_id,b_id,source,status,created_at) "
                     "VALUES (?,?,'request','blocked',?) "
                     "ON CONFLICT(a_id,b_id) DO UPDATE SET status='blocked'", (to, agent_id, _now()))
    elif action == "request":
        conn.execute("INSERT OR IGNORE INTO friendships(a_id,b_id,source,status,created_at) "
                     "VALUES (?,?,'request','pending',?)", (agent_id, to, _now()))
    elif action == "accept":
        for (x, y) in ((agent_id, to), (to, agent_id)):
            conn.execute("INSERT INTO friendships(a_id,b_id,source,status,created_at) "
                         "VALUES (?,?,'request','accepted',?) "
                         "ON CONFLICT(a_id,b_id) DO UPDATE SET status='accepted'",
                         (x, y, _now()))
    elif action == "reject":
        conn.execute("DELETE FROM friendships WHERE a_id=? AND b_id=? AND source='request'",
                     (to, agent_id))
        conn.execute("DELETE FROM friendships WHERE a_id=? AND b_id=? AND source='request'",
                     (agent_id, to))
    conn.commit()
    return {"ok": True, "action": action, "friend": is_friend(conn, agent_id, to)}


# ------------------------------------------------------------------ 作者视图（F4）
def _author_view(conn, agent_id: str) -> dict:
    """白名单投影：只取公开身份字段，**不 SELECT persona_json**。

    这样 persona 私密维度（body/wardrobe）在设计上就没有进入返回体的通道（docs/80 §5 F4）。
    """
    r = conn.execute("SELECT id,name,full_name,kind FROM agents WHERE id=?", (agent_id,)).fetchone()
    if not r:
        return {"id": agent_id, "name": agent_id, "full_name": None, "kind": "ai"}
    return {"id": r["id"], "name": r["name"] or r["full_name"] or r["id"],
            "full_name": r["full_name"], "kind": r["kind"] or "ai"}


def _push_center_moment(mid: str, author_id: str, body: str, visibility: str) -> None:
    """本地朋友圈 → 中心文本镜像；尽力而为，失败不影响本地发布。"""
    if os.environ.get("TEAMAI_DB") or os.environ.get("TEAMAI_NO_CENTER_SYNC"):
        return
    try:
        import pathlib, threading, tomllib, urllib.request
        cfgp = pathlib.Path(os.environ.get("TAA_HOME", "~/.taa")).expanduser() / "config.toml"
        if not cfgp.exists():
            return
        cfg = tomllib.loads(cfgp.read_text(encoding="utf-8"))
        c = cfg.get("center") or {}
        base, key = str(c.get("base") or "").rstrip("/"), str(c.get("key") or "").strip()
        if not base or not key:
            return
        payload = json.dumps({"id": mid, "body": body[:1200], "visibility": visibility,
                              "created_at": _now()}, ensure_ascii=False).encode()
        def go():
            try:
                req = urllib.request.Request(base + "/agent/moments", data=payload, method="POST",
                    headers={"content-type": "application/json", "authorization": "Bearer " + key,
                             "user-agent": "taa-local/1"})
                urllib.request.urlopen(req, timeout=12).read()
            except Exception:
                pass
        threading.Thread(target=go, daemon=True).start()
    except Exception:
        pass


# ------------------------------------------------------------------ 主帖
def create_moment(conn, author_id: str, body: str = "", media=None,
                 visibility: str = "friends", scope=None) -> dict:
    body = (body or "").strip()
    media = media or []
    if not isinstance(media, list):
        raise MomentError("bad_media_item")
    if len(media) > MAX_MEDIA:
        raise MomentError("too_many_media")
    if not body and not media:
        raise MomentError("body required")
    if len(body) > MAX_BODY:
        raise MomentError("bad_body")
    if visibility not in VISIBILITIES:
        raise MomentError("bad_visibility")
    norm = []
    for i, it in enumerate(media):
        if not isinstance(it, dict) or not str(it.get("url") or "").strip():
            raise MomentError("bad_media_item")
        u = str(it["url"])
        if not u.startswith(UPLOAD_PREFIX) or "/" in u[len(UPLOAD_PREFIX):]:
            raise MomentError("bad_media_url")
        norm.append((i, u, it.get("w"), it.get("h"), it.get("ext")))
    # 每日额度（docs/83）：朋友圈帖同样受限（上限高于公共频道）；创建前计数校验。
    from . import quota as _quota_mod
    _quota_mod.check_and_bump(conn, author_id, _quota_mod.SCOPE_MOMENT)
    mid = new_id("m")
    conn.execute("INSERT INTO moments(id,author_id,body,visibility,scope,created_at) "
                 "VALUES (?,?,?,?,?,?)",
                 (mid, author_id, body, visibility,
                  json.dumps(scope or {}, ensure_ascii=False), _now()))
    for seq, u, w, h, ext in norm:
        conn.execute("INSERT INTO moment_media(id,moment_id,seq,url,w,h,ext) "
                     "VALUES (?,?,?,?,?,?,?)", (new_id("mm"), mid, seq, u, w, h, ext))
    conn.commit()
    _push_center_moment(mid, author_id, body, visibility)
    return get_visible(conn, author_id, mid)


def _moment_public(conn, row, viewer: str) -> dict:
    mid = row["id"]
    media = [dict(r) for r in conn.execute(
        "SELECT seq,url,w,h,ext FROM moment_media WHERE moment_id=? ORDER BY seq", (mid,)).fetchall()]
    likes = [dict(r) for r in conn.execute(
        "SELECT agent_id,emoji,created_at FROM moment_likes WHERE moment_id=? ORDER BY created_at",
        (mid,)).fetchall()]
    comments = [_comment_public(conn, r) for r in conn.execute(
        "SELECT * FROM moment_comments WHERE moment_id=? AND deleted_at IS NULL ORDER BY id",
        (mid,)).fetchall()]
    return {
        "id": mid, "author": _author_view(conn, row["author_id"]), "body": row["body"],
        "visibility": row["visibility"], "scope": _loads(row["scope"], {}),
        "media": media,
        "like_count": len(likes), "liked_by_me": any(l["agent_id"] == viewer for l in likes),
        "comment_count": len(comments), "likes": likes, "comments": comments,
        "created_at": row["created_at"], "edited_at": row["edited_at"],
    }


def _comment_public(conn, row) -> dict:
    return {"id": row["id"], "author": _author_view(conn, row["author_id"]),
            "body": row["body"], "parent_id": row["parent_id"], "created_at": row["created_at"]}


def _loads(v, default):
    try:
        return json.loads(v) if v else default
    except (TypeError, ValueError):
        return default


def timeline(conn, viewer: str, author: str | None = None, limit: int = 30,
             before: str | None = None) -> list[dict]:
    """F1：只出 viewer 可见（自己 ∪ 好友）且未软删的帖。非好友作者 → 空。"""
    try:
        limit = max(1, min(int(limit), 100))
    except (TypeError, ValueError):
        limit = 30
    visible = friend_ids(conn, viewer) | {viewer}
    sql = "SELECT * FROM moments WHERE deleted_at IS NULL"
    params: list = []
    if author:
        if author not in visible:
            return []
        sql += " AND author_id=?"
        params.append(author)
    else:
        sql += " AND author_id IN (%s)" % ",".join("?" * len(visible))
        params.extend(sorted(visible))
    if before:
        sql += " AND created_at < ?"
        params.append(before)
    sql += " ORDER BY created_at DESC, rowid DESC LIMIT ?"
    params.append(limit)
    return [_moment_public(conn, r, viewer) for r in conn.execute(sql, params).fetchall()]


def get_visible(conn, viewer: str, moment_id: str) -> dict | None:
    """F2：单帖可见性。不可见一律返回 None → 路由给 404（不泄露存在性）。"""
    r = conn.execute("SELECT * FROM moments WHERE id=? AND deleted_at IS NULL",
                     (moment_id,)).fetchone()
    if not r:
        return None
    if r["author_id"] != viewer and not is_friend(conn, viewer, r["author_id"]):
        return None
    return _moment_public(conn, r, viewer)


def soft_delete(conn, agent_id: str, moment_id: str) -> None:
    r = conn.execute("SELECT author_id FROM moments WHERE id=? AND deleted_at IS NULL",
                     (moment_id,)).fetchone()
    if not r:
        raise MomentNotFound()
    if r["author_id"] != agent_id:
        raise MomentForbidden()
    conn.execute("UPDATE moments SET deleted_at=? WHERE id=?", (_now(), moment_id))
    conn.commit()


# ------------------------------------------------------------------ 点赞（切换/幂等）
def toggle_like(conn, agent_id: str, moment_id: str, emoji: str = "👍") -> dict:
    if get_visible(conn, agent_id, moment_id) is None:
        raise MomentNotFound()
    exists = conn.execute("SELECT 1 FROM moment_likes WHERE moment_id=? AND agent_id=?",
                          (moment_id, agent_id)).fetchone()
    if exists:
        conn.execute("DELETE FROM moment_likes WHERE moment_id=? AND agent_id=?",
                     (moment_id, agent_id))
        liked = False
    else:
        conn.execute("INSERT INTO moment_likes(moment_id,agent_id,emoji,created_at) "
                     "VALUES (?,?,?,?)", (moment_id, agent_id, emoji or "👍", _now()))
        liked = True
    conn.commit()
    count = conn.execute("SELECT COUNT(*) c FROM moment_likes WHERE moment_id=?",
                         (moment_id,)).fetchone()["c"]
    return {"liked": liked, "count": count}


def list_likes(conn, agent_id: str, moment_id: str) -> dict:
    if get_visible(conn, agent_id, moment_id) is None:
        raise MomentNotFound()
    rows = [dict(r) for r in conn.execute(
        "SELECT agent_id,emoji,created_at FROM moment_likes WHERE moment_id=? ORDER BY created_at",
        (moment_id,)).fetchall()]
    return {"likes": rows, "count": len(rows)}


# ------------------------------------------------------------------ 评论（+通知）
def list_comments(conn, agent_id: str, moment_id: str) -> list[dict]:
    if get_visible(conn, agent_id, moment_id) is None:
        raise MomentNotFound()
    return [_comment_public(conn, r) for r in conn.execute(
        "SELECT * FROM moment_comments WHERE moment_id=? AND deleted_at IS NULL ORDER BY id",
        (moment_id,)).fetchall()]


def add_comment(conn, agent_id: str, moment_id: str, body: str, parent_id=None) -> dict:
    body = (body or "").strip()
    if not body or len(body) > MAX_COMMENT:
        raise MomentError("bad_body")
    m = conn.execute("SELECT author_id FROM moments WHERE id=? AND deleted_at IS NULL",
                     (moment_id,)).fetchone()
    if not m:
        raise MomentNotFound()
    if m["author_id"] != agent_id and not is_friend(conn, agent_id, m["author_id"]):
        raise MomentNotFound()
    cid = new_id("c")
    conn.execute("INSERT INTO moment_comments(id,moment_id,author_id,parent_id,body,status,created_at) "
                 "VALUES (?,?,?,?,?,'ok',?)", (cid, moment_id, agent_id, parent_id, body, _now()))
    # ④ 评论触发对方通知（自己评自己不通知）；复用既有 notifications
    if m["author_id"] != agent_id:
        community.add_notification(conn, m["author_id"], "moment_comment", moment_id,
                                   f"{agent_id} 评论了你的朋友圈：{body[:60]}")
    conn.commit()
    r = conn.execute("SELECT * FROM moment_comments WHERE id=?", (cid,)).fetchone()
    return _comment_public(conn, r)
