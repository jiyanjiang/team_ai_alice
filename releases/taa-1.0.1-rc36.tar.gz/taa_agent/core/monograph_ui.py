"""专著流水线的浏览器入口：状态看板 + 阶段触发。

薄封装：**不重写流水线**，只读 `research/<slug>/` 的产物（facts.db / draft / 报告），
按需起 `scripts/monograph.py` 子命令。所有写操作都在子进程里，页面只负责显示。

为什么要有这块：
  · 十万字规模下，卡的是"哪一章没写、哪个问题没跑、事实核验有没有掉"，
    这些指标必须一眼看见，而不是每次去敲 `status` 看一行字；
  · 阶段是长任务（检索/写作动辄几十分钟），页面要能"起任务 + 看日志"，
    而不是让浏览器请求一直挂着。
"""
from __future__ import annotations

import html as _h
import json
import os
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from .procutil import pid_alive

ROOT = Path(__file__).resolve().parent.parent
CLI = ROOT / "scripts" / "monograph.py"


def _research_root() -> Path:
    """专著数据目录：config `research.dir` > 环境变量 TAA_RESEARCH_DIR > <安装根>/research。

    为什么要可配：CLI 常常在**源码仓库**里跑（书的产物在仓库 research/），
    而网页跑的是**已安装实例**（根目录不同）。不配就会看到空看板。
    """
    p = ""
    try:
        from core import config as _cfg
        p = str(_cfg.get("research.dir", "", env="TAA_RESEARCH_DIR") or "")
    except Exception:  # noqa: BLE001
        p = os.environ.get("TAA_RESEARCH_DIR", "")
    return Path(p).expanduser() if p else (ROOT / "research")


WORK = _research_root()

#: 允许从页面触发的阶段（init 需要帖子/文件，走 CLI；其余都可点）
STAGES: dict[str, tuple[str, list[str]]] = {
    #  按钮名               子命令      附加参数
    "plan": ("生成问题树", ["plan"]),
    "research": ("检索并抽事实", ["research", "--only-pending"]),
    "compile": ("合并成稿", ["compile"]),
    "check": ("三自检", ["check", "--allow-partial"]),
    "appendix": ("生成附录", ["appendix"]),
    "audit": ("论证表(LR)", ["audit"]),
}

ARTIFACTS = [("TOPIC.json", "立意"), ("OUTLINE.md", "大纲"), ("QUESTIONS.md", "问题树"),
             ("FACTS.md", "事实库"), ("DRAFT.md", "成稿"), ("ARGUMENTS.json", "论证表")]

esc = _h.escape


def _cli() -> tuple[Path, Path] | None:
    """找到可执行的 monograph CLI 及其仓库根。

    安装包**不带** `scripts/`，所以优先用「研究目录的父目录」里的 CLI——
    那通常就是源码仓库（书和流水线代码都在那儿）；找不到再回落到本位安装根。
    """
    for p in (WORK.parent / "scripts" / "monograph.py", ROOT / "scripts" / "monograph.py"):
        if p.is_file():
            return p, p.parent.parent
    return None


def _valid_slug(slug: str) -> bool:
    """项目名只允许小写字母/数字/下划线/点/横线，杜绝 ../ 之类的路径穿越。"""
    import re as _re
    return bool(_re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", str(slug or "")))


# ------------------------------------------------------------------ 读状态
def _dirs() -> list[Path]:
    if not WORK.exists():
        return []
    out = [p for p in WORK.iterdir()
           if p.is_dir() and not p.name.startswith(("_", "."))]
    return sorted(out, key=lambda p: p.stat().st_mtime, reverse=True)


def _ro_db(slug: str) -> sqlite3.Connection | None:
    p = WORK / slug / "facts.db"
    if not p.is_file():
        return None
    try:
        c = sqlite3.connect(f"file:{p}?mode=ro", uri=True, timeout=3)
        c.row_factory = sqlite3.Row
        return c
    except Exception:  # noqa: BLE001
        return None


def _run_state(slug: str) -> dict:
    p = WORK / slug / "ui_run.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}
    pid = int(d.get("pid") or 0)
    alive = pid_alive(pid) if pid > 0 else False
    d["alive"] = alive
    return d if alive else {}


def _count(c: sqlite3.Connection | None, sql: str) -> int:
    if c is None:
        return 0
    try:
        return int(c.execute(sql).fetchone()[0] or 0)
    except Exception:  # noqa: BLE001
        return 0


def _chars(paths: list[Path]) -> int:
    n = 0
    for p in paths:
        try:
            n += len([ch for ch in p.read_text(encoding="utf-8") if "\u4e00" <= ch <= "\u9fff"])
        except Exception:  # noqa: BLE001
            pass
    return n


def status(slug: str) -> dict:
    """一本书的进度快照（只读；失败一律降级为 0，不抛）。"""
    d = WORK / slug
    c = _ro_db(slug)
    try:
        st = {
            "slug": slug,
            "q_total": _count(c, "select count(*) from questions"),
            "q_done": _count(c, "select count(*) from questions where status='done'"),
            "facts": _count(c, "select count(*) from facts"),
            "facts_verified": _count(c, "select count(*) from facts where verified is not null and verified != 0"),
            "chapters_facts": _count(c, "select count(distinct chapter_no) from facts"),
            "claims": _count(c, "select count(*) from claims"),
        }
    finally:
        if c is not None:
            c.close()
    drafts = sorted((d / "draft").glob("ch*.md")) if (d / "draft").is_dir() else []
    st["draft_chapters"] = len(drafts)
    st["draft_chars"] = _chars(drafts)
    st["artifacts"] = {name: (d / name).is_file() for name, _ in ARTIFACTS}
    st["mtime"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(d.stat().st_mtime)) if d.exists() else ""
    st["running"] = _run_state(slug)
    return st


def _stage_done(st: dict) -> dict[str, bool]:
    return {
        "立意": st["artifacts"].get("TOPIC.json", False),
        "结构": st["artifacts"].get("OUTLINE.md", False) and st["q_total"] > 0,
        "检索": st["q_total"] > 0 and st["q_done"] >= st["q_total"],
        "事实": st["facts"] > 0,
        "写作": st["draft_chapters"] > 0,
        "成稿": st["artifacts"].get("DRAFT.md", False),
    }


def _pct(a: int, b: int) -> str:
    return f"{(100.0 * a / b):.0f}%" if b else "—"


# ------------------------------------------------------------------ 动作
def run_stage(slug: str, stage: str, chapter: str = "") -> tuple[bool, str]:
    """后台起一个流水线阶段；返回 (是否成功启动, 说明)。"""
    if not _valid_slug(slug):
        return False, "非法项目名"
    if stage not in STAGES and stage != "write":
        return False, "不支持的阶段"
    d = WORK / slug
    if not d.is_dir():
        return False, f"找不到 {slug}"
    if _run_state(slug):
        return False, "已有任务在跑，等它结束（或到终端里 kill）"
    cli = _cli()
    if not cli:
        return False, ("找不到 monograph CLI：安装包不带 scripts/。请把 research.dir 指向"
                       "源码仓库的 research/（其父目录需有 scripts/monograph.py）")
    cli_path, cli_root = cli
    args = list(STAGES[stage][1]) if stage in STAGES else ["write"]
    cmd = [sys.executable, str(cli_path)] + args + ["--slug", slug]
    if stage == "write":
        cmd += ["--chapter", (chapter or "1").strip()]
    log_dir = d / "logs"
    log_dir.mkdir(exist_ok=True)
    log = log_dir / f"ui-{stage}-{time.strftime('%Y%m%dT%H%M%S')}.log"
    env = dict(os.environ)
    env.setdefault("PYTHONUNBUFFERED", "1")
    try:
        with open(log, "wb") as fh:
            p = subprocess.Popen(cmd, cwd=str(cli_root), stdout=fh, stderr=subprocess.STDOUT,
                                 start_new_session=True, env=env)
    except Exception as exc:  # noqa: BLE001
        return False, f"启动失败：{type(exc).__name__}: {exc}"
    (d / "ui_run.json").write_text(json.dumps(
        {"stage": stage, "chapter": chapter, "pid": p.pid, "log": str(log.relative_to(ROOT)),
         "at": time.strftime("%Y-%m-%d %H:%M:%S")}, ensure_ascii=False), encoding="utf-8")
    return True, f"已启动 {STAGES.get(stage, ('写作',))[0]}（pid {p.pid}）"


def tail_log(slug: str, lines: int = 40) -> str:
    d = WORK / slug / "logs"
    if not d.is_dir():
        return ""
    logs = sorted(d.glob("ui-*.log"), key=lambda p: p.stat().st_mtime)
    if not logs:
        return ""
    try:
        text = logs[-1].read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(text[-lines:])
    except Exception:  # noqa: BLE001
        return ""


# ------------------------------------------------------------------ 页面
def _chips(done: dict[str, bool]) -> str:
    out = []
    for name, ok in done.items():
        cls = "tag" if ok else "tag dim"
        out.append(f'<span class="{cls}">{name}{"✓" if ok else "·"}</span>')
    return " ".join(out)


def _run_bar(slug: str, st: dict, detail: bool = False) -> str:
    r = st.get("running") or {}
    if r:
        return (f'<p class="tag">运行中：{esc(r.get("stage", ""))} '
                f'(pid {r.get("pid")}) — 起于 {esc(r.get("at", ""))}</p>')
    btns = []
    for key, (label, _args) in STAGES.items():
        btns.append(
            f'<form method="post" action="/app/monograph/{esc(slug)}/run" style="display:inline">'
            f'<input type="hidden" name="stage" value="{key}">'
            f'<button class="btn" type="submit">{esc(label)}</button></form>')
    chapter = ('<form method="post" action="/app/monograph/%s/run" style="display:inline">'
               '<input type="hidden" name="stage" value="write">'
               '<input name="chapter" value="1" size="2" title="章号">'
               '<button class="btn primary" type="submit">写本章</button></form>') % esc(slug)
    gap = "" if detail else ""
    return f'<div class="tool-actions">{chapter}{" ".join(btns)}{gap}</div>'


def page_list(shell, limit: int = 15) -> str:
    """看板：只列**真在跑的书**（有 facts.db 或 OUTLINE.md），按修改时间取最近 N 本。"""
    books = [d for d in _dirs()
             if (d / "facts.db").is_file() or (d / "OUTLINE.md").is_file()]
    shown, rows = books[:limit], []
    for d in shown:
        try:
            st = status(d.name)
        except Exception:  # noqa: BLE001
            continue
        done = _stage_done(st)
        rows.append(
            f'<div class="card sec" style="margin-bottom:12px">'
            f'<div class="kicker">{esc(st["mtime"])}　·　{done and ""}'
            f'{esc(st["slug"])}</div>'
            f'<h3 style="margin:6px 0"><a href="/app/monograph/{esc(st["slug"])}">{esc(st["slug"])}</a></h3>'
            f'<p>{_chips(done)}</p>'
            f'<div class="kv"><span>问题</span><b>{st["q_done"]}/{st["q_total"]} 已跑（{_pct(st["q_done"], st["q_total"])}）</b></div>'
            f'<div class="kv"><span>事实</span><b>{st["facts"]} 条（已核 {st["facts_verified"]}）· 覆盖 {st["chapters_facts"]} 章</b></div>'
            f'<div class="kv"><span>草稿</span><b>{st["draft_chapters"]} 章 · {st["draft_chars"]:,} 汉字</b></div>'
            f'{_run_bar(st["slug"], st)}'
            f'</div>')
    if not rows:
        rows.append('<p class="dim">还没有专著项目。用 CLI 初始化：'
                    '<code>scripts/monograph.py init --slug &lt;名字&gt; --post &lt;帖子&gt;</code></p>')
    body = f"""
  <section class="card sec">
    <div class="kicker">MONOGRAPH · 立项 → 结构 → 检索 → 事实 → 写作 → 三自检</div>
    <h2 style="margin:6px 0 8px">专著流水线</h2>
    <p class="dim">这里只读 <code>research/&lt;slug&gt;/</code> 的产物并起子命令；
       写作/检索是长任务，页面起的是**后台进程**，日志在 <code>research/&lt;slug&gt;/logs/</code>。</p>
    <p class="dim">数据目录：<code>{esc(str(WORK))}</code>　·　共 {len(books)} 本有产物的专著，显示最近 {len(shown)} 本。</p>
    {"".join(rows)}
  </section>"""
    return shell("专著流水线", body, "tools", "十万字规模的进度与阶段操作", side=_side())


def _side() -> str:
    return ('<div class="card sec"><div class="kicker">判据</div>'
            '<p class="dim">· 问题覆盖率 = 已跑/总数<br>· 事实核验率 = verified/总数<br>'
            '· 章覆盖 = facts 里的 chapter_no 去重<br>· 草稿字数只数汉字</p></div>')


def page_detail(shell, slug: str, msg: str = "") -> str:
    if not _valid_slug(slug) or not (WORK / slug).is_dir():
        body = ('<section class="card sec"><h2>找不到这个项目</h2>'
                f'<p class="dim">{esc(slug)} 不在 research/ 下。<a href="/app/monograph">返回看板</a></p>'
                '</section>')
        return shell("专著 · 未找到", body, "tools", "")
    st = status(slug)
    done = _stage_done(st)
    gaps = []
    c = _ro_db(slug)
    if c is not None:
        try:
            for r in c.execute("select qid, chapter_no, title from questions "
                               "where status!='done' order by chapter_no limit 12"):
                gaps.append(f'<div class="row"><span class="tag">{esc(str(r[1]))}</span>'
                            f'<span style="flex:1">{esc(str(r[2] or r[0]))}</span>'
                            f'<span class="dim mono">{esc(str(r[0]))}</span></div>')
        except Exception:  # noqa: BLE001
            pass
        finally:
            c.close()
    arts = "".join(
        f'<div class="row"><span class="tag">{esc(label)}</span>'
        f'<b style="flex:1">{esc(name)}</b>'
        f'<span class="dim">{"有" if ok else "缺"}</span></div>'
        for name, label in ARTIFACTS for ok in [st["artifacts"].get(name, False)])
    log = tail_log(slug, 30)
    body = f"""
  <section class="card sec">
    <div class="kicker"><a href="/app/monograph">← 全部专著</a>　·　{esc(st["mtime"])}</div>
    <h2 style="margin:6px 0 8px">{esc(slug)}</h2>
    {f'<p class="tag">{esc(msg)}</p>' if msg else ''}
    <p>{_chips(done)}</p>
    <div class="kv"><span>问题</span><b>{st["q_done"]}/{st["q_total"]}</b></div>
    <div class="kv"><span>事实</span><b>{st["facts"]} 条 · 已核 {st["facts_verified"]}（{_pct(st["facts_verified"], st["facts"])}）</b></div>
    <div class="kv"><span>章覆盖</span><b>{st["chapters_facts"]} 章有事实</b></div>
    <div class="kv"><span>草稿</span><b>{st["draft_chapters"]} 章 · {st["draft_chars"]:,} 汉字</b></div>
    <div class="kv"><span>论点</span><b>{st["claims"]} 条</b></div>
    {_run_bar(slug, st, detail=True)}
    <div class="kicker" style="margin-top:16px">还没跑的问题（前 12）</div>
    <div class="rows">{"".join(gaps) or '<div class="dim">无（全部已跑）</div>'}</div>
    <div class="kicker" style="margin-top:16px">产物</div>
    <div class="rows">{arts}</div>
    <div class="kicker" style="margin-top:16px">最近日志</div>
    <pre class="mono" style="white-space:pre-wrap;max-height:320px;overflow:auto">{esc(log) or "（无）"}</pre>
  </section>"""
    return shell(f"专著 · {slug}", body, "tools", "现状 / 缺口 / 阶段操作", side=_side())
