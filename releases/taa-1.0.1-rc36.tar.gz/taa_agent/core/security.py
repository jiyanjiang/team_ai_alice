"""密钥、加密与请求签名（docs/03 §3/§6）。"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = Path(__file__).resolve().parent.parent
BOOTSTRAP_DIR = ROOT / "bootstrap"
MASTER_KEY_FILE = BOOTSTRAP_DIR / "master.key"

_MASTER: bytes | None = None


def master_key() -> bytes:
    """主密钥：TEAM_MASTER_KEY（base64url）> bootstrap/master.key > 首启生成。"""
    global _MASTER
    if _MASTER is not None:
        return _MASTER
    env = os.environ.get("TEAM_MASTER_KEY")
    if env:
        _MASTER = base64.urlsafe_b64decode(env)
        return _MASTER
    key_file = MASTER_KEY_FILE
    try:
        BOOTSTRAP_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        # 安装形态下 bootstrap/ 是指向 $TAA_HOME/bootstrap 的 junction。受限令牌
        # （IDE 代理沙箱）穿越它会被 Windows 拒绝（WinError 448 不受信任装入点）。
        # 同一份 master.key 在 home 侧是真实文件 —— 这里只换访问路径，**绝不另生成
        # 密钥**（另生成会让库里既有密文全部解不开）。目录真不可用时，写入仍会报错。
        alt = (Path(os.environ.get("TAA_HOME") or (Path.home() / ".taa"))
               / "bootstrap" / "master.key")
        try:
            if alt.is_file():
                key_file = alt
        except OSError:
            pass
    if key_file.is_file():
        _MASTER = base64.urlsafe_b64decode(key_file.read_text(encoding="utf-8").strip())
    else:
        _MASTER = AESGCM.generate_key(bit_length=256)
        key_file.write_text(base64.urlsafe_b64encode(_MASTER).decode(), encoding="utf-8")
        os.chmod(key_file, 0o600)
    return _MASTER


def encrypt(plaintext: str) -> str:
    nonce = secrets.token_bytes(12)
    ct = AESGCM(master_key()).encrypt(nonce, plaintext.encode("utf-8"), None)
    return base64.urlsafe_b64encode(nonce + ct).decode()


def decrypt(token: str) -> str:
    raw = base64.urlsafe_b64decode(token)
    nonce, ct = raw[:12], raw[12:]
    return AESGCM(master_key()).decrypt(nonce, ct, None).decode("utf-8")


def hash_secret(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def gen_key() -> str:
    return secrets.token_urlsafe(32)


def gen_key_id() -> str:
    return secrets.token_hex(6)


def gen_token() -> str:
    return secrets.token_urlsafe(24)


def canonical(method: str, path: str, body: bytes, ts: str, nonce: str) -> bytes:
    body_hash = hashlib.sha256(body or b"").hexdigest()
    return f"{method.upper()}\n{path}\n{body_hash}\n{ts}\n{nonce}".encode("utf-8")


def sign(key: str, method: str, path: str, body: bytes, ts: str, nonce: str) -> str:
    return hmac.new(key.encode("utf-8"), canonical(method, path, body, ts, nonce),
                    hashlib.sha256).hexdigest()


def verify(key: str, method: str, path: str, body: bytes, ts: str, nonce: str, sig: str) -> bool:
    return hmac.compare_digest(sign(key, method, path, body, ts, nonce), sig)
