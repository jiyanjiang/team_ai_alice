"""P2P event sync primitives (P10.4R-100-4).

The event log is the canonical append-only exchange; this module only provides
token-gated export/merge and deterministic validation. It does not copy SQLite
files and does not put content on the center.

For beta, the peer token is a local/shared secret (``TAA_PEER_TOKEN``). A later
step replaces it with owner/group-issued grants.
"""
from __future__ import annotations

import datetime as _dt
import hmac
import json
import os
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from . import timeutil


def expected_token() -> str:
    return (os.environ.get("TAA_PEER_TOKEN") or "").strip()


def authorized(header_value: str) -> bool:
    expected = expected_token()
    if not expected:
        return False
    return hmac.compare_digest(str(header_value or ""), expected)


def validate_events(raw: Any, limit: int = 500) -> list[dict]:
    if not isinstance(raw, list):
        raise ValueError("events must be a list")
    if len(raw) > limit:
        raise ValueError(f"too many events (max {limit})")
    out: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        eid = item.get("id")
        type_ = item.get("type")
        payload = item.get("payload")
        if not isinstance(eid, str) or not eid or not isinstance(type_, str) or not type_:
            continue
        if not isinstance(payload, dict):
            continue
        try:
            lamport = int(item.get("lamport") or 0)
            ts = float(item.get("ts") or 0)
        except (TypeError, ValueError):
            continue
        event = {
            "id": eid[:128], "lamport": lamport, "node_id": str(item.get("node_id") or "")[:128],
            "type": type_[:64], "payload": payload, "ts": ts,
        }
        for k in ("signed_by", "pubkey", "signature"):
            if item.get(k):
                event[k] = str(item[k])[:4096]
        out.append(event)
    return out


def _now(ts: float | None = None) -> str:
    d = _dt.datetime.fromtimestamp(float(ts or 0), _dt.timezone.utc) if ts else _dt.datetime.now(_dt.timezone.utc)
    return d.astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _local_author(p: dict) -> tuple[str, str, str, str]:
    """远端事件的作者 → (本地 agent id, 显示名, owner_id, owner_name)。

    两台机器的 owner agent 都叫 `human`；直接用这个 id 会撞上**本机**的 owner，
    对端的帖子在本机会署本机的名（反之亦然）。项目既有约定是远端人类用
    `remote-human-<owner_id>`（app_ui 多处依赖），这里对齐。

    回传的自己的事件（owner 与本机相同）保持原 id，避免把自己改成分身。
    """
    aid = str(p.get("author") or "").strip()
    name = str(p.get("author_name") or "").strip()
    owner = str(p.get("author_owner") or "").strip()
    oname = str(p.get("author_owner_name") or "").strip()
    if not owner or not aid:
        return aid, name, owner, oname
    try:
        from . import friend_sync
        mine = friend_sync.local_owner_id()
    except Exception:                                            # noqa: BLE001
        mine = ""
    if mine and owner == mine:
        return aid, name, owner, oname
    if aid == "human" or aid.startswith("human-"):
        return ("remote-human-" + owner)[:64], name, owner, oname
    return aid, name, owner, oname


def _ensure_agent(conn, agent_id: str, name: str = "", owner_id: str = "",
                  owner_name: str = "") -> None:
    agent_id = (agent_id or "").strip()
    if not agent_id:
        return
    display = (name or "").strip()
    if agent_id.startswith("remote-human-"):
        # docs/559 §3.3：远端真人名以**中心**为准；对端自报的名字只在中心查不到时兜底。
        # 否则对端的旧自报名会把中心的新 username 覆盖掉（qiji → jiyanjiang 就是这么来的）。
        from . import friend_sync as _friend_sync
        display = (_friend_sync.username_for(
            conn, owner_id or agent_id[len("remote-human-"):]) or display)
    row = conn.execute("SELECT name FROM agents WHERE id=?", (agent_id,)).fetchone()
    if row:
        # 作者本人报的名字是权威：早期事件没带名字，本机可能给过自动名（Owner 之类）。
        # 但 docs/542 §6：远端报的**裸名**不可信——它会把本机规范名
        # `alice.jiyanjiang` 打回 `Alice`，所以 AI 的裸名一律拒绝写回。
        old = str(row["name"] or "")
        is_human = agent_id.startswith(("remote-human-", "human"))
        from .agent_identity import has_placeholder_owner, is_placeholder_name
        # `alice`（裸名）、`Owner`（占位名）、`alice.Owner`（占位 owner）都不可信。
        bad = (is_placeholder_name(display)
               or (not is_human and ("." not in (display or "")
                                     or has_placeholder_owner(display or ""))))
        if display and old != display and not bad:
            try:
                conn.execute("UPDATE agents SET name=?, full_name=? WHERE id=?",
                             (display[:64], display[:64], agent_id))
            except sqlite3.IntegrityError:
                # full_name 有 UNIQUE 约束：对端报的名字与本机某行撞名时，
                # 整条 UPDATE 会抛异常 —— 而 apply_events 外层是 `except: continue`，
                # 结果是这条事件（连同帖子/分享）被静默丢弃。只改 name 保住事件。
                conn.execute("UPDATE agents SET name=? WHERE id=?", (display[:64], agent_id))
        return
    if not display:
        from .agent_names import next_available_name
        display, _renamed = next_available_name(conn, agent_id, exclude_agent_id=agent_id[:64])
    kind = "human" if agent_id.startswith("remote-human-") else "ai"
    # full_name 有 UNIQUE 约束：撞名时 `INSERT OR IGNORE` 会静默丢掉整行。
    # 冲突就留 NULL（SQLite 允许多个 NULL），保证 id 这一行一定建出来。
    full = display[:64]
    try:
        if conn.execute("SELECT 1 FROM agents WHERE full_name=?", (full,)).fetchone():
            full = None
    except Exception:                                            # noqa: BLE001
        full = None
    conn.execute(
        "INSERT OR IGNORE INTO agents(id,name,kind,full_name,role,persona_json,status,last_seen,"
        "owner_id,owner_name) VALUES(?,?,?,?, 'executor', '{}', 'offline', "
        "datetime('now','localtime'), ?, ?)",
        (agent_id[:64], display[:64], kind, full,
         (owner_id or None), (owner_name or None)),
    )


def _ensure_channel(conn, channel_id: str, author_id: str) -> None:
    channel_id = (channel_id or "").strip()
    if not channel_id:
        return
    if conn.execute("SELECT 1 FROM channels WHERE id=?", (channel_id,)).fetchone():
        return
    name = channel_id if channel_id.startswith("#") else "#" + channel_id
    conn.execute(
        "INSERT OR IGNORE INTO channels(id,name,kind,purpose,created_by) "
        "VALUES(?,?, 'public', 'P2P synced channel', ?)",
        (channel_id[:80], name[:80], author_id[:64]),
    )


_MESSAGE_COLS_OK = False


def _ensure_message_cols(conn) -> None:
    """补 room_messages 的幂等/UTC 列与唯一索引（老库缺 client_message_id 就不能去重）。

    进程内只跑一次：`db.ensure_message_columns` 里带全表回填 UPDATE，逐事件调用太贵。
    """
    global _MESSAGE_COLS_OK
    if _MESSAGE_COLS_OK:
        return
    try:
        from .db import ensure_message_columns
        ensure_message_columns(conn)
    except Exception:                                            # noqa: BLE001
        return
    _MESSAGE_COLS_OK = True


def _ensure_room(conn, room_id: str, agent_id: str, center_group_id: str = "") -> None:
    room_id = (room_id or "").strip()
    if not room_id:
        return
    if not conn.execute("SELECT 1 FROM rooms WHERE id=?", (room_id,)).fetchone():
        conn.execute(
            "INSERT OR IGNORE INTO rooms(id,topic,kind,title,status,created_by) "
            "VALUES(?,?, 'group', ?, 'running', ?)",
            (room_id[:80], "P2P synced room", "P2P synced room", agent_id[:64]),
        )
        if center_group_id:
            # 占位房也要挂上中心群身份：否则同一场对话在本机会分裂成两个房间，
            # 后续消息（尤其直投那条通道）也对不上。
            try:
                conn.execute("UPDATE rooms SET center_group_id=? WHERE id=?",
                             (center_group_id[:120], room_id[:80]))
            except sqlite3.Error:
                pass
    if agent_id:
        conn.execute(
            "INSERT OR IGNORE INTO room_members(room_id,agent_id,kind,role) VALUES(?,?, 'ai','member')",
            (room_id[:80], agent_id[:64]),
        )
    if center_group_id:
        _ensure_local_primary_member(conn, room_id)


def _local_primary_agent_id(conn) -> str:
    """本机首席 agent 的 id：`identity.json` 是真相源，其次按 owner/node 收敛。

    不能只按 `is_primary` 取最早一行：老库里存在占位行 `agent`
    （name=`agent.<owner>`、owner_id 为空、node 却是本机），created_at 比真 agent 更早。
    它一旦入座，`_local_ais()` 会把它当本机 AI 派活，任务全落到空壳上。
    """
    import pathlib

    try:
        home = pathlib.Path(os.environ.get("TAA_HOME") or (pathlib.Path.home() / ".taa"))
        idf = json.loads((home / "identity.json").read_text(encoding="utf-8"))
    except Exception:                                            # noqa: BLE001
        idf = {}
    node = idf.get("node") or {}
    owner_id = str((idf.get("center") or {}).get("owner_id") or "")
    for a in (idf.get("agents") or []):
        if not isinstance(a, dict):
            continue
        aid = str(a.get("agent_id") or "").strip()
        if not aid:
            continue
        row = conn.execute(
            "SELECT id FROM agents WHERE id=? AND kind='ai' "
            "AND coalesce(status,'active')='active'", (aid,)).fetchone()
        if row:
            return str(row["id"])
    sql = ("SELECT id FROM agents WHERE kind='ai' "
           "AND coalesce(is_primary,0)=1 AND coalesce(status,'active')='active' "
           "AND id<>'agent' ")
    args: list = []
    if owner_id:
        sql += "AND coalesce(owner_id,'')=? "
        args.append(owner_id)
    node_ids = [x for x in (str(node.get("alias") or ""), str(node.get("node_id") or "")) if x]
    if node_ids:
        sql += "AND coalesce(node_id,'') IN (%s) " % ",".join("?" * len(node_ids))
        args.extend(node_ids)
    sql += "ORDER BY created_at LIMIT 1"
    row = conn.execute(sql, args).fetchone()
    return str(row["id"]) if row else ""


def _ensure_local_primary_member(conn, room_id: str) -> None:
    """跨机群把本机首席 agent 也入座（4 主体群的最小前提）。

    缺了这一步，对端 @ 本机 agent 时本机 `executor_bridge._local_ais()` 返回空，
    `_maybe_dispatch_remote` 会把消息标成"已派活"直接丢掉 —— 群里看得见消息、
    却永远没人干活（2026-11-10 真机）。只加人、不改已有成员与角色。
    """
    try:
        agent_id = _local_primary_agent_id(conn)
        if not agent_id:
            return
        conn.execute(
            "INSERT OR IGNORE INTO room_members(room_id,agent_id,kind,role) VALUES(?,?, 'ai','member')",
            (room_id[:80], agent_id[:64]),
        )
    except sqlite3.Error:
        pass


def ensure_local_primary_members(conn) -> list[str]:
    """启动期兜底：把所有已存在的跨机群补上本机首席 agent（幂等）。

    只在收到新消息时补是不够的：老群的历史消息早已落库，用户看着群安静地
    "没人接活"，却要等对端再发一条才会自愈。返回补齐的 room_id 列表。
    """
    fixed: list[str] = []
    try:
        rows = conn.execute(
            "SELECT id FROM rooms WHERE coalesce(center_group_id,'')<>''").fetchall()
    except sqlite3.Error:
        return fixed
    for r in rows:
        rid = str(r["id"])
        try:
            before = conn.execute(
                "SELECT count(*) FROM room_members WHERE room_id=?", (rid,)).fetchone()[0]
            _ensure_local_primary_member(conn, rid)
            after = conn.execute(
                "SELECT count(*) FROM room_members WHERE room_id=?", (rid,)).fetchone()[0]
            if after > before:
                fixed.append(rid)
        except sqlite3.Error:
            continue
    if fixed:
        try:
            conn.commit()
        except sqlite3.Error:
            pass
    return fixed


def _seen(conn, event_id: str) -> bool:
    conn.execute("CREATE TABLE IF NOT EXISTS p2p_applied(event_id TEXT PRIMARY KEY, at TEXT)")
    return bool(conn.execute("SELECT 1 FROM p2p_applied WHERE event_id=?", (event_id,)).fetchone())


def _mark(conn, event_id: str) -> None:
    conn.execute("INSERT OR IGNORE INTO p2p_applied(event_id,at) VALUES(?,datetime('now','localtime'))",
                 (event_id,))


def apply_events(conn, events: list[dict]) -> int:
    """Apply remote events to local posts/replies/room_messages.

    Idempotent by event id. Remote authors/channels/rooms get local placeholder
    rows so the existing /app UI can render them; this does not import remote
    attachment bytes (that is the next /peer/blob step).
    """
    applied = 0
    for e in events or []:
        eid = str(e.get("id") or "")
        typ = str(e.get("type") or "")
        p = e.get("payload") or {}
        if not eid or _seen(conn, eid):
            continue
        try:
            if typ == "post.created":
                # 对端兜底（BUG-1）：显式标记 local 的帖不落库。
                # 只拦明确标记的，老事件（无该字段）保持原行为，避免历史投递卡死。
                if str(p.get("channel_egress") or "").strip() == "local":
                    continue
                author, a_name, a_owner, a_oname = _local_author(p)
                if not author or not p.get("id"):
                    continue
                _ensure_agent(conn, author, a_name, a_owner, a_oname)
                _ensure_channel(conn, str(p.get("channel") or ""), author)
                ptype = str(p.get("type") or "note")
                if ptype not in {"standup", "share", "reading", "idea", "question", "announcement",
                                 "retro", "artifact", "review", "intent", "note"}:
                    ptype = "note"
                from . import peer_blobs
                atts = []
                for a in (p.get("attachments") or []):
                    if isinstance(a, dict) and a.get("sha256"):
                        a = {**a, "url": peer_blobs.peer_url(a)}
                    atts.append(a)
                # 分享跨机：share_of 保留引用，share_snapshot 让对端在「没有原帖」时也能渲染，
                # 不留一条点开就 404 的分享卡（docs/531 的跨机补齐）。
                _snap = p.get("share_snapshot")
                if isinstance(_snap, dict):
                    _snap = json.dumps(_snap, ensure_ascii=False)
                cur = conn.execute(
                    "INSERT OR IGNORE INTO posts(id,channel_id,author_id,type,title,body,links,standup,"
                    "tags,attachments,kind,visibility,share_of,share_snapshot,status,created_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'published',?)",
                    (str(p["id"])[:80], str(p.get("channel") or "")[:80] or None, author[:64],
                     ptype, str(p.get("title") or "")[:200], str(p.get("body") or "")[:16000],
                     json.dumps(p.get("links") or [], ensure_ascii=False),
                     json.dumps(p.get("standup") or {}, ensure_ascii=False) if p.get("standup") else None,
                     json.dumps(p.get("tags") or [], ensure_ascii=False),
                     json.dumps(atts, ensure_ascii=False),
                     str(p.get("kind") or "public_channel"), str(p.get("visibility") or "public"),
                     str(p.get("share_of") or "")[:80] or None, _snap or None,
                     _now(e.get("ts"))))
                if cur.rowcount:
                    conn.execute("INSERT OR IGNORE INTO thread_state(post_id,last_activity) VALUES(?,?)",
                                 (str(p["id"])[:80], _now(e.get("ts"))))
                    applied += 1
            elif typ == "reply.created":
                post_id = str(p.get("post_id") or "")
                author, a_name, a_owner, a_oname = _local_author(p)
                if not post_id or not author or not p.get("body"):
                    continue
                if not conn.execute("SELECT 1 FROM posts WHERE id=?", (post_id,)).fetchone():
                    continue
                _ensure_agent(conn, author, a_name, a_owner, a_oname)
                kind = str(p.get("kind") or "comment")
                if kind not in {"fact", "derivation", "computation", "counterexample",
                                "proposal", "question", "ack", "disagree", "comment"}:
                    kind = "comment"
                conn.execute(
                    "INSERT INTO replies(post_id,parent_reply_id,author_id,depth,kind,body,evidence,status,created_at) "
                    "VALUES(?,?,?,1,?,?,?, 'visible',?)",
                    (post_id[:80], None, author[:64], kind, str(p.get("body") or "")[:8000],
                     str(p.get("evidence") or "")[:4000] or None, _now(e.get("ts"))))
                conn.execute("UPDATE thread_state SET reply_count=reply_count+1,last_activity=? WHERE post_id=?",
                             (_now(e.get("ts")), post_id))
                applied += 1
            elif typ == "room.message":
                rid = str(p.get("room_id") or "")
                agent = str(p.get("agent") or "")
                # 跨机身份以**全局 owner + 规范署名**为准（docs/542 §三）：发送端本地 id
                # 在本机含义不同，直接落库会把别人的话记成本机主人说的（派活/权限全错）。
                _sender_owner = str(p.get("sender_owner_id") or "").strip()[:80]
                _sender_name = str(p.get("sender_name") or "").strip()[:64]
                _sender_kind = str(p.get("sender_kind") or "").strip()
                if _sender_owner and _sender_kind == "human":
                    try:
                        from .app_ui import center_state as _center_state
                        _stt = _center_state()
                        _mine = str(getattr(getattr(_stt, "center", None), "owner_id", "") or "")
                    except Exception:  # noqa: BLE001
                        _mine = ""
                    if _mine and _sender_owner != _mine:
                        agent = "remote-human-" + _sender_owner
                gid = str(p.get("center_group_id") or "")
                from . import peer_blobs
                att = p.get("attachment_manifest")
                att_list = p.get("attachment_manifests")
                att_url = str(p.get("attachment") or "")
                _ms = [m for m in (att_list or []) if isinstance(m, dict) and m.get("sha256")]
                if _ms:
                    # 多图：每张都换成对本机 blob 的引用（/app/peer-blob/<sha>），
                    # 直接存对端的 /static/uploads/<name> 只会 404。
                    att_url = json.dumps(
                        [{"url": peer_blobs.peer_url(m), "name": m.get("name") or "",
                          "mime": m.get("mime") or "", "size": m.get("size") or 0} for m in _ms],
                        ensure_ascii=False)
                elif isinstance(att, dict) and att.get("sha256"):
                    att_url = peer_blobs.peer_url(att)
                # 纯图片消息（没有正文）也是合法消息：直投通道早就允许，
                # 事件通道曾无条件要求 body，于是"只发图"永远同步不过去。
                if not rid or not agent or not (p.get("body") or att_url):
                    continue
                if gid:
                    # 本机 id 与对端不同，中心群 id 才是同一场对话。先按群 id 找本机房间，
                    # 找到就落进这个房间（否则同一条消息会另建一个占位房）。
                    # **必须优先可写主房**：同群在本机可能有多间房（主房 + read_only 副本），
                    # 直接 LIMIT 1 会落到副本，主房界面永远看不到对端消息（2026-11-12 实测）。
                    try:
                        local = conn.execute(
                            "SELECT id FROM rooms WHERE center_group_id=? "
                            "ORDER BY coalesce(read_only,0) ASC, (status='running') DESC LIMIT 1",
                            (gid[:120],)).fetchone()
                    except sqlite3.OperationalError:
                        # 旧库/沙箱没有 read_only 列：退回最简查询，绝不能因此丢消息。
                        local = conn.execute(
                            "SELECT id FROM rooms WHERE center_group_id=? LIMIT 1",
                            (gid[:120],)).fetchone()
                    if local:
                        rid = str(local["id"])
                # 署名跟着事件走：name 用发送方规范署名（真人 `<owner>`、AI `<agent>.<owner>`），
                # owner_id 用来认人。远端真人名最终以中心 username 为准（_ensure_agent 内处理）。
                _ensure_agent(conn, agent, name=_sender_name,
                              owner_id=_sender_owner, owner_name=_sender_name)
                _ensure_room(conn, rid, agent, center_group_id=gid)
                kind = str(p.get("kind") or "assertion")
                if kind not in {"assertion", "fact", "question", "emotion", "skip", "system"}:
                    kind = "assertion"
                _ensure_message_cols(conn)
                cid_evt = str(p.get("client_message_id") or "").strip()[:120]
                # 同一句话会同时经"事件通道"和"直投通道"到达本机，用 client_message_id
                # 去重（唯一索引 ux_room_messages_client 兜底，这里先查一次避免异常中断整批）。
                if cid_evt and conn.execute(
                        "SELECT 1 FROM room_messages WHERE room_id=? AND client_message_id=? LIMIT 1",
                        (rid[:80], cid_evt)).fetchone():
                    _mark(conn, eid)
                    continue
                created_utc = timeutil.from_epoch(e.get("ts")) if e.get("ts") else timeutil.now_utc_iso()
                # 发送者归属随事件到达（rc27 起由 rooms.emit_message 写入）：
                # 派活登记 group_command 时 source_owner_id 必填，缺了就只是"消息能看见、
                # 没人干活"（2026-11-11 真机现象）。
                sender_owner = str(p.get("sender_owner_id") or "").strip()[:80]
                sender_kind = str(p.get("sender_kind") or "").strip()[:20]
                cur = conn.execute(
                    "INSERT OR IGNORE INTO room_messages(room_id,round,agent_id,body,kind,source,"
                    "attachment,created_at,created_at_utc,client_message_id,reply_to_center_id,"
                    "sender_owner_id,sender_kind) "
                    "VALUES(?,?,?,?,?, 'p2p', ?,?,?,?,?,?,?)",
                    (rid[:80], int(p.get("round") or 0), agent[:64], str(p.get("body") or "")[:16000],
                     kind, att_url or None, timeutil.to_local_text(created_utc, assume="utc"),
                     created_utc, cid_evt or None,
                     str(p.get("reply_to_center_id") or "")[:100] or None,
                     sender_owner or None, sender_kind or None))
                if not cur.rowcount:
                    # 唯一索引挡住了（另一通道刚插过同一条），别再广播/计数。
                    _mark(conn, eid)
                    continue
                if cur.lastrowid:
                    try:
                        from . import app_ui
                        payload = app_ui._ws_payload(conn, rid[:80], int(cur.lastrowid))
                        if payload:
                            app_ui._ws_broadcast(rid[:80], {"type": "message", "message": payload})
                    except Exception:  # noqa: BLE001
                        pass
                    # docs/532 · P-C：拉取入库同样要派活。此前只有 push 路径
                    # （peer_server 收到 POST 后）调 _maybe_dispatch_remote，
                    # 拉回来的消息只入库不执行 —— 这就是"消息发了没人干"的一半。
                    try:
                        from . import app_ui
                        app_ui._maybe_dispatch_remote(
                            conn, rid=rid[:80], mid=int(cur.lastrowid),
                            body=str(p.get("body") or ""), source="p2p",
                            owner_id=sender_owner)
                    except Exception:  # noqa: BLE001
                        pass
                applied += 1
            else:
                # Unknown event types are still marked as seen to avoid replay.
                _mark(conn, eid)
                continue
            _mark(conn, eid)
        except Exception:  # noqa: BLE001
            # One malformed/remote event must not block the rest.
            continue
    conn.commit()
    return applied


def pull_events(base: str, token: str, since: int = 0, *, timeout: int = 30) -> list[dict]:
    """Pull incremental events from a peer's /peer/v1/events endpoint.

    走 peer server 而不是 web：LAN 上 6080 只开手机分享白名单，`/v1/peer/*`
    一律 403；peer server（6090/6091）把 `/peer/v1/*` 透明转发到本机 loopback。
    """
    events, _next, _node = pull_events_page(base, token, since, timeout=timeout)
    return events


def push_events(base: str, token: str, events: list[dict], *, timeout: int = 30) -> dict:
    """Push events to a peer's /peer/v1/events endpoint (via its peer server)."""
    body = json.dumps({"events": events}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request((base or "").rstrip("/") + "/peer/v1/events",
                                 data=body, method="POST",
                                 headers={"content-type": "application/json",
                                          "X-TAA-Peer-Token": token,
                                          "user-agent": "TAA-Peer/0.1"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ------------------------------------------------------------------ P2P orchestration
def _peer_base(base: str) -> str:
    return (base or "").strip().rstrip("/")


def _cursor_table(conn) -> None:
    conn.execute("CREATE TABLE IF NOT EXISTS p2p_cursors("
                 "peer TEXT PRIMARY KEY, since INTEGER NOT NULL DEFAULT 0, updated_at TEXT)")
    conn.commit()


def cursor_get(conn, base: str) -> int:
    _cursor_table(conn)
    row = conn.execute("SELECT since FROM p2p_cursors WHERE peer=?", (_peer_base(base),)).fetchone()
    return int(row["since"]) if row else 0


def cursor_set(conn, base: str, since: int) -> None:
    _cursor_table(conn)
    conn.execute(
        "INSERT INTO p2p_cursors(peer,since,updated_at) VALUES(?,?,datetime('now','localtime')) "
        "ON CONFLICT(peer) DO UPDATE SET since=excluded.since,updated_at=excluded.updated_at",
        (_peer_base(base), int(since or 0)))
    conn.commit()


def _retry(fn, *, attempts: int = 3, base_delay: float = 0.25):
    """Retry transient peer failures with bounded exponential backoff."""
    last = None
    for i in range(max(1, int(attempts or 1))):
        try:
            return fn()
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            last = exc
            if i + 1 < attempts:
                time.sleep(base_delay * (2 ** i))
    raise last


PAGE_EVENTS = 500      # 单页条数：与 validate_events 的硬上限对齐
PAGE_MAX = 20          # 单次 sync 最多翻多少页（20×500=1 万条，防止对端异常时跑飞）


def _self_node() -> str:
    """本节点在事件日志里的 node_id（用于让对端别回传我自己的事件）。"""
    try:
        from .net.events import node_log
        return str(node_log().node_id or "")
    except Exception:                                            # noqa: BLE001
        return ""


def pull_events_page(base: str, token: str, since: int = 0, *, timeout: int = 30,
                     attempts: int = 3, page_size: int = PAGE_EVENTS,
                     max_pages: int = PAGE_MAX) -> tuple[list[dict], int, str]:
    """Return (events, source_next_since, source_node) with retry + paging.

    为什么要翻页：旧实现一次把 since 之后的**全部**事件取回，而 `validate_events`
    上限 500 → 对端首次全量 707 条就抛 `too many events`，游标永不推进，
    该方向永久不通（2026-11-10 真机实测：本机 ← taa-win 727 条事件拉不动）。
    """
    base = _peer_base(base)
    cursor = int(since or 0)
    out: list[dict] = []
    node = ""
    next_since = cursor
    me = _self_node()
    for _ in range(max(1, int(max_pages or 1))):
        url = (base + "/peer/v1/events?since=" + str(cursor)
               + "&limit=" + str(max(1, int(page_size or PAGE_EVENTS)))
               + ("&exclude=" + urllib.parse.quote(me) if me else ""))

        def one(u=url):
            req = urllib.request.Request(u, headers={
                "X-TAA-Peer-Token": token,
                "user-agent": "TAA-Peer/0.1",
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))

        d = _retry(one, attempts=attempts)
        node = node or str(d.get("node") or "")
        # 放宽到 2×page_size：服务端为了保证"同 lamport 同批"会在 limit 边界上多带几条。
        raw_batch = validate_events(d.get("events") or [],
                                    limit=max(2 * int(page_size or PAGE_EVENTS), 1000))
        page_next = int(d.get("next_since") or 0)
        if page_next <= 0:
            page_next = max([int(e.get("lamport") or 0) for e in raw_batch] or [cursor])
        # 老对端不认 `exclude`，本地兜底再滤一遍自己的回流事件（否则会被签名校验
        # 判成 unsigned，白刷日志）。
        batch = [e for e in raw_batch if str(e.get("node_id") or "") != me] if me else raw_batch
        out.extend(batch)
        next_since = page_next
        # 新对端显式给 has_more；老对端没有该字段且不支持 limit，只能按"装满一页"推断。
        # 判断用**过滤前**的条数：过滤只影响本地要不要，不影响对端还有没有下一页。
        if "has_more" in d:
            has_more = bool(d.get("has_more"))
        else:
            has_more = len(raw_batch) >= max(1, int(page_size or PAGE_EVENTS))
        if not raw_batch or page_next <= cursor or not has_more:
            break
        cursor = page_next
    return out, next_since, node


def event_blob_manifests(events: list[dict]) -> dict[str, dict]:
    """Collect sha256 manifests carried by remote post/room events."""
    out: dict[str, dict] = {}
    for e in events or []:
        typ = str(e.get("type") or "")
        p = e.get("payload") or {}
        items = []
        if typ == "post.created" and isinstance(p.get("attachments"), list):
            items = p.get("attachments") or []
        elif typ == "room.message":
            if isinstance(p.get("attachment_manifests"), list):
                items = [m for m in p.get("attachment_manifests") if isinstance(m, dict)]
            if isinstance(p.get("attachment_manifest"), dict):
                items = list(items) + [p.get("attachment_manifest")]
        for item in items:
            if not isinstance(item, dict):
                continue
            sha = str(item.get("sha256") or "").strip().lower()
            if len(sha) == 64 and all(c in "0123456789abcdef" for c in sha):
                out.setdefault(sha, item)
    return out


def sync_from_peer(base: str, token: str, conn, *, since: int | None = None,
                   log=None, fetch_blobs: bool = True, timeout: int = 30,
                   attempts: int = 3, allow_unsigned: bool = False) -> dict:
    """Pull -> merge -> apply -> fetch missing blobs.

    The cursor only advances when every referenced blob was fetched and verified.
    If a blob is unavailable, the next call re-pulls the same events and retries
    the blob instead of permanently losing the attachment.
    """
    from . import peer_blobs, peer_sign

    base = _peer_base(base)
    if not base:
        raise ValueError("peer base required")
    current = cursor_get(conn, base) if since is None else int(since or 0)
    events, next_since, node = pull_events_page(base, token, current, timeout=timeout,
                                                attempts=attempts)
    events, signature_errors = peer_sign.verify_events(conn, events, allow_unsigned=allow_unsigned)
    if signature_errors:
        # verify_events 已经把不可信事件剔除，`events` 里剩下的是干净的。
        # 默认丢弃坏事件继续同步：一条无签名事件不该毁掉整轮（典型场景是
        # 自己产生的事件经对端回传，本地事件本来就没有签名）。
        # 需要严格拒绝时显式开启 TAA_PEER_REQUIRE_SIGN_STRICT=1。
        _strict = (os.environ.get("TAA_PEER_REQUIRE_SIGN_STRICT") or "").strip().lower() in (
            "1", "true", "yes", "on")
        if _strict:
            raise ValueError("peer signature rejected: " + ",".join(signature_errors[:3]))
        print(f"[peer_sync] 丢弃 {len(signature_errors)} 条签名不可信事件："
              + ",".join(signature_errors[:3]))
    accepted = log.merge(events) if log is not None else 0

    fetched = 0
    errors: list[str] = []
    missing = 0
    # 先把附件字节取回来，再落消息 —— 顺序反了就会出现"消息先到、图片 404"：
    # 前端渲染出 /app/peer-blob/<sha> 时 blob 还没落盘，一次失败就被隐藏，
    # 用户必须手动刷新才看得到（真机 2026-11-11 复现）。
    if fetch_blobs:
        for sha, item in event_blob_manifests(events).items():
            try:
                target = peer_blobs.blob_path(sha)
            except ValueError:
                errors.append("bad sha256")
                continue
            if target.is_file():
                continue
            missing += 1
            try:
                _retry(lambda s=sha: peer_blobs.fetch_blob(base, token, s, timeout=timeout),
                       attempts=attempts)
                fetched += 1
            except Exception as exc:  # noqa: BLE001 — keep syncing other blobs
                errors.append(f"{sha[:12]}: {type(exc).__name__}")

    applied = apply_events(conn, events)
    if not errors:
        cursor_set(conn, base, next_since)
    conn.commit()
    return {
        "ok": not errors,
        "peer": base,
        "node": node,
        "since": current,
        "next_since": next_since,
        "events": len(events),
        "accepted": accepted,
        "applied": applied,
        "blobs_fetched": fetched,
        "blobs_missing": missing,
        "blob_errors": errors,
    }
