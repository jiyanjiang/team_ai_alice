#!/usr/bin/env python3
"""TAA 安装引导器 —— 跨平台，只用标准库。

分工（2026-11-14 收敛）：
  - **本文件 = 编排层**：命令行 → 环境打印 → 包完整性 → 分派「首装 / 升级」。
  - **install 类逻辑全在 `taa_install_ops.py`**（六个动作共用唯一真相源）：
    解释器 / 源测速 / 布局 / venv / 依赖 / 启动 / 自检 / timings。

这样 `install.sh`、`install.ps1`、重装、修复等动作都在同一套底座上跑，
不会出现「两份代码各自演化」的漂移 —— 这是 2026-11-08 Win 冷装 1 小时事故的主要教训。

用法：
    python3 bootstrap.py [--home DIR] [--port N] [--no-browser] [--skip-deps]
                         [--source DIR] [--dry-run]
    py -3 bootstrap.py ...
"""

from __future__ import annotations

import argparse
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import taa_install_ops as ops  # noqa: E402
import taa_plat as plat  # noqa: E402

# 兼容：历史上这些名字住在本文件，外部若有 import 不应断。
Timer = ops.Timer
INDEX_CANDIDATES = ops.INDEX_CANDIDATES
DEFAULT_INDEX = ops.DEFAULT_INDEX
probe_index = ops.probe_index
pick_index = ops.pick_index
find_uv_python = ops.find_uv_python
python_hint = ops.python_hint
write_timings = ops.write_timings
_log = ops.log
_err = ops.err


def parse_args(argv: list[str]) -> tuple[argparse.Namespace, list[str]]:
    ap = argparse.ArgumentParser(prog="bootstrap.py", add_help=True,
                                 description="TAA installer (cross-platform)")
    ap.add_argument("--home", default=None, help="安装根目录（默认 ~/.taa）")
    ap.add_argument("--port", type=int, default=None, help="本地端口（默认 6080）")
    ap.add_argument("--no-browser", action="store_true", help="装完不打开浏览器")
    ap.add_argument("--skip-deps", action="store_true", help="跳过依赖安装（排障用）")
    ap.add_argument("--source", default=None, help="包根目录（默认脚本所在目录）")
    ap.add_argument("--dry-run", action="store_true", help="只打印计划，不落盘")
    # 中心 bootstrap 会把这些透传进来；包内不消费，但必须接受，不能报 unknown option
    ap.add_argument("--center", default=None)
    ap.add_argument("--ref", default=None)
    ap.add_argument("--base", default=None)
    ap.add_argument("--from", dest="from_peer", default=None)
    ap.add_argument("--key", default=None, help="已废弃（安装器不再需要 agent key）")
    args, unknown = ap.parse_known_args(argv)
    return args, unknown


def do_upgrade(src: Path, home: Path, port: int, no_browser: bool, t: ops.Timer,
               base_exe: str = "") -> int:
    """已有安装：走 taa_upgrade.py（原子替换 + 回滚），不在活目录上覆盖。

    venv 的检测/备份/重建交给 `ops.ensure_venv()`；替换与回滚仍由 taa_upgrade.py 负责。
    """
    venv = home / "venv"
    vpy = plat.venv_python(venv)
    rebuild = False
    if not venv.exists():
        _log("[upgrade] 未发现 venv，先建一个再升级")
        rebuild = True
    elif not plat.probe_python(vpy):
        _log("[upgrade] 现有 venv 不是可用的 Python 3.11+，重建后再升级")
        rebuild = True

    skip_deps = (os.environ.get("TAA_UPGRADE_SKIP_DEPS") or "").strip() == "1"
    if rebuild and skip_deps:
        _err("[upgrade] 警告：venv 要重建，却又设了 TAA_UPGRADE_SKIP_DEPS=1——")
        _err("          新 venv 里没有任何依赖，升级后的服务几乎必然起不来。")
        if sys.stdin.isatty():
            ans = input("[upgrade] 仍要继续？[y/N] ").strip().lower()
            if ans not in ("y", "yes"):
                _err("[upgrade] 已取消：去掉 TAA_UPGRADE_SKIP_DEPS 后重跑")
                return 4
        else:
            _err("[upgrade] 非交互模式下不替你做这个决定，已中止：去掉 TAA_UPGRADE_SKIP_DEPS 后重跑")
            return 4

    if rebuild:
        vout = ops.ensure_venv(home, base_exe=base_exe, timer=t)
        if vout.backup is not None:
            _log(f"[upgrade] 旧 venv 已移开：{vout.backup}")
        if not vout.ok:
            return 4
        vpy = vout.python or plat.venv_python(venv)

    _log("[upgrade] existing install detected")
    cmd = [str(vpy), str(src / "taa_upgrade.py"), "--source", str(src),
           "--home", str(home), "--port", str(port), "--python", str(vpy)]
    if no_browser:
        cmd.append("--no-open")
    st = time.time()
    rc = subprocess.run(cmd, cwd=str(src)).returncode
    t.since("upgrade", st)
    # 模板由 taa_upgrade.py 的 stage 阶段补（升级路径唯一真相源，别在这里再补一份）
    ops.write_timings(home, t, {"mode": "upgrade", "rc": rc})
    return rc


def main(argv: list[str] | None = None) -> int:
    args, unknown = parse_args(list(sys.argv[1:] if argv is None else argv))
    if unknown:
        _err(f"[warn] 忽略未知参数：{' '.join(unknown)}（中心 bootstrap 透传的新参数不应让安装失败）")

    t = ops.Timer()
    home = Path(args.home or os.environ.get("TAA_HOME") or plat.default_home())
    dest = home / "app"
    port = int(args.port or os.environ.get("TAA_HTTP_PORT") or 6080)
    src = Path(args.source or Path(__file__).resolve().parent)
    if not (src / "VERSION").exists() and (src.parent / "VERSION").exists():
        src = src.parent
    explicit_index = (os.environ.get("UV_DEFAULT_INDEX")
                      or os.environ.get("PIP_INDEX_URL") or "").strip()

    plat_name = "windows" if plat.IS_WIN else ("macos" if plat.IS_MAC else sys.platform)
    _log(f"PLATFORM={plat_name} ARCH={platform.machine()} PYTHON={platform.python_version()}")
    _log(f"TAA_HOME={home}")
    _log(f"SOURCE={src}")
    _log(f"PORT={port}")
    if plat.uv_path():
        _log(f"UV={plat.uv_path()}")
    if args.ref or os.environ.get("TAA_REF"):
        _log(f"REF={args.ref or os.environ.get('TAA_REF')}")

    incomplete = ops.check_package(src)
    if incomplete:
        _err(f"x {incomplete}")
        return 2
    if args.dry_run:
        _log("[dry-run] 将执行：复制 → venv → deps → launch → 自检（本次未落盘）")
        return 0

    ops.save_ref(home, str(args.ref or os.environ.get("TAA_REF", "")))

    # ---- 1. 找解释器 -------------------------------------------------------
    found = ops.locate_python(home, timer=t)
    if not found:
        _err("x " + ops.python_hint())
        return 3
    cmd, ver = found
    _log(f"PYTHON={cmd[0]} {ver}")
    base_exe = ops.resolve_base_exe(found)

    # ---- 2. 升级分支 -------------------------------------------------------
    if (home / "identity.json").exists() and dest.exists():
        return do_upgrade(src, home, port, args.no_browser, t, base_exe)

    # ---- 3~7. 首装（布局 → venv → 依赖 → 启动 → 自检）----------------------
    rc = ops.install(src, home, port=port, no_browser=args.no_browser,
                     skip_deps=args.skip_deps, base_exe=base_exe,
                     explicit_index=explicit_index, timer=t)
    if rc != 0:
        return rc

    _log("")
    _log(f"TAA_HOME={home}")
    _log(f"TAA_APP={dest}")
    _log(f"LOCAL_UI_URL=http://127.0.0.1:{port}/app/bridge")
    if (os.environ.get("TAA_REF") or args.ref):
        _log("NEXT=浏览器里完成认领（/setup/），--ref 会自动建立好友关系")
    return 0


if __name__ == "__main__":
    sys.exit(main())
