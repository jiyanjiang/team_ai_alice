/* 服务端渲染页（/app/*，走 app_ui.shell）的数学渲染。
 *
 * 背景（2026-11-11）：KaTeX 只挂在看板 SPA（static/index.html + board.js），
 * 而 /app/p/、/app/moments、/app/feed 是服务端 shell 渲染，页面上从来没有 KaTeX
 * → 正文里的 $\textbf{M}$ 原样显示。这个脚本补的就是这一层。
 *
 * 判定规则与 board.js 保持一致（t-d119b7d2）：
 *   单 $ 行内公式必须含「字母 / 反斜杠 / 数学符号」，否则当货币或普通文本
 *   （「价格 $5 到 $10」不能被当公式）。$$…$$ / \[…\] / \(…\) 直接认。
 */
(function () {
  "use strict";
  if (window.__taaMathLoaded) return;          // shell 可能重复注入，只跑一次
  window.__taaMathLoaded = true;

  var MATH_SIGNAL = /[A-Za-z\\^_{}=+\-*/<>|]/;
  // 这些容器里即便有 $ 也不能渲染：代码块、输入框、已经渲染好的公式
  var SKIP_SEL = "pre, code, kbd, samp, script, style, textarea, .katex, .katex-rendered";

  var RE = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$([^\n$]+?)\$/g;

  function renderTex(tex, display) {
    try {
      var span = document.createElement("span");
      span.className = "katex-rendered";
      span.innerHTML = katex.renderToString(tex, {
        displayMode: !!display,
        throwOnError: false,
        strict: false,
      });
      return span;
    } catch (e) {
      return null;                              // 渲染失败保留原文，用户仍看得到 LaTeX 源
    }
  }

  function scan(node) {
    var s = node.nodeValue;
    if (!s || (s.indexOf("$") < 0 && s.indexOf("\\(") < 0 && s.indexOf("\\[") < 0)) return;
    var out = [], last = 0, m, changed = false;
    RE.lastIndex = 0;
    while ((m = RE.exec(s)) !== null) {
      var tex, display;
      if (m[1] !== undefined) { tex = m[1]; display = true; }
      else if (m[2] !== undefined) { tex = m[2]; display = true; }
      else if (m[3] !== undefined) { tex = m[3]; display = false; }
      else { tex = m[4]; display = false; }
      if (tex === undefined) continue;
      if (display === false && m[1] === undefined && m[2] === undefined && m[3] === undefined) {
        // 单 $ 行内：必须过数学信号关，且不能跨行
        if (tex.indexOf("\n") !== -1 || !MATH_SIGNAL.test(tex)) continue;
      }
      var el = renderTex(tex, display);
      if (!el) continue;
      if (m.index > last) out.push(document.createTextNode(s.slice(last, m.index)));
      out.push(el);
      last = m.index + m[0].length;
      changed = true;
    }
    if (!changed) return;
    if (last < s.length) out.push(document.createTextNode(s.slice(last)));
    var frag = document.createDocumentFragment();
    for (var i = 0; i < out.length; i++) frag.appendChild(out[i]);
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
  }

  function walk(root) {
    if (!root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var nodes = [], n;
    while ((n = walker.nextNode())) {
      var p = n.parentNode;
      if (!p || !p.closest) continue;
      if (p.closest(SKIP_SEL)) continue;
      nodes.push(n);
    }
    for (var i = 0; i < nodes.length; i++) scan(nodes[i]);
  }

  function boot() {
    if (typeof katex === "undefined" || !katex.renderToString) return;
    walk(document.querySelector("main"));
    walk(document.getElementById("detail-scroll"));
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
