"""TAA 平台差异层 —— Windows / macOS / Linux 的差异**只允许**出现在这里。

为什么要有这一层（2026-11-08）：
1. 旧安装链把 venv 解释器写死成 `venv/bin/python`，Windows 实际是
   `venv/Scripts/python.exe` → "复用已有 venv" 恒判失败，每次安装都重建 + 重装依赖；
2. `ln -s` 在 Windows 需要开发者模式，失败后退化成整目录拷贝；
3. `sha256sum` 在 MSYS/Git Bash 下输出带反斜杠转义，字符串比较会误判；
4. 系统代理会把 `127.0.0.1` 也代理走，本地 health 探活失败；
5. `nohup` / `kill -TERM -pgid` / `ps` 在 Windows 没有对等语义。

以上五类差异全部收敛到本模块。安装器与启动器只调这里的函数，
任何其他文件里都**不得**再出现 `bin/python`、`ln -s`、`nohup` 这类平台假设。

只依赖标准库：bootstrap 在没有 venv 时就要运行，不能引入第三方包。
"""

from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path

IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"

MIN_PY = (3, 11)


# ---------------------------------------------------------------- 解释器与 venv

def venv_python(venv: Path) -> Path:
    """venv 内的解释器路径：Windows = Scripts/python.exe，其余 = bin/python。"""
    venv = Path(venv)
    return venv / "Scripts" / "python.exe" if IS_WIN else venv / "bin" / "python"


def probe_python(path: str | Path) -> str | None:
    """跑一次 `-c` 确认解释器**真的可用**且 ≥3.11，返回 "3.12" 形式；否则 None。

    为什么不能只看文件存在：Windows 上 `venv/bin/python` 可能是个残缺的 MSYS
    符号链接，`-x` 判定通过但执行直接 WinError 193（2026-11-08 Win 实测）。
    """
    return probe_python_cmd([str(path)])


def find_python(*, explicit: str | None = None, home: Path | None = None) -> tuple[list[str], str] | None:
    """按优先级找一个 ≥3.11 的解释器，返回 (命令前缀, 版本)。

    命令前缀是 list：Windows 的 `py -3` 是 launcher（两段），POSIX 是单段路径。
    """
    cands: list[list[str]] = []
    if explicit:
        cands.append([str(explicit)])
    if home:
        cands.append([str(venv_python(Path(home) / "venv"))])
    # 3.12 优先（回归基线：wheel 覆盖最全）；3.13/3.11 次之；3.14 排最后——
    # 新版本常出现"某个包还没有 wheel"，pip 会退化成源码编译（几十分钟）。
    if IS_WIN:
        cands += [["py", "-3.12"], ["py", "-3.13"], ["py", "-3.11"], ["py", "-3.14"],
                  ["py", "-3"], ["python"], ["python3"]]
    else:
        cands += [["python3.12"], ["python3.13"], ["python3.11"], ["python3.14"],
                  ["python3"], ["python"]]
    seen: set[tuple[str, ...]] = set()
    for cmd in cands:
        key = tuple(cmd)
        if key in seen:
            continue
        seen.add(key)
        ver = probe_python_cmd(cmd)
        if ver:
            return cmd, ver
    return None


def probe_python_cmd(cmd: list[str]) -> str | None:
    """同 probe_python，但接受多段命令（用于 `py -3`）。"""
    try:
        r = subprocess.run(
            cmd + ["-c", "import sys;print('%d.%d' % sys.version_info[:2])"],
            capture_output=True, text=True, errors="replace", timeout=25)
    except (OSError, subprocess.SubprocessError):
        return None
    out = (r.stdout or "").strip().splitlines()
    if r.returncode != 0 or not out:
        return None
    try:
        major, minor = (int(x) for x in out[-1].split(".")[:2])
    except (TypeError, ValueError):
        return None
    return out[-1] if (major, minor) >= MIN_PY else None


def uv_path() -> str | None:
    return shutil.which("uv")


def create_venv(venv: Path, base_py: str | None = None, *,
                python_spec: str = "3.12") -> tuple[bool, str]:
    """建 venv。有 uv 用 uv（毫秒级、可代下指定版本），否则 `python -m venv`。

    base_py 只用显式路径；launcher 形式（py -3）请传 sys.executable ——
    bootstrap 本身就跑在目标解释器上，这是最可靠的一条。
    uv 优先用 python_spec（默认 3.12：wheel 覆盖最全），没有就让 uv 自己下。
    """
    venv = Path(venv)
    py = base_py or sys.executable
    uv = uv_path()
    if uv:
        spec = py if base_py else python_spec
        r = subprocess.run([uv, "venv", "--python", spec, str(venv)],
                           capture_output=True, text=True, errors="replace")
        if r.returncode == 0:
            return True, f"uv({spec})"
        # uv 失败（离线、版本过旧、镜像缺 Python）→ 回落到标准库，不硬失败
        note = f"uv 建 venv 失败（{(r.stderr or '').strip()[:120]}），回落 venv 模块"
    else:
        note = "venv 模块"
    r = subprocess.run([py, "-m", "venv", str(venv)], capture_output=True, text=True, errors="replace")
    if r.returncode == 0:
        return True, note
    return False, f"{(r.stderr or r.stdout or '').strip()[:300]}"


def backup_venv(venv: Path) -> Path | None:
    """把不可用的 venv 移开（不删除）：重建失败时还能人肉搬回。"""
    venv = Path(venv)
    if not venv.exists():
        return None
    dst = venv.with_name(f"{venv.name}.bak.{time.strftime('%Y%m%d-%H%M%S')}")
    try:
        shutil.move(str(venv), str(dst))
        return dst
    except OSError:
        # Windows 上目录被占用时改名也可能失败：退一步用 rmtree，仍然只在真损坏时走这里
        return None


def install_deps(venv_py: Path, requirements: Path, *, index_url: str = "",
                 only_binary: bool = True, timeout: int = 1800) -> tuple[bool, str]:
    """装依赖：uv 优先；pip 兜底时强制 wheel（避免 MSVC 源码编译拖到几十分钟）。"""
    req = str(requirements)
    venv_py = str(venv_py)
    uv = uv_path()
    uv_err = ""
    if uv:
        # 2026-11-09：uv 在抖动链路上会把一次 Connect 失败放大成 3 次重试 × 超时
        # ≈ 45 秒（实测清华源 45.7s 才放弃），而紧接着的 pip 兜底只要 4.5 秒。
        # 所以把 uv 的 HTTP 超时压到 8s、重试压到 1 次，失败尽快回退 pip。
        env = dict(os.environ)
        env.setdefault("UV_HTTP_TIMEOUT", "8")
        env.setdefault("UV_HTTP_RETRIES", "1")
        cmd = [uv, "pip", "install", "--python", venv_py, "-r", req]
        if index_url:
            cmd += ["--default-index", index_url]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                               timeout=min(timeout, 600), env=env)
            if r.returncode == 0:
                return True, "uv"
            tail = (r.stderr or r.stdout or "").strip().splitlines()
            uv_err = (tail[-1] if tail else "").strip()[:200]
            print(f"[deps] uv 失败（{uv_err or ('rc=' + str(r.returncode))}），回退 pip",
                  file=sys.stderr, flush=True)
        except subprocess.TimeoutExpired:
            uv_err = "uv timeout"
            print("[deps] uv 超时，回退 pip", file=sys.stderr, flush=True)
        except Exception as exc:                                 # noqa: BLE001
            uv_err = f"{type(exc).__name__}: {exc}"[:200]
            print(f"[deps] uv 异常（{uv_err}），回退 pip", file=sys.stderr, flush=True)
    # pip 兜底：串行 + 短超时，抖动时尽快给出结论（uv 那边已经耗掉一次机会）
    cmd = [venv_py, "-m", "pip", "install", "--disable-pip-version-check",
           "--timeout", "15", "--retries", "2", "-r", req]
    if only_binary:
        cmd += ["--only-binary", ":all:"]
    if index_url:
        cmd += ["-i", index_url]
    r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout)
    if r.returncode == 0:
        return True, "pip"
    if only_binary:
        # 个别包只有 sdist：去掉强制 wheel 再试一次（仍失败才报错）
        cmd = [c for c in cmd if c != "--only-binary" and c != ":all:"]
        r2 = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout)
        if r2.returncode == 0:
            return True, "pip(sdist)"
        return False, (r2.stderr or r2.stdout or uv_err).strip()[:600]
    return False, (r.stderr or r.stdout or uv_err).strip()[:600]


# ---------------------------------------------------------------- 文件与目录

def remove_path(p: Path) -> None:
    """删文件 / 符号链接 / 目录（Windows 上目录链接要用 rmdir）。"""
    p = Path(p)
    if not p.exists() and not p.is_symlink():
        return
    if p.is_symlink() or p.is_file():
        try:
            p.unlink()
            return
        except OSError:
            pass
    shutil.rmtree(p, ignore_errors=True)


def _robocopy_cmd(src: Path, dst: Path, excludes: tuple[str, ...]) -> list[str]:
    """Windows 整包复制命令。

    `/XJ` 不是可选项（2026-11-09 Windows 验收补）：装过一遍之后 `app\\agents` 是指向
    `~\\.taa\\agents` 的 **junction**，而 `/MIR` 会把目标端多余目录删掉、并跟随 junction
    进入其内容——重装/升级时可能把真实记忆镜像甚至删掉。`/XJ` 让 robocopy 不跟随任何
    重解析点，链接原样保留，交给 `ensure_data_dirs` 用 `is_link()` 判定。
    """
    cmd = ["robocopy", str(src), str(dst), "/MIR", "/NFL", "/NDL", "/NJH", "/NJS", "/NP", "/XJ"]
    for name in excludes:
        cmd += ["/XD", str(src / name.lstrip("/"))]
    return cmd


def copy_tree(src: Path, dst: Path, *, excludes: tuple[str, ...] = ()) -> str:
    """整包复制，返回用了哪种实现（robocopy / rsync / shutil）。

    统计口径：Windows 上 robocopy 多线程复制几千个小文件比 Python 逐文件快一个量级。
    """
    src, dst = Path(src), Path(dst)
    dst.mkdir(parents=True, exist_ok=True)
    if IS_WIN and shutil.which("robocopy"):
        cmd = _robocopy_cmd(src, dst, excludes)
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
        if r.returncode <= 7:                     # robocopy: 0–7 都算成功
            return "robocopy"
    if not IS_WIN and shutil.which("rsync"):
        cmd = ["rsync", "-a"]
        for name in excludes:
            cmd.append(f"--exclude=/{name.lstrip('/')}")
        cmd += [f"{src}/", f"{dst}/"]
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
        if r.returncode == 0:
            return "rsync"
    ignore = shutil.ignore_patterns(*[n.split("/")[-1] for n in excludes], "__pycache__", "*.pyc")
    shutil.copytree(src, dst, dirs_exist_ok=True, ignore=ignore)
    return "shutil"


def link_dir(target: Path, link: Path) -> str:
    """把 link 指向 target：POSIX symlink；Windows 先 symlink 再 junction。

    junction（mklink /J）不需要管理员/开发者模式，是 Windows 上唯一"开箱可用"的
    目录链接。返回 "symlink" / "junction" / ""（失败，调用方决定降级方式）。
    """
    target, link = Path(target), Path(link)
    target.mkdir(parents=True, exist_ok=True)
    remove_path(link)
    link.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.symlink(str(target), str(link), target_is_directory=True)
        return "symlink"
    except (OSError, NotImplementedError):
        pass
    if IS_WIN:
        r = subprocess.run(["cmd", "/c", "mklink", "/J", str(link), str(target)],
                           capture_output=True, text=True, errors="replace")
        if r.returncode == 0:
            return "junction"
    return ""


DATA_DIRS = ("agents", "bootstrap", "static/uploads")

TEMPLATES_REL = "agents/_templates"

# Windows 目录重解析点（junction / symlink 共享这个属性位）
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)


def is_link(path: Path) -> bool:
    """path 是否**已经是指向别处的链接**（POSIX symlink 或 Windows junction）。

    2026-11-09 Windows 验收报告（问题 1，阻断级）：
        `Path.is_symlink()` 对 Windows **junction 返回 False**，而普通 Windows 机器
        没有符号链接特权，`link_dir` 只能退化成 junction。于是 `ensure_data_dirs`
        把 `app\\agents`（其实是 `~\\.taa\\agents` 本体）当成普通目录 copytree 到它自己，
        报 `[WinError 32] 另一个程序正在使用此文件`，`taa start` 每次必崩。
    判据改为「symlink 或 reparse point」，3.11 也成立（不依赖 3.12 的 os.path.isjunction）。
    """
    p = Path(path)
    try:
        if p.is_symlink():
            return True
    except OSError:
        pass
    try:
        st = os.lstat(p)
    except OSError:
        return False
    return bool(getattr(st, "st_file_attributes", 0) & _REPARSE_POINT)


def seed_templates(src: Path, home: Path) -> int:
    """把包里的 `agents/_templates/` 落进 `$TAA_HOME/agents/`，返回复制的文件数。

    事故（2026-11-09，rc19「已知问题」，rc20 修）：安装器整包复制时把 `agents/` 整个
    **排除**（避免把 agent 私有记忆当运行时投递），紧接着 `ensure_data_dirs` 只在 home
    建一个**空** `agents/` 再链回 app —— 发布包里的 `_templates/*.yaml` 就此丢失。
    干净机器装完在 `/setup/` 建首个 agent 时 `rng.choice([])` → IndexError，装完即不可用
    （`install_report` 的「人设模板」项也会同时变红）。

    口径：只搬 `_templates` 这一个子目录（**不含任何 agent 记忆**），同名文件覆盖
    （模板属于随包代码资产，不是用户数据）。src 是包根目录，不是已装目录——已装目录的
    `agents/` 是指向 home 的链接，从那里读等于读自己。
    """
    s = Path(src) / TEMPLATES_REL
    d = Path(home) / TEMPLATES_REL
    if not s.is_dir():
        return 0
    d.mkdir(parents=True, exist_ok=True)
    n = 0
    for f in sorted(s.iterdir()):
        if f.is_file():
            shutil.copy2(f, d / f.name)
            n += 1
    return n


def ensure_data_dirs(root: Path, home: Path) -> list[str]:
    """把 agents / bootstrap / static/uploads 收拢到 home，再链接回 app。

    链接失败时复制回去（宁可多占空间，也不要"装完起不来"），返回失败项供调用方告警。
    安装器与启动器都调这一份，避免两套逻辑漂移。

    **判据必须用 is_link()，不能用 Path.is_symlink()**：Windows junction 的
    `is_symlink()` 是 False，会把链接当成实体目录复制到它自己（见 is_link 文档）。
    """
    root, home = Path(root), Path(home)
    failed: list[str] = []
    for rel in DATA_DIRS:
        src = root / rel
        dst = home / rel
        dst.mkdir(parents=True, exist_ok=True)
        if is_link(src):
            # 已经是链接（symlink 或 junction）：只确认目标在，别碰内容。
            # 这一步同时修掉「每次 taa start 都复制自己」的反复崩。
            continue
        if src.exists() and src.is_dir():
            if any(src.iterdir()):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            shutil.rmtree(src, ignore_errors=True)
        how = link_dir(dst, src)
        if not how:
            failed.append(rel)
            shutil.copytree(dst, src, dirs_exist_ok=True)
    return failed


# ---------------------------------------------------------------- 进程

def spawn_detached(cmd: list[str], *, cwd: Path, log_path: Path, env: dict | None = None) -> int:
    """起一个脱离当前终端的子进程，返回 pid。

    这就是 `nohup ... &` 的跨平台等价物：POSIX 用新会话（可整组 kill），
    Windows 用 CREATE_NEW_PROCESS_GROUP + DETACHED_PROCESS。
    """
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    f = open(log_path, "ab", buffering=0)
    kw: dict = {"cwd": str(cwd), "stdout": f, "stderr": subprocess.STDOUT,
                "stdin": subprocess.DEVNULL, "env": env or os.environ.copy()}
    if IS_WIN:
        flags = (subprocess.CREATE_NEW_PROCESS_GROUP                    # type: ignore[attr-defined]
                 | getattr(subprocess, "DETACHED_PROCESS", 0))
        # 2026-11-11 B 端事故：DETACHED_PROCESS 只脱离控制台，不脱离**作业对象**。
        # 从 SSH 会话（sshd 会给整条命令建 job）里起的服务，会话一结束就被 job
        # 一起收走——升级 START 打完 health OK，几十秒后进程凭空消失。
        # CREATE_BREAKAWAY_FROM_JOB 才是"逃出 job"的开关；job 未允许 breakaway 时
        # 系统直接拒绝，此时回退到原 flags 而不是让启动整体失败。
        breakaway = getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0x01000000)
        try:
            p = subprocess.Popen(cmd, creationflags=flags | breakaway, **kw)   # noqa: S603
        except OSError:
            p = subprocess.Popen(cmd, creationflags=flags, **kw)               # noqa: S603
    else:
        kw["start_new_session"] = True
        p = subprocess.Popen(cmd, **kw)          # noqa: S603
    try:
        return int(p.pid)
    finally:
        # 父进程不持有句柄，子进程继续写自己的日志文件
        try:
            f.close()
        except Exception:                        # noqa: BLE001
            pass


def is_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    if IS_WIN:
        r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                           capture_output=True, text=True, errors="replace")
        return str(pid) in (r.stdout or "") and "No tasks" not in (r.stdout or "")
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def kill_tree(pid: int, *, force: bool = False) -> bool:
    """结束进程**及其子进程**：Windows `taskkill /T`，POSIX 先杀进程组。"""
    if not is_alive(pid):
        return False
    if IS_WIN:
        cmd = ["taskkill", "/PID", str(pid), "/T"]
        if force:
            cmd.append("/F")
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
        return r.returncode == 0
    try:
        pgid = os.getpgid(pid)
    except OSError:
        pgid = None
    sig = 9 if force else 15
    import signal
    try:
        if pgid and pgid != os.getpgid(0):
            os.killpg(pgid, sig if not force else signal.SIGKILL)
        else:
            os.kill(pid, sig if not force else signal.SIGKILL)
        return True
    except OSError:
        return False


def wait_port(port: int, *, timeout: float = 30.0, host: str = "127.0.0.1") -> bool:
    """等本地端口接受连接（不依赖 curl，规避 Windows 回环被代理劫持的问题）。"""
    import socket
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.2)
    return False


# ---------------------------------------------------------------- 网络与浏览器

def local_env(base: dict | None = None) -> dict:
    """给子进程用的环境：把这些名字加进 NO_PROXY，避免本地回环走系统代理。"""
    env = dict(base or os.environ.copy())
    hosts = "127.0.0.1,localhost,::1"
    for key in ("NO_PROXY", "no_proxy"):
        cur = (env.get(key) or "").strip()
        env[key] = f"{cur},{hosts}" if cur else hosts
    return env


def no_proxy_opener():
    """urllib opener：完全不使用代理（只用于访问 127.0.0.1）。"""
    import urllib.request
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def open_url(url: str) -> bool:
    try:
        if IS_WIN:
            os.startfile(url)                    # type: ignore[attr-defined]
        elif IS_MAC:
            subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:                            # noqa: BLE001
        return False


def default_home() -> Path:
    return Path(os.path.expanduser("~")) / ".taa"
